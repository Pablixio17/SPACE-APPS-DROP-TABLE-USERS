# 22035 test parameter notes

- Identificador: pdf_4fb6adf78432c3e742fc
- Investigaciones: PSI-10
- Tipo de documento: Raw Data
- Estado: processed
- Temas detectados automaticamente: oxygen, ignition, extinction, hardware, operations

## Fuentes

- [PSI-10_Raw Data_22035 test parameter notes.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-10/Raw%20Data/PSI-10_Raw%20Data_22035%20test%20parameter%20notes.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_4fb6adf78432c3e742fc, p. 1]. Metodo: windows_ocr_grid_removed.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_4fb6adf78432c3e742fc/p0001.jpg)

~~~~text
testpointName | 22035A1
dataCameraPrelgnitionExposureUs | 1000000
dataCameraTestExposureUs | 83000
analogCameraShutter | 2
uselntensifiedCamera | TRUE
intensifierGainAmplitude | 60000
preignition' mageTimeSec
postFlamelmagingTimeSec | 3
useDataCameraAut0Gain | FALSE
autoGainT01erancePercent | 5
autoGainMaxDb | 33
autoGainMinDb
auto GainOutliers
autoGainRatePercent | 100
autoGainTargetPercent | 50
rampDataCameraGain | FALSE
dataCameraGain1d3
dataCameraGain2dB
dataCameraGain3dB
dataCameraHoldTime1Sec
dataCameraH01dTime2Sec
dataCameraRamp1t02TimeSec | 5
dataCameraRamp2t03TimeSec | 5
dataCameraManuatGain | 24
useBracketedExposures | FALSE
bracketinglmagesPerExp0sure | 1
bracketingNumberOfExposures | 4
bracketingExposureStartUsec | 2000
bracketingExposureMultipiierTimes100 | 300
igniterStartPosition | 2150
igniterEndPosition | 2270
igniterVelocityCountsPerSec | 80
igniterPreheatPowerV | 3
igniterPreheatDurationMs | 1000
igniterlgnitionP0werV | 4
igniterlgnitionDurationMs | 3000
igniterDelayBeforeRetractMs | 1800
igniterRetractVelocityCountsPerSec | 500
use* gnitionDetection | TRUE
pmt1Gain | 5.5
pmt2Gain
pmt3Gain | 5.5
fiberlgnitionPosition
fiberTestPosition
fiberMoveDuringTest | FALSE
fiberSegmentDistance | 100
fiberVelocity | 3000
fiberH01dDurationSec | 1
fiberCycles | 100
useFoma | TRUE
flowTimeoutSec | 180
oxidizerFlowlgnitionDeltaMs | soo
nitrogenFlowlgnitionDeltaMs
stabilizationTime1Sec
stabilizationTime2Sec
oxidizerlgnitionFlowSlpm | 0.259
nitrogenlgnitionFlowSlpm
oxidizer TestF10w1Slpm | 0.259
nitrogenTestFlow1Slpm
oxidizerTestFlow2Slpm
nitrogenTestFlow2Slpm
oxidizerTestF10w3Slpm
nitrogenTestFlow3Slpm
constantFlowTime1Sec | 20
constantFlowTime2Sec
constantFlowTime3Sec
ignitionTOTestRampTimeSec
testFlowRamp1T02TimeSec
testF10wRamp2T03TimeSec
postExtinctionDelaySec
postExtinctionFIowChangeOxidizerPercent
postExtinctionFlowChangeNitrogenPercent
postExtinctionFlowCha ngeRampTimeSec
postExtinctionFlowChangeHOIdSec
burnerTemperatureLimitC | 450
burnerTemperatureLimitDurationSecs | 1
~~~~

### Pagina 2

Cita: [pdf_4fb6adf78432c3e742fc, p. 2]. Metodo: windows_ocr_grid_removed.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_4fb6adf78432c3e742fc/p0002.jpg)

~~~~text
testpointName | 2203581
dataCa meraPrelgnitionExposureUsl | 1000000
dataCameraTestExposureUs | 83000
analogCameraShutter | 2
uselntensifiedCamera | TRUE
intensifierGainAmplitude | 60000
prelgnitionlmageTimeSec
postFla melmagingTimeSec | 3
useDataCameraAut0Gain | FALSE
autoGainT01erancePercent | 5
autoGainMaxDb | 33
autoGainMinDb
autoGainOutliers
autoGainRatePercent | 100
autoGainTargetPercent | 50
rampDataCameraGain | FALSE
dataCameraGain1dB
dataCameraGain2dB
dataCameraGain3dB
dataCameraHoldT1me1Sec
dataCameraHoldTime2Sec
dataCameraRamp1t02TimeSec | 5
dataCameraRamp2t03TimeSec | 5
dataCameraManualGain
useBracketedExposures | TRUE
bracketinglmagesPerExposure | 1
bracketingNumberOfExposures | 4
bracketingExposureStartUsec | 2000
bracketingExposureMultiplierTimes100 | 300
igniterStartPosition | 2150
igniterEndPosition | 2270
igniterVeIocityCountsPerSec | 80
igniterPreheatPowerV | 3
igniterPreheatDurationMs | 1000
igniterlgnitionPowerV | 4
igniterlgnitionDurationMs | 3000
igniterDelayBeforeRetractMs | 1800
igniterRetractVelocityCountsPerSec | 500
uselgnitionDetection | TRUE
pmt1Gain | 5.5
pmt2Gain | 5
pmt3Gain | 5
fiberlgnitionPosition | '10000
fiberTestPosition | 15700
fiberM0veDuringTest | FALSE
fiberSegmentDistance | 100
fiberVelocity | 3000
fiberH01dDurationSec | 1
fiberCycles | 100
useFoma | TRUE
flowTimeoutSec | 180
oxidizerFlowlgnitionDeltaMs
nitrogenF10wlgniti0nDeltaMs
stabilizationTime1Sec
sta bilizationTime2Sec
oxidizerlgnitionFlowSlpm | 0.259
nitrogenlgnitionFlowSlpm
oxidizerTestF10w1Slpm | 0.259
nitrogenTestFlow1Slpm
oxidizerTestFlow2Slpm
nitrogenTestFlow2Slpm
oxidizer TestFlOw3Slpm
nitrogenTestF10w3Slpm
constantFlowTime1Sec | 20
constantFlowTime2Sec
constantFlowTime3Sec
ignitionTOTestRampTimeSec
testFlowRamp1T02TimeSec
testFlowRamp2T03TimeSeC
postExtinctionDelaySec
postExtinctionF10wChangeOxidizerpercent
postExtinctionFlowChangeNitrogenPercent
postExtinctionFlowChangeRampTimeSec
postExtinctionF10wChangeH01dSec
burnerTemperatureLimitC | 450
burner TemperatureLimitDurationSecs | 1
~~~~

### Pagina 3

Cita: [pdf_4fb6adf78432c3e742fc, p. 3]. Metodo: windows_ocr_grid_removed.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_4fb6adf78432c3e742fc/p0003.jpg)

~~~~text
testpointName | 22035C1
dataCameraPrelgnitionExposureUs | 1000000
dataCameraTestExposureUs | 83000
analogCameraShutter | 2
uselntensifiedCamera | TRUE
intensifierGainAmplitude | 60000
prelgnitionlmageTimeSec
postFlamelmagingTmeSec | 3
useDataCameraAutoGain | FALSE
autoGainTolerancePercent | 5
autoGainMaxDb | 33
autoGainMinDb
autoGainOutliers
autoGainRatePercent | 100
autoGainTargetPercent | 50
rampDataCameraGain | FALSE
dataCameraGain1dB
dataCameraGain2dB
dataCameraGain3dB
dataCameraH01dTime1Sec
dataCa meraH01dTime2Sec
dataCameraRamp1t02TimeSec | 5
dataCameraRamp2t03TimeSec | 5
dataCameraManualGain
useBracketedExposures | STRUE
bracketinglmagesPerExposure | 1
bracketingNumberOfExposures | 4
bracketingExposureStartUsec | 2000
bracketingExposureMultiplierTimes100 | 300
igniterStartPosition | 2150
igniterEndPosition | 2270
igniterVelociWCountsPerSec | 80
igniterPreheatPowerV | 3
igniterPreheatDurationMs | 1000
igniterlgnitionPowerV | 4
igniterlgnitionDurationMs | 3000
igniterDelayBeforeRetractMs | 1800
igniterRetractVelocityCountsPerSec | 500
uselgnitionDetection | TRUE
pmt1Gain | 5.5
pmt2Gain | 5
pmt3Gain
fiberlgnitionPosition | 10000
fiberTestPosition | 15700
fiberMoveDuringTest | FALSE
fiberSegmentDistance | 100
fiberVelocity | 3000
fiberH01dDurationSec | 1
fiberCycles | 100
useFoma | TRUE
flowTimeoutSec | 180
oxidizerF10wlgnitionDeltaMs
nitrogenFlowlgnitionDeltaMs
stabilizationTime1Sec
stabilizationTime2Sec | 3
oxidizerlgnitionFlowSlpm | 0.224
nitrogenlgnitionFlowSlpm | 00±0.12
oxidizerTestFlow1Slpm | 0.224
nitrogenTestFlow1Slpm | 12
OxidizerTestFlow2Slpm
nitrogenTestFlow2Slpm
oxidizerTestFlow3Slpm
nitrogenTestFlow3Slpm
constantFlowTime1Sec | 15
constantFlowTime2Sec
constantFlowTime3Sec
ignitionToTestRampTimeSec
testFlowRamp1T02TimeSec
testFlowRamp2T03TimeSec
postExtinctionDelaySec
postExtinctionFlowChangeOxidizerPercent
postExtinctionFlowChangeNitrogenPercent
postExtinCtionF lowChangeRa mpTimeSec
postExtinctionFlowChangeHoldSec
burnerTemperatureLimitC | 450
burner TemperatureLimitDurationSecs | 1
~~~~

### Pagina 4

Cita: [pdf_4fb6adf78432c3e742fc, p. 4]. Metodo: windows_ocr_grid_removed.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_4fb6adf78432c3e742fc/p0004.jpg)

~~~~text
testpointNamel | 22035D1
dataCameraPrelgnitionExposureUsl | 1000000
dataCameraTestExposureUs | 83000
analogCameraShutter | 2
uselntensifiedCamera | TRUE
intensifierGainAmplitude | 60000
prelgnitionlmageTimeSec
postFlamelmagingTimeSec | 3
useDataCameraAutoGain | FALSE
autoGainTolerancePercent | 5
autoGainMaxDb | 33
autoGainMinDb
autoGainOutliers
autoGainRatePercent | 100
autoGainTargetPercent | 50
rampDataCameraGain | FALSE
dataCameraGain1dB
dataCameraGain2dB
dataCameraGain3dB
dataCameraH01dTime1Sec
dataCa meraHoldTime2Sec
dataCameraRamp1t02TimeSec | 5
dataCa meraRamp2t03TimeSec | 5
dataCameraManualGain
useBracketedExposures | tÄRUE
bracketingtmagesPerExposure | 1
bracketingNumberOfExposureS | 4
bracketingExposureStartUsec | 2000
bracketingExposureMu ItiplierTimeSIOO | 300
igniterStartPosition | 2150
igniterEndPosition | 2270
igniterVelocityCountsPerSec | 80
igniterPreheatPowerV | 3
igniterPreheatDurationMs | 1000
igniterlgniti0nPowerV | 4
igniterlgnitionDurationMs | 3000
igniterDelayBeforeRetractMs | 1800
igniterRetractVelocityCou ntsPerSec | 500
uselgnitionDetection | TRUE
pmt1Gain | 5.5
pmt2Gain | 5
pmt3Gain | 5
fiberlgnitionPosition | 10000
fiberTestPosition | .15700 | 15600
fiberMoveDuringTest | FALSE
fiberSegmentDistance | 100
fiberVelocity | 3000
fiberHoIdDurationSec | 1
fiberCycles | 100
useFoma | TRUE
flowTimeoutSec | 180
oxidizerFlowlgnitionDeltaMs
nitrogenF10wlgnitiOnDeltaMs
stabilizationTime1Sec
stabilizationTime2Sec
oxidizer'gnitionFlowSlpm | 0.207
nitrogenlgnitionFlowSlpm | JO.186
Oxidizer TestFlow1Slpm | 0.207
nitrogenTestF10w1Slpm | 0.186
Oxidizer TestFlow2Slpm
nitrogenTestFlow2Slpm
oxidizer TestFlow3Slpm
nitrogenTestFlOw3Slpm
consta ntFlowTime 1 Sec | 15
consta ntFlowTime2Sec
constantFlowTime3Sec
ignitionTOTestRampTimeSec
testFlowRamp1T02TimeSec
testF10wRamp2T03TimeSec
postExtinctionDelaySec
postExtinctionFlowChangeOxidizerPercent
postExtinctionFlowChangeNitrogenPercent
postExtinctionFlOwChangeRampTimeSec
postExtinctionFlowChangeH0 ldSec
burnerTemperatureLimitC | 450
burnerTemperatureLimitDurationSecS | 1
~~~~

### Pagina 5

Cita: [pdf_4fb6adf78432c3e742fc, p. 5]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_4fb6adf78432c3e742fc/p0005.jpg)

~~~~text
testpointName | 22035F1
dataCameraPrelgnitionExposureUs | 1000000
dataCameraTestExposureUs | 83000
analogCameraShutter | 2
use IntensifiedCamera | TRUE
intensifierGainAmplitud | 60000
prelgnitionlmageTimeSe
postFlamelmagingTimeSec
use Data CameraAutoGain | FALSE
autoGainT01erancePercent
autoGainMaxDb | 33
autoGainMinDb
autoGainOutliers
autoGainRatePerCent | 100
autoGainTargetPercen | 50
rampDataCameraGain | FALSE
dataCameraGain1dB
dataCameraGain2dB
dataCameraGain3dB
dataCameraH01dTime1Sec
dataCameraHoldTime2Se
dataCa meraRa mp1t02TimeSe
dataCameraRamp2t03TimeSe
dataCameraManualGain
useBracketedExposures | TRUE
bracketinglmagesPerExposure
bracketingNumberOfExposures
bracketingExposureStartUse | 2000
bracketingExposureMultiplierTimes100 | 300
igniterStartPosition | 2150
igniterEndPOsition | 2270
igniterVelocityCountsPerSec | 80
igniterPreheatPowerV
igniterPreheatDurationMs | 1000
igniterlgnitionPowe
igniterlgnitionDurati0nMs | 3000
ign iterDelayBeforeRetractMs | 1800
igniterRetractVelocityCountsPerSec | 500
uselgniti0nDetectio | TRUE
pmt1Gain | 5.5
pmt2Gain
pmt3Gain
fiberlgnitionPositi0n | 10000
fiberTestPosition | 15700
fiberMoveDuringTest | FALSE
fiberSegmentDistanCe | 100
fiberVelocity | 3000
fiberHoldDurationSe
fiberCycles | 100
useFoma | TRUE
flowTimeoutSec | 180
oxidizerFlowlgnitionDeltaMs | 300
nitrogenFlowlgnitionDeltaMs
stabilizationT1me1Se
sta bilizationTime2Se
oxidizerlgnitionFIowSlpm | 0.189
nitrogenlgnitionFlowSlpm | 0.256
oxidizer TestFlow1Slpm | 0.189
nitrogenTestFlow1Slpm | 0256
oxidizerTestFlow2Slpm
nitrogenTestFlow2Slpm
oxidizerTestFiow3Slp
nitrogenTestFlow3Slpm
constantF10wTime1Sec | 15
constantFlowTime2Sec
constantFlowTime3Sec
ignitionToTestRampTimeSec
testF10wRamp1T02T1meSec
testFlOwRamp2T03TimeSec
postExtinctionDelaySe
postExtinctionF10wChangeOxidizerPercen
postExtinctionFlowChangeNitrogenpercent
postExtinctionFlowChangeRampTimeSec
postExtinctionFlowChangeHoidSe
burner TemperatureLimitC | 450
burner TemperatureLimitDurationSecs
~~~~

### Pagina 6

Cita: [pdf_4fb6adf78432c3e742fc, p. 6]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_4fb6adf78432c3e742fc/p0006.jpg)

~~~~text
testpointName | 22035G1
dataCameraPrelgnitionExposureUs | 1000000
dataCameraTestExposureUs | 83000
analogCameraShutter
use! ntensifiedCamera | TRUE
intensifierGainAmplitud | 60000
prelgnitionlmageTimeSec
postFlamelmagingTimeSec | 3
useDataCameraAut0Gain | FALSE
autoGainT01erancePercent | 5
autoGainMaxDb | 33
autoGainMinDb
autoGainOutliers
autoGainRatePercen | 100
autoGainTargetPercent | 50
rampDataCameraGain | FALSE
dataCameraGain1dB
dataCameraGain2dB | 0
dataCameraGain3dB
dataCameraHoldTime1Sec
dataCameraHoldTime2Se
data Camera Ramplt02TimeSe
dataCameraRamp2t03TimeSec | 5
dataCameraManualGain
useBracketedExposures | TRUE
bracketinglmagesPerExp0sure
bracketingNumberOfExposures
bracketingExposureStartUsec | 2000
bracketingExposureMultiplierTimes100 | 300
igniterStartPosition | 2150
igniterEndPosition | 2270
igniterVelocityCountsPerSec | 80
igniterPreheatPowerV
igniterPreheatDurationMs | 1000
igniterlgnitionPowerV | 4
igniterlgnitionDurationMs | 3000
igniterDelayBeforeRetractMs | 1800
igniterRetractVelocityCountsPerSec | 500
uselgnitionDetection | TRUE
pmt1Gain | 5.5
pmt2Gain
pmt3Gain
fiberlgnitionPosition | 10000
fiberTestPosition | 15700
fiberMoveDuringTes | FALSE
fiberSegmentDistanc | 100
fiberVelocit | 3000
fiberHoldDurationSe
fiberCycles | 100
useFoma | TRUE
flowTimeoutSec | 180
oxidizerFlowlgnitionDeltaM | 300
nitrogenF10wlgnitionDeltaM
stabilizationTime1Se
stabilizationTime2Se
oxidizerlgnitionFlowSlpm | 0.172
nitrogenlgniti0nFlowSlpm | 0.333
oxidizerTestF10w1Slpm | 0.172
nitrogenTestFlow1Slpm | 0.333
oxidizerTestFlow2Slpm
nitrogenTestFlow2Slpm
oxidizerTestFlow3Slpm
nitrogenTestFlow3Slpm
consta ntFlowTime1Se | 15
constantFlowTime2Se
consta ntF lowTime3Sec
ignitionTOTestRampTimeSec
testFlowRamp1T02TimeSec
testFlowRamp2T03TimeSec
postExtinctionDelaySe
postExtinctionFlOwChangeOxidizerPercen
postExtinctionFlowChangeNitrogenPercen
postExtinctionFlowChangeRa mpTimeSe
postExtincti0nF10wChangeH01dSe
burnerTemperatureLimit | 450
burnerTemperatureLimitDurationSec
IZ7cr-3
~~~~

### Pagina 7

Cita: [pdf_4fb6adf78432c3e742fc, p. 7]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_4fb6adf78432c3e742fc/p0007.jpg)

~~~~text
22035H1 | testpointName
1000000 | datacameraPrelgnitionExposureUs
83000 | dataCameraTestExposureUs
analogCameraShutter
TRUE | uselntensifiedCamera
60000 | intensifierGainAmplitude
prelgnitionlmageTimeSec
postFlamelmagingTimeSec
FALSE | useDataCameraAutoGain
autoGainT01erancePercent
33 | autOGainMaxDb
autoGainMinDb
autoGainOutliers
100 | autoGainRatePercent
50 | autoGainTargetPercent
FALSE | rampDataCameraGain
dataCameraGain1dB
dataCameraGain2dB
dataCameraGain3dB
dataCameraH01dTime1Sec
dataCameraH01dTime2Sec
dataCameraRamp1t02TimeSec
dataCameraRamp2t03TimeSec
dataCameraManualGain
TRUE | useBracketedExposures
bracketinglmagesPerExposure
bracketingNumberOfExposures
2000 | bracketingExposureStartUsec
300 | bracketingExposureMultiplierTimes100
2150 | igniterStartPosition
2270 | igniterEndPosition
80 | igniterVelociwCountsPerSec
igniterPreheatPowerV
1000 | igniterPreheatDurationMs
igniterlgniti0nPowerV
3000 | igniterlgnitionDurationMs
1800 | igniterDelayBeforeRetractMs
500 | igniterRetractVelocityCountsPerSec
TRUE | uselgnitionDetection
5.5 | pmt1Gain
pmt2Gain
pmt3Gain
10000 | fiberlgnitionPosition
15700 | fiberTestPosition
FALSE | fiberMoveDuringTest
100 | fiberSegmentDistance
3000 | fiberVelocity
fiberHoldDurationSec
100 | fiberCycles
TRUE | useFoma
180 | flowTimeoutSec
•300 | oxidizerFlowtgnitionDeltaMs
nitrogenFtowlgnitionDeltaMs
stabilizationTime1Sec
stabilizationTlme2Sec
0.112 | oxidizerlgnitionFlowSlpm
0.102 | nitrogenlgnitionFlowSlpm
0.112 | oxidizerTestFlow1Slpm
0.102 | nitrogenTestFlow1Slpm
oxidizerTestFlow2Slpm
nitrogenTestFiow2Slpm
oxidizerTestFlow3Slpm
nitrogenTestF10w3Slpm
120 | constantF10wTime1Sec
constantF10wTime2Sec
constantFlowTime3SeC
ignitionToTestRampTimeSec
testFlowRamp1T02TimeSec
testFlowRamp2T03TimeSec
postExtinctionDelaySec
postExtinctionFlowChangeOxidizerPercent
postExtinctionHowChangeNitrogenPercent
postExtinctionHowChangeRampTimeSec
postExtinctionF10wChangeHoldSec
500 | burnerTemperatureLimitC
burnerTemperatureLimitDurationSecs
~~~~

### Pagina 8

Cita: [pdf_4fb6adf78432c3e742fc, p. 8]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_4fb6adf78432c3e742fc/p0008.jpg)

~~~~text
22035J1 | testpointName
1000000 | dataCameraPrelgniti0nExposureUs
83000 | dataCameraTestExposureUs
2 | ana logCameraShutter
TRUE | use' ntensifiedCamera
60000 | intensifierGainAmplitude
prelgnitionlmageTimeSec
postFlamelmagingTimeSec
FALSE | useDataCameraAutoGain
autoGainT01erancePercent
33 | autoGainMaxDb
autoGainMinDb
autoGainOutliers
100 | autoGainRatePercent
50 | autoGainTargetPercent
FALSE | rampDataCameraGain
dataCameraGain1dB
dataCameraGain2dB
dataCameraGain3dB
dataCameraHoldTime1Sec
dataCameraHoldTime2Sec
dataCameraRamp1t02TimeSec
dataCameraRamp2t03TimeSec
dataCameraManualGain
TRUE | useBracketedExposures
bracketing'magesPerExposure
bracketingNumberOfExposures
2000 | bracketingExposureStartusec
300 | bracketingExposureMultiplierTimes100
2150 | igniterStartPosition
2270 | igniterEndPosition
80 | igniterVelocityCountsPerSec
igniterPreheatPowerV
1000 | igniterPreheatDurationMs
4 | igniterlgnitionP0werV
3000 | igniterlgnitionDurationMs
1800 | igniterDelayBeforeRetractMs
500 | igniter RetractVelocityCountsPerSec
TRUE | uselgnitionDetection
5 | pmt1Gain
pmt2Gain
pmt3Gain
10000 | D | fiberignitionPosition
15700 | fiberTestPosition
FALSE | fiberM0veDuringTest
100 | fiberSegmentDistance
3000 | fiberVelocity
fiberHofdDurationSec
100 | fiberCycles
TRUE | useFoma
180 | flowTimeoutSec
300 | oxidizerFlowlgnitionDeltaMs
nitrogenFlowlgnitionDeltaMs
stabilizationTime1Sec
sta bilizationTime2Sec
eo.å72 | oxidizedgnitionFlowSlpm
nitrogentgnitionFIowSlpm
0.172 | oxidizerTestFlow1Slpm
nitrogenTestFlOw1Slpm
oxidizer TestFlow2Slpm
nitrogenTestFlow2Slpm
oxidizerTestFlow3Slpm
nitrogenTestFlow3Slpm
120 | constantFlowTime1Sec
constantFlowTime2Sec
constantFlowTime3Sec
ignitionTOTestRampTimeSec
testF10wRamp1T02TimeSec
testFlowRamp2T03TimeSec
postExtinctionDelaySec
postExtinctionFlowChangeOxidizerPercent
postExtinctionFlOwChangeNitrogenPercent
postExtinctionFlowChangeRampTimeSec
postExtincti0nFlowChangeHoldSec
450 | burnerTemperatureLimitC
burner TemperatureLimitDurationSecs
13 | 46cC)
)
~~~~

### Pagina 9

Cita: [pdf_4fb6adf78432c3e742fc, p. 9]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_4fb6adf78432c3e742fc/p0009.jpg)

~~~~text
2203531 | testpointName
1000000 | dataCameraPrelgnitionExposureUs
83000 | dataCameraTestExposureUs
analogCameraShutter
TRUE | uselntensifiedCamera
60000 | intensifierGainAmplitude
preignitionlmageTimeSec
postFlamelmagingTimeSec
FALSE | useDataCameraAutoGain
autoGainTOIerancePercent
33 | autoGainMaxDb
autoGainMinDb
autoGainOutliers
100 | autoGainRatePercent
50 | autoGainTargetPercent
FALSE | rampDataCameraGain
dataCameraGain1dB
dataCameraGain2dB
dataCameraGain3dB
dataCameraHoidTime1Sec
dataCameraHoldTime2Sec
dataCameraRamp1t02TimeSec
dataCameraRamp2t03TimeSec
dataCameraManualGain
TRUE | useBracketedExposures
1 | bracketinglmagesPerExposure
bracketingNumberOfExposures
2000 | bracketingExposureStartUsec
300 | bracketingExposureMultiplierTimes100
2150 | igniterStartPosition
2270 | igniterEndPosition
80 | igniterVelocityCountsPerSec
3 | igniterPreheatPowerV
1000 | igniterPreheatDurationMs
igniterlgnitionPowerV
3000 | igmterlgnitionDurationMs
1800 | igniterDelayBeforeRetractMs
500 | igniterRetractVelocityCountsPerSec
TRUE | uselgnitionDetection
pmt1Gain
pmt2Gain
pmt3Gain
10000 | fiberlgnitionPosition
15700 | fiberTestPosition
FALSE | fiberMoveDuringTest
100 | fiberSegmentDistance
3000 | fiberVeIocity
fiberH01dDurationSec
100 | fiberCycles
TRUE | useFoma
180 | flowTimeoutSec
300 | oxidizerFlowlgnitionDeltaMs
nitrogenFtowlgnitionDeltaMs
stabilizationTime1Sec
stabilizationTime2Sec
.172 | oxidizerlgnitionFlowSlpm
nitrogenlgnitionFlowSlpm
0.17 | oxidizerTestFlow1Slpm
nitrogenTestFlow1Slpm
oxidizerTestFlow2Slpm
nitrogenTestFlow2Slpm
o | oxidizerTestFlow3Slpm
nitrogenTestFlow3Slpm
120 | constantFlowTime1Sec
constantFlowTime2Sec
constantFlowTime3Sec
ignitionToTestRampTimeSec
testFlowRamp1T02TimeSec
testFlowRamp2T03TimeSec
postExtinctionDelaySec
postExtinctionFlowChangeOxidizerPercent
postExtinctionFlowChangeNitrogenPercent
postExtinctionF10wChangeRampTimeSec
postExtinctionFlowChangeHoldSec
4SO | burnerTemperatureLimitC
1 | burnerTemperatureLimitDurationSecs
13750
~~~~

### Pagina 10

Cita: [pdf_4fb6adf78432c3e742fc, p. 10]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_4fb6adf78432c3e742fc/p0010.jpg)

~~~~text
22035K1 | testpointName
1000000 | dataCameraPrelgnitionExposureUS
83000 | dataCameraTestExposureUs
analogCameraShutter
TRUE | uselntensifiedCamera
60000 | intensifierGainAmplitude
preignitionlmageTimeSec
postFlamelmagingTimeSec
FALSE | useDataCameraAut0Gain
5 | autoGainTolerancePercent
33 | autoGainMaxDb
autoGainMinDb
autoGainOutliers
100 | autoGainRatePercent
50 | autoGainTargetPercent
FALSE | rampDataCameraGain
dataCameraGain1d8
dataCameraGain2dB
dataCameraGain3dB
dataCameraHoldTime1Sec
dataCameraHoldTime2Sec
dataCameraRamp1t02TimeSec
dataCameraRamp2t03TimeSec
dataCameraManualGain
TRUE | useBracketedExposures
bracketinglmagesPerExposure
bracketingNumberOfExposures
2000 | bracketingExposureStartUsec
300 | bracketingExposureMultiplierTimes100
2150 | igniterStartPosition
2270 | igniterEndPosition
80 | igniterVelocityCountsPerSec
igniterPreheatPowerV
1000 | igniterPreheatDurationMs
igniterlgnitionP0werV
3000 | igniterlgnitionDurationMs
1800 | igniterDelayBeforeRetractMs
500 | igniterRetractVelocityCountsPerSec
TRUE | uselgnitionDetection
pmt1Gain
pmt2Gain
pmt3Gain
10000 | fiberlgnitionPosition
15700 | fiberTestPosition
FALSE | fiberMoveDuringTest
100 | fiberSegmentDistance
3000 | fiberVelocity
fiberHoldDurationSec
100 | fiberCycles
TRUE | useFoma
180 | flowTimeoutSec
oxidizerFlowlgnitionDeltaMs
nitrogenFlowlgnitionDeltaMs
stabilizationT1me1Sec
StabilizationTme2Sec
'0.172 | oxidizerlgnitionFlowSlpm
0.13 | nitrogenlgnitionFlowSlpm
0.172 | oxidizerTestFlow1Slpm
0.13 | nitrogenTestFlow1Slpm
oxidizerTestFlow2Slpm
nitrogenTestFlow2Slpm
oxidizerTestFlow3Slpm
nitrogenTestFlow3Slpm
120 | ConstantFlowTime1Sec
constantFlowTime2Sec
constantFlowTime3Sec
ignitionToTestRampTimeSec
testFlowRamp1T02TimeSec
testFlowRamp2T03TimeSec
postExtinctionDelaySec
postExtinctionFlowChangeOxidizerPercent
postExtinctionF10wChangeNitrogenPercent
postExtinctionFlowChangeRampTimeSec
postExtinctionF10wChangeHoldSec
burnerTemperatureLimitC
burnerTemperatureLimitDurationSecs
~~~~

### Pagina 11

Cita: [pdf_4fb6adf78432c3e742fc, p. 11]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_4fb6adf78432c3e742fc/p0011.jpg)

~~~~text
22035L1 | testpointName
1000000 | dataCameraPrelgnitionExposureUs
83000 | dataCameraTestExposureUs
2 | analogCameraShutter
TRUE | uselntensifiedCamera
60000 | intensifierGainAmplitude
preignitionlmageTimeSec
postFlamelmagingTimeSec
FALSE | useDataCameraAutoGain
autoGainTolerancePercent
33 | autoGainMaxDb
autoGainMinDb
autoGainOutliers
100 | autoGainRatePercent
50 | autoGainTargetPercent
FALSE | rampDataCameraGain
dataCameraGain1dB
dataCameraGain2dB
dataCameraGain3dB
dataCameraH01dTime1Sec
dataCameraHoldTime2Sec
dataCameraRamp1t02TimeSec
dataCameraRamp2t03TimeSec
dataCameraManualGain
TRUE | useBracketedExposures
bracketinglmagesPerExposure
bracketingNumberOfExp0sures
2000 | bracketingExposureStartUsec
300 | bracketingExposureMultiplierTimes100
2150 | igniterStartPosition
2270 | igniterEndPosition
80 | igniterVelocityC0untsPerSec
3 | igniterPreheatPowerV
1000 | igniterPreheatDurationMs
igniterlgnitionPowerV
3000 | igniterlgnitionDurationMs
1800 | igniterDelayBeforeRetractMs
500 | igniterRetractVelocityCountsPerSec
TRUE | uselgnitionDetection
pmt1Gain
pmt2Gain
4 | pmt3Gain
10000 | fiberlgnitionPosition
15700 | fiberTestPosition
FALSE | fiberMoveDuringTest
100 | fiberSegmentDistance
3000 | fiberVelocity
1 | fiberH01dDurationSec
100 | fiberCycles
TRUE | useFoma
180 | flowTimeoutSec
300 | oxidizerFiowlgnitionDeltaMs
nitrogenFlowlgnitionDeltaMs
stabilizationTime1Sec
stabilizationTime2Sec
oxidizerlgnitionFlowSlpm
0.29 | nitrogenlgnitionFlowSlpm
0.172 | oxidizerTestFlow1Slpm
0.29 | nitrogenTestFlow1Slpm
oxidizerTestFlow2Slpm
nitrogenTestF10w2Slpm
oxidizerTestFlow3Slpm
nitrogenTestFlow3Slpm
120 | constantFlowTime1Sec
constantF10wTime2Sec
constantFlowTime3Sec
ignitionToTestRampTimeSec
testFlowRamp1T02TimeSec
testFlowRamp2T03TimeSec
postExtinctionDelaySec
postExtinctionFlowChangeOxidizerPercent
postExtinctionFlowChangeNitrogenPercent
postExtinctionF10wChangeRampTimeSec
postExtinctionFlowChangeHoldSec
450 | burner TemperatureLimitC
burnerTemperatureLimitDurationSecs
~~~~

### Pagina 12

Cita: [pdf_4fb6adf78432c3e742fc, p. 12]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_4fb6adf78432c3e742fc/p0012.jpg)

~~~~text
2203SM1 | testpointName
1000000 | dataCameraPrelgnitionExposureUs
83000 | data CameraTestExposureUs
analogCameraShutter
TRUE | uselntensifiedCamera
60000 | intensifierGainAmplitude
prelgnitionlmageTimeSec
postFlamelmagingTimeSec
FALSE | useDataCameraAut0Gain
autoGainTolerancePercent
33 | autoGainMaxDb
autoGainMinDb
autoGainOutliers
100 | autoGainRatePercent
50 | autoGainTargetPercent
FALSE | rampDataCameraGain
dataCameraGain1dB
dataCameraGain2dB
dataCameraGain3dB
dataCameraH01dTime1Sec
dataCameraH01dTime2Sec
dataCameraRamp1t02TimeSec
dataCameraRamp2t03TimeSec
dataCameraManualGain
TRUE | useBracketedExposures
bracketinglmagesPerExposure
bracketingNumberOfExposures
2000 | bracketingExposureStartUsec
300 | bracketingExposureMultiplierTimes100
2150 | igniterStartPosition
2270 | igniterEndPosition
80 | igniterVelocityCountsPerSec
igniterPreheatP0werV
1000 | igniterPreheatDurationMs
igniterlgnitionPowerV
3000 | igniterlgnitionDurationMs
1800 | igniterDelayBef0reRetractMs
500 | igniterRetractVelocityCountsPerSec
TRUE | uselgnitionDetection
pmt1Gain
pmt2Gain
pmt3Gain
10000 | fiberlgnitionPOsition
15700 | fiber TestPosition
FALSE | fiberMoveDuringTest
100 | fiberSegmentDistance
3000 | fiberVelocity
fiberH01dDurationSec
100 | fiberCycles
TRUE | useFoma
180 | flowTimeoutSec
300 | oxidizerFlowlgnitionDeltaMs
nitrogenFlowlgnitionDeltaMs
stabilization TimelSec
stabilizationTime2Sec
0.3 | oxidizerlgnitionF10wSlpm
0.241 | nitrogenlgnitionFlowSlpm
0.3 | oxidizerTestFlow1Slpm
0.241 | nitrogenTestFlow1Slpm
oxidizerTestFlow2Slpm
nitrogenTestFlOw2Slpm
oxidizerTestF10w3Slpm
nitrogenTestFlow3Slpm
120 | constantFiowTime1Sec
consta ntF10wTime2Sec
consta ntFlowTime3Sec
ignitionTOTestRampTimeSec
testFlowRamp1T02TimeSec
testFlowRamp2T03TimeSec
postExtinctionDelaySec
postExtinctionFlowChangeOxidizerPercent
postExtinctionFiowChangeNitrogenPercent
postExtinctionFlowChangeRampTimeSec
postExtinctionFlowChangeH01dSec
450 | burnerTemperatureLimitC
burner TemperatureLimitDurati0nSecs
~~~~

### Pagina 13

Cita: [pdf_4fb6adf78432c3e742fc, p. 13]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_4fb6adf78432c3e742fc/p0013.jpg)

~~~~text
22035N1 | testpointName
1000000 | dataCameraPrelgnitionExposureUs
100000 | dataCameraTestExposureUs
2 | analogCameraShutter
TRUE | uselntensifiedCamera
60000 | intensifierGainAmplitude
o | prelgnitionlmageTimeSec
3 | postFlamelmagingTimeSec
FALSE | useDataCameraAutoGain
5 | autoGainT01erancePercent
33 | autoGainMaxDb
o | autoGainMinDb
autoGainOutliers
100 | autoGainRatePercent
50 | autoGainTargetPercent
FALSE | rampDataCameraGain
o | dataCameraGain1dB
o | dataCameraGain2dB
o | dataCameraGain3dB
o | dataCameraHoldTime1Sec
o | dataCameraHoldTime2Sec
dataCameraRamp1t02TimeSec
5 | dataCameraRamp2t03TimeSec
26 | dataCameraManualGain
FALSE | useBracketedExposures
1 | bracketinglmagesPerExposure
4 | bracketingNumberOfExposures
2000 | bracketingExposureStartUsec
300 | bracketingExpOSureMultiplierTimes100
2150 | igniterStartPosition
2270 | igniterEndPositi0n
80 | igniterVelocityCountsPerSec
3 | igniterPreheatPowerV
1000 | igniterPreheatDurationMs
4 | igniterlgnitionPowerV
3000 | igniterlgnitionDurationMs
1800 | igniterDelayBeforeRetractMs
soo | igniterRetractVe10cityCountsPerSec
TRUE | uselgnitionDetection
pmt1Gain
4 | pmt2Gain
4 | pmt3Gain
o | fiberlgnitionPosition
o | fiberTestPosition
FALSE | fiberM0veDuringTest
100 | fiberSegmentDistance
3000 | fiberVeIocity
1 | fiberHoldDurationSec
100 | fiberCycles
TRUE | useFoma
180 | flowTimeoutSec
oxidizerFlowlgnitionDeltaMs
o | nitrogenF10wlgnitionDeltaMs
o | stabilizationTime1Sec
stabilizationTime2Sec
0.3 | oxidizer!gnitionFlowSlpm
0.241 | nitrogenlgnitionFlowSlpm
0.3 | oxidizer TestFlOw1Slpm
0.241 | nitrogenTestFlOw1Slpm
o | oxidizerTestFlow2Slpm
o | nitrogenTestFlow2Slpm
o | oxidizerTestFlow3Slpm
o | nitrogenTestFlOw3Slpm
120 | constantFlowTime1Sec
o | consta ntFlowTime2Sec
o | constantFlowTime3Sec
o | ignitionTOTestRampTimeSec
o | testFlowRamp1T02TimeSec
O | testFt0wRamp2T03TimeSec
postExtinctionDelaySec
o | postExtinCtionFlowChangeOxidizerPercent
o | postExtincti0nFlowChangeNitrogenPercent
o | postExtinctionF10wChangeRampTimeSec
o | postExtinctionFlowChangeHoldSec
450 | burner TemperatureLimitC
1 | burner TemperatureLimitDurationSecS
~~~~
