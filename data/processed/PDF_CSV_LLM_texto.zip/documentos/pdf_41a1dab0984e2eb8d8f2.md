# 21174 test sheets

- Identificador: pdf_41a1dab0984e2eb8d8f2
- Investigaciones: PSI-159
- Tipo de documento: Raw Data
- Estado: processed
- Temas detectados automaticamente: oxygen, pressure, ignition, hardware, soot

## Fuentes

- [PSI-159_Raw Data_21174 test sheets.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-159/Raw%20Data/PSI-159_Raw%20Data_21174%20test%20sheets.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_41a1dab0984e2eb8d8f2, p. 1]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_41a1dab0984e2eb8d8f2/p0001.jpg)

~~~~text
ACME / CFI-G (normal flame) - Science Test Sheet
est date: | 20 | CME test #: 2?'
Local time: | est of day #:
GMT: | Flame of day #:
Rack Officer (RO): | PD (ACME):
DMO (CIR): | Researcher:
TEST CONDITIONS | Control? | K fully automated D 'manual'
Test type? o ignition no-flame <standard o other
Oxygen conc. | % (vol, nominal) | Fuel bottle (next row)
Oxygen conc. | g | % (vol, per calc) | o C2H6 | % C3H8 | % n-C4HIÄ0/o
Chamber pressure: | psia (CIR avg) | Burner fuel conc.: | % (volume)
ent before? | yes, to | psia | Fuel flow rate:O | slpm (N 2 basis)
Air' added? nokyes, to | psia | rate: | D > | slpm | Jl/z—
Iso just before? o fan GC scrub
no o fixed c] moving back-n-forth
INSTRUMENTATION | Gain: | DataCam 3 ops camera
a(DataCam: filter? zclear BG7 | CH20 | ROI? Q full c] reduced | fps
*Intensified: filter? ü clear o CH*VCH20 none | ROI? z full reduced | 22 fps
s-HiBMSIbacklight filter? no.yes | CIR backlight? 910 yes fps2-Q-15-LL30
FLAME BEHAVIOR
Flame Khot cool maybe cool | Ignited? yes no yes, but
.
Flame hole/openingepartially detached | oot@ignition | none little Mots
Flamege oscillatingÅunsteady o | oot@middle | noneAlittle lots
Out( ext. detect time out o temp. limit | oot@end | non | little lots
POST-TEST CONDITIONS | hamber pressure: | 435 psia (CIR avg)
Oxygen conc. | % (vol, per calc) | Oxidizer bottle pressure: 15 | psia
alve safety timer | sec | Fuel bottle pressure: | psia
*GENERAL COMMENTS
24 March 2021
~~~~

### Pagina 2

Cita: [pdf_41a1dab0984e2eb8d8f2, p. 2]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_41a1dab0984e2eb8d8f2/p0002.jpg)

~~~~text
ACME / CFI-G (normal flame) - Science Test Sheet
est date: | Z? Zeal | CME test#: 2117
Local time: | est of day #: 2—
GMT: | Flame of day #: Z--
TEST CONDITIONS | Control? | ßfully automated 'manual'
Test type? ignition no-flame < standard other
Oxygen conc. | D % (vol, nominal) | Fuel bottle (next row)
Oxygen conc. | % (vol, per calc) | C2H6 | 0/0 C3H8
Chamber pressure: 734- psia (CIR avg) | Burner fuel conc.. | % (volume)
ent before? no o yes, to | psia | Fuel flow rate: D- | > | slpm (N2 basis)
Air' added? | yes, to | psia | N2fiw-rate: | > | slpm
Iso just before? Qfan GC scrub
FP?Åno D fixed moving back-n-forth
INSTRUMENTATION | Gain: | DataCam | ops camera
u DataCam: | BG7 CH* CH20 | ROI? (full reduced | fps
—Intensified: filter? clear CH*ACH20 0 none | ROI? A-full reduced | Zfps
a-HiBMs: backlight filter? no [*yes | CIR backlight?eno yes fps?-ä45-e-30
FLAME BEHAVIOR
Flame hot o cool D maybe cool | Ignited?ßyes no yes, but
.
Flame hole/openingb<partially detached | oot@ignition | none littleß lots
Flam | oscillating y-unsteady | Soot@middle | noneq little o lots
Out ext. detect time out temp. limit | oot@end | o noneglittle lots
POST-TEST CONDITIONS | Chamber pressure: | psia (CIR avg)
Oxygen conc. 35255 % (vol, per calc) | xidizer bottle pressure: 15 | psia
alve safety timer | sec | Fuel bottle pressure: | 5 | psia
*GENERAL COMMENTS
24 March 2021
~~~~

### Pagina 3

Cita: [pdf_41a1dab0984e2eb8d8f2, p. 3]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_41a1dab0984e2eb8d8f2/p0003.jpg)

~~~~text
ACME / CFI-G (normal flame) - Science Test Sheet
est date: | zoz | CME test #: a 17443
Local time: | est of day
GMT: | 4k Flame of day #:
TEST CONDITIONS | Control? | a fully automated 'manual'
Test type? ignition no-flame Ütandard D other
Oxygen conc. | % (vol, nominal) | Fuel bottle (next row)
Oxygen conc. _ | % (vol, per calc) | ü C2H6 | % C3Hg | % B-n-C4H10@0/0
hamber pressure: | psia (CIR avg) | Burner fuel conc.: | % (volume)
ent before? | yes, to | psia | Fuel flow rate: &-2- | slpm (N2 basis)
Air' added? no yes, to | psia | w rate: | > | slpm
Iso just before? | fan o GC scrub
FP?E-no fixed moving c] back-n-forth
INSTRUMENTATION | ain: | DataCam _a_i_ ops camera
ZDataCam: filter? | BG7 0 CH* CH20 | ROI? Qfull reduced | fps
_
Vlntensified: filter? clear CH*SCH20 none | ROI? Efull reduced
g-HiBMs: backlight filter? no Ayes | CIR backlight? Eno yes fps?-e-1-5-t-3€—
FLAME BEHAVIOR
Flame | cool maybe cool | Ignited? yes no o yes, but ...*
Flame hole/opening€partially detached | Soot@ignition | none [i littlest lots
Flamecoscillating | oot@middle | noneDQ little o lots
Out ext. detect time out o temp. limit | oot@end | none little lots
POST-TEST CONDITIONS | Chamber | 3 psia (CIR avg) @ eva
pressure:
Oxygen conc. | % (vol, per calc) | Oxidizer bottle pressure: / | psia
alve safety timer | sec | Fuel bottle pressure: | psia
*GENERAL COMMENTS
24 March 2021
~~~~

### Pagina 4

Cita: [pdf_41a1dab0984e2eb8d8f2, p. 4]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_41a1dab0984e2eb8d8f2/p0004.jpg)

~~~~text
ACME / CFI-G (normal flame) - Science Test Sheet
est date: | CME test 211
Local time: | est of day | +
GMT: | '7 | Flame of day #:
TEST CONDITIONS | Control? | <ully automated 'manual'
Test type? ignition no-flamekstandard o other
xygen conc. | O % (vol, nominal) | Fuel bottle (next row)
Oxygen conc. | % (vol, per calc) | c] C2H6 | % ü C3H8 | % NZn-C4H10Äo
Chamber pressure: | psia (CIR avg) | Burner fuel conc.. | % (volume)
ent before? Cno | to | psia | Fuel flow rate:öri - > | slpm (N2 basis)
yes,
Air' added? Eno yes, to | psia | w rate: | > | slpm
Iso just before? Cfan GC scrub
FP? | o fixed moving back-n-forth
INSTRUMENTATION | Gain: | DataCam | ops camera
(DataCam: filter? •clear BG7 | ü CH20 | ROI? k full reduced | fps
Intensified: filter? o clear CH* ÄCH20 none | ROI? & full reduced | fps
3--HiBMs: backlight filter? noz yes | CIR backlight? | yes
FLAME BEHAVIOR
Flamed hot cool maybe cool | Ignited? •yes o no yes, but
.
Flame hole/opening | artially detached | Soot@ignition | none little lots
Flam | Soot@middle d none little lots
Out&ext. detect o time out temp. limit | oot@end | c] little lots
POST-TEST CONDITIONS | Chamber pressure: | psia (CIR avg)
Oxygen conc. _3ÖrRS % (vol, per calc) | xidizer bottle pressure: / | psia
alve safety timer | sec | Fuel bottle pressure: | psia
*GENERAL COMMENTS
24 March 2021
~~~~

### Pagina 5

Cita: [pdf_41a1dab0984e2eb8d8f2, p. 5]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_41a1dab0984e2eb8d8f2/p0005.jpg)

~~~~text
ACME / CH-G (normal flame) - Science Test Sheet
est date: | CME test#: 2114
Local time: | est of day #:
GMT: ZI / | Flame of day #:
TEST CONDITIONS | Control ? | Qfully automated 'manual'
Test type? ignition no-flame€standard o other
Oxygen conc. | % (vol, nominal) | Fuel bottle (next row)
Oxygen conc. | % (vol, per calc) | o C2H6 | % C3H8 | % An-C4H10A%
Chamber pressure: | psia (CIR avg) | Burner fuel conc.: | % (volume)
ent before? 'no yes, to | psia | Fuel flow rate: 01 | slpm (N2 basis)
Air' added? Qno yes, to | psia | ow rate: D > | slpm
Iso just before? •fan GC scrub
FP? noßixed moving back-n-forth
INSTRUMENTATION | ain: O Datacam 2.1—ops camera
Oatacam: filter? | BG7 CH* CH20 | ROI? e full o reduced | fps
_
Wntensified: filter? clear CH* KCH20 0 none | ROI? Efull o reduced | 2>fps
zNBM%backlight filter? no Ryes | CIR | yes
FLAME BEHAVIOR
Flame {hot cool maybe cool | Ignited? yes no yes, but ...*
Flame hole/opening E-partially detached | oot@ignition | none little (lots
Flame goscillatingø unsteady o | oot@middle enone o little lots
Outzext. detect time out temp. limit | oot@end | none little ü lots
POST-TEST CONDITIONS | Chamber pressure: | psia (CIR avg)
Oxygen conc. | % (vol, per calc) | xidizer bottle pressure: b | psia
alve safety timer | 4 ZO sec | Fuel bottle pressure: | psia
*GENERAL COMMENTS
24 March 2021
~~~~

### Pagina 6

Cita: [pdf_41a1dab0984e2eb8d8f2, p. 6]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_41a1dab0984e2eb8d8f2/p0006.jpg)

~~~~text
ACME / CFI-G (normal flame) - Science Test Sheet
est date: | CME test#: Zu
Local time: | est of day#: | C
GMT: | /q Flame of day
TEST CONDITIONS | Control? | Qfully automated o 'manual'
Test type? o ignition no-flame (standard o other
Oxygen conc. | % (vol, nominal) | Fuel bottle (next row)
xygen conc. | % (vol, per catc) | ü C2H6 | % o C3H8 | 0/0 u n-C4H10
Chamber pressure: | sia (CIR avg) | Burner fuel conc.. | % (volume)
ent before? no €yes, to 02— psia | Fuel flow rate: | > | slpm (N2 basis)
Air' added? no Z yes, to ZZ>6 psia | N 2 flow rate: O > | slpm
Iso just before? | fan GC scrub
FP? Kno o fixed o moving back-n-forth
INSTRUMENTATION | Gain: 323? DataCam | camera
ops
KDataCam: filter? Sclear BG7 CH* o CH20 | ROI? | reduced | fps
_
filter? clear CH* X-CH20 none | ROI? z full o reduced | fps
-e-HiBMs•. backlight filter? ncwyes | CIR backlight? •no yes fps?-e-æs-3-30
FLAME BEHAVIOR
Flame | ot o cool maybe cool | Ignited? A yes no yes, but *
...
Flame hole/opening partially detached | oot@ignition | none littleø lots
Soot@middle | none" little o lots
Out ext. detect time out o temp. limit | Soot@end | o none ß-little lots
POST-TEST CONDITIONS | Chamber pressure: 4>7psia (CIR avg)
Oxygen conc. | Z 3 ) % (vol, per calc) | xidizer bottle pressure:'Z7 psia
alve safety timer | sec | Fuel bottle pressure: | 5 | psia
*GENERAL COMMENTS
24 March 2021
~~~~

### Pagina 7

Cita: [pdf_41a1dab0984e2eb8d8f2, p. 7]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_41a1dab0984e2eb8d8f2/p0007.jpg)

~~~~text
ACME / CFI-G (normal flame) - Science Test Sheet
est date: | 2? Ze | CME test #: | 274c a
Local time: | est of day #:
GMT: | h Flame of day #:
TEST CONDITIONS | Control? | kfully automated 'manual'
Test type? o ignition c] | other
Oxygen conc. | % (vol, nominal) | Fuel bottle (next row)
Oxygen conc. | % (vol, per calc) | a C2H6 | % C3H8 | 0/0 xn-C4H1020/0
Chamber pressure: Z | psia (CIR avg) | Burner fuel conc.: | % (volume)
ent before? | o yes, to | psia | Fuel flow rate: D_ it' > | slpm (N2 basis)
Air' added? Cno yes, to | psia | w rate: | slpm
Iso just before? k-fan GC scrub
FP? Qno o fixed o moving back-n-forth
INSTRUMENTATION | Gain: | DataCam | ops camera
filter? | BG7 | CH20 | ROI? •full o reduced | fps
Xlntensified: filter? o clear o | none | full reduced | fps
cA•åiBMs: backlight filter? no éyes | CIR backlight? Kno yes
FLAME BEHAVIOR
FlameQot cool maybe cool | Ignited? yes no o yes, but ...*
Flame hole/opening partially detached | Soot@ignition | none little lots
Flame g,oscillating unsteady o | oot@middle | none< little lots
nöf-
Out ext. detect time out temp. limit | Soot@end | noneu little lots
POST-TEST CONDITIONS | hamber pressure: €37 psia (CIR avg)
Oxygen conc. | % (vol, per calc) | Oxidizer bottle pressure: | 5 psia
alve safety timer | g sec | Fuel bottle pressure: | 4 psia
*GENERAL COMMENTS
/ Z 70b
24 March 2021
~~~~

### Pagina 8

Cita: [pdf_41a1dab0984e2eb8d8f2, p. 8]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_41a1dab0984e2eb8d8f2/p0008.jpg)

~~~~text
ACME / CFI-G (normal flame) - Science Test Sheet
est date: | Z | CME test | Z)
Local time: | est of day#:
MT: | 17 | /t$ Flame of day #: e
Rack Officer (RO): | PD (ACME):
DMO (CIR): | Researcher:
TEST CONDITIONS | Control? | dfully automated 'manual'
Test type? ignition c] no-flame <standard other
xygen | c. | % (vol, nominal) | Fuel bottle (next row)
Oxygen conc. | % (vol, per calc) | D C2H6 | % C3H8 | O/o-<n-C4H10A0/0
Chamber pressure: | psia (CIR avg) | Burner fuel conc.: | • D % (volume)
ent before? Eno yes, to | psia | Fuel flow | > | slpm (N2 basis)
Air' added? Q no yes, to | psia | ow rate: | slpm
Iso just before? Xfan GC scrub
FP? | o fixed moving o back-n-forth
INSTRUMENTATION | ain: 33 DataCam | ops camera
filter? Eclear o BG7 CH* CH20 | ROI? R full reduced | fps
_
Ulntensified: filter? clear o | none | ROI? Q full o reduced | fps
: backlight filter? noø_yes | CIR backlight? Vo yes
FLAME BEHAVIOR
Flame hot cool maybe cool | Ignited? yes no yes, but *
...
Flame o hole/opening &partially detached | oot@ignition | none little *lots
Flamea oscillatingg unsteady | Soot@middle o none little o lots
Out Ä_ext. detect o time out c] temp. limit | oot@end | none | lots
POST-TEST CONDITIONS | Chamber pressure: | psia (CIR avg)
Oxygen conc. 3? ; 7 Z % (vol, per calc) | Oxidizer bottle pressure: | psia
alve safety timer | sec | Fuel bottle pressure: | psia
*GENERAL COMMENTS
25dZZD
4-ecÅr
24 March 2021
~~~~

### Pagina 9

Cita: [pdf_41a1dab0984e2eb8d8f2, p. 9]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_41a1dab0984e2eb8d8f2/p0009.jpg)

~~~~text
ACME / CFI-G (normal flame) - Science Test Sheet
est date: | 23. | CME test #: 21174C
Local time: | est of day #:
MT: Z | 17 | lame of day
TEST CONDITIONS | Control? | Q fully automated 'manual'
Test type? o ignition | standard other
Oxygen conc. | % (vol, nominal) | Fuel bottle (next row)
Oxygen conc. | 7 2—0/0 (vol, per calc) | C2H6 | % C3H8
Chamber pressure: Z 7 psia (CIR avg) | Burner fuel conc.. | ü % (volume)
_
ent before? no o yes, to | psia | Fuel flow | slpm (N2 basis)
Air' | yes, to | psia | w rate: O > | slpm
Iso just before? c fan o GC o scrub
FP?Éno o fixed moving a back-n-forth
INSTRUMENTATION | Gain: | DataCam Bi ops camera
DataCam: | BG7 0 CH* o CH20 | ROI? Rfull reduced | fps
_
filter? o clear CH* [KCH20 none | ROI? Z full reduced | 2-2 fps
Q.HiBMs: backlight filter? noßyes | CIR backlight? | yes fps?-trl$-tse-— | no
FLAME BEHAVIOR
Flame•hot cool maybe cool | Ignited? kyes D no yes, but *
...
Flame hole/opening Zbartially detached | oot@ignition | none little Ots
FlameE oscillating flunsteady o | Soot@middle | none | lots
Out ext. detect time out c] temp. limit | oot@end | nonetélittle o lots
POST-TEST CONDITIONS | Chamber pressure: | psia (CIR avg)
Oxygen conc. | % (vol, per calc) | Oxidizer bottle pressure: Z | psia
alve safety timer | u sec | Fuel bottle pressure: | psia
*GENERAL COMMENTS
24 March 2021
~~~~

### Pagina 10

Cita: [pdf_41a1dab0984e2eb8d8f2, p. 10]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_41a1dab0984e2eb8d8f2/p0010.jpg)

~~~~text
ACME / CFI-G (normal flame) - Science Test Sheet
est date: | C Z | 2-1 | CME test #:
Local time: | 7 | est of day#: D
MT: | 2/ | /337 | hhFlame of day #: D
PD (ACME):
DMO (CIR): | Researcher:
TEST CONDITIONS | Control? | 'fully automated 'manual'
Test type? ignition no-flame Zstandard c] other
Oxygen conc. | .4 40 % (vol, nominal) | Fuel bottle (next row)
Oxygen conc. | % (vol, per calc) | C2H6 | % C3H8
Chamber pressure: Z | i psia (CIR avg) | Burner fuel conc.. | Ö % (volume)
ent before? «no yes, to | psia | Fuel flow rate: | slpm (N2 basis)
Air' | yes, to | psia | N2 flow rate: CD > | slpm
Iso just before? Afan | scrub
FP? no Ååixed o moving back-n-forth
INSTRUMENTATION | Gain: | DataCam | ops camera
OataCam: filter? Y-clear o BG7 0 CH* CH20 | ROI? (full reduced | fps
Alntensified: filter? clear E CH*4CH20 none | ROI? | reduced | zEfps
D-HiBMs: backlight filter? no Ryes | CIR backlight? gno yes
FLAME BEHAVIOR
Flame hot o cool o maybe cool | Ignited? Ayes o no o yes, but ...*
Flame hole/opening<partially detached | oot@ignition o none little Q lots
Flame koscillatingæ unsteady | oot@middle | noneÅlittle lots
ut ext. detect time out temp. limit | Soot@end | Vnone | lots
POST-TEST CONDITIONS | Chamber pressure: | psia (CIR avg)
Oxygen conc. 3 | S % (vol, per calc) | xidizer bottle pressure: 27 psia
alve safety timer | sec | Fuel bottle pressure: | psia
*GENERAL COMMENTS
24 March 2021
~~~~

### Pagina 11

Cita: [pdf_41a1dab0984e2eb8d8f2, p. 11]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_41a1dab0984e2eb8d8f2/p0011.jpg)

~~~~text
ACME / CFI-G (normal flame) - Science Test Sheet
est date: | CME test | 2117
Local time: | est of day#: [
MT: | -7 + | Flame of day #:
TEST CONDITIONS | ontrol? | Ofully automated o 'manual'
Test type? ignition a no-flame kstandard other
Oxygen conc. | % (vol, nominal) | Fuel bottle (next row)
Oxygen conc. | % (vol, per calc) | C2H6 | % c] C3H8 | 0/0V_n-C4H1a-0/o
Chamber pressure: ZZ psia (CIR avg) | Burner fuel conc.: | % (volume)
ent before? t no yes, to | psia | Fuel flow rate: D | slpm (N2 basis)
Air' added? L no o yes, to | psia | rate: O > | slpm
Iso just before? | fan GC scrub
FP? (no fixed o moving o back-n-forth
INSTRUMENTATION | Gain: | DataCam | ops camera
DataCam: | BG7 | CH20 | ROI? Afull c] reduced | fps
*Intensified: filter? clear o | SCH20 none | ROI? Afull reduced | fps
c*iBMs.• backlight filter? noÄ_yes | CIR backlight? gno a yes fps? @45-E-30
FLAME BEHAVIOR
Flame hot cool o maybe cool | Ignited? yes no o yes, but ...*
Flame hole/opening partially detached | Soot@ignition | none little lots
Flame oscillatingzunsteady o | oot@middle | none (little lots
Out | detect time out temp. limit | oot@end | none little lots
POST-TEST CONDITIONS | Chamber pressure: 38 psia (CIR avg)
Oxygen conc. 37-67 % (vol, per calc) | Oxidizer bottle pressure: 276 psia
alve safety timer | sec | Fuel bottle pressure: | 36 | psia
*GENERAL COMMENTS
4u-bc
5i,y26Åy
24 March 2021
~~~~

### Pagina 12

Cita: [pdf_41a1dab0984e2eb8d8f2, p. 12]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_41a1dab0984e2eb8d8f2/p0012.jpg)

~~~~text
ACME / CFI-G (normal flame) - Science Test Sheet
est date: | 2— | Ze | CME test | i 1746
Local time: | est of day | iZ-
MT: | Flame of day #:
TEST CONDITIONS | ontrol? | fully automated 'manual'
Test type? o ignition no-flameEstandard o other
xygen conc. | % (vol, nominal) | Fuel bottle (next row)
Oxygen conc. | % (vol, per calc) | C2H6
Chamber pressure: Z?4Dpsia (CIR avg) | Burner fuel conc.: | % (volume)
ent before? no yes, to | psia | Fuel flow rate: S7 | slpm (N2 basis)
Air' added? gno c:) yes, to | psia | N 2 flow rate: | O > | slpm
Iso just before? Cfan GC scrub
F P? 6--no o fixed moving back-n-forth
INSTRUMENTATION | Gain: | OPS Camera
E'DataCam: | BG7 | CH20 | ROI? Mull o reduced | fps
_
L Intensified: filter? clear o CH*ßCH20 none | ROI? (full o reduced
eaHiBMs: backlight filter? no<yes | CIR backlight? Q no yes fps2-e4.sæ30
FLAME BEHAVIOR
cool maybe cool | Ignited? i#es no yes, but ...*
Flame o hole/opening partially detached | oot@ignition A-none little lots
Flame ü oscillating unsteady | oot@middle | none little lots
Out o ext. detect time out temp. limit | oot@end | onone little ü lots
POST-TEST CONDITIONS | hamber pressure: m | psia (CIR avg)
Oxygen conc. | 37 | % (vol, per calc) | Oxidizer bottle pressure: 276 psia
alve safety timer | 5 | sec | Fuel bottle pressure: | psia
*GENERAL COMMENTS
fez"
24 March 2021
~~~~

### Pagina 13

Cita: [pdf_41a1dab0984e2eb8d8f2, p. 13]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_41a1dab0984e2eb8d8f2/p0013.jpg)

~~~~text
ACME / CFI-G (normal flame) - Science Test Sheet
est date: | e | CME test | za 17
Local time: | est of day#:
GMT: | 2.01 | ho Flame of day #: ?
TEST CONDITIONS | Control? | fully automated 'manual'
Test type? c] ignition o no-flame standard o other
Oxygen conc. | % (vol, nominal) | Fuel bottle (next row)
Oxygen conc. | % (vo', per calc) | C2H6 | 0/0 C3H8 | % nn-C4H102/o
Chamber pressure: 2 | psia (CIR avg) | Burner fuel conc.: | D % (volume)
ent before? gno o yes, to | psia | Fuel flow rate: O it > | slpm (N2 basis)
Air' added? pno o yes, to | psia | N2 flow rate: O | > | slpm
Iso just before? | GC scrub
FP?Vno D fixed o moving back-n-forth
INSTRUMENTATION | Gain: | DataCam | ops camera
<DataCam: | BG7 | CH20 | ROI? Afull reduced | fps
_
Ø Intensified: filter? o clear CH*qCH20 none | full o reduced | Z fps
. backlight filter? noß._yes | CIR backlight?pno yes fes-?-E+5-tr30--
FLAME BEHAVIOR
Flam | hot cool maybe cool | Ignited? yes no yes, but
..
Flame hole/opening Q_partially detached | oot@ignition | none little *lots
Flame •oscillating Punsteady | Soot@middle Z none o little o lots
Outpext. detect time out temp. limit | oot@end | Vnone little lots
POST-TEST CONDITIONS | Chamber pressure: | psia (CIR avg)
Oxygen conc. | % (vol, per calc) | Oxidizer bottle pressure: 275 psia
alve safety timer | sec | Fuel bottle pressure: | 3 Z- psia
*GENERAL COMMENTS
24 March 2021
~~~~

### Pagina 14

Cita: [pdf_41a1dab0984e2eb8d8f2, p. 14]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_41a1dab0984e2eb8d8f2/p0014.jpg)

~~~~text
ACME / CFI-G (normal flame) - Science Test Sheet
est date: | Z) 2>2— | CME test | •z117
Local time: | est of day | /
MT: | Flame of day #:
TEST CONDITIONS | Control? | V fully automated c] 'manual'
Test type? ignition o no-flameøtandard c] other
Oxygen conc. | % (vol, nominal) | Fuel bottle (next row)
Oxygen conc. | C % (vol, per calc) | C2H6 | % C3H8 | n-C4H10Z20/0
hamber pressure: | Amsia (CIR avg) | Burner fuel conc.: | % (volume)
ent before? uno yes, to | psia | Fuel flow rate: | slpm (N2 basis)
Air' added?Qno yes, to | psia | N-2-ftow rate: | > | slpm
Iso just before? | fan GC scrub
fixed moving back-n-forth
INSTRUMENTATION | Gain: | DataCam | ops camera
ZDataCam: filter? | o BG7 0 CH* CH20 | ROI? Efull reduced | fps
_
élntensified: filter? o clear CH*KCH20 none | ROI? E-full reduced | ZZ fps
*IBMs: backlight filter? noeyes | CIR backlight? Ano yes
FLAME BEHAVIOR
Flameuhot cool maybe cool | Ignited? eyes no yes, but *
...
Flame hole/opening partially detached | oot@ignition | none little lots
Flame o oscillating unsteady•g iAA | oot@middle | none little lots
Out o ext. detect time out temp. limit | Soot@end | none a | lots
POST-TEST CONDITIONS | Chamber pressure: Z9>Zpsia (CIR avg)
Oxygen conc. | % (vol, per calc) | Oxidizer bottle pressure: | psia
alve safety timer | sec | Fuel bottle pressure: | psia
*GENERAL COMMENTS
24 March 2021
~~~~

### Pagina 15

Cita: [pdf_41a1dab0984e2eb8d8f2, p. 15]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_41a1dab0984e2eb8d8f2/p0015.jpg)

~~~~text
ACME / CFI-G (normal flame) - Science Test Sheet
TEST CONDITIONS | Control? | fully automated 'manual'
Test type? c ignition c] no-flameotandard other
Oxygen conc. | a D % (vol, nominal) | Fuel bottle (next row)
Oxygen conc. • 475% (vol, per calc) | C2H6 | % C3H8 | % En-C4H
Chamber pressure: Z? | psia (CIR avg) | Burner fuel conc.: | % (volume)
ent before? «-no c] yes, to | psia | Fuel flow rate: D.Z | slpm (N2 basis)
Air' added? Cno yes, to | psia | N2 flow rate: O | > | slpm
Iso just before? | fan GC scrub
FP? Yno fixed o moving o back-n-forth
INSTRUMENTATION | Gain: | DataCam 31 ops camera
0 Datacam: | BG7 | CH20 | ROI? Mull reduced | fps
_
Intensified: filter? clear | none | ROI? full a reduced | fps
g-HiBfVTS: backlight filter? | yes | CIR backlight? swno yes fps?-E-æs-B-ao
FLAME BEHAVIOR
Flame hot o cool maybe cool | Ignited? Ryes no yes, but *
...
Flame hole/opening partially detached | oot@ignition | none little lots
Flame o oscillating unsteadytÉ | oot@middle | none o little (lots
Out c] ext. detect o time out temp. limit | Soot@end | none ü little#lots
POST-TEST CONDITIONS | Chamber pressure: 29) | psia (CIR avg)
xygen conc. | % (vol, per calc) | Oxidizer bottle pressure: Z | psia
alve safety timer | sec | Fuel bottle pressure: | 50 | psia
*GENERAL COMMENTS
19ec.Ö
24 March 2021
~~~~

### Pagina 16

Cita: [pdf_41a1dab0984e2eb8d8f2, p. 16]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_41a1dab0984e2eb8d8f2/p0016.jpg)

~~~~text
ACME / CFI-G (normal flame) - Science Test Sheet
est date: | CME test#:
Local time: | est of day #:
GMT: | 14 | Flame of day
TEST CONDITIONS | Control? | Rfully automated 'manual'
Test type? ignition no-flame astandard other
Oxygen conc. | % (vol, nominal) | Fuel bottle (next row)
xygen conc. | D % (vol, per calc) | C2H6 | % ü C3H8 | 0/0 an -Q H
Chamber pressure: | -4Zpsia (CIR avg) | Burner fuel conc.: | % (volume)
ent before? Q no yes, to | psia | Fuel flow rate:Q. | slpm (N2 basis)
Air' | yes, to | psia | N2-ftow rate: D > | slpm
Iso just before? Afan GC scrub
FP? | fixed moving back-n-forth
INSTRUMENTATION | Gain: 33 Datacam —Zi-ops camera
V-Datacam: filter?ßclear BG7 | a CH20 | ROI? Qfull reduced | fps
Elntensified: filter? clear CH* | none | ROI? Ofull c] reduced | 22 fps
a-HiBMs: backlight filter? no' yes | CIR backlight? Eno yes fps2-a-15-a-30
FLAME BEHAVIOR
Flame hot cool maybe cool | Ignited?ßyes o no o yes, but ...*
Flame Chole/opening@-partially detached | oot@ignition o none littl | lots
unsteady | oot@middle c]
Out ext. | out temp. limit | Soot@end | Cl none Q_little lots
POST-TEST CONDITIONS | Chamber pressure. | psia (CIR avg)
Oxygen conc. 3C | % (vol, per calc) | Oxidizer bottle pressure: Z | psia
alve safety timer | sec | Fuel bottle pressure: | psia
*GENERAL COMMENTS
24 March 2021
~~~~
