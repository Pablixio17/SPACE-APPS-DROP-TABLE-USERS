# FinalRpt_ACME.CFI-G

- Identificador: pdf_f6cce7cc08ca69c15599
- Investigaciones: PSI-159
- Tipo de documento: Reports
- Estado: processed
- Temas detectados automaticamente: hardware, cool_flames, ignition, pressure, microgravity, oxygen, soot, operations, extinction, droplets, computational_models, electric_fields, smoke_detection, solid_materials

## Fuentes

- [PSI-159_Reports_FinalRpt_ACME.CFI-G.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-159/Reports/PSI-159_Reports_FinalRpt_ACME.CFI-G.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Pasajes de orientacion (extractivos, no resumen validado)

### abstract - pagina 23

Abstract for Spherical Gas-Fueled Cool Diffusion Flames: An improved understanding of cool 
diffusion flames could lead to improved engines. CDFs are investigated here using a spherical 
porous burner with gaseous fuels in the microgravity environment of the International Space 
Station. Normal and inverse flames burning ethane, propane, and n-butane were explored with 
various fuel and oxygen concentrations, pressures, and flow rates. The diagnostics included an 
intensified video camera, radiometers, and thermocouples. Spherical CDFs burning gases were 
observed for the first time. However, these CDFs were not readily produced and were only 
obtained for normal n-butane flames at 2 bar with an ambient oxygen mole fraction of 0.39. The 
hot flames that spawned the CDFs were 2.6 times as large. An analytical model is presented that 
combines previous models for steady droplet burning and the partial-burning regime for CDFs. 
The results identify the importance of burner temperature on the behavior of these CDFs. They 
also indicate that the observed CDFs reside in rich regions near a mixture fraction of 0.53.
Abstract for Cool Diffusion Flames in a Stably Stratified Stagnation Flow: Cool diffusion flames 
have been a growing research topic since their discovery in 2012. Until now their study has been 
hindered by the high cost of the experimental systems used to observe them. A method is 
presented here for observing CDFs inexpensively using a pool of liquid n-heptane and parallel 
plates heated so as to produce a stably stratified stagnation flow. The flames were imaged with a 
color camera and measurements included gas phase temperatures, fuel evaporation rates, and 
formaldehyde emissions. These are the first observations of CDFs burning near the surface of fuel 
poo

### conclusion - pagina 17

conclusion of the inverse-flame testing. 
That change was made because it wasn’t until after completion of the first round of testing, 
through analysis of the final day’s results, that evidence of cool flames was discovered in the CFI￾G results. The added test day, conducted on 18 Oct. 2021 (GMT 291) was carried out with the 
long (near) thermocouple rake with the goal of measuring the cool flame temperature. 
Unfortunately, an unwanted outcome was hot-flame reignition (from the cool flames) caused by 
catalysis from the platinum in the exposed type-B thermocouple closest to the burner. While 
temperature measurements were made, the cool flames on that additional day of testing were 
regrettably short-lived. While this was arguably a hardware shortcoming, the use of fine type B 
thermocouples had been recommended in the ACME science requirements for the closest 
thermocouples on the long (near) rake.

### summary - pagina 4

Summary from the experiment’s 2017 proposal in response to a 
solicitation from the NSF/CASIS Collaboration on Combustion and Thermal Transport Processes 
Research on the International Space Station to Benefit Life on Earth.
Overview:
Cool diffusion flames were discovered in 2012 aboard the ISS. This spawned a rapidly growing 
research field, but only a small number of measurements at limited conditions are available. 
Consequently, cool flame kinetics mechanisms cannot be adequately tested or advanced. This 
could be impeding the development of cleaner and more efficient internal combustion engines.
It is proposed here to observe cool diffusion flames supported by porous spherical burners fed 
with propane, n-butane, and n-pentane. Normal and inverse flames will be considered for a broad 
range of dilution conditions and pressures. The ISS is the ideal platform for observing cool 
diffusion flames because they typically require 20 s to establish and they could burn indefinitely.
Tests will be performed using the ACME insert in the CIR. Minimal hardware development will be
required because the spherical porous burners and gas delivery system will be those used by the 
Flame Design flight experiment, while the diagnostics will be those used by the CFI flight 
experiment.
The objectives are to observe diverse cool diffusion flames aboard the ISS, to simulate the tests 
with an advanced CFD model, and to identify or develop a chemical kinetics mechanism that 
accurately models these conditions.
Intellectual Merit:
Most internal combustion engines are designed using computer models that neglect cool flame 
chemistry, but ignition and flame propagation in engines depend on cool flame chemistry. Cool 
flame chemistry also has a significant impact on fuel octane and cetane num

### objective - pagina 4

objectives are to observe diverse cool diffusion flames aboard the ISS, to simulate the tests 
with an advanced CFD model, and to identify or develop a chemical kinetics mechanism that 
accurately models these conditions.
Intellectual Merit:
Most internal combustion engines are designed using computer models that neglect cool flame 
chemistry, but ignition and flame propagation in engines depend on cool flame chemistry. Cool 
flame chemistry also has a significant impact on fuel octane and cetane numbers, whose 
understanding has large economic consequences.
The proposed experiments will take advantage of many state-of-the-art diagnostics that are 
already available on the ISS. The flame system to be studied will allow steady spherical cool 
diffusion flames to be observed for the first time. An advanced CFD model will simulate the flames 
and will aid the testing and development of cool flame kinetics models.
Observing cool flames burning as steady spherical diffusion flames will yield valuable insight into 
cool flame chemical kinetics. The measurements proposed cannot be performed in normal gravity 
or in ground-based microgravity facilities.
Broader Impacts:
The research will be disseminated widely to the combustion research community and to industry. 
It should advance the state-of-the-art in cool flame kinetics mechanisms, which in turn could lead 
to cleaner, more efficient internal combustion engines.
This project will have several educational impacts. Graduate students will conduct much of the

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_f6cce7cc08ca69c15599, p. 1]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
1
Advanced Combustion via Microgravity Experiments (ACME)
Cool Flames Investigation with Gases (CFI-G)
ACME/CFI-G Final Report (2022*)
Prepared by:
Dennis P. Stocker, NASA Glenn Research Center
dennis.p.stocker@nasa.gov, 216-433-2166
Prof. Peter B. Sunderland, University of Maryland
Prof. Richard L. Axelbaum, Washington University in St. Louis
Prof. Forman A. Williams, University of California, San Diego
Cool flame appearance after hot flame quenching in a composite time sequence of intensified images.
*Data analysis and the publication of results is still underway, so it is expected that this
report will be updated in the future with at least a revision of the list of papers and 
presentations.
~~~~

### Pagina 2

Cita: [pdf_f6cce7cc08ca69c15599, p. 2]. Metodo: native.

Calidad: table_structure_not_manually_validated.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
2
Table of Contents Page
1. Overview 3
2. Science Overview 4
A. Background 4
B. Rationale for Microgravity 5
C. Science Objectives 6 
3. Hardware Overview 6
A. General Description 6
B. Hardware Shortcomings 15
4. Preliminary Results 17
A. Changed Test Plans 17
B. Overview of Experiment Test Operations 18
C. Summary of Preliminary Results 23
D. Surprises and New Discoveries 23
E. Accomplishment of Approved Objectives 23
F. Additional Objectives Achieved 24
G. Impacts, Benefits, and Products 24
H. Patents 24
5. Appendices 25
A. Abbreviations and Acronyms 25
B. 30-Day Operational Accomplishments Report for ISS Increment 64 28
C. 30-Day Operational Accomplishments Report for ISS Increment 65 35
D. Operational Timeline 48
E. Astronauts who Conducted ISS Operations for CFI-G 50
F. ISS Operations per the Payload Weekly Science Summary 51
G. Crew Activity per Space Station Science Highlights 68
H. Crew Activity per the ISS Daily Summary Report 72
I. Crew Activity per the NASA Space Station Blog 79
J. Crew Activity in Publicly Available NASA Photos 80
K. ACME Operations per @ISS_Research on Twitter 81
L. ACME Operations per Astronauts on Twitter 85
M. Summary of the ISS data collection 86
N. Publications, Presentations, Awards, and Outreach 87
1. Publications and Presentations with ISS Results 87
2. Publications and Presentations (comprehensive list) 87
3. Awards 88
4. Outreach 88
~~~~

### Pagina 3

Cita: [pdf_f6cce7cc08ca69c15599, p. 3]. Metodo: native.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
3
1. Overview
The Cool Flames Investigation with Gases (CFI-G) experiment is one of six independent experiments that 
make up the Advanced Combustion via Microgravity Experiments (ACME) project for which the tests were
conducted within the Combustion Integrated Rack (CIR) on the International Space Station (ISS).
The experiment’s Principal Investigator (PI) is Prof. Peter B. Sunderland of the Department of Fire 
Protection Engineering at the University of Maryland. The two Co-Investigators (Co-Is) are Profs. Richard 
L. Axelbaum and Forman A. Williams who are respectively from the Washington University of St. Louis and 
the University of California, San Diego (UCSD).
Meanwhile, Dennis P. Stocker of the NASA Glenn Research Center is the Project Scientist (PS) for ACME 
including CFI-G and the rest of the ACME investigations. In ACME’s preparatory drop testing, etc., Dr. 
Fumiaki Takahashi of the Case Western Reserve University (CWRU)served as the Deputy Project Scientist. 
For ACME’s spaceflight operations, the NASA science team included Drs. Uday G. Hegde and Vedha 
Nayagam who are also with CWRU.
The ISS operations for CFI-G were conducted from March to Oct. 2021 in two sequential rounds of testing. 
The two rounds occurred during Increments 64-65 and 65-66 and respectively featured normal and 
inverse flames. The inverse flame tests were conducted with the chamber filled with a mixture of nitrogen 
and gaseous fuel while an oxygen/nitrogen mixture flowed from the burner. As a result, the inverse 
flames were effectively inside out, e.g., where the soot formed outside rather than inside of the flames. 
Although it was in the second round, the final day of CFI-G testing was carried out in the normal flame 
configuration, with gaseous fuel (with or without nitrogen) flowing into an oxygen/nitrogen atmosphere. 
This was an added test day carried out under conditions in which low-temperature combustion occurred 
during the first round of testing.
CFI-G was a late addition to ACME, where the experiment was jointly selected for spaceflight by the 
National Science Foundation (NSF) and the Center for the Advancement of Science in Space (CASIS) rather 
than NASA. The selection was notably announced after the core ACME hardware had launched to the ISS 
and just weeks before ACME’s on-orbit operations began. It is effectively an extension of ACME’s Flame 
Design experiment for which the PI and Co-I are respectively Axelbaum and Sunderland. And it is likewise 
a follow-on to the Cool Flames Investigation (CFI), led by Williams, in which liquid droplets were burned 
rather than gaseous fuel.
Although CFI-G wasn’t selected for spaceflight by NASA, its ISS operations and the development of its 
unique hardware, software, and procedure were carried out by the same teams of personnel as the other 
ACME experiments, primarily from ZIN Technologies, Inc.
~~~~

### Pagina 4

Cita: [pdf_f6cce7cc08ca69c15599, p. 4]. Metodo: native.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
4
2. Science Overview
A. Background
This background is the Project Summary from the experiment’s 2017 proposal in response to a 
solicitation from the NSF/CASIS Collaboration on Combustion and Thermal Transport Processes 
Research on the International Space Station to Benefit Life on Earth.
Overview:
Cool diffusion flames were discovered in 2012 aboard the ISS. This spawned a rapidly growing 
research field, but only a small number of measurements at limited conditions are available. 
Consequently, cool flame kinetics mechanisms cannot be adequately tested or advanced. This 
could be impeding the development of cleaner and more efficient internal combustion engines.
It is proposed here to observe cool diffusion flames supported by porous spherical burners fed 
with propane, n-butane, and n-pentane. Normal and inverse flames will be considered for a broad 
range of dilution conditions and pressures. The ISS is the ideal platform for observing cool 
diffusion flames because they typically require 20 s to establish and they could burn indefinitely.
Tests will be performed using the ACME insert in the CIR. Minimal hardware development will be
required because the spherical porous burners and gas delivery system will be those used by the 
Flame Design flight experiment, while the diagnostics will be those used by the CFI flight 
experiment.
The objectives are to observe diverse cool diffusion flames aboard the ISS, to simulate the tests 
with an advanced CFD model, and to identify or develop a chemical kinetics mechanism that 
accurately models these conditions.
Intellectual Merit:
Most internal combustion engines are designed using computer models that neglect cool flame 
chemistry, but ignition and flame propagation in engines depend on cool flame chemistry. Cool 
flame chemistry also has a significant impact on fuel octane and cetane numbers, whose 
understanding has large economic consequences.
The proposed experiments will take advantage of many state-of-the-art diagnostics that are 
already available on the ISS. The flame system to be studied will allow steady spherical cool 
diffusion flames to be observed for the first time. An advanced CFD model will simulate the flames 
and will aid the testing and development of cool flame kinetics models.
Observing cool flames burning as steady spherical diffusion flames will yield valuable insight into 
cool flame chemical kinetics. The measurements proposed cannot be performed in normal gravity 
or in ground-based microgravity facilities.
Broader Impacts:
The research will be disseminated widely to the combustion research community and to industry. 
It should advance the state-of-the-art in cool flame kinetics mechanisms, which in turn could lead 
to cleaner, more efficient internal combustion engines.
This project will have several educational impacts. Graduate students will conduct much of the
~~~~

### Pagina 5

Cita: [pdf_f6cce7cc08ca69c15599, p. 5]. Metodo: native.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
5
research. The research results will be integrated into three combustion courses taught by the PI. 
The PI will team with two organizations at UMD - the Women in Engineering Program and the 
Center for Minorities in Science and Engineering - to foster interest in science and engineering 
among female and minority secondary school students. A day-long flame laboratory will be 
developed for secondary school studentsthat will foster their interest in combustion and scientific 
inquiry.
B. Rationale for Microgravity
This is the ‘Justification for Testing Aboard the ISS’ section (3.1) of the experiment’s 2017 proposal 
in response to a solicitation from the NSF/CASIS Collaboration on Combustion and Thermal 
Transport Processes Research on the International Space Station to Benefit Life on Earth. The 
included equation is formatted differently in this copy.
Previous ground-based microgravity experiments have demonstrated the scientific value of
spherical, burner-supported diffusion flames. These one-dimensional flames offer a simple,
fundamental configuration to improve the understanding of diffusion flame behavior and to
explore such effects as transport, kinetics, soot formation, and radiation, which can be more
pronounced under microgravity conditions (Atreya et al. 1992; Law et al. 2001; Lecoustre et al.
2012).
Spherically-symmetric flames are not generally practical in normal gravity. This can be explained 
by considering the Richardson number, which is the ratio of the buoyancy force to the inertial 
force,
Ri = g (ΔT L) / (T u
2
) , (1)
where g is the acceleration of gravity, T is temperature, L is the characteristic length scale, and u
is the characteristic velocity. Taking as representative values L = 50 mm, u = 5 cm/s, ΔT = 2000 K,
and T = 300 K, Ri = 1300 in normal gravity. Ri can be reduced with a judicious choice of fuels and 
inert; Law et al. (2001) have shown that nearly spherical flames can be created in normal gravity 
using low pressure hydrogen inverse flames. However for typical spherical diffusion flames the 
only way to obtain Ri << 1 is to reduce g by four orders of magnitude. This requires a microgravity 
environment.
Available microgravity drop tower facilities do not offer sufficient time to observe quasi-steady
spherical diffusion flames, let alone their radiative extinction followed by cool diffusion flames. 
Experiments performed in the 5 s drop facility confirm that typical spherical diffusion flames 
continue growing during 5 s (see Fig. 2). Observations of cool flames in the FLEX, FLEX-2, and CFI 
droplet experiments involved or will involve burn times of up to 60 s.
Analytical work supports these observations of slow flame development. Radial velocities in
spherical diffusion flames scale with 1 / r2, where r is radius. Thus, at only a few burner diameters
distance from the sphere, diffusion is the dominant transport mechanism. The characteristic
diffusion time is r
2
/D, where D is mass diffusivity. For r = 25 mm and D = 20 mm2
/s, this diffusion
time is 30 s. Decreasing the flame size can reduce this time, but will not permit the observation 
of radiative extinction followed by cool diffusion flames. Our analytical and numerical calculations
indicate that approximately 30 s of jitter-free (less than 10-5
g) microgravity is needed to approach
quasi-steady state for these flames. The ISS is the only microgravity platform that can provide 
this environment.
~~~~

### Pagina 6

Cita: [pdf_f6cce7cc08ca69c15599, p. 6]. Metodo: native.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
6
C. Science Objectives
The objectives text presented here is the ‘Hypotheses and Objectives’ section (1.3) of the 
experiment’s 2017 proposal in response to a solicitation from the NSF/CASIS Collaboration on 
Combustion and Thermal Transport Processes Research on the International Space Station to
Benefit Life on Earth.
The hypotheses of this research are that testing aboard the ISS can demonstrate the following for
the first time, contributing to an improved understanding of cool flame kinetics.
1. Steady-state cool diffusion flames on spherical porous burners.
2. Cool diffusion flames burning propane, n-butane, and n-pentane.
3. Cool diffusion flames for a wide range of Zst, Tad, and pressures.
4. Inverse cool diffusion flames.
5. Cool diffusion flames for which a decrease in fluent flow rate will cause extinction, 
whereas an increase will cause a transition to a hot diffusion flame, with oscillation 
possible between hot and cool flames.
The research objectives of the proposed work are as follows.
1. Plan and support flight testing on the ISS.
2. Determine the conditions for which cool diffusion flames occur for propane, n-butane, 
and n-pentane; normal and inverse flames; and a broad range of Zst, Tad, and fluent flow 
rate.
3. Support the flight tests with advanced CFD simulations.
4. Identify or develop a chemical kinetics mechanism that yields good agreement between 
the CFD predictions and the ISS measurements.
5. Disseminate the results as widely as possible.
In contrast to objective 2 (and hypothesis 3), it was not feasible with the Combustion Integrated 
Rack (CIR) and ACME chamber insert to conduct tests with n-pentane as proposed (because of its 
low vapor pressure) and testing was instead conducted with ethane as an alternate.
3. Hardware Overview
A. General Description
This section is copied from section 2.A of the April 2021 version of ‘ACME Engineering 
Implementation’ which should be consulted for additional details. References to other sections 
within the boxed text of this section refer to the ACME Engineering Implementation document.
This section provides a general description of the ACME engineering from the ‘3.0 Experimental’ 
section of the following 2014 conference paper:
Dennis P. Stocker, Fumiaki Takahashi, J. Mark Hickman, and Andrew C. Suttles, “Gaseous 
Non-Premixed Flame Research Planned for the International Space Station,” Spring 
Technical Meeting of the Central States Section of the Combustion Institute, Tulsa, OK, 16–
18 March 2014.
~~~~

### Pagina 7

Cita: [pdf_f6cce7cc08ca69c15599, p. 7]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
7
IMPORTANT: The 2104 paper from which this section was extracted proceeded completion of the 
spaceflight hardware which was mostly launched in 2017. As a result, it does not accurately 
describe the final engineering in some regards. Therefore updates, clarifications, additional 
details, shortcomings, references, etc. have been included in boxed notes like this following the 
original description. As a minor note, the sizes of figures were adjusted in this report, but none 
were cropped.
As previously discussed, the ACME experiments will be conducted within the Combustion 
Integrated Rack (CIR) using a chamber insert, depicted in Figure 2, which was designed to 
accommodate gas delivery to a variety of exchangeable burners. Besides the chamber insert, 
other ACME-unique hardware includes a high-definition color camera and an avionics package, 
which is for data acquisition and control.
Figure 2: Design of the Advanced Combustion via Microgravity Experiments (ACME) chamber 
insert that will be used in the Combustion Integrated Rack (CIR) on ISS.
ACME’s chamber insert, which is ~0.4 m in diameter, provides common mounting for a variety of 
burners on the chamber axis (but only one at a time) and includes a retracting resistive igniter. As 
depicted in Figure 3, there will initially be gas-jet burners (with inner diameters ranging from 0.4 
to 3.2 mm), a small coflow burner (where the two concentric tubes have inner diameters of 2.1 
and 25 mm), porous spherical burners (with diameters ranging from 6.35 to 12.7 mm), and two 
flat porous burners for the BRE experiment (with inner diameters of 25 and 50 mm). Most burners 
will be equipped with a surface thermocouple, and each BRE burner will have two heat flux 
transducers. The internal pressure of the porous burners will be measured to allow monitoring 
of the pressure differential across the outlet surface. The igniter will have a crew-exchangeable 
tip and arm (to accommodate the various burners) and its stepper-motor drive will allow for 
precise positioning.
~~~~

### Pagina 8

Cita: [pdf_f6cce7cc08ca69c15599, p. 8]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
8
Figure 3: ACME burner types, including from left to right, gas-jet burners, a co-flow burner, 
porous spherical burners, and flat porous burners for the BRE experiment.
Ultimately, the spherical burners were limited to a single diameter of 6.35 mm, and the fabricated 
gas-jet burners were limited to two sizes with nominal inner diameters of 1.3 and 2.1 mm. 
However, only the larger gas-jet burner was used during the spaceflight tests. The burners are 
addressed in detail in section 3.C.
Unfortunately, the spherical burners have not always yielded spherically symmetric flames, 
presumably as a result of (1) greater burner flow through the joint between the porous sphere and 
supply tube, and (2) heat loss to the support tube (encompassing the supply tube) causing local 
flame quenching.
Two types of igniter tips have been used during ACME testing. Most tests have been conducted 
using a loop igniter tip like those which had been successfully used in the droplet combustion 
experiments which preceded ACME research in the CIR. However, some tests were conducted with 
a coil igniter tip, where that included the CFI-G investigation and the second-round testing for both 
the Burning Rate Emulator (BRE) and Structure and Response of Spherical Diffusion Flames (s￾Flame) experiments, with the exception of the latter’s first day testing. For more information 
about the igniter tips, see section 3.D.
The chamber insert includes three mass flow controllers (visible on the left of Fig. 2) for the 
delivery of fuel, oxidizer or inert (e.g., helium or carbon dioxide), and nitrogen to the burner. The 
maximum fuel flow is 2 slpm (on a nitrogen basis), whereas much higher flows, e.g., 10 slpm (on 
a nitrogen basis), are possible for the oxidizer and nitrogen lines. The crew can exchange the mass 
flow controllers to provide appropriate ranges that maximize the flow accuracy. The gas delivery 
system enables on-orbit dilution of the fuel or oxidizer (but not both simultaneously), coflow, 
inverse flames (e.g., oxidizer delivery to the center of a coflow burner), and premixed flames, 
although the latter are not planned for any of the current ACME experiments. Gases can also be 
delivered premixed to the space station where that is necessary in some circumstances, such as 
the blending of different fuel gases. CIR’s standard bottle sizes are 1, 2.25, and 3.8 liters but ACME 
will sometimes use smaller bottles as a hazard control to limit the deficient reactant (e.g., fuel) 
that can be released into the combustion chamber.
Thus far, ACME tests were not conducted with carbon dioxide as a diluent. Furthermore, the fuel 
diluted with helium was premixed prior to launch rather than on orbit. Ultimately, oxidizer flows 
of up to 20 slpm (on a nitrogen basis) were possible, while the nitrogen flow was limited to a
~~~~

### Pagina 9

Cita: [pdf_f6cce7cc08ca69c15599, p. 9]. Metodo: native.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
9
maximum of 5 slpm. ACME has not used gas bottles smaller than 1 liter as indicated above; the 
bottle fill pressure was instead limited as an additional hazard control. 
ACME’s primary flame diagnostics are a suite of imaging systems including five video cameras and 
two illumination systems, of which three cameras are part of the CIR facility and are already in 
use on orbit. All but one of the cameras is mounted outside of the chamber. Collectively, the 
imaging systems will enable color, CH*, and OH* imaging; pyrometry; measurement of the soot 
volume fraction; and operational support. However, it is unlikely that all functions would be 
exercised at any one time as will become apparent in the subsequent discussion.
Color imaging is provided by two cameras: a high-definition digital camera mounted outside of 
the chamber and a standard analog camera mounted on the chamber insert (with a turning 
mirror). Both cameras are part of the ACME hardware that is now in development. The analog 
camera signal will be downlinked in near real time to support the experiment operations. Light￾emitting diodes within the chamber can be used to illuminate the igniter and burner to both 
support the operations and provide reference images. The 12-bit digital camera records at up to 
30 full frames (1360x1024) per second, and is equipped with a motorized lens with independent 
control of the zoom, iris, and focus. The digital camera will be equipped with a filter assembly 
with four options, where selection of a clear “filter” allows for color imaging. Color imaging can 
also be carried out with a blue-green BG7 Schott glass filter, which balances the color planes to 
avoid saturation in the red while maintaining sensitivity in the blue and green. The natural flame 
color can be approximately reconstructed, but the primary purpose of the filter is pyrometry and 
measurement of the soot volume fraction, again via the techniques of [23-24]. Alternately, CH* 
imaging can be conducted with this camera because the filter assembly includes a 430-nm 
bandpass filter with a 10-nm full width at half-maximum transmission (FWHM). A 450-nm 
bandpass filter (again with a 10-nm FWHM) can be used with the CH* filter to effectively subtract 
interfering broadband soot emission. However, the filter assembly rotates slowly so such 
subtraction effectively requires a separate test with each filter and of course reproducible flame 
conditions.
The video from the analog operations (i.e., ops) camera, also referred to as the internal camera, 
is not archived in space. The video is instead recorded on the ground in the operations center. Its 
gain was sometimes adjusted for improved imaging of dim flames, e.g., approaching extinction. 
The sensitivity of the color digital camera, often referenced as the ACME DataCam (i.e., Data 
Camera), to the dim microgravity flames was such that it was often used with long exposure times 
and thus low framing rates, for example on the order of 1 frame per second. The clear “filter” is 
of fused silica. Unfortunately, the thickness of the blue-green BG7 Schott glass filter and the added 
antireflective (AR) coating caused too great a reduction in the red, so it does not balance the 
intensity of the three color planes as intended and thereby can limit the accuracy of temperature 
determination. Meanwhile, rather than the 450-nm bandpass filter described above, the high 
definition color camera was equipped with a bandpass filter for imaging formaldehyde emissions. 
For more information, see the Data Camera Characterization Report (ACME-RPT-010 Rev. A). 
Imaging of the dim hydrogen flames in the Structure and Response of Spherical Diffusion Flames 
(s-Flame) experiment was particularly challenging with these, if not all, cameras.
~~~~

### Pagina 10

Cita: [pdf_f6cce7cc08ca69c15599, p. 10]. Metodo: native.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
10
Pyrometry can alternately be accomplished with CIR’s monochrome High-Bit Depth Multispectral 
(HiBMs) camera, equipped with a Liquid-Crystal Tunable Filter (LCTF), which allows for imaging at 
multiple spectra, but requires a quasi-steady flame for measurement at each desired band. This 
camera has a telecentric optical system and is recorded at 512x512 and 30 frames per second 
(fps). Although it has a 1024x1024 pixel array, binning has been necessary because of signal loss 
through the LCTF. Both soot pyrometry and Thin Filament Pyrometry (TFP) are possible, where 
ACME is equipped with a crew-replaceable array of 5 silicon carbide (SiC) fibers. The fibers are 
orthogonal to the flame axis and the array can be translated along the flame axis to the desired 
position downstream of the burner, e.g., based on the downlink of the analog video. During set 
up, the crew can manually orient the array so that it is orthogonal to either ACME’s color digital 
camera or the HiBMs camera with the LCTF. An alternate fiber array including a platinum wire 
will be used for inflight characterization, which in combination with preflight calibration will 
enable determination of the soot volume fraction [24].
In contrast to the preceding paragraph, ACME did not use a HiBMs camera for pyrometry, but 
instead relied on use of ACME’s color DataCam for such temperature measurements. For an 
example of how this can be done, see the techniques described in the following papers: 
P.B. Kuhn, B. Ma, B.C. Connelly, M.D. Smooke, and M.B. Long, “Soot and Thin-filament Pyrometry 
Using a Color Digital Camera,” Proceedings of the Combustion Institute, 33 (2011) 743-750. 
B. Ma, M. B. Long, “Absolute light calibration using S-type thermocouples,” Proceedings of the 
Combustion Institute, 34 (2) (2013) 3531-3539.
Thus far, TFP tests have been conducted with 14-micron fibers spaced apart by 5 mm for a total 
span of 20 mm (in the case of 5 intact ceramic fibers), neglecting optional translation of the array. 
Tests have been conducted using arrays with and without the platinum wire in the furthest 
downstream position. Tests have also been conducted with some of the fibers broken and 
subsequently removed, leaving only three fibers in the final testing for the BRE and Coflow Laminar 
Diffusion Flame (CLD Flame) experiments and for all of the CFI-G testing.
CIR has a second HiBMs camera, without a filter, that will be used in combination with CIR’s 
illumination package for alternate measurements of the soot volume fraction. This will be 
accomplished via an extinction technique previously employed in microgravity [3,6,26], where the 
camera and the collimated light source (with its two fiber-coupled laser diodes) are positioned at 
opposite windows. The images are recorded at 1024x1024 and 30 fps. Thus far, the primary 
purpose of this combined system has been the measurement of the droplet diameter for 
determination of the droplet burning rate.
A HiBMs camera without the Liquid Crystal Tunable Filter (LCTF) has been used throughout much, 
but not all, of ACME’s operations. In the first round of the CLD Flame experiment, it was used 
without a filter for flame imaging, but this proved to be largely unsuccessful because the camera 
is very insensitive to blue. Afterward, it was equipped with a red filter corresponding to the CIR 
illumination package for the rest of the ACME testing. Unfortunately, that filter is sufficiently 
broad that significant incandescence can pass through the filter limiting its utility for 
determinations of soot volume fraction via light extinction, e.g., through the technique described 
in the following papers:
~~~~

### Pagina 11

Cita: [pdf_f6cce7cc08ca69c15599, p. 11]. Metodo: native.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
11
D.L. Urban, Z.G. Yuan, P.B. Sunderland, K.C., Lin, Z. Dai, and G.M. Faeth, “Smoke-Point Properties 
of Nonbuoyant Round Laminar Jet Diffusion Flames,” Proceedings of the Twenty-Eighth 
Symposium (International) on Combustion 28 (2000) 1965-1972. 
F.J. Diez, C. Aalburg, P.B. Sunderland, D.L. Urban, Z.-G. Yuan, G.M. Faeth, “Soot properties of 
laminar jet diffusion flames in microgravity,” Combustion and Flame, 156 (2009) 1514-1524. 
P.S. Greenberg and J.C. Ku, “Soot Volume Fraction Imaging,” Applied Optics, 36 (22) (1997) 5514-
5522.
Nonetheless, soot volume fraction can also be determined from the color DataCam images.
During ACME operations, the HiBMs camera is typically archived at 15 fps because of data limits 
for transfer and downlink operations. And because operations are constrained by the data limits, 
image data from this camera are sometimes deleted without downlinking to enable additional 
testing. And in some testing, HiBMs images aren’t even acquired given their lesser value.
Unfortunately, the HiBMs backlight illumination is significantly obstructed by the bracket for the 
electrode mesh further limiting its utility for the E-FIELD Flames experiment. This was a design 
trade-off necessitated primarily by ACME’s large number of cameras and other optical 
instruments.
CIR’s Low-Light-Level Ultraviolet (LLL-UV) package is a monochrome camera with an intensifier 
(for 280-700 nm) and a 310-nm bandpass filter (with a 10-nm FWHM) for OH* imaging. Again as 
a result of the signal loss through the filter, binning is employed such that the OH* images are 
recorded at 512x512 and 30 fps.
During ACME operations, the LLL-UV camera has only been used for the Structure and Response 
of Spherical Diffusion Flames (s-Flame) experiment.
While not discussed in the preceding section, another intensified camera was used throughout 
ACME testing, although its image data was sometimes deleted or not even acquired to allow the 
performance of additional tests. This was the Cool Flames Investigation (CFI) camera which was
generally configured with its CH* filter, where an exception is some s-Flame testing with 
particularly dim flames. Due to design trade-offs, its Field of View (FOV) was partially obstructed 
by the arms of the Thin Filament Pyrometry (TFP) fiber array when it was moved inwards to the 
flame. More information about this camera can be found in its characterization report, CIR-RPT￾4600.
The ACME chamber insert will also be equipped with non-imaging optical diagnostics including 
both thermopile radiometers and Photomultiplier Tubes (PMTs). There is a crew-exchangeable 
linear array of radiometers of which there are two versions supporting the initial set of 
experiments. The array has a fixed position which is parallel to the chamber axis and centered 
(along the chamber length) relative to the chamber windows and thus most of the other 
instrumentation. One array is equipped with a single wide-view radiometer with two narrow￾view radiometers that are downstream and two more that are upstream, where all views are 
orthogonal to the chamber axis, as depicted in Figure 4. The narrow-view radiometers are 
intended to support studies of gas-jet flames, where ACME can accommodate shorter burners, 
making the “lower” detectors useful. The other array, also seen in Fig. 4, provides for three wide￾view measurements of the flame, where one view is masked to nominally block radiant emission
~~~~

### Pagina 12

Cita: [pdf_f6cce7cc08ca69c15599, p. 12]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
12
from the burner. It was specifically designed for the BRE experiment but will be a resource 
available to other ACME experiments. Given that the radiometer array can be exchanged by the 
crew, alternate arrays could be developed. 
Figure 4: Crew-exchangeable radiometer arrays on the ACME chamber insert: (top) standard 
(ACME) array of 5 radiometers, and (bottom) array with three radiometers, designed for the BRE 
experiment, where the lowest detector is masked to avoid view of the burner.
A third radiometer array was used in the CFI-G experiment, where it is important to understand 
that only a single radiometer array can be used at a time. Unlike ACME’s other radiometer arrays, 
each sensor in the CFI-G array has two fixed gains, i.e., a high gain and low gain. It is described in
the Cool Flames Radiometer Characterization Report (CIR-RPT-4600). 
The narrow-view radiometers in the standard array are only fully sensitive in small spots, but they 
are each sensitive in a much greater Field of View (FOV) than represented in the preceding figure.
~~~~

### Pagina 13

Cita: [pdf_f6cce7cc08ca69c15599, p. 13]. Metodo: native.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
13
They do not have lenses; their FOV is a result of an aperture where most of their FOV is within the 
penumbra which is only visible to a portion of the sensor. Figures representing the measured FOVs 
of the as-built standard and BRE radiometer arrays are found in section 3.F of this document. 
Unfortunately, the radiometers in the BRE array typically saturated in the first round of BRE 
testing, so the standard array was used in its second round. However, those radiometers similarly 
saturated in many of round 2 tests. In this regard, each of ACME’s BRE and standard radiometers 
have a fixed gain. 
For more information about the standard radiometer array used for most ACME testing, see the 
Radiometer Characterization Report (ACME-RPT-011). Meanwhile, you can learn about the array 
used in the first round of BRE testing from the BRE Radiometer Characterization Report (ACME￾RPT-012). 
An additional wide-view radiometer, that is fixed and not crew exchangeable, is positioned 
downstream of the burner and flame at 30o
from the chamber axis. This detector is primarily 
intended to support the spherical flame experiments and will have a quicker response than the 
more sensitive detectors that will used in the linear arrays. Like the radiometers on the two linear 
arrays, it will have a spectral range of nominally 0.2-11 micron and its field of view will be 
established by an appropriately selected aperture.
The FOV of the off-set radiometer is also shown in section 3.F. Learn more about this sensor from 
the Radiometer Characterization Report (ACME-RPT-011). 
To detect the quenching of dim flames, the chamber insert will be equipped with a set of three 
PMTs. Each PMT will have a wide-angle view, a sight line that is orthogonal to the chamber axis, 
and will be centered (along the chamber length) relative to the chamber windows so that it is 
aligned with most of the other instrumentation. The PMTs’ spectral range will be 230-700 nm, 
i.e., visible and near ultraviolet, but one will have a 310-nm bandpass filter and another will have 
a 430-nm bandpass filter (where both are with a 10-nm FWHM). The pair of detectors will enable 
measurement of OH* and CH* emission, respectively. The third PMT will be equipped with a 
neutral density filter to prevent saturation. Like many other components, the PMT array can be 
removed from the chamber insert by the crew.
Unlike the radiometers, each PMT had a readily adjustable gain. However, the PMT signals 
sometimes saturated when the gains were set too high. See the PMT Characterization Report 
(ACME-RPT-013) to learn more about the three Photomultiplier Tube (PMTs). 
The chamber insert is also equipped with six far-field thermocouples to measure the spread of 
the thermal field in the spherical flame experiments. They are of limited utility for other 
experiments because they are positioned upstream of the burner tip. Therefore, they will 
generally not be installed by the crew to reduce the chance of accidental damage. There will be 
two versions of a four-thermocouple rake to allow a choice of near and far measurements. Other 
arrays could be designed to support future experiments, but they cannot extend downstream of 
the burner tip without interfering with other (e.g., optical) measurements.
~~~~

### Pagina 14

Cita: [pdf_f6cce7cc08ca69c15599, p. 14]. Metodo: native.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
14
The two lone thermocouples, which are both at nominally 200 mm from the center of the spherical 
burner, have been installed throughout ACME testing. The tip of one was seen to be slightly bent 
early in testing, as discussed and depicted in section 3.G of this report. 
Only the short (or far) version of the radiometer rake has been used thus far, where factors include 
the need for crew time to switch between rakes and the heat loss that could result from 
thermocouples in the long (close) rake. The short (far) rake’s thermocouple tips should nominally 
be at 45, 60, 100, and 100 mm from the spherical burner center. For thermocouples at the same 
distance from the burner center, the angle between the rays from the burner center to the two 
thermocouples should be 90 degrees. The bead size of the thermocouples was not measured, but 
it is undoubtedly at least twice the size of the 0.2 mm diameter wire.
The two thermocouples closest to the burner outlets on each four-thermocouple rake are type B, 
while the others are type K.
Except for the final test day, CFIG’s second-round testing was carried out where the fine tip of the 
thermocouple closest to the flame was bent at roughly 90 degrees. In the following section (3.B), 
his can be seen in Figure 5 where, as a size reference, the spherical burner is 6.35 mm in diameter.
Experiment-unique hardware is also mounted on the chamber insert. For example, to 
accommodate the E-FIELD Flames experiment, the insert is equipped with a high-voltage supply 
and a crew-removable electrode mesh which can be set between +10 and -10 kV. The circular mesh 
is orthogonal to the chamber axis and is positioned (during set up) at either ~35 or ~50 mm 
downstream of the insulated burner. The ion current between the burner and electrode mesh will 
be determined via measurement of the voltage drop across a known resistor and application of 
Ohm’s Law.
Additional images of the chamber insert can be seen in subsequent sections of this report. The 
hardware specific to E-FIELD Flames is discussed further in section 2.B.
Additional supporting measurements will be made, where the chamber pressure is a simple 
example. The ACME experiments will use the CIR’s gas chromatograph for pre- and post-test 
analysis of the chamber atmosphere, e.g., for oxygen, nitrogen, carbon dioxide, carbon monoxide, 
and fuel gases. Acceleration measurements will be provided by the Space Acceleration 
Measurement System (SAMS) [27], which is the primary instrument for such measurements on 
ISS and previously served that role for the space shuttle.
The CIR’s Gas Chromatograph Instrumentation Package (GCIP) was not used for the CLD Flame or 
E-FIELD Flames investigations and thus far was only sometimes used during BRE, Flame Design, 
and s-Flame testing. Its use requires significant time and as such effectively reduces the number 
of tests that can be conducted. However, estimates of the chamber contents were computed 
assuming that the fuel in a normal flame test (for example) was either fully or not at all oxidized, 
e.g., for unsustained ignition in the latter case.
The CIR facility was equipped with a 3-axis SAMS sensor head and the acceleration measurements, 
along with relevant documentation, are accessible via the home page for the Principal Investigator
Microgravity Services (PIMS), https://gipoc.grc.nasa.gov/wp/pims/home/. To be clear, the
~~~~

### Pagina 15

Cita: [pdf_f6cce7cc08ca69c15599, p. 15]. Metodo: native.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
15
acceleration measurements are not archived with the ACME experiment data in the Physical 
Sciences Informatics (PSI) website, www.nasa.gov/PSI. 
All ACME experiments will be constant volume (i.e., rather than constant pressure) studies, where 
the chamber’s free volume will be about 90 liters. Burner flows will generally be constrained to 
limit the pressure rise, and tests will typically be 0.5-2 minutes in duration.
The chamber’s free volume is approximately 83 liters depending on the installed hardware.
The ACME experiments will be configured, but not conducted, by the ISS crew. Instead, the 
experiments will be commanded from the ground, specifically from the Telescience Support 
Center (TSC) at the NASA Glenn Research Center in Cleveland, Ohio. They can be conducted in a 
nominally automated mode using pre-programmed scripts. However, it will also be possible to 
effectively operate the experiments in a “manual” mode, where changes can be made in response 
to the analog video downlink and the numerical data available in the telemetry stream. For 
example, a flow rate could be adjusted to approach a stability or soot limit. Step and ramp 
changes can be made in the flow rate(s) or electric field potential. The TFP fiber array can be 
translated uniformly through a soot-free flame to get a continuum measurement of the 
temperature field. In summary, ACME’s experiment control will allow for broad flexibility. 
The TSC is now also referred to as the Glenn ISS Payload Operations Center (GIPOC). Thus far, the 
ACME tests have always been conducted in a nominally automated mode.
B. Hardware Shortcomings
CFI-G’s two primary challenges were in initiating cool flames and discerning their presence. Based 
on the findings of the earlier studies with droplet combustion, non-premixed cool flames can be 
directly ignited by limiting the ignition energy or can occur after the self-extinguishment of 
(normal) hot flames. Tests intended to directly ignite cool flames sometimes unintentionally 
resulted in hot flames. Meanwhile, evidence of cool flames was first discovered in review of the 
data a few days after the testing. During that testing, it wasn’t known that the cool flames were 
present after hot flame extinction and the tests were terminated, which unknowingly and sadly 
shortened the duration of the cool flame combustion.
In later testing with the long/near thermocouple, two of the tests exhibited repeated hot flame 
quenching and reignition, which resulting from intervening low-temperature combustion. It 
appears that the closest thermocouple, approximately 1 cm from the burner surface, was a factor 
in the reignition. The exposed type-B thermocouple includes platinum, a catalyst for the oxidation 
of hydrocarbons. The catalysis contributed to the rapid reignition limiting the duration of the low￾temperature combustion in these tests.
A challenge for cool flame detection was concern about potential damage to the CFI intensified 
camera by exposing it to bright light, especially from the energized igniter, while the intensifier 
gain was set high.
There were also issues with the Image Processing and Storage Units (IPSUs) which affected CFI-G 
operations. On 30 Aug. 2021 (GMT 242), the primary IPSU, used to record the imaging from both 
the ACME DataCam and CFI intensified camera (IPSU-G, also known as IPSU5), caused issues and
~~~~

### Pagina 16

Cita: [pdf_f6cce7cc08ca69c15599, p. 16]. Metodo: native.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
16
eventually stopped working. Only the first two tests on that day were successful, where two tests 
aborted due to an IPSU error, and three tests failed to ignite. In closing checkout, it was 
determined that the hot-wire igniter tip had also failed. With the IPSU-G failure, the test day was 
nearly a total loss. Except for a small number of sample images downloaded during the midst of 
testing, the primary image data from even the successful tests was lost. Furthermore, there was 
no more propane available for use in inverse-flame testing, so the test day could not be repeated. 
However, astronaut Mark Vande Hei replaced the failed igniter tip on Sept. 8 and the failed hard 
drive in the IPSU-G on Sept. 10, and CFI-G testing successfully resumed on Sept. 13, just 2 weeks 
after the double failure. 
IPSU1, which is used with the High Bit-depth Multi-spectral (HiBMs) camera and the opposed CIR 
illumination package, ceased functioning on 29 March 2021 (GMT 088). Tests 21088M1-M3 
aborted due to an error with IPSU1 communication, where test M4 was successful when the test 
was run without use of the HiBMs camera. The troublesome IPSU1 was replaced by astronaut 
Megan McArthur on May 18 (GMT 138), but it was not available during the intervening test days. 
However, this wasn’t particularly a loss to CFI-G because that camera, with its red filter, is only 
sensitive to the red backlight from the CIR illumination package and visible thermal radiation, e.g., 
from glowing soot particles. Furthermore, the illumination could make it more difficult to discern 
cool flames, so the HiBMs camera, illumination package, and IPSU1 were rarely used for CFI-G. 
The principal exception was during the second round of testing. With the inverse-flame tests, the 
soot is generated outside of the flames, so this photography was used to track potential soot 
deposition on the chamber windows, etc. However, the end-of-day imaging did not appear to 
change over time, suggesting that the soot was not an issue for the chamber windows. However, 
the Photomultiplier Tube (PMT) modules and radiometers were closer to the flame than the 
windows and might had been adversely affected by soot.
When at a small fraction (e.g., less than 10%) of the maximum flow rate, Mass Flow Controller 
(MFC) performance has been seen to be poor during CFI-G testing, i.e., where actual flow rate 
differed from that desired.
Meanwhile, at high flow rates of fuel and nitrogen, the burner does not produce spherically 
symmetric flames. While nominally spherical at moderate flow rates, the flame’s center becomes 
increasing offset from the burner center. More specifically, the flame is shifted toward the supply 
tube indicating that the sintered attachment of the porous sphere to the supply tube is more 
‘open’ than the pores of the spherical burner. In other words, the flow from the burner is not 
spherically symmetric. At sufficiently high flow rates, the flame becomes obviously non-spherical, 
where it can appear to be ellipsoidal or even parabolic in shape. In the latter case, the flame 
locally quenches near the supply tube.
During Burning Rate Emulator (BRE) testing on 23 Dec. 2020, it was discovered that the lowest of 
the 14-micron silicon carbide fibers on the Thin Filament Pyrometry (TFP) fiber array had broken. 
Recovery plans were developed and enacted on 18 Jan. 2021 to remove the broken fragments 
from the harp-like array. Unfortunately, the next fiber was broken during the delicate operations 
where the fibers are only spaced 5 mm apart. Although ACME does have alternate arrays, it also 
had months of remaining testing, so the decision was made to continue testing with only 3 fibers 
(instead of 5) for the final BRE testing and the subsequent CLD Flame and CFI-G tests. This was a 
minor loss, where the fiber array was only occasionally used in CFI-G testing.
~~~~

### Pagina 17

Cita: [pdf_f6cce7cc08ca69c15599, p. 17]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
17
Except for the final test day, CFIG’s second-round testing was carried out where the fine tip of the 
thermocouple closest to the flame was bent at roughly 90 degrees. This can be seen in Figure 5
where, as a size reference, the spherical burner is 6.35 mm in diameter.
Figure 5: Image of the spherical burner, the coiled hot-wire igniter (just to the left), and 
two thermocouples (in the lower right) which are part of the short/far thermocouple rake.
In addition to sections 3.A-B, shortcomings are discussed in Appendices B and C of this report and 
in the ACME Engineering Implementation document. The latter document includes discussion of 
deviations and waivers (in section 4.B), etc.
4. Preliminary Results
A. Changed Test Plans
The most significant change was the substitution of ethane for n-pentane in the test matrix after 
it was determined through ground testing that the use of the latter was not feasible because of 
the n-pentane’s low vapor pressure.
An additional normal-flames test day was added after the conclusion of the inverse-flame testing. 
That change was made because it wasn’t until after completion of the first round of testing, 
through analysis of the final day’s results, that evidence of cool flames was discovered in the CFI￾G results. The added test day, conducted on 18 Oct. 2021 (GMT 291) was carried out with the 
long (near) thermocouple rake with the goal of measuring the cool flame temperature. 
Unfortunately, an unwanted outcome was hot-flame reignition (from the cool flames) caused by 
catalysis from the platinum in the exposed type-B thermocouple closest to the burner. While 
temperature measurements were made, the cool flames on that additional day of testing were 
regrettably short-lived. While this was arguably a hardware shortcoming, the use of fine type B 
thermocouples had been recommended in the ACME science requirements for the closest 
thermocouples on the long (near) rake.
~~~~

### Pagina 18

Cita: [pdf_f6cce7cc08ca69c15599, p. 18]. Metodo: native.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
18
Other changes to the test plans were minor in comparison.
B. Overview of Experiment Test Operations
While not yet prepared, additional details will be made available in the ACME/CFI-G Experimental 
Procedure document.
The narrative description of the experimental procedure is an excerpt from the ‘Methods / 
Experimental’ section of the following conference paper.
Y.-C. Chien, J. Tinajero, D. Stocker, U. Hegde, and D. Dunn-Rankin, “Electric Field Effects on 
Flames in Microgravity on the International Space Station,” 2018 Spring Technical Meeting of 
the Central States Section of The Combustion Institute, Minneapolis, MN, 20-22 May 2018.
While the paper was written for the Electric-Field Effects on Laminar Diffusion Flames (E-FIELD 
Flames) experiment, much of the discussion applies to ACME in general, including the CFI-G 
investigation. The figure referenced in this excerpt is not included herein. Clarifications and 
additional information, not in the conference paper, are included in boxed notes like this.
The CIR experiments are configured, but not conducted, by the ISS crew. Thus far, ACME’s activity 
has included the majority of the crew members, regardless of their nationalities. Most often the 
astronauts and cosmonauts exchange gas bottles, mass flow controllers, and igniter tips. In the 
latter case, the igniter tip exchange can occur after failure or proactively before failure when the 
crew already has changes to make changes in the interior of the insert. While these activities may 
seem mundane, the crew play a critical role in setting up the hardware for each experiment. As 
an extreme example, there were crew activities on 8 separate days in Sept.-Oct. 2017 to configure 
the CIR and ACME hardware for the first ACME experiment, namely the Coflow Laminar Diffusion 
Flame (CLD Flame) experiment. In contrast, only two crew days were required to reconfigure the 
hardware for the first E-FIELD Flames tests because of the initial use of the same coflow burner. 
Planning is critical because crew activity is scheduled three weeks in advance, for which detailed 
procedures must be prepared and uplinked to the ISS.
As a correction, including two maintenance activities, there were 11 crew days in Sept.-Oct. 2017 
to prepare for the initial CLD Flame testing on the space station.
All CIR tests are remotely commanded from the ground from NASA’s Glenn ISS Payload Operations 
Center (GIPOC) in Cleveland, Ohio. Typically, four to six people staff four consoles during the 
testing. The CIR hardware is controlled from the Rack Officer (RO) and Data Management Officer 
(DMO) consoles, and the ACME hardware is controlled from the Payload Developer (PD) console. 
Two shifts of personnel are scheduled to staff these three consoles on test days because they 
typically last 14 hours with the many pre- and post-testing activities. Given that the tests are 
remotely commanded, the operations are carried out in the day and evening in Cleveland, e.g., 
from 7 AM to 9 PM. A day’s tests, i.e., with flames, are normally conducted in a period of 10 hours 
of less. Tests are normally conducted on three weekdays per two weeks. On intervening 
weekdays, the image data is downlinked and the crew often swap one or both gas bottles. 
Transferring and downlinking data from a day’s tests also requires a 2-shift day for the RO and 
DMO consoles, where it is always necessary to verify that data was downlinked without errors 
and that data is not missing. Those two positions are also staffed to guide and oversee the crew
~~~~

### Pagina 19

Cita: [pdf_f6cce7cc08ca69c15599, p. 19]. Metodo: native.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
19
activity. As a result, the CIR consoles are normally actively staffed on four weekdays per week. A 
team of four carry out the detailed planning for the CIR and ACME console staff, and the daily 
operational plans typically exceed 50 pages on days including testing.
The science console allows for review of the analog video and non-imaging telemetry (at 1 Hz) in 
near real time but doesn’t allow for commanding. In the case of E-FIELD Flames, arrangements 
were made so that the analog video is streamed to a secure computer at UC Irvine to allow the 
research team to participate in test operations and to recommend adjustments to the day’s 
planned parameters. That team does not see the telemetry during the testing, but is in 
communication via phone and e-mail with their NASA research partners at the GRC ISS Payload 
Operations Center (GIPOC). While there are many preparatory steps, the tests are ultimately 
conducted using an uploaded software script and parameter files. In advance of the test day, the 
UC Irvine science team plans the nearly 60 parameters in the voltage sweep script and specifies 
other parameters that are configured outside of the script, such as camera settings. It is also 
possible to effectively conduct tests in a ‘manual’ mode, where parameters are changed in 
response to the analog video downlink or telemetry. For example, the electric field potential can 
be adjusted to approach a stability or soot limit.
Provisions were made to enable the investigators from all ACME experiments to remotely view the 
analog video while they communicated verbally with NASA science personnel in the operations 
center. All ACME flame tests, including those for CFI-G, were conducted in a nominally automated 
manner using software scripts and extensive parameter files.
Typically, ten E-FIELD Flames tests are conducted per test day. Despite the short test durations, 
the low rate results from several unavoidable factors. After a test is conducted, the 125-Hz non￾imaging data is downlinked for immediate review by the science team. A small sample of images 
are often downlinked to ensure that the camera exposures are appropriate, where the times for 
those images are typically selected based on non-imaging data to provide extreme examples. The 
review helps to verify parameters or plan for adjustments in subsequent tests, e.g., to select the 
voltage range after determining where the ion current saturates for the given flame conditions. 
After a test is conducted, a fan circulates the chamber atmosphere after which the chamber is 
vented (to space) back to atmospheric pressure, if needed. Midway through a day’s E-FIELD 
Flames tests, the atmosphere is circulated for 15 minutes through a filter cartridge filled with 
molecular sieves to capture any soot and adsorb at least a portion of the combustion products, 
e.g., carbon dioxide, water vapor, and incomplete combustion products. The tests are only 
conducted when both Ku and S band communication is available through NASA’s Tracking and 
Data Relay Satellite (TDRS) System. Depending on the various orbits, there are periodic 
communication outages with a loss of signal (LOS) that can be a short handover (from one satellite 
to another) or can last as long as 30 minutes.
Typically, on the order of 12 tests were conducted per CFI-G Flame test day.
In contrast to E-FIELD Flames, recirculation during CFI-G test operations was only conducted prior 
to venting: (1) at the end of a test day and/or (2) between atmospheres, where the latter was 
limited to days with normal-flame testing.
~~~~

### Pagina 20

Cita: [pdf_f6cce7cc08ca69c15599, p. 20]. Metodo: native.

Calidad: table_structure_not_manually_validated.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
20
A variety of constraints limit the number of tests that can be performed, both overall and on a 
daily basis. The next combustion experiments in the CIR will feature solid fuels and focus on flame 
spread and material flammability. That follow-on plan limits the duration of ACME operations, 
where each ACME experiment is allotted four months for testing. Although it requires additional 
crew time, these allotments are split into two rounds so that the investigators have a break from 
testing for careful review of the early results so that they can maximize the scientific outcome of 
their second round. This paper reports on early results from the first round of E-FIELD Flames.
While nitrogen is available from the space station, the combustion testing is limited by the 
available gas bottles that were and are launched to support the tests. For E-FIELD Flames and 
most of ACME’s experiments, the test matrices used to plan those gas resources were established 
in 2010. At that time, NASA limited the scope of the ACME tests matrices with the intent of 
focused experiments with limited objectives rather than comprehensive experiments. As such, 
the general target was 50 tests per experiment. For most ACME experiments, the limiting gas 
constraint is the oxygen/nitrogen bottles used to fill the chamber. This resource constraint is 
exacerbated by the CIR because it is equipped with a pair of redundant safety timers to limit the 
fuel that can flow into the combustion chamber (where the timers can be set for the oxidizer flow 
in the case of inverse flame testing). The timers can only be reset by venting the combustion 
chamber. Therefore, the timer limit combined with other constraints effectively corresponds to 
the day’s maximum flow time for the fuel (or more generally, the limiting reactant). For E-FIELD 
Flames, the safety timers are set to the maximum value of 999 seconds, which corresponds to the 
10 tests typically completed per day.
The maximum limit of 999 seconds for the valve safety timers was used for all ACME testing.
Another constraint is the available time in a day, where the console personnel and ISS resources, 
such as the video downlink, are planned for a limited number of hours. When necessary for the 
research, NASA does have continuous 24-hour/day operations for some non-CIR experiments. 
But as discussed, the ACME tests are typically two minutes or less in duration, so the testing is
almost always limited to the planned durations.
Data limits are yet another constraint, where the on-orbit hardware can store a limited amount 
of data. More importantly, 127,000 MB is the most that can be reasonably managed in a two￾shift transfer and downlink day. Therefore, tests days are limited to this amount of data, where 
image data from select cameras is often archived at reduced rates to mitigate this challenge. 
Nonetheless, the limit sometimes forces decisions to abandon recorded images.
This detailed description of operations and hardware provides the context under which the ACME 
experiments are conducted. …
Table 1 and 2 are summary logs of the flames ignited for CFI-G during the two consecutive rounds 
of testing, including a limited overview of the test conditions. They were copied from this report’s 
Appendix C. 30-Day Operational Accomplishments Report for ISS Increment 65 which 
comprehensively reflects all CFI-G testing on the ISS.
~~~~

### Pagina 21

Cita: [pdf_f6cce7cc08ca69c15599, p. 21]. Metodo: native.

Calidad: table_structure_not_manually_validated.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
21
Table 1. Flames ignited for the CFI-G experiment in the first round of testing, during 
Increments 64-65, with normal flames (where fuel from the burner flows into oxidizer)
Test 
Day1 Year Month Date Atmosphere2 Fuel bottle
Hot flames 
ignited3
Increment 64
21088
2021
3 29
~40% O2, 13.7 psia
~21% O2, 14.7 psia
~18% O2, 14.7 psia
100% C2H6 14
21102
4
12 ~40% O2, 14.7 psia
~21% O2, 14.7 psia 50% n-C4H10
with N2
9
21106 16 ~40% O2, 7.35 psia
~21% O2, 7.35 psia 10
Increment 65
21112
2021
4 22 ~40% O2, 13.7 psia
~21% O2, 14.7 psia 100% C3H8 13
21125
5
5
~40% O2, 14.7 psia
~21% O2, 14.7 psia
30% n-C4H10
with N2
6
21130 10 ~21% O2, 29.4 psia
~21% O2, 44.1 psia 30% C3H8
with N2
15
21137 17 ~40% O2, 14.7 psia
~21% O2, 14.7 psia 12
21153
6
2
~40% O2, 7.35 psia
~40% O2, 29.4 psia g30% C2H6
with N2
14
21162 11 ~40% O2, 14.7 psia
~21% O2, 14.7 psia 12
21174 23 ~40% O2, 7.35 psia
~40% O2, 29.4 psia
30% n-C4H10
with N2
16
1Test Day includes the year as the first two digits followed by the 3-digit day of the year.
2Atmosphere, diluted by nitrogen in all cases, is only nominal where the pressure 
increases and O2% drops with vitiation. 
3Flames ignited is the number of sustained or momentary hot flames ignited on that day 
(neglecting the day change on ISS).
~~~~

### Pagina 22

Cita: [pdf_f6cce7cc08ca69c15599, p. 22]. Metodo: native.

Calidad: table_structure_not_manually_validated.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
22
Table 2. Flames ignited for the CFI-G experiment in the second round of testing, during 
Increments 65-66, with inverse flames (where oxidizer from the burner flowed into a 
gaseous fuel/nitrogen mixture) plus an added day of normal-flame testing
Test 
Day1
Year Month Date Atmosphere2
Fluent 
reactant 
bottle
Hot flames 
ignited3
Increment 65
21196
2021
7
15 ~30% C2H6, 14.7 psia
~30% C2H6, 7.35 psia
85% O2 with N2
13
21202 21
~6% C2H6, 29.4 psia
~12% C2H6, 29.4 psia
~12% C2H6, 14.7 psia
11
21209 28 ~24% C2H6, 7.35 psia 11
21216
8
4
~10% C2H6, 44.1 psia
~10% C2H6, 14.7 psia 12
21222 10 ~8% C3H8, 44.1 psia 9
21228 16 ~9% C3H8, 29.4 psia
~9% C3H8, 14.7 psia 17
21235 23 ~21% C3H8, 14.7 psia
~21% C3H8, 7.35 psia 9
21242 30 ~43% C3H8, 7.35 psia 2
21256
9
13 ~9% n-C4H10, 29.4 psia
~7% n-C4H10, 29.4 psia 17
21265 22 ~6% n-C4H10, 44.1 psia 15
21270 27 ~17% n-C4H10, 14.7 psia 
~14% n-C4H10, 14.7 psia 10
21277 10 4
~36% n-C4H10, 7.35 psia
~25% n-C4H10, 7.35 psia
~18% n-C4H10, 7.35 psia
~14% n-C4H10, 7.35 psia
11
Increment 66
21291 2021 10 18 ~40% O2, 29.4 psia
~40% O2, 14.7 psia
30% n-C4H10
with N2
22
1Test Day includes the year as the first two digits followed by the 3-digit day of the year.
2Atmosphere, diluted by nitrogen in all cases, is only nominal where the pressure 
increases and O2% drops with vitiation. 
3Flames ignited is the number of sustained or momentary hot flames ignited (or 
reignited) on that day (neglecting the day change on ISS).
~~~~

### Pagina 23

Cita: [pdf_f6cce7cc08ca69c15599, p. 23]. Metodo: native.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
23
C. Summary of Preliminary Results
Abstract for Spherical Gas-Fueled Cool Diffusion Flames: An improved understanding of cool 
diffusion flames could lead to improved engines. CDFs are investigated here using a spherical 
porous burner with gaseous fuels in the microgravity environment of the International Space 
Station. Normal and inverse flames burning ethane, propane, and n-butane were explored with 
various fuel and oxygen concentrations, pressures, and flow rates. The diagnostics included an 
intensified video camera, radiometers, and thermocouples. Spherical CDFs burning gases were 
observed for the first time. However, these CDFs were not readily produced and were only 
obtained for normal n-butane flames at 2 bar with an ambient oxygen mole fraction of 0.39. The 
hot flames that spawned the CDFs were 2.6 times as large. An analytical model is presented that 
combines previous models for steady droplet burning and the partial-burning regime for CDFs. 
The results identify the importance of burner temperature on the behavior of these CDFs. They 
also indicate that the observed CDFs reside in rich regions near a mixture fraction of 0.53.
Abstract for Cool Diffusion Flames in a Stably Stratified Stagnation Flow: Cool diffusion flames 
have been a growing research topic since their discovery in 2012. Until now their study has been 
hindered by the high cost of the experimental systems used to observe them. A method is 
presented here for observing CDFs inexpensively using a pool of liquid n-heptane and parallel 
plates heated so as to produce a stably stratified stagnation flow. The flames were imaged with a 
color camera and measurements included gas phase temperatures, fuel evaporation rates, and 
formaldehyde emissions. These are the first observations of CDFs burning near the surface of fuel 
pools. The measured peak temperatures were between 705 – 760 K, which corresponds to an 
increase in gas temperature of 70 K. Autoignition first occurred at 550 K. Cantera autoignition 
simulations for homogeneous mixtures with the CRECK mechanism predicted a cool flame 
temperature of 885 K, which is significantly higher than observed.
Publications:
• M. Kim, K.A. Waddell, P.B. Sunderland, V. Nayagam, D.P. Stocker, D.L. Dietrich, Y. Ju, F.A. 
Williams, P. H. Irace, R.L. Axelbaum, Spherical Gas-Fueled Cool Diffusion Flames, 
Proceedings of the Combustion Institute (2022) in press.
• M. Kim, Spherical Gas-Fueled Cool Diffusion Flames, MS Thesis, University of Maryland, 
60 pp., May, 2022.
• K.A. Waddell, H. Lee, V. Nayagam, R.L. Axelbaum, P.B. Sunderland, Cool Diffusion Flames 
in a Stably Stratified Stagnation Flow, Combustion and Flame, submitted.
• K.A. Waddell, Cool Diffusion Flames in Stagnation Flow, Ph.D. Dissertation, University of 
Maryland, in preparation.
D. Surprises and New Discoveries
• Spherical cool diffusion flames burning gases were observed for the first time.
• Cool diffusion flames burning near the surface of fuel pools were observed for the first 
time.
E. Accomplishment of Approved Objectives
All the approved objectives were accomplished, neglecting substitution of ethane for n￾pentane in the test matrix after it was determined through ground testing that the use of the
~~~~

### Pagina 24

Cita: [pdf_f6cce7cc08ca69c15599, p. 24]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
24
latter was not feasible because of the n-pentane’s low vapor pressure.
F. Additional Objectives Achieved
Cool diffusion flames burning near the surface of fuel pools in normal gravity were observed for 
the first time.
G. Impacts, Benefits, and Products
Combustion provides 86% of the world’s energy and an even higher fraction of the energy used 
for transportation. The internal combustion engines used for transportation generally have 
thermal efficiencies of 38% or lower because of thermal losses. These efficiencies may increase 
to 60% if future engines can take advantage of ultra-lean combustion. However, this progress is 
being impeded by the limited understanding of the chemistry of cool flames. Research into cool 
diffusion flames (whose peak temperatures are 500 – 1000 K) has grown exponentially since they 
were discovered in 2012. 
The measurements performed for this project will help to test and advance cool flame kinetics 
mechanisms. This should facilitate the development of more efficient internal combustion 
engines.
H. Patents
No patents have been filed from the CFI-G research.
~~~~

### Pagina 25

Cita: [pdf_f6cce7cc08ca69c15599, p. 25]. Metodo: native.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
25
Appendix A. Abbreviations and Acronyms
##### ACME days are identified by year (2 digits) and the day of the year (3 digits, 001-366)
#####x# ACME tests are identified by day (5 digits; see above), a letter, and a 1-digit number
0-g microgravity
1-g normal gravity (on the surface of the Earth)
ACME Advanced Combustion via Microgravity Experiments (CIR project)
ADP Acceptance Data Package
ASGSR American Society for Gravitational and Space Research
AVP avionics package
BRE Burning Rate Emulator (an ACME experiment)
C2H4 ethylene
C3H8 propane
CH2O formaldehyde
CASIS Center for the Advancement of Science in Space
CCD Charge-Coupled Device (such as a camera sensor)
CFI Cool Flames Investigation (an MDCA experiment preceding ACME in the CIR)
CFI-G Cool Flames Investigation with Gases (an ACME experiment)
CH4 methane
CIA Chamber Insert Assembly (inserted into the CIR combustion chamber)
CIR Combustion Integrated Rack (ISS facility in which ACME experiments are conducted)
CLD Flame Coflow Laminar Diffusion Flame (an ACME experiments)
CM Combustion Module (space shuttle precursor to the CIR)
cm centimeter
CO2 carn dioxide
Co-I Co-Investigator
CRS Commercial Resupply Service (a designation of ISS cargo missions)
CSA Canadian Space Agency
CSV comma-separated values
CWRU Case Western Reserve University
Da Damköhler number
DataCam Data Camera (ACME’s primary camera which was characterized for pyrometry, etc.)
E-FIELD Flames Electric-Field Effects on Laminar Diffusion Flames (an ACME experiment)
EMI electromagnetic interference
EMS Experiment Mounting Structure
ERD Engineering Requirements Document
ESA European Space Agency
Fiji Fiji Is Just ImageJ (a version of ImageJ preloaded with many plug-in features)
Flame Design Flame Design (an ACME experiment)
FOMA Fuel and Oxidizer Management Assembly (CIR’s gas management subsystem)
FOV field of view
fps frames per second
GC Gas Chromatograph (see GCIP)
GCIP Gas Chromatograph Instrumentation Package (for measuring CIR chamber contents)
GigE Gigabit Ethernet (an interface standard for high performance cameras)
GIPOC Glenn ISS Payload Operations Center (also known as the TSC)
GMT Greenwich Mean Time (where most references in this report are the day)
H2 hydrogen
~~~~

### Pagina 26

Cita: [pdf_f6cce7cc08ca69c15599, p. 26]. Metodo: native.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
26
HiBMs High Bit-depth Multi-spectral camera (developed for the CIR facility)
HOBJ Halcon object (binary uncompressed format; used for the DataCam) 
HV high voltage
HVPS High-Voltage Power Supply
ICDERS International Colloquium on the Dynamics of Explosions and Reactive Systems 
ID inner diameter (e.g., of burner tube)
ImageJ Image Processing and Analysis in Java (open-source image processing software) 
IPSU Image Processing and Storage Unit (CIR device for recording images on ISS)
IPSU-G IPSU for GigE cameras (including the DataCam and CFI intensified camera)
ISRD Integrated Science Requirements Document (for a set of experiments)
ISS International Space Station
JAXA Japan Aerospace Exploration Agency
kPa kilopascal
kV kilovolt
LLL-UV Low Light Level Ultraviolet camera ((developed for the CIR facility)
LSP Laminar Soot Processes (a shuttle study conducted in the Combustion Module)
MDCA Multi-user Droplet Combustion Apparatus (a CIR chamber insert)
MFC Mass Flow Controller
Mist Water-Mist Fire Suppression Experiment (a Combustion Module experiment)
MIUL Materials Identification/Usage List
mm millimeter
MSG Microgravity Science Glovebox (ISS facility in which SLICE was conducted)
N2 nitrogen
NSF National Science Foundation
NTSC National Television System Committee
O2 oxygen
OMA2 Optical Multi-channel Analyzer 2 (open-source software for image processing)
ops operations
PARIS Passive Rack Isolation System (with which the CIR is equipped, but not used for ACME)
PI Principal Investigator
PIMS Principal Investigator Microgravity Services
PMT Photomultiplier Tube (where ACME is equipped with three PMT modules)
PS Project Scientist
PSI Physical Science Informatics System
psia pounds per square inch
PT pressure transducer
QD quick disconnect
qty quantity
RSA Russian Space Agency, i.e., Roscosmos
s second
SAMS Space Acceleration Measurement System
SDP Safety Data Package
s-Flame Structure and Response of Spherical Diffusion Flames (an ACME experiment)
SiC Silicon Carbide (material of the TFP fibers) 
SLICE Structure & Liftoff In Combustion Experiment (CLD Flame precursor)
slpm standard liters per minute (a measure of the mass or molar flow rate of a gas)
SOFBALL Structure Of Flame Balls At Low Lewis-number (a Combustion Module study)
~~~~

### Pagina 27

Cita: [pdf_f6cce7cc08ca69c15599, p. 27]. Metodo: native.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
27
SoFIE Solid Fuel Ignition and Extinction (project to follow ACME in the CIR facility)
SORD Science Operations Requirements Document (an ACME supplement to the ISRD)
SRD Science Requirements Document
TDRS Tracking and Data Relay Satellite (System)
TFP Thin Filament Pyrometry (a method for gas-phase temperature measurements)
TIFF or TIF Tagged Image File Format (for the CFI intensified, HiBMs, and LLL-UV cameras)
TM thermistor
TS Transport Stream (a video format)
TSC Telescience Support Center (also known as the GIPOC)
UV ultraviolet
Ze Zeldovich number
zero-g zero gravity, i.e., microgravity
ZIN ZIN Technologies, Inc. (ACME engineering and operations provider)
µA microamp
While this list of abbreviations and acronyms is long, it is not comprehensive. Contact ACME Project 
Scientist Dennis Stocker (216-433-2166, dennis.p.stocker@nasa.gov) for additional clarification.
~~~~

### Pagina 28

Cita: [pdf_f6cce7cc08ca69c15599, p. 28]. Metodo: native.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
28
Appendix B. 30-Day Operational Accomplishments Report for ISS 
Increment 64
21 June 2021
30-day Operational Accomplishments Report 
… for the International Space Station (ISS) Increment 64 [incorrectly identified as 63]
ACME Advanced Combustion via Microgravity Experiments
CFI-G Cool Flames Investigation with Gases
The CFI-G investigation is one of several independent experiments that are part of the ACME 
project, which uses a single modular set of hardware to carry out studies of flames burning 
gaseous fuels in the ISS’ Combustion Integrated Rack (CIR). Unlike the other ACME studies, CFI-G 
was selected for spaceflight by the Center for the Advancement of Science in Space (CASIS) and 
the National Science Foundation (NSF). CFI-G testing began late in Increment 64 and should be 
completed in Increment 65.
Prepared by the PI team and Dennis Stocker (dennis.p.stocker@nasa.gov), the ACME Project 
Scientist, who is the primary contact for s-Flame and ACME information.
Principal Investigator (PI): Prof. Peter B. Sunderland, University of Maryland, College Park, MD
Co-Investigator (Co-I): Prof. Richard L. Axelbaum, Washington University in St. Louis, MO
Co-Investigator (Co-I): Prof. Forman A. Williams, U. of California San Diego, San Diego, CA
NASA Project Scientist (PS): Dennis P. Stocker, NASA Glenn Research Center, Cleveland, OH
PS team member: Dr. Vedha Nayagam, Case Western Reserve University, Cleveland, OH
I. Introduction
Tests for the Cool Flames Investigation with Gases (CFI-G) experiment are conducted in the 
Combustion Integrated Rack (CIR) on the International Space Station, as part of the Advanced 
Combustion via Microgravity Experiments (ACME) project. As explained in the research proposal:
Cool diffusion flames were discovered during droplet experiments aboard the International 
Space Station (ISS) in 2012, and this initiated a rapidly growing field of combustion research. 
Droplet experiments necessarily involve unsteady burning rates, so cool diffusion flames have 
never been observed as steady spherical flames. A natural progression toward understanding 
cool diffusion flames is to observe quasi-steady spherical flames on porous burners, and this 
is the topic of this proposal. The flames to be studied are rich in the physics and chemistry of 
combustion and thermal transport processes.
~~~~

### Pagina 29

Cita: [pdf_f6cce7cc08ca69c15599, p. 29]. Metodo: native.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
29
Most internal combustion engines are designed using computer models that neglect cool flame 
chemistry, but ignition and flame propagation in engines depend on cool flame chemistry. Cool 
flame chemistry also has a significant impact on fuel octane and cetane numbers, whose 
understanding has large economic consequences.
The flame system to be studied will allow steady spherical cool diffusion flames to be observed 
for the first time. The tests, performed with gaseous fuel and a porous spherical burner, cannot 
be performed in normal gravity or in ground-based microgravity facilities.
CFI-G had the following experimental hypotheses and experimental objective when it was 
proposed in 2017:
Hypotheses
The hypotheses of this research are that testing aboard the ISS can demonstrate the following 
for the first time, contributing to an improved understanding of cool flame kinetics.
1. Steady-state cool diffusion flames on spherical porous burners.
2. Cool diffusion flames burning propane, n-butane, and n-pentane.
3. Cool diffusion flames for a wide range of Zst, Tad, and pressures.
4. Inverse cool diffusion flames.
5. Cool diffusion flames for which a decrease in fluent flow rate will cause extinction,
whereas an increase will cause a transition to a hot diffusion flame, with oscillation 
possible between hot and cool flames.
Experimental Objective
A. Determine the conditions for which cool diffusion flames occur for propane, n-butane, 
and n-pentane; normal and inverse flames; and a broad range of Zst, Tad, and fluent 
flow rate.
where Zst and Tad are respectively the stochiometric mixture fraction and adiabatic flame 
temperature.
However, it was later determined that the CIR facility could not support testing with pentane 
because of the fuel’s low vapor pressure so the test matrix was revised to instead include testing 
with ethane in addition to the propane and n-butane. 
The additional research objectives are as follows, where CFD stands for Computational Fluid 
Dynamics.
B. Support the flight tests with advanced CFD simulations.
C. Identify or develop a chemical kinetics mechanism that yields good agreement 
between the CFD predictions and the ISS measurements.
D. Disseminate the results as widely as possible.
The experiment is carried out using the same spherical burner configuration as ACME’s Flame 
Design and s-Flame (Structure and Response of Spherical Diffusion Flames) experiments. The 
instrumentation is the same as that used for Flame Design except that an alternate radiometer 
array was developed for CFI-G. Furthermore, the CFI-G tests were conducted using the
~~~~

### Pagina 30

Cita: [pdf_f6cce7cc08ca69c15599, p. 30]. Metodo: native.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
30
formaldehyde filter on the CFI intensified camera rather than the typically used CH* filter. In this 
regard, the CFI camera was developed for the Cool Flames Investigation (CFI) which preceded 
ACME and studied non-premixed cool flames in the combustion of liquid droplets. 
Microgravity studies of flames allow for a range of simplifications and provide various advantages 
over normal-gravity studies. For example, the natural flicker of flames, which is a buoyancy￾driven (i.e., gravity-driven) instability, is eliminated yielding quasi-steady flames in microgravity. 
Characteristic length scales are increased in microgravity flames facilitating analysis of the flame 
structure. Momentum-dominated flames, which are important for most practical combustion 
systems, can be studied at low velocities to simplify analysis. Microgravity flames tend to have a 
much stronger sensitivity to their atmosphere and exhibit a much broader range of 
characteristics than normal-gravity flames because of the near absence of buoyant entrainment. 
The long residence times in microgravity flames can lead to strong soot production, but many 
microgravity flames are soot free. The absence of buoyancy makes microgravity flames 
advantageous for studies of limit and stability behavior where chemical kinetics are important. 
For example, chemi-ion species, electronically-excited chemiluminescent species, are at very low 
concentration in typical flames, making the reduced buoyancy environment valuable for 
evaluating the minor species chemistry. With these advantages, microgravity testing can lead to 
new understanding of the complex nature of combustion – regardless of the gravitational 
environment of the combustion application.
II. Methods/Research Operations
A. Discussion of Method/Protocol
The CFI-G investigation and other ACME experiments are configured, but not conducted, 
by the ISS crew. The crew’s role is to set up the hardware, gas bottles, etc. for each set 
of tests. The most common changes include the gas bottles on the Combustion Integrated 
Rack (CIR) and the mass flow controllers on the modular ACME chamber insert.
All testing is commanded from the ground, specifically from the Glenn ISS Payload 
Operations Center (GIPOC). The science portion of the tests were all conducted in a 
nominally automated mode using pre-programmed scripts. No CFI-G tests were 
conducted in a ‘manual’ mode, where changes are made to a control parameter in 
response to the analog video downlink and the numerical data available in the telemetry 
stream. Thus far, that has been the case for all ACME tests, with the mundane exception 
of ‘manually’ halting the test after the flame has extinguished or perhaps if a temperature 
has reached a critical value.
Testing is not conducted when thrusters fire or spacecraft dock or undock from ISS to 
ensure an acceptable acceleration environment.
Data is downlinked between each set of tests, i.e., day of testing, to allow for preliminary 
analysis and requisite planning for subsequent testing.
~~~~

### Pagina 31

Cita: [pdf_f6cce7cc08ca69c15599, p. 31]. Metodo: native.

Calidad: table_structure_not_manually_validated.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
31
III. Results
A. Baselined Activities Completed – Pre-flight, In-flight, Post-Flight
A total of 33 hot flames were ignited for the CFI-G experiment during Increment 64, where 
data is still be reviewed to assess the presence of cool flames. This was just the beginning 
of testing, which is expected to continue through most if not all of Increment 65.
The CFI-G experiment does not have living subjects like a life science experiment, but the 
tests are independently conducted with various gaseous fuels, including ethane, propane, 
and n-butane. These are simple hydrocarbon gases for which the hot flame chemistry is 
reasonably well understood, where there is more to be learned about cool flame 
chemistry.
No samples (e.g., of soot) were collected for CFI-G; all of the ISS results were electronically 
transmitted to the ground. That is furthermore the case for all currently planned ACME 
experiments.
A summary log of the flames ignited for CFI-G during Increment 64, including a limited 
overview of the test conditions, is found in Table 1.
Table 1. Flames ignited for the CFI-G experiment during Increment 64
Test 
Day1 Year Month Date Atmosphere2 Fuel bottle
Hot flames 
ignited3
First round of tests, with normal flames (where fuel from the burner flows into oxidizer)
21088
2021
3 29
~40% O2, 13.7 psia
~21% O2, 14.7 psia
~18% O2, 14.7 psia
100% C2H6 14
21102
4
12 ~40% O2, 14.7 psia
~21% O2, 14.7 psia 50% n-C4H10
with N2
9
21106 16 ~40% O2, 7.35 psia
~21% O2, 7.35 psia 10
1Test Day includes the year as the first two digits followed by the 3-digit day of the year.
2Atmosphere, diluted by nitrogen in all cases, is only nominal where the pressure 
increases and O2% drops with vitiation. 
3Flames ignited is the number of sustained or momentary hot flames ignited on that day 
(neglecting the day change on ISS).
Pre-flight and post-flight activities are generally not addressed in this report.
B. List of Preflight, In-flight, Postflight Anomalies
1. Mission anomalies
The Image Processing and Storage Unit (IPSU1) used with the High Bit-depth Multi￾spectral (HiBMs) camera and the opposed CIR illumination package ceased 
functioning on the first day, March 29 (GMT 088). Tests 21088M1-M3 all aborted due
~~~~

### Pagina 32

Cita: [pdf_f6cce7cc08ca69c15599, p. 32]. Metodo: native.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
32
to an error with IPSU1 communication, where test M4 was successful when the test 
was run without use of the HiBMs camera. The troublesome IPSU1 was replaced by 
astronaut Megan McArthur on May 18 (GMT 138), but it was not available during the 
intervening test days. However, this wasn’t particularly a loss to CFI-G because the 
camera, with its red filter, is only sensitive to soot. Furthermore, the illumination 
could make it more difficult to discern cool flames. However, the camera and 
illumination package will be used during the second round CFI-G testing with inverse 
flames to track possible soot deposition on the chamber windows. 
2. Any other difficulties in obtaining scientific data
CFI-G’s two primary challenges are in initiating cool flames and discerning their 
presence. Based on the findings of the earlier studies with droplet combustion, non￾premixed cool flames can be directly by limiting the ignition energy or can occur after 
the self-extinguishment of (normal) hot flames. Tests intended to directly ignite cool 
flames sometimes unintentionally resulted in hot flames.
A challenge for cool flame detection is concern about potential damage to the CFI 
intensified camera by exposing it to bright light, especially from the energized igniter, 
while the intensifier gain is set high.
When at a small fraction (e.g., less than 10%) of the maximum flow rate, Mass Flow 
Controller (MFC) performance has been seen to be poor during CFI-G testing, i.e., 
where actual flow rate differed from that desired.
Meanwhile, at high flow rates of fuel and nitrogen, the burner does not produce 
spherically symmetric flames. While nominally spherical at moderate flow rates, the 
flame’s center becomes increasing offset from the burner center. More specifically, 
the flame is shifted toward the supply tube indicating that the sintered attachment of 
the porous sphere to the supply tube is more ‘open’ than the pores of the spherical 
burner. In other words, the flow from the burner is not spherically symmetric. At 
sufficiently high flow rates, the flame becomes obviously non-spherical, where it can 
appear to be ellipsoidal or even parabolic in shape. In the latter case, the flame locally 
quenches near the supply tube.
During Burning Rate Emulator (BRE) testing on 23 Dec. 2020, it was discovered that 
the lowest of the 14-micron silicon carbide fibers on the Thin Filament Pyrometry 
(TFP) fiber array had broken. Recovery plans were developed and enacted on 18 Jan. 
2021 to remove the broken fragments from the harp-like array. Unfortunately, the 
next fiber was broken during the delicate operations where the fibers are only spaced 
5 mm apart. Although ACME does have alternate arrays, it also has months of 
remaining testing, so the decision was made to continue testing with only 3 fibers 
(instead of 5) for the final BRE testing, the subsequent CLD Flame tests, and at least
~~~~

### Pagina 33

Cita: [pdf_f6cce7cc08ca69c15599, p. 33]. Metodo: native.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
33
the start of CFI-G testing. This is viewed as a minor loss, where for example the fiber 
array is only used in some CFI-G tests.
C. Completeness/Quality of Data
Only the first 3 of 22 CFI-G test days were conducted during Increment 64, so only a small 
fraction of the test matrix has been completed. In this regard, CFI-G testing is expected 
to continue through most of Increment 65.
The cameras are sensitive to radiation where pixels gradually become ‘hot’ (i.e., dead) 
over time. While these bright spots are addressed in image post-processing, they are a 
degradation of the image quality.
It is possible that the tests are subtly affected by the acceleration environment, but there 
is not obvious indication of this; and it has thus far not been evaluated with available 
measurements from the Space Acceleration Measurement System (SAMS).
Recorded image data is sometimes deleted without downlinking. This is done because of 
operational constraints which limit the amount of data that can be managed per test day. 
Given the constraint, the decision is sometimes made to sacrifice some image data to 
allow additional tests to be conducted. This is intentionally done in order to maximize 
the scientific return of each day of testing within the project constraints.
D. Status of Data Analysis
[provided by the U. of Maryland investigator team and lightly edited by Stocker]
Data sets of spherical diffusion flames as a function of the fuel mass flow rate, 
atmospheric O2 concentration, fuel dilution, and pressure were obtained. The raw test 
measurements made from devices - such as thermocouples, photomultiplier tubes 
(PMTs), gas flow meters, and radiometers - were saved in a csv file format per each test. 
The data rate of the non-imaging measurements was 125 per sec.
The raw data was processed to transform it into scientific measurements. The 
transformed data were visualized as plots for further analysis. In addition, test images 
recorded in tiff and hobj formats respectively for the CFI intensified camera and ACME 
DataCam have been analyzed to find flame diameters. Of these the intensified camera is 
of most value and all of its images to date have been converted to video files and 
reviewed. Particular attention has been given to the PMT-2 measurements due to its 
sensitivity to wavelengths of 230 – 700 nm for CH2O* to investigate the presence of cool 
flames. PMT-2 measurements have been analyzed to determine flame durations as well.
~~~~

### Pagina 34

Cita: [pdf_f6cce7cc08ca69c15599, p. 34]. Metodo: native.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
34
Burner temperatures will be analyzed to find their correlation to the cool flame 
diameters.
E. Preliminary Research Findings [provided by the U. Maryland investigator team]
The first three days of testing have yielded dozens of flames, some lasting several 
minutes. Based on the output from the photomultipliers, radiometers, and intensified 
camera images we do not believe any self-sustained cool flames were created. While it 
is possible that momentary cool flames were created, these are difficult to detect without 
increasing the gain on the intensified camera before the hot flames extinguish, which is 
planned.
The video record will furnish excellent measurements of flame diameter versus time for 
a broad range of fuels and conditions. These will be compared with a simple analytical 
model and detailed CFD simulations using Sphdif. Thin-filament pyrometry has been 
performed and the results will soon be analyzed.
F. Communication Imagery
1. Still Imagery
Photos are available online at www.flickr.com/photos/space-flames. Although the 
Facebook page at www.facebook.com/space.flames is meant to provide updates on 
ACME and related combustion research, it is good source for recent photos, e.g., of 
flames, that may not be available on the Flickr site. Additional photographs may be 
requested from the Project Scientist, Dennis Stocker (dennis.p.stocker@nasa.gov).
2. Video
‘The Power of Studying Combustion on the ISS,’ which was developed with input from 
the ACME Project Scientist, is available at https://science.nasa.gov/science￾news/news-articles/the-power-of-studying-combustion-on-the-iss.
Video(s) describing the ACME project can be found at 
https://www1.grc.nasa.gov/space/iss-research/iss-fcf/cir/acme/.
Videos related to CFI-G and other microgravity combustion research can also be seen 
on Facebook at www.facebook.com/space.flames.
Contact Dennis Stocker (dennis.p.stocker@nasa.gov) for access to those videos or for 
additional videos.
IV. Additional Comments from science team
None.
~~~~

### Pagina 35

Cita: [pdf_f6cce7cc08ca69c15599, p. 35]. Metodo: native.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
35
Appendix C. 30-Day Operational Accomplishments Report for ISS 
Increment 65
14 Dec. 2021
30-day Operational Accomplishments Report 
… for the International Space Station (ISS) Increment 65
ACME Advanced Combustion via Microgravity Experiments
CFI-G Cool Flames Investigation with Gases
The CFI-G investigation is one of several independent experiments that are part of the ACME 
project, which uses a single modular set of hardware to carry out studies of flames burning 
gaseous fuels in the ISS’ Combustion Integrated Rack (CIR). Unlike the other ACME studies, CFI-G 
was selected for spaceflight by the Center for the Advancement of Science in Space (CASIS) and 
the National Science Foundation (NSF). CFI-G testing began late in Increment 64 and was 
completed at the very beginning of Increment 66. That final testing is reflected in this report as 
well as the early testing conducted in Increment 64.
Prepared by the PI team and Dennis Stocker (dennis.p.stocker@nasa.gov), the ACME Project 
Scientist, who is the primary contact for CFI-G and ACME information.
Principal Investigator (PI): Prof. Peter B. Sunderland, University of Maryland, College Park, MD
Co-Investigator (Co-I): Prof. Richard L. Axelbaum, Washington University in St. Louis, MO
Co-Investigator (Co-I): Prof. Forman A. Williams, U. of California San Diego, San Diego, CA
NASA Project Scientist (PS): Dennis P. Stocker, NASA Glenn Research Center, Cleveland, OH
PS team member: Dr. Vedha Nayagam, Case Western Reserve University, Cleveland, OH
V. Introduction
Tests for the Cool Flames Investigation with Gases (CFI-G) experiment are conducted in the 
Combustion Integrated Rack (CIR) on the International Space Station, as part of the Advanced 
Combustion via Microgravity Experiments (ACME) project. As explained in the research proposal:
Cool diffusion flames were discovered during droplet experiments aboard the International 
Space Station (ISS) in 2012, and this initiated a rapidly growing field of combustion research. 
Droplet experiments necessarily involve unsteady burning rates, so cool diffusion flames have 
never been observed as steady spherical flames. A natural progression toward understanding 
cool diffusion flames is to observe quasi-steady spherical flames on porous burners, and this 
is the topic of this proposal. The flames to be studied are rich in the physics and chemistry of 
combustion and thermal transport processes.
~~~~

### Pagina 36

Cita: [pdf_f6cce7cc08ca69c15599, p. 36]. Metodo: native.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
36
Most internal combustion engines are designed using computer models that neglect cool flame 
chemistry, but ignition and flame propagation in engines depend on cool flame chemistry. Cool 
flame chemistry also has a significant impact on fuel octane and cetane numbers, whose 
understanding has large economic consequences.
The flame system to be studied will allow steady spherical cool diffusion flames to be observed 
for the first time. The tests, performed with gaseous fuel and a porous spherical burner, cannot 
be performed in normal gravity or in ground-based microgravity facilities.
CFI-G had the following experimental hypotheses and experimental objective when it was 
proposed in 2017:
Hypotheses
The hypotheses of this research are that testing aboard the ISS can demonstrate the following 
for the first time, contributing to an improved understanding of cool flame kinetics.
1. Steady-state cool diffusion flames on spherical porous burners.
2. Cool diffusion flames burning propane, n-butane, and n-pentane.
3. Cool diffusion flames for a wide range of Zst, Tad, and pressures.
4. Inverse cool diffusion flames.
5. Cool diffusion flames for which a decrease in fluent flow rate will cause extinction, 
whereas an increase will cause a transition to a hot diffusion flame, with oscillation 
possible between hot and cool flames.
Experimental Objective
A. Determine the conditions for which cool diffusion flames occur for propane, n-butane, 
and n-pentane; normal and inverse flames; and a broad range of Zst, Tad, and fluent 
flow rate.
where Zst and Tad are respectively the stochiometric mixture fraction and adiabatic flame 
temperature.
However, it was later determined that the CIR facility could not support testing with pentane 
because of the fuel’s low vapor pressure so the test matrix was revised to instead include testing 
with ethane in addition to the propane and n-butane. 
The additional research objectives are as follows, where CFD stands for Computational Fluid 
Dynamics.
B. Support the flight tests with advanced CFD simulations.
C. Identify or develop a chemical kinetics mechanism that yields good agreement 
between the CFD predictions and the ISS measurements.
D. Disseminate the results as widely as possible.
The experiment is carried out using the same spherical burner configuration as ACME’s Flame 
Design and s-Flame (Structure and Response of Spherical Diffusion Flames) experiments. The 
instrumentation is the same as that used for Flame Design except that an alternate radiometer 
array was developed for CFI-G. Furthermore, the CFI-G tests were conducted using the
~~~~

### Pagina 37

Cita: [pdf_f6cce7cc08ca69c15599, p. 37]. Metodo: native.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
37
formaldehyde filter on the CFI intensified camera rather than the typically used CH* filter. In this 
regard, the CFI camera was developed for the Cool Flames Investigation (CFI) which preceded 
ACME and studied non-premixed cool flames in the combustion of liquid droplets. 
Microgravity studies of flames allow for a range of simplifications and provide various advantages 
over normal-gravity studies. For example, the natural flicker of flames, which is a buoyancy￾driven (i.e., gravity-driven) instability, is eliminated yielding quasi-steady flames in microgravity. 
Characteristic length scales are increased in microgravity flames facilitating analysis of the flame 
structure. Momentum-dominated flames, which are important for most practical combustion 
systems, can be studied at low velocities to simplify analysis. Microgravity flames tend to have a 
much stronger sensitivity to their atmosphere and exhibit a much broader range of 
characteristics than normal-gravity flames because of the near absence of buoyant entrainment. 
The long residence times in microgravity flames can lead to strong soot production, but many 
microgravity flames are soot free. The absence of buoyancy makes microgravity flames 
advantageous for studies of limit and stability behavior where chemical kinetics are important. 
For example, chemi-ion species, electronically-excited chemiluminescent species, are at very low 
concentration in typical flames, making the reduced buoyancy environment valuable for 
evaluating the minor species chemistry. With these advantages, microgravity testing can lead to 
new understanding of the complex nature of combustion – regardless of the gravitational 
environment of the combustion application.
VI. Methods/Research Operations
B. Discussion of Method/Protocol
The CFI-G investigation and other ACME experiments are configured, but not conducted, 
by the ISS crew. The crew’s role is to set up the hardware, gas bottles, etc. for each set 
of tests. The most common changes include the gas bottles on the Combustion Integrated 
Rack (CIR) and the mass flow controllers on the modular ACME chamber insert.
All testing is commanded from the ground, specifically from the Glenn ISS Payload 
Operations Center (GIPOC). The science portion of the tests were all conducted in a 
nominally automated mode using pre-programmed scripts. No CFI-G tests were 
conducted in a ‘manual’ mode, where changes are made to a control parameter in 
response to the analog video downlink and the numerical data available in the telemetry 
stream. Thus far, that has been the case for all ACME tests, with the mundane exception 
of ‘manually’ halting the test after the flame has extinguished or perhaps if a temperature 
has reached a critical value.
Testing is not conducted when thrusters fire or spacecraft dock or undock from ISS to 
ensure an acceptable acceleration environment.
Data is downlinked between each set of tests, i.e., day of testing, to allow for preliminary 
analysis and requisite planning for subsequent testing.
~~~~

### Pagina 38

Cita: [pdf_f6cce7cc08ca69c15599, p. 38]. Metodo: native.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
38
VII. Results
G. Baselined Activities Completed – Pre-flight, In-flight, Post-Flight
A total of 280 hot flames were ignited (or in some cases naturally reignited) for the CFI-G 
experiment during Increments 64-66, where 33, 225, and 22 flames were ignited in the 
three increments, respectively. Testing began near the end of Increment 64 and the final 
test day was conducted at the start of Increment 66. Cool flame evidence was seen in 
some tests and 15 cool flames, listed and discussed later, have been identified thus far.
The CFI-G experiment does not have living subjects like a life science experiment. The 
tests were instead conducted burning various gaseous fuels, including ethane (C2H6), 
propane (C3H8), and n-butane (n-C4H10). These are simple hydrocarbon gases for which 
the hot flame chemistry is reasonably well understood, but where there is much 
remaining to be learned about the cool flame chemistry.
No samples (e.g., of soot) were collected for CFI-G; all of the investigation’s data was 
electronically transmitted to the ground. That is furthermore the case for all current 
ACME experiments.
Summary logs of the flames ignited for CFI-G for the two rounds of testing are found in 
Tables 1 and 2. The first round of testing featured normal flames in which the fuel flowed 
from the burner into an oxygen/nitrogen atmosphere. In contrast, the second round was 
largely conducted with inverse-flame tests in which an oxygen/nitrogen mixture flowed 
from the burner into a mixture of nitrogen and gaseous fuel. The round two exception 
was the final test day (at the start of Increment 66) which was again conducted in the 
normal-flames mode.
~~~~

### Pagina 39

Cita: [pdf_f6cce7cc08ca69c15599, p. 39]. Metodo: native.

Calidad: table_structure_not_manually_validated.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
39
Table 1. Flames ignited for the CFI-G experiment in the first round of testing, during 
Increments 64-65, with normal flames (where fuel from the burner flows into oxidizer)
Test 
Day1 Year Month Date Atmosphere2 Fuel bottle
Hot flames 
ignited3
Increment 64
21088
2021
3 29
~40% O2, 13.7 psia
~21% O2, 14.7 psia
~18% O2, 14.7 psia
100% C2H6 14
21102
4
12 ~40% O2, 14.7 psia
~21% O2, 14.7 psia 50% n-C4H10
with N2
9
21106 16 ~40% O2, 7.35 psia
~21% O2, 7.35 psia 10
Increment 65
21112
2021
4 22 ~40% O2, 13.7 psia
~21% O2, 14.7 psia 100% C3H8 13
21125
5
5
~40% O2, 14.7 psia
~21% O2, 14.7 psia
30% n-C4H10
with N2
6
21130 10 ~21% O2, 29.4 psia
~21% O2, 44.1 psia 30% C3H8
with N2
15
21137 17 ~40% O2, 14.7 psia
~21% O2, 14.7 psia 12
21153
6
2
~40% O2, 7.35 psia
~40% O2, 29.4 psia g30% C2H6
with N2
14
21162 11 ~40% O2, 14.7 psia
~21% O2, 14.7 psia 12
21174 23 ~40% O2, 7.35 psia
~40% O2, 29.4 psia
30% n-C4H10
with N2
16
1Test Day includes the year as the first two digits followed by the 3-digit day of the year.
2Atmosphere, diluted by nitrogen in all cases, is only nominal where the pressure 
increases and O2% drops with vitiation. 
3Flames ignited is the number of sustained or momentary hot flames ignited on that day 
(neglecting the day change on ISS).
~~~~

### Pagina 40

Cita: [pdf_f6cce7cc08ca69c15599, p. 40]. Metodo: native.

Calidad: table_structure_not_manually_validated.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
40
Table 2. Flames ignited for the CFI-G experiment in the second round of testing, during 
Increments 65-66, with inverse flames (where oxidizer from the burner flowed into a 
gaseous fuel/nitrogen mixture) plus an added day of normal-flame testing
Test 
Day1
Year Month Date Atmosphere2
Fluent 
reactant 
bottle
Hot flames 
ignited3
Increment 65
21196
2021
7
15 ~30% C2H6, 14.7 psia
~30% C2H6, 7.35 psia
85% O2 with N2
13
21202 21
~6% C2H6, 29.4 psia
~12% C2H6, 29.4 psia
~12% C2H6, 14.7 psia
11
21209 28 ~24% C2H6, 7.35 psia 11
21216
8
4
~10% C2H6, 44.1 psia
~10% C2H6, 14.7 psia 12
21222 10 ~8% C3H8, 44.1 psia 9
21228 16 ~9% C3H8, 29.4 psia
~9% C3H8, 14.7 psia 17
21235 23 ~21% C3H8, 14.7 psia
~21% C3H8, 7.35 psia 9
21242 30 ~43% C3H8, 7.35 psia 2
21256
9
13 ~9% n-C4H10, 29.4 psia
~7% n-C4H10, 29.4 psia 17
21265 22 ~6% n-C4H10, 44.1 psia 15
21270 27 ~17% n-C4H10, 14.7 psia 
~14% n-C4H10, 14.7 psia 10
21277 10 4
~36% n-C4H10, 7.35 psia
~25% n-C4H10, 7.35 psia
~18% n-C4H10, 7.35 psia
~14% n-C4H10, 7.35 psia
11
Increment 66
21291 2021 10 18 ~40% O2, 29.4 psia
~40% O2, 14.7 psia
30% n-C4H10
with N2
22
1Test Day includes the year as the first two digits followed by the 3-digit day of the year.
2Atmosphere, diluted by nitrogen in all cases, is only nominal where the pressure 
increases and O2% drops with vitiation. 
3Flames ignited is the number of sustained or momentary hot flames ignited (or 
reignited) on that day (neglecting the day change on ISS).
Pre-flight and post-flight activities are generally not addressed in this report.
~~~~

### Pagina 41

Cita: [pdf_f6cce7cc08ca69c15599, p. 41]. Metodo: native.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
41
H. List of Preflight, In-flight, Postflight Anomalies
3. Mission anomalies
On Aug. 30 (GMT 242), the primary Image Processing and Storage Unit, used to record 
the imaging from both the ACME DataCam and CFI intensified camera (IPSU-G, also 
known as IPSU5), caused issues and eventually stopped working. Only the first two 
tests on that day were successful, where two tests aborted due to an IPSU error, and 
three tests failed to ignite. In closing checkout, it was determined that the hot-wire 
igniter tip had also failed. With the IPSU-G failure, the test day was nearly a total loss. 
Except for a small number of sample images downloaded during the midst of testing, 
the primary image data from even the successful tests was lost. Furthermore, there 
was no more propane available for use in inverse-flame testing, so the test day could 
not be repeated. However, astronaut Mark Vande Hei replaced the failed igniter tip 
on Sept. 8 and the failed hard drive in the IPSU-G on Sept. 10, and CFI-G testing 
successfully resumed on Sept. 13, just 2 weeks after the double failure. 
Looking back to Increment 64, the Image Processing and Storage Unit (IPSU1) used 
with the High Bit-depth Multi-spectral (HiBMs) camera and the opposed CIR 
illumination package ceased functioning on March 29 (GMT 088). Tests 21088M1-M3 
aborted due to an error with IPSU1 communication, where test M4 was successful 
when the test was run without use of the HiBMs camera. The troublesome IPSU1 
was replaced by astronaut Megan McArthur on May 18 (GMT 138), but it was not 
available during the intervening test days. However, this wasn’t particularly a loss to 
CFI-G because that camera, with its red filter, is only sensitive to the red backlight 
from the CIR illumination package and visible thermal radiation, e.g., from glowing 
soot particles. Furthermore, the illumination could make it more difficult to discern 
cool flames, so the HiBMs camera, illumination package, and IPSU1 were rarely used 
for CFI-G. The principal exception was during the second round of testing. With the 
inverse-flame tests, the soot is generated outside of the flames, so this photography 
was used to track potential soot deposition on the chamber windows, etc. However, 
the end-of-day imaging did not appear to change over time, suggesting that the soot 
was not an issue for the chamber windows. However, the Photomultiplier Tube (PMT) 
modules and radiometers were closer to the flame than the windows and might had 
been adversely affected by soot.
4. Any other difficulties in obtaining scientific data
CFI-G’s two primary challenges are in initiating cool flames and discerning their 
presence. Based on the findings of the earlier studies with droplet combustion, non￾premixed cool flames can be directly ignited by limiting the ignition energy or can 
occur after the self-extinguishment of (normal) hot flames. Tests intended to directly 
ignite cool flames sometimes unintentionally resulted in hot flames. Meanwhile, 
evidence of cool flames was first discovered in review of the data a few days after the 
testing. During that testing, it wasn’t known that the cool flames were present after
~~~~

### Pagina 42

Cita: [pdf_f6cce7cc08ca69c15599, p. 42]. Metodo: native.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
42
hot flame extinction and the tests were terminated, which unknowingly and sadly 
shortened the duration of the cool flame combustion.
In later testing with the long/near thermocouple, two of the tests exhibited repeated 
hot flame quenching and reignition, which resulting from intervening low￾temperature combustion. It is likely that the closest thermocouple, approximately 1 
cm from the burner surface, was a factor in the reignition. The exposed type-B 
thermocouple includes platinum, a catalyst for the oxidation of hydrocarbons. The 
catalysis contributed to the rapid reignition limiting the duration of the low￾temperature combustion in these tests.
A challenge for cool flame detection was concern about potential damage to the CFI 
intensified camera by exposing it to bright light, especially from the energized igniter, 
while the intensifier gain is set high.
When at a small fraction (e.g., less than 10%) of the maximum flow rate, Mass Flow 
Controller (MFC) performance has been seen to be poor during CFI-G testing, i.e., 
where actual flow rate differed from that desired.
Meanwhile, at high flow rates of fuel and nitrogen, the burner does not produce 
spherically symmetric flames. While nominally spherical at moderate flow rates, the 
flame’s center becomes increasing offset from the burner center. More specifically, 
the flame is shifted toward the supply tube indicating that the sintered attachment of 
the porous sphere to the supply tube is more ‘open’ than the pores of the spherical 
burner. In other words, the flow from the burner is not spherically symmetric. At 
sufficiently high flow rates, the flame becomes obviously non-spherical, where it can 
appear to be ellipsoidal or even parabolic in shape. In the latter case, the flame locally 
quenches near the supply tube.
During Burning Rate Emulator (BRE) testing on 23 Dec. 2020, it was discovered that 
the lowest of the 14-micron silicon carbide fibers on the Thin Filament Pyrometry 
(TFP) fiber array had broken. Recovery plans were developed and enacted on 18 Jan. 
2021 to remove the broken fragments from the harp-like array. Unfortunately, the 
next fiber was broken during the delicate operations where the fibers are only spaced 
5 mm apart. Although ACME does have alternate arrays, it also had months of 
remaining testing, so the decision was made to continue testing with only 3 fibers 
(instead of 5) for the final BRE testing and the subsequent CLD Flame and CFI-G tests. 
This was a minor loss, where the fiber array was only occasionally used in CFI-G 
testing.
~~~~

### Pagina 43

Cita: [pdf_f6cce7cc08ca69c15599, p. 43]. Metodo: native.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
43
I. Completeness/Quality of Data
The experiment’s proposal to CASIS and NSF stated:
“It is assumed here that approximately 50 ISS flames can be conducted. 
These will include approximately 12 chamber fills following evacuation.”
Far more testing was carried out for this experiment, where that included the ignition of 
280 hot flames in 23 days of ISS testing, some of which included multiple chamber fills. 
Although some of the flames were short lived, the testing far exceeded the quantity that 
had been proposed.
The cameras are sensitive to radiation where pixels gradually become ‘hot’ (i.e., dead) 
over time. While these bright spots are addressed in image post-processing, they are a 
degradation of the image quality.
It is possible that the tests are subtly affected by the acceleration environment, but there 
is not obvious indication of this; and it has thus far not been evaluated with available 
measurements from the Space Acceleration Measurement System (SAMS).
Recorded image data is sometimes deleted without downlinking. This is done because of 
operational constraints which limit the amount of data that can be managed per test day. 
Given the constraint, the decision is sometimes made to sacrifice some image data to 
allow additional tests to be conducted. This is intentionally done to maximize the 
scientific return of each day of testing within the project constraints.
J. Status of Data Analysis
[provided by the U. of Maryland investigator team and lightly edited by Stocker]
Data sets of spherical diffusion flames as a function of the fuel mass flow rate (for normal 
flames), the oxidizer mass flow rate (for inverse flames), O2 concentration, fuel dilution, 
and pressure were obtained for all the normal and inverse flame test days. The raw test 
measurements made from devices - such as thermocouples, photomultiplier tubes 
(PMTs), gas flow meters, and radiometers - were saved in a csv file format per each test. 
The data rate of the non-imaging measurements was 125 per sec. 
The raw data was processed to transform it into scientific measurements. The 
transformed data were visualized as plots for further analysis. In addition, test images 
recorded in tiff and hobj formats respectively for the CFI intensified camera and ACME 
DataCam have been analyzed to investigate the presence of cool flames and to find flame 
diameters. Of these the intensified camera is of most value, and all of its images to date 
have been converted to video files and reviewed. Since the intensified camera images 
were taken under the maximum possible gain applied, the images were averaged and 
filtered to decrease the overall noise level, and the intensity of the images was increased 
by a factor of 50 to facilitate the search of intensity peaks.
~~~~

### Pagina 44

Cita: [pdf_f6cce7cc08ca69c15599, p. 44]. Metodo: native.

Calidad: table_structure_not_manually_validated.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
44
Particular attention has been given to the PMT-2 measurements due to its sensitivity to 
wavelengths of 230 – 700 nm for CH2O* to investigate the presence of cool flames. PMT￾2 measurements have been analyzed to determine flame durations as well. Because cool 
diffusion flames were identified through the readings of radiometers after the radiative 
extinction of hot flames, the radiometer data was carefully analyzed. Burner 
temperatures were analyzed to find their correlation to the ignition and diameter of cool 
flames.
K. Preliminary Research Findings
[provided by the U. of Maryland investigator team and lightly edited by Stocker]
A total of 280 hot diffusion flames were observed. Among them, 189 flames experienced 
radiative extinction, and the rest were extinguished when their flow was terminated, 
either because the preset flow time was out or the burner overheated. Of those that 
extinguished radiatively, 15 subsequently reignited as cool diffusion flames. These cool 
flames were observed only with the following conditions: a) concentrations of 30 vol% n￾butane and 40 vol% O2, b) normal flames, c) a pressure of 2.03 bar, and d) mass flow rates 
between 0.75 – 1.5 mg/s. 
Cool diffusion flames were initially identified by the readings of radiometers after the 
radiative extinction of hot flames. Unlike the heat flux shown in Fig. 1(a), Fig. 1(b) shows 
that the radiant heat flux did not drop to zero after the radiative extinction of a hot flame. 
Instead, it decreased to a certain level and stayed at that level until the fuel stopped 
flowing. Figure 1(c) shows multiple hot-cool flame transitions. The first cool flame, the 
first drop of the radiant heat flux, followed the radiative extinction of the first hot flame. 
In a few seconds, the heat flux abruptly increased due to reignition of a hot flame. This 
cycle of radiative extinction, transition to a cool flame, and reignition of a hot flame 
continued until the flow was terminated. The observed cool flames are summarized in 
Table 3. 
Cool flames were also identified by processed images taken from the intensified camera. 
When cool flames appeared after the radiative extinction of the hot flames, no flame 
luminosity was evident for about 1 s, after which cool flames appeared. For test points 
21174C3, C4, C6, and F1, the cool flames lasted for approximately 14 s and disappeared 
as soon as the fuel flow stopped. For the tests of multiple hot-cool flame transitions, 
21291A1 and 21291C1, the first cool flame lasted longer than the following cool flames. 
The intensified camera images of hot and cool flames were used to find flame radii as 
well. The radii of hot flames were measured at the time just before the flame oscillation. 
Representative images of a hot flame and a cool flame are presented in Fig. 2. It is shown 
that the hot flame is brighter and larger than the cool flame. While a flame sheet is clearly 
indicated in the hot flame image, the intensity of a cool flame gradually decreases from 
the peak along radial direction, which implies that the reaction zone of the cool flame is
~~~~

### Pagina 45

Cita: [pdf_f6cce7cc08ca69c15599, p. 45]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
45
broader than that of the hot flame. In addition, it is noted that the hot flame is more 
spherical and less attached to the burner tube than the cool flame.
Fig. 1. Radiant heat flux and fuel flow rate versus time for (a) a hot flame that 
extinguishes, (b) a hot flame that transitions to a cool diffusion flame, and (c) multiple 
hot-cool flame transitions. These flames involve 30 vol% n-butane flowing at 1.5 mg/s 
into (a) 37.9, (b) 39.5, and (c) 39.9 vol% O2 at 300 K. The pressure for (a) is 0.5 bar 
whereas that for (b) and (c) is 2.0 bar.
~~~~

### Pagina 46

Cita: [pdf_f6cce7cc08ca69c15599, p. 46]. Metodo: native.

Calidad: figures_not_digitized, table_structure_not_manually_validated.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
46
Table 3. Summary of the cool flame tests
test pt.1 XO2 Xf
p
(bar)
𝑚̇
2
(mg/s)
flame 
duration 
(sec)
rhf
(mm)
rcf
(mm)
rhf/rcf
21174C3 0.395 0.300 2.03 1.50 13.9 17.6 7.6 2.3
21174C4 0.394 0.300 2.03 1.00 13.8 14.6 5.3 2.8
21174C6 0.385 0.300 2.03 0.75 14.3 12.4 5.1 2.4
21174D13 0.392 0.300 2.03 1.00 - 13.9 - -
21174F1 0.390 0.300 2.03 1.50 13.8 17.4 7.5 2.3
21291A1-1 0.399 0.300 2.03 1.50 10.9 17.2 7.1 2.4
21291A1-2 0.399 0.300 2.03 1.50 3.4 17.3 6.5 2.7
21291A1-3 0.399 0.300 2.03 1.50 3.8 17.6 6.3 2.8
21291A1-4 0.399 0.300 2.03 1.50 4 17.6 6.2 2.8
21291A1-5 0.399 0.300 2.03 1.50 3.7 17.7 6.2 2.9
21291C1-1 0.394 0.300 2.03 1.00 6.2 14.4 5.1 2.8
21291C1-2 0.394 0.300 2.03 1.00 5.8 14.9 5.5 2.7
21291C1-3 0.394 0.300 2.03 1.00 5.5 14.7 5.7 2.6
21291C1-4 0.394 0.300 2.03 1.00 5.4 14.9 5.7 2.6
21291C1-5 0.394 0.300 2.03 1.00 5.3 14.4 5.5 2.6
1 Subnumbers after a dash represent the sequential order of reignited hot flames and following 
cool flames during a single test.
2 Hydrocarbon mass flow rate. 
3 The cool flame radius could not be evaluated due to low camera gain.
L. Communication Imagery
1. Still Imagery
Photos are available online at www.flickr.com/photos/space-flames. Although the 
Facebook page at www.facebook.com/space.flames is meant to provide updates on 
ACME and related combustion research, it is good source for recent photos, e.g., of 
Fig. 2. Images of (a) a hot flame and (b) a cool flame at test point 21174C3. The dashed 
circle represents the gas-fed porous sphere burner. These images were converted from 
the grayscale camera output to the expected blue colors shown here.
~~~~

### Pagina 47

Cita: [pdf_f6cce7cc08ca69c15599, p. 47]. Metodo: native.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
47
flames, that may not be available on the Flickr site. Additional photographs may be 
requested from the Project Scientist, Dennis Stocker (dennis.p.stocker@nasa.gov).
2. Video
‘The Power of Studying Combustion on the ISS,’ which was developed with input from 
the ACME Project Scientist, is available at https://science.nasa.gov/science￾news/news-articles/the-power-of-studying-combustion-on-the-iss.
Video(s) describing the ACME project can be found at 
https://www1.grc.nasa.gov/space/iss-research/iss-fcf/cir/acme/.
Videos related to CFI-G and other microgravity combustion research can also be seen 
on Facebook at www.facebook.com/space.flames.
Contact Dennis Stocker (dennis.p.stocker@nasa.gov) for access to those videos or for 
additional videos.
VIII. Additional Comments from science team
None.
~~~~

### Pagina 48

Cita: [pdf_f6cce7cc08ca69c15599, p. 48]. Metodo: native.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
48
Appendix D. Operational Timeline
This summary timeline of CFI-G operations was prepared by Dennis Stocker, where the red text indicates 
the key days when flames were ignited. The dates were based on plans, where it is possible that the dates 
for some simple tasks, e.g., hardware gather or stowage, may have shifted slightly.
The timeline also includes the launch and landing of spacecraft crews who supported the CFI-G operations.
Date GMT Activity
CFI-G (first round, normal flames)
2020
Oct. 14 288 Launch of Kud-Sverchkov, Rubins, and Ryzhikov
Nov. 15 320 Launch of Glover, Hopkins, Noguchi, and Walker
2021
March 9-10 068-069 ACME chamber insert reconfigured for CFI-G by Rubins
March 11 070 Hardware stow by Rubins; Mass Flow Controller (MFC) testing & tuning
March 16 075 Bottle swaps, etc. by Hopkins
March 29 088 CFI-G tests using 100% C2H6
April 9 099 Bottle swap by Hopkins; launch of Dubrov, Novitsky, and Vande Hei
April 12-13 102-103 CFI-G tests using 50% n-C4H10 (with ops planned past midnight EDT)
April 16 106 CFI-G tests using 50% n-C4H10
April 17 107 Landing of Kud-Sverchkov, Rubins, and Ryzhikov
April 19 109 Bottle swaps by Hopkins
April 22 112 CFI-G tests using 100% C3H8
April 23 113 Launch of Hoshide, Kimbrough, McArthur, and Pesquet
April 28 118 Fuel MFC swap by Kimbrough
April 29 119 Bottle swap by Kimbrough
May 2 122 Landing of Glover, Hopkins, Noguchi, and Walker
May 5 125 CFI-G tests using 30% n-C4H10
May 6 126 Hardware gather by Vande Hei
May 7 127 Bottle swaps by Vande Hei
May 10-11 130-131 CFI-G tests using 30% C3H8 (with ops planned past midnight EDT)
May 17 137 CFI-G tests using 30% C3H8
May 18 138 IPSU1 swap by McArthur
May 20 140 Imaging checkout
May 25 145 Bottle swaps by McArthur
June 2 153 CFI-G tests using 30% C2H6 (with ops planned until midnight EDT)
June 8 159 Bottle swap by Kimbrough
June 11-12 162-163 CFI-G tests using 30% C2H6 (with ops planned past midnight EDT)
June 14 165 Bottle swaps by Vande Hei
June 23 174 CFI-G tests using 30% n-C4H10
~~~~

### Pagina 49

Cita: [pdf_f6cce7cc08ca69c15599, p. 49]. Metodo: native.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
49
CFI-G (second round, inverse flames except for the final test day)
2021
July 2 183 ACME chamber insert reconfigured for inverse-flame tests by Vande Hei
July 7 188 MFC testing & tuning
July 9 190 MFC testing & tuning
July 12 193 Bottle swaps by McArthur
July 15-16 196-197 CFI-G tests using C2H6 (with ops planned past midnight EDT)
July 19 200 Bottle swap by McArthur
July 21-22 202-203 CFI-G tests using C2H6 (with ops planned past midnight EDT)
July 26 207 Bottle swap by McArthur
July 28-29 209-210 CFI-G tests using C2H6 (with ops planned past midnight EDT)
Aug. 2 214 Bottle swaps by Vande Hei
Aug. 3 215 Bottles opened by Kimbrough
Aug. 4-5 216-217 CFI-G tests using C2H6 (with ops planned past midnight EDT)
Aug. 10-11 222-223 Bottle swaps by Vande Hei; CFI-G tests using C3H8 (with ops past midnight)
Aug. 16 228 Bottle swap by Vande Hei; CFI-G tests using C3H8
Aug. 20 232 Bottle swap by Kimbrough
Aug. 23 235 Bottle swap by Kimbrough; CFI-G tests using C3H8
Aug. 30-31 242-243 Bottle swap by Vande Hei; CFI-G tests using C3H8 (with ops past midnight)
Sept. 8 251 Igniter tip replacement by Vande Hei
Sept. 10 253 IPSU-G hard drive replacement by Vande Hei; no-flame check-out
Sept. 13-14 256-257 Bottle swap by McArthur; CFI-G tests using n-C4H10 (ops past midnight)
Sept. 20 263 Bottle swap by McArthur
Sept. 22 265 Bottle swap by McArthur; CFI-G tests using n-C4H10
Sept. 27-28 270-271 Bottle swap by Kimbrough; CFI-G tests using n-C4H10 (ops past midnight)
Oct. 4-5 277-278 Bottle swap by Vande Hei; CFI-G tests using n-C4H10 (ops past midnight)
Oct. 5 278 Launch of Shkaplerov
Oct. 12 285 ACME chamber insert reconfigured for normal-flame tests by McArthur
Oct. 13 286 Bottle swaps by Kimbrough
Oct. 14 287 Bottle swap by McArthur
Oct. 17 290 Landing of Novitsky
Oct. 18 291 CFI-G normal-flame tests using 30% C3H8 (with ops planned until midnight)
Nov. 8 312 Landing of Hoshide, Kimbrough, McArthur, and Pesquet
2022
March 30 089 Landing of Dubrov, Shkaplerov, and Vande Hei
~~~~

### Pagina 50

Cita: [pdf_f6cce7cc08ca69c15599, p. 50]. Metodo: native.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
50
Appendix E. Astronauts who Conducted ISS Operations for CFI-G
This list was prepared by Dennis Stocker from his log of ACME operations.
The CFI-G experiment was supported by five NASA astronauts, including three men and two women. They 
are listed by the number of days in which they conducted supporting on-orbit activities and alphabetically. 
Crew members from partner agencies were not involved (at least directly) in the research. 
Crew member Year Day(s) of year # days
Vande Hei, Mark (NASA) 2021 126, 127, 165, 183, 214, 222, 228, 242, 251, 253, 277 11
McArthur, K. Megan (NASA) 2021 138, 145, 193, 200, 207, 256, 263, 265, 285, 287 10
Kimbrough, Shane (NASA) 2021 118, 119, 159, 215, 232, 235, 270, 286 8
Hopkins, Mike (NASA) 2021 075, 099, 109 3
Rubins, Kate (NASA) 2021 068-069, 070 3
The early CFI-G tasks were carried out by Kate Rubins and Mike Hopkins, but most of the on-orbit work 
was undertaken by Mark Vande Hei, Megan McArthur, and Shane Kimbrough. Additional information 
about the crew activity can be seen in Appendix D and some of the subsequent appendices.
~~~~

### Pagina 51

Cita: [pdf_f6cce7cc08ca69c15599, p. 51]. Metodo: native.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
51
Appendix F. ISS Operations per the Payload Weekly Science Summary
2021 (for all of CFI-G)
First round (normal flames)
Increment 64
Week 21: March 5-11 
On GMT 062, the final test points were performed for ACME CLD Flame (Coflow Laminar Diffusion). The 
Principal Investigator, Marshall Long from Yale University, considers the experiment to have been very 
successful. On this day, 11 flames were ignited, which contributed to the over 300 that were ignited for 
all of CLD Flame. Early results show that the dilution limits are extended in microgravity compared to 
normal gravity. Steady microgravity flames are also more stable and have lower lift-off heights due to the 
lack of buoyancy. We have gathered a superior set of experimental data to be used for improving our 
ability to computationally model highly diluted flames. This capability could be implemented in design 
tools resulting in more efficient and less polluting combustion here on Earth.
On GMT 068 & 069, Kate Rubins configured the ACME Chamber Insert to support the next ACME 
experiment, CFI-G Part 1 (Cool Flames Investigation with Gases). CFI-G will study flames with unusually 
low temperatures known as cool flames. These flames were discovered in 2012 with the first subrack 
payload to use CIR, but this investigation only used liquid fuels. ACME’s hardware will allow CFI-G to study 
gaseous fuels to gain valuable insight into the combustion processes in engines.
The time-lapse CLD Flame image associated with this submission is not included in this report.
Week 22: March 12-18 
On GMT 075, Mike Hopkins lubricated the CIR GC Argon QDs and replaced the gas bottles at CIR Manifold 
#2 and CIR Manifold #4. These tasks prepared the CIR for supporting the next ACME experiment, CFI-G 
Part 1 (Cool Flames Investigation with Gases). CFI-G will study flames with unusually low temperatures 
known as cool flames. These flames were discovered in 2012 with the first subrack payload to use CIR, but 
this investigation only used liquid fuels. ACME’s hardware will allow CFI-G to study gaseous fuels to gain 
valuable insight into the combustion processes in engines.
Week 24: March 26 – April 1
On GMT 088, the first test points were performed for ACME CFI-G Part 1 (Cool Flames Investigation with 
Gases) with 14 ethane flames, sometimes diluted with nitrogen, ignited in various oxygen/nitrogen 
atmospheres. CFI-G studies flames with unusually low temperatures known as cool flames, which were 
discovered in 2012 with droplet combustion research being conducted in CIR at the time. That experiment 
burned liquid fuel droplets, which shrink as they burn. Instead, CFI-G will burn gaseous fuel ejected from 
a porous spherical burner to investigate cool flames under quasi-steady conditions. Cool flame chemical 
kinetics are important to ignition and the results could lead to cleaner burning and more efficient internal 
combustion engines.
~~~~

### Pagina 52

Cita: [pdf_f6cce7cc08ca69c15599, p. 52]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
52
Figure 1. Preliminary False-Colored Image of Hot Ethane Flame for CFI-G
This false-colored image shows a spherical flame, which is only possible in microgravity without the 
buoyant flows created by Earth’s gravity. Spherical flames greatly simplify experimental analysis by 
reducing the flame structure to a single dimension, which allows computational models to focus on 
chemical kinetics and transport phenomena. 
The hot flame in Figure 1 has a hole at the bottom because of heat loss to the fuel tube, which supplies 
the ethane to the porous sphere. The three bright lines passing through the flame are 14-micron ceramic 
fibers, which were translated into the flame to determine temperature measurements from the color of 
the glowing fibers. Residual soot clusters, like the fibers, are glowing because of their high temperature. 
These soot clusters were “pushed” to the bottom half of the flame by the insertion of the fibers.
Week 26: April 9-15
On GMT 102, nine nitrogen-diluted butane flames were ignited for ACME CFI-G (Cool Flames Investigation 
with Gases). Non-premixed (i.e., fuel and oxidizer are not mixed prior to reacting) cool flames were 
discovered in 2012 with CIR droplet combustion research using liquid fuels. CFI-G’s goal is to study non￾premixed cool flames using gaseous fuels, which have not been observed before and so far have not been 
observed in CFI-G testing. It is still possible that they may be detected in a more thorough review of the 
data. Whether cool flames are present or not, we are still acquiring useful results, such as data about soot 
processes.
CAPTION TO VIDEO, WHICH IS NOT INCLUDED IN THIS LOG
In this test point video, a bright, sooty spherical flame is ignited with a retracting hot-wire igniter. 
Due to microgravity, the soot remains in the flame longer and forms clusters. Many clusters 
escape the flame while trapped soot eventually fades as it cools. 
On its right side, the flame starts to open due to heat loss to the burner’s fuel supply tube. With 
increasing heat loss, the flame nearly extinguishes, which creates a larger hole. This large hole in 
the flame shell allows for the direct mixing of the fuel and oxygen, which causes the flame to
~~~~

### Pagina 53

Cita: [pdf_f6cce7cc08ca69c15599, p. 53]. Metodo: native.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
53
momentarily reestablish. After a few oscillations, the hot flame extinguishes. The results from this 
and the other tests will be carefully reviewed to look for evidence of cool flame behavior.
Increment 65
Week 2: April 16-22
On GMT 106, additional tests were performed with nitrogen-diluted butane for ACME CFI-G (Cool Flames 
Investigation with Gases). While last week’s tests with this fuel were performed at a chamber pressure of 
1 atm, this week’s tests were performed at half that pressure. Ten hot flames were ignited, and the data 
is being analyzed to determine if a cool flame occurred after the hot flame extinguished. In 13 other tests, 
data is being analyzed to determine if a cool flame was ignited directly with a low-energy ignition. 
Meanwhile, the data collected from the hot flames contribute to an earlier ACME experiment, Flame 
Design, which only tested with ethylene fuel. On GMT 109, Mike Hopkins replaced the gas bottles at CIR 
Manifold #2 and CIR Manifold #4 to support continuation of CFI-G test points.
CAPTION TO VIDEO, WHICH IS NOT INCLUDED IN THIS LOG
This clip from a test point video shows a 50% butane flame ignited in a chamber atmosphere with 
elevated oxygen at 0.5 atm. The flame is bright and sooty, where the soot is formed when the fuel 
molecules within the flame combine in the absence of oxygen, which is outside the flame. The 
flame is like a bubble that separates the two reactants. The flame shell, like the film of the bubble, 
is a thin sheet where the fuel and oxygen come together and react, producing heat, light, carbon 
dioxide, and water vapor.
Due to microgravity, the soot remains in the flame longer and forms clusters. Some of these soot 
clusters escape the flame—being pushed by the outward flow of the fuel from the burner. Others 
are trapped in the flame as a temperature gradient drives them away from the flame shell and 
toward the cooler burner. These opposing forces cause some soot clusters to just “dance” in 
place.
After the video clip ends, the soot continues to fade as the flame temperature drops, where hardly 
any soot remained when the flame extinguished.
Week 3: April 23-29
On GMT 112, ACME CFI-G (Cool Flames Investigation with Gases) test points were performed using 
propane fuel. Flames with unusually low temperatures, known as cool flames, were discovered in 2012 
with CIR droplet combustion research using liquid fuels. CFI-G’s goal is to study cool flames using gaseous 
fuels to gain valuable insight into the combustion processes in engines. On GMT 118 and 119, Shane 
Kimbrough replaced an ACME controller and the gas bottle at CIR Manifold #4 to support continuation of 
CFI-G test points.
Week 4: April 30 – May 6
On GMT 125, ACME CFI-G (Cool Flames Investigation with Gases) test points were performed using 
nitrogen-diluted butane fuel at both elevated and normal oxygen concentrations. The data is being 
analyzed to determine if the elusive and hard-to-detect cool flames were burning after the hot flames 
extinguished or if they ignited directly. Regardless, the testing is providing valuable results that will add 
to our understanding of flammability limits and soot production, clustering, and oxidation.
~~~~

### Pagina 54

Cita: [pdf_f6cce7cc08ca69c15599, p. 54]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
54
CFI-G studies flames with unusually low temperatures known as cool flames, which were discovered in 
2012 with droplet combustion research being conducted in CIR at the time. That experiment burned liquid 
fuel droplets, which shrink as they burn. Instead, CFI-G will burn gaseous fuel ejected from a porous 
spherical burner to investigate cool flames under quasi-steady conditions. Cool flame chemistry is 
important to ignition, and the results could lead to cleaner burning and more efficient internal combustion 
engines.
Figure 1. CFI-G Hot Flame of Nitrogen-Diluted Butane
Figure 1 shows a hot flame of nitrogen-diluted butane in an atmosphere of elevated oxygen. The porous 
spherical burner of sintered stainless-steel sits on top of the tube that supplies the gaseous fuel. The blue 
flame shell is spherical, which is only possible in microgravity without the buoyant flows created by Earth’s 
gravity. Spherical flames greatly simplify experimental analysis by reducing the flame structure to a single 
dimension, which allows computational models to focus on the chemistry and transport phenomena 
rather than the prediction of the flame shape. 
The yellow particles are clusters of soot. Their color is the result of thermal radiation and is indicative of 
their temperature. Soot is formed when the fuel molecules within the flame combine in the absence of 
oxygen, which is outside the flame. The flame is like a bubble that separates the two reactants. The flame 
shell, like the film of the bubble, is a thin sheet where the fuel and oxygen come together and react, 
producing heat, light, carbon dioxide, and water vapor.
Due to microgravity, the soot remains in the flame longer and forms clusters. Some of these soot clusters 
escape the flame because they are pushed by the outward flow of the fuel from the burner. Others are 
trapped in the flame as a temperature gradient drives them away from the flame shell and toward the 
cooler burner.
Week 5: May 7-13
On GMT 130, ACME CFI-G (Cool Flames Investigation with Gases) test points were performed using 
nitrogen-diluted propane fuel at chamber pressures of both 2 and 3 atm. Fifteen hot flames were ignited.
~~~~

### Pagina 55

Cita: [pdf_f6cce7cc08ca69c15599, p. 55]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
55
Figure 1. CFI-G Hot Flame of Nitrogen-Diluted Propane
Figure 1 shows images of a CFI-G hot flame from two different cameras. The left image is from a color 
camera. The right image, which has been false-colored, is from an intensified camera filtered for 
formaldehyde (CH2O) emissions, which are associated with cool flame chemistry. When cool flames were 
first discovered in 1809, Sir Humphrey Davy observed a “pale phosphorescent light.” 
Residual soot created during ignition escapes from opposite sides of the flame. In the right image, soot is 
visible as light spots, such as at the top of the porous sphere.
Week 6: May 14-20
On GMT 137, ACME CFI-G (Cool Flames Investigation with Gases) test points were performed using 
nitrogen-diluted propane fuel in elevated oxygen concentrations (about 40%). These tests were 
performed at a chamber pressure of 1 atm, while last week’s tests with this fuel were performed at 2 and 
3 atm. Twelve hot flames were ignited.
Figure 1. CFI-G Hot Flame of Nitrogen-Diluted Propane
~~~~

### Pagina 56

Cita: [pdf_f6cce7cc08ca69c15599, p. 56]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
56
Figure 1 shows a hot flame of nitrogen-diluted propane in an atmosphere of elevated oxygen. At ignition, 
this flame was bright yellow from the soot, but the soot diminished over time due to radiative heat loss. 
In the absence of buoyancy, the soot remained in the flame longer and formed the large clusters seen in 
Figure 1. By the time the flame extinguished, the soot had largely faded away. The porous spherical burner 
of sintered stainless-steel sits on top of the tube that supplies the gaseous fuel. The opening in the bottom 
of the flame is due to heat loss to the tube.
Week 7: May 21-27
On GMT 138, Megan McArthur replaced a failing FCF IPSU (Image Processing and Storage Unit) on the 
back of the CIR Optics Bench. Later in the week, we powered up the new IPSU and its associated camera 
package. The checkout was successful! On GMT 145, Megan replaced the gas bottles at CIR Manifold #2 
and CIR Manifold #4 to support continuation of CFI-G test points.
Week 8: May 28 – June 3
On GMT 153, 14 nitrogen-diluted ethane flames were ignited for ACME CFI-G (Cool Flames Investigation 
with Gases) in atmospheres ranging between 30-40% oxygen with pressures of both 0.5 and 2 atm.
Figure 1. False-colored Image of a CFI-G Flame with Residual Soot Clusters
Figure 1 shows a hot flame of nitrogen-diluted ethane in an atmosphere with elevated oxygen and 
pressure. Initially, the flame was bright yellow with soot, and over time some of the soot escaped from 
the flame. This preliminary false-colored image is from later in the test, where residual soot clusters were 
still visible within the flame when it self-extinguished due to excessive heat loss.
Week 9: June 4-10
On GMT 159, Shane Kimbrough replaced the gas bottle at CIR Manifold #2 to support continuation of CFI￾G test points.
~~~~

### Pagina 57

Cita: [pdf_f6cce7cc08ca69c15599, p. 57]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
57
Week 10: June 11-17
On GMT 162, 12 nitrogen-diluted ethane flames were ignited for ACME CFI-G (Cool Flames Investigation 
with Gases) at ambient pressures. Some tests were performed in atmospheres with 21% oxygen, while 
some tests were performed in higher oxygen concentrations of 35-40%. During two tests, the 14-micron 
ceramic fibers were translated into the flame to optically measure the flame temperature through a 
technique known as Thin Filament Pyrometry (TFP). On GMT 165, Mark Vande Hei replaced the gas bottles 
at CIR Manifold #2 and CIR Manifold #4 to support continuation of CFI-G test points.
Figure 1. Flame Temperature Measurement of CFI-G Hot Flame
Figure 1 shows two images of the same nitrogen-diluted ethane flame. The right-hand image has been 
enhanced to show the faint spherical flame. The color of the fibers’ glow in the left-hand image is 
indicative of the temperature, where yellow is hotter than orange, which in turn is hotter than red. Using 
a camera characterized for quantitative measurements, we can determine a radial temperature 
distribution across the flame by analyzing the color variation along the length of a fiber.
The top fiber is outside of the flame. Its glow can be used to determine the temperature near the flame, 
where it is obviously cooler despite its proximity. The fibers that pass through the flame are much brighter 
except for their centers, which are dimmer and cooler. The flame shell separates the fuel and the oxygen, 
where the heat, light, carbon dioxide, and water vapor are created at its surface, so the flame is hottest 
at its shell.
Week 11: June 18-24
On GMT 174, we ignited 16 nitrogen-diluted butane flames in the final tests for the first round of ACME 
CFI-G (Cool Flames Investigation with Gases). Cool flames remained elusive, where there has been no clear 
evidence of these low-temperature phenomena during this round of testing. In the coming weeks and 
months, we will review the data more closely to assess their potential presence. Regardless, we gathered 
a wealth of valuable data that will improve our fundamental understanding of soot process and flame
dynamics. Since CFI-G tested with different fuels, these data expand upon the results gained from the 
other ACME experiments. 
Next week, the ACME Chamber Insert will be configured to support the second and final round of CFI-G 
testing. This testing will explore the potential existence of cool flames in an inverse configuration. The 
flow direction will be reversed, where a mixture of nitrogen and oxygen will flow from the burner into the 
Combustion Chamber, which will be filled with a mixture of nitrogen and gaseous fuel. As a result, the 
flames will be inside out, where, as an example, the soot will be formed outside of the flame.
~~~~

### Pagina 58

Cita: [pdf_f6cce7cc08ca69c15599, p. 58]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
58
CAPTION TO VIDEO, WHICH IS NOT INCLUDED IN THIS LOG
In this test point video, soot that forms at ignition escapes from the flame, especially opposite of 
the burner’s supply tube (toward the left). The escaping soot clusters exacerbate the heat loss 
experienced by the flame and cause it to locally quench, creating a hole in the flame. This hole 
allows for direct mixing of the fuel and oxygen, which are normally separated by the flame, 
thereby enhancing flammability. As a result, the flame reforms, closing the hole, but it opens again 
due to heat loss. This repeated opening and closing of the flame creates a visually dramatic flame 
that swirls around the porous spherical burner.
Second round (inverse flames except for the final test day)
Week 12: June 25 – July 1
Recent data analysis shows evidence of cool flames! 
Data from several of the ACME CFI-G (Cool Flames Investigation with Gases) tests on GMT 174 indicate 
the presence of cool flames. These tests were performed at a chamber pressure of 2 atm with nitrogen￾diluted butane fuel. Cool flames give off little heat or light and were too faint to be visible real time during 
testing. But their presence was revealed by thermal radiation and burner temperature measurements 
after the hot flames quenched.
Non-premixed (i.e., fuel and oxidizer are not mixed prior to reacting) cool flames were discovered in 2012 
with CIR droplet combustion research using liquid fuels. Now, we’ve achieved non-premixed cool flames 
using gaseous fuels! Cool flame chemistry is important to ignition and the results could lead to vehicles 
that experience less wear on engine parts, get better gas mileage, and create less pollution.
Figure 1. Time Sequence from CFI-G Hot Flame to Cool Flame
~~~~

### Pagina 59

Cita: [pdf_f6cce7cc08ca69c15599, p. 59]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
59
The images in Figure 1 are from an intensified camera filtered to look for the very faint emissions of a cool 
flame (associated with the excited formaldehyde molecule, CH2O*). The sequence shows the quenching 
of the hot flame due to radiative heat loss, followed by a comparatively dark period lasting roughly a 
second, after which the cool flame becomes evident. As expected, the cool flame is much smaller than 
the hot flame. The dark center in each cool flame image is the porous spherical burner and its fuel supply 
tube can be seen extending to the right.
Week 13: July 2-8
On GMT 183, Mark Vande Hei configured the ACME Chamber Insert to support CFI-G Part 2 (Cool Flames 
Investigation with Gases). CFI-G studies flames with unusually low temperatures known as cool flames. 
Part 2 testing will explore the potential existence of cool flames in an inverse configuration. The flow 
direction will be reversed, where a mixture of nitrogen and oxygen will flow from the burner into the 
Combustion Chamber, which will be filled with a mixture of nitrogen and gaseous fuel. As a result, the 
flames will be inside out, where, as an example, the soot will be formed outside of the flame. Cool flame 
chemistry is important to ignition and the results could lead to vehicles that experience less wear on 
engine parts, get better gas mileage, and create less pollution.
Week 14: July 9-15
On GMT 193, Megan McArthur replaced the gas bottles at CIR Manifold #2 and CIR Manifold #4 to support 
the start of CFI-G Part 2 (Cool Flames Investigation with Gases) test points.
Week 15: July 16-22
On GMT 196, the first test points were performed for ACME CFI-G Part 2 (Cool Flames Investigation with 
Gases), where inverse flames were ignited in space for the first time. We ignited seven sustained inverse 
flames with diluted ethane fuel at both elevated and reduced pressures. With inverse flames, the diluted 
oxygen flows from the burner into a chamber filled with diluted gaseous fuel. As a result, inverse flames 
are inside out, where, as an example, the soot is formed outside rather than inside the flame. On GMT 
200, Megan McArthur replaced the gas bottle at CIR Manifold #4 to support continuation of CFI-G Part 2 
(Cool Flames Investigation with Gases) test points.
Figure 1. CFI-G Inverse Flame of Nitrogen-Diluted Ethane
~~~~

### Pagina 60

Cita: [pdf_f6cce7cc08ca69c15599, p. 60]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
60
Figure 1 shows a bright blue, spherical inverse flame. The porous spherical burner of sintered stainless￾steel sits on top of the tube that typically supplies gaseous fuel for normal flames. Instead, for inverse 
flames it supplies oxygen, which may be diluted with nitrogen.
Week 16: July 23-29
On GMT 202, we ignited 11 inverse flames for CFI-G Part 2 (Cool Flames Investigation with Gases). For 
these tests, an oxygen/nitrogen mixture flowed from the burner into the Combustion Chamber filled with 
an ethane/nitrogen mixture. We observed that flames in 12% ethane burned longer than those in 6% 
ethane. Tests were performed at a chamber pressure of both 1 and 2 atm, and some tests used the array 
of 14-micron ceramic fibers to make flame temperature measurements. On GMT 207, Megan McArthur 
replaced the gas bottle at CIR Manifold #4 to support continuation of CFI-G Part 2 test points.
Figure 1. Composite Image of CFI-G Inverse Flames at Increasing Oxidizer Flow Rates
Figure 1 compares the flames from three tests with different flow rates of oxidizer from the burner. The 
flame size is dependent on the limiting reactant, which for inverse flames is the oxygen.
The porous spherical burner and its supply tube are visible within each spherical flame. Heat loss to the 
supply tube causes the flame to locally quench and creates an opening. This opening leads to direct mixing 
of the reactants, which would otherwise be separated by the flame shell. Mixing enhances the combustion 
and brightens the flame at the opening.
Week 17: July 30 – Aug. 5
On GMT 209 and 216, we ignited 23 inverse flames in a Combustion Chamber filled with ethane and 
nitrogen for CFI-G Part 2 (Cool Flames Investigation with Gases). These two test days ignited flames in 
different fuel concentrations and pressures while an oxygen/nitrogen mixture flowed from the porous 
spherical burner. We gained valuable information about the conditions that influence soot formation. On 
GMT 214, Mark Vande Hei replaced the gas bottles at CIR Manifold #2 and CIR Manifold #4. On GMT 215, 
Shane Kimbrough opened the valves on these two bottles. These tasks were performed to support 
continuation of CFI-G Part 2 test points.
CAPTION TO VIDEO, WHICH IS NOT INCLUDED IN THIS LOG
This test point video of a CFI-G inverse flame is at 3x normal speed. The flame is initially blue but 
overtime an orange band appears just outside the flame. This orange band is made up of soot 
particles, which are black but glow because of their high temperature—just like metal in a forge.
~~~~

### Pagina 61

Cita: [pdf_f6cce7cc08ca69c15599, p. 61]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
61
The soot is formed when the fuel, at a high temperature, reacts with itself in the absence of 
oxygen. The temperature is highest at the flame’s surface, and for inverse flames, the fuel is 
outside the flame. Therefore, in this test, the soot forms just outside the flame.
The glowing soot doesn’t fully encompass the flame because of heat loss to the burner’s supply 
tube and because the flow from the burner is not quite uniform. However, in this instance, these 
shortcomings reveal the sensitivity of soot formation to temperature, residence time, and 
reactant mixture.
Week 18: Aug. 6-12
On GMT 222, Mark Vande Hei replaced the gas bottle at CIR Manifold #4 to support CFI-G Part 2 (Cool 
Flames Investigation with Gases). We then ignited seven inverse flames in a Combustion Chamber filled 
with propane and nitrogen. These sustained flames flowed oxygen/nitrogen mixtures over a broad range 
of concentrations from the spherical burner into the fuel-filled chamber. The testing today was limited to 
conserve the oxidizer for upcoming tests with a higher propane concentration but lower chamber 
pressure.
Figure 1. Comparison inverse flame tests with the same oxygen flow, 
but a greater nitrogen flow on the right.
This image compares two CFI-G inverse flames that had the same oxygen flow rate, but where the flame 
on the right had a greater nitrogen flow rate, making the oxygen more dilute and the total flow rate 
greater. The chamber had been filled to 3 atm with propane and nitrogen. The flames, photographed 
with an intensified camera, are similar in size. Flame size is determined by access to sufficient fuel to 
consume the oxygen, which was at the same flow rate in both cases.
Week 19: Aug. 13-19
On GMT 228, Mark Vande Hei replaced the gas bottle at CIR Manifold #4 to support CFI-G Part 2 (Cool 
Flames Investigation with Gases). We then ignited sixteen sustained inverse flames in a Combustion 
Chamber filled with propane and nitrogen at two different pressures. The test parameters included
~~~~

### Pagina 62

Cita: [pdf_f6cce7cc08ca69c15599, p. 62]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
62
varying the concentration ratios of the oxygen/nitrogen mixture flowing from the burner and the flow 
rates.
Figure 1. Composite Image of CFI-G Inverse Flames at Increasing Flow Rates
This composite image compares inverse flames with multiples of oxygen/nitrogen flow rates from the 
porous spherical burner faintly seen within the flames. The oxygen flows outward until it reaches sufficient 
fuel to be consumed. As such, the tests with the greater oxidizer flow rates result in larger flames. 
Radiative heat loss scales with flame size, and the larger flames are dimmer than the smaller flames. The 
oxygen/nitrogen ratio, propane concentration, and Combustion Chamber pressure were consistent in this 
trio of tests. 
These flames are locally quenched by heat loss to the burner’s supply tube leaving an opening in the flame. 
The opening, which allows reactant mixing, often oscillates in size while growing until the flame fully 
extinguishes. In some tests the extinction occurs abruptly, but in others the oscillations can last for tens 
of seconds. Meanwhile, some flames are quasi-steady despite the opening. This is one example of how 
these spherical flames are not as simple as had earlier been imagined.
Week 20: Aug. 20-26
Shane Kimbrough replaced the gas bottle at CIR Manifold #2 on GMT 232 and the gas bottle at CIR 
Manifold #4 on GMT 235 to support CFI-G Part 2 (Cool Flames Investigation with Gases). We then ignited 
eight sustained inverse flames in a Combustion Chamber filled with a 20% propane mixture at two 
different pressures. These tests also varied the flow rate and concentration ratio of the oxygen/nitrogen 
mixture flowing from the burner.
CAPTION TO VIDEO, WHICH IS NOT INCLUDED IN THIS LOG
This clip from the beginning of a test point video shows an inverse flame that is initially sooty, but 
the soot quickly fades away as the flame temperature drops. With inverse flames, the fuel is 
outside the flame, so that is where the soot forms. Soot is created when the fuel in the chamber, 
heated to a high temperature by the flame, combines in the absence of oxygen, which is inside 
the flame.
The flame cools due to both radiative heat loss and conductive heat loss to the burner, especially 
to the tube supplying the oxygen/nitrogen mixture. The soot lasts the longest away from the 
supply tube where the flame is hottest. To visibly glow due to their temperature, materials must
~~~~

### Pagina 63

Cita: [pdf_f6cce7cc08ca69c15599, p. 63]. Metodo: native.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
63
be about 800 K. Therefore, if it’s not hot enough for soot to glow, then it’s also not hot enough 
for the fuel to combine and then form the soot.
Week 21: Aug. 27 – Sept. 2
On GMT 242, Megan McArthur replaced the gas bottle at CIR Manifold #4 to support CFI-G Part 2 (Cool 
Flames Investigation with Gases). We then ignited only two inverse flames before a hard drive failure in 
the FCF Image Processor, which processes and stores our image data. Then, during the end-of-the-day 
check, we discovered that the igniter tip had burned out as well. 
This day was our fourth day of testing with inverse propane flames, and we have yet to see evidence of 
cool flames with this fuel. After the hardware is replaced, we will start inverse-flame testing with butane—
the fuel with which cool flames were discovered in earlier normal-flame testing.
CAPTION TO VIDEO, WHICH IS NOT INCLUDED IN THIS LOG
In this test point video, the bright soot shell that surrounds the propane flame hides the spherical 
burner. The high temperature of the flame is revealed when it extinguishes, and you can see the 
burner glowing because of its high temperature. The test point automatically stops when the 
burner reaches 650 °C. Materials start glowing because of their temperature at about 525 °C (the 
Draper point).
Week 22: Sept. 3-9
On GMT 251, Mark Vande Hei replaced the burnt-out igniter tip for CFI-G Part 2 (Cool Flames Investigation 
with Gases). Following replacement of the FCF Image Processor failed hard drive later this week, we’ll 
return to performing CFI-G test points.
Week 23: Sept. 10-16
On GMT 253 on the back of the CIR Optics Bench, Mark Vande Hei replaced the failed hard drive in the 
FCF Image Processor. Afterwards, the CIR was powered up and a checkout of the new hard drive and 
igniter tip was successful. On GMT 256, Megan McArthur replaced the gas bottle at CIR Manifold #4 to 
support CFI-G Part 2 (Cool Flames Investigation with Gases). We then ignited 17 inverse flames in a 
Combustion Chamber filled with nitrogen and butane at two different concentrations. Tests were 
performed at a chamber pressure of about 2 atm, and we varied the oxygen concentration and oxidizer 
flow rate from the burner into the fuel-filled chamber. A couple tests also used the array of 14-micron 
ceramic fibers to make flame temperature measurements.
~~~~

### Pagina 64

Cita: [pdf_f6cce7cc08ca69c15599, p. 64]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
64
Figure 1. CFI-G Inverse Flames at Increasing Oxidizer Flow Rate and Butane Concentrations
This composite image shows the effects of both the oxidizer flow rate from the burner and the butane 
concentration on the inverse flames. The oxygen concentration was held constant in these four tests. 
From bottom to top, the oxidizer flow rate was doubled, which greatly impacted the flame size. From left 
to right, the ~20% increase in the butane concentration had a more subtle effect. At the higher fuel 
concentration, the flames are slightly smaller and much brighter.
Week 24: Sept. 17-23
Megan McArthur replaced the gas bottle at CIR Manifold #2 on GMT 263 and the gas bottle at CIR Manifold 
#4 on GMT 265 to support CFI-G Part 2 (Cool Flames Investigation with Gases). We then ignited 15 inverse 
flames in a Combustion Chamber filled with butane and nitrogen while an oxygen/nitrogen mixture 
flowed from the porous spherical burner. Tests were performed at a chamber pressure of 3 atm, and we 
varied the oxidizer flow rate and oxygen/nitrogen ratio.
Figure 1. Effects of Oxidizer Flow Rate from the Burner on CFI-G Inverse Flames
~~~~

### Pagina 65

Cita: [pdf_f6cce7cc08ca69c15599, p. 65]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
65
This composite image shows the effects of the oxidizer flow rate on inverse flames. In these tests, the 
flame size depends on the amount of fuel in the atmosphere required to consume the oxygen, so a larger 
flow rate results in a larger flame. However, a flame’s radiative heat loss increases with its size and the 
larger flame is significantly dimmer. Measurements of thermal radiation from the flame on the right were 
several times greater than from the flame on the left.
Week 25: Sept. 24-30
On GMT 270, Megan McArthur replaced the gas bottle at CIR Manifold #4 to support CFI-G Part 2 (Cool 
Flames Investigation with Gases). We then ignited ten inverse flames. For these tests, we varied the 
concentration of the butane fuel in the Combustion Chamber, the flow rate of the oxygen/nitrogen 
mixture from the burner, and the oxygen concentration.
Figure 1. Effects of Butane Concentration on a CFI-G Inverse Flame
Figure 1 is a graph of the thermal radiation emitted by an inverse flame, and it compares two tests with 
the same oxidizer mixture ratio and flow rate but a different butane concentration. The dim flame in the 
14.0% butane experienced large oscillations (shown in blue on the graph) due to heat loss to the burner’s 
supply tube. These oscillations grew in strength until the flame self-extinguished. In contrast, the flame in 
17.5% butane was much brighter. It eventually experienced similar oscillations (shown in red on the 
graph), but they were weaker and didn’t cause the flame to extinguish during the test.
Week 26: Oct. 1-7
On GMT 277, Mark Vande Hei replaced the gas bottle at CIR Manifold #4 to support CFI-G Part 2 (Cool 
Flames Investigation with Gases). We then ignited eleven inverse flames. The tests were carried out at a 
pressure of 0.5 atm with various butane concentrations ranging from 14 to 36% (by volume), where the
~~~~

### Pagina 66

Cita: [pdf_f6cce7cc08ca69c15599, p. 66]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
66
fuel was diluted with nitrogen. The other test parameters included changing the flow rate and ratio of the 
oxygen/nitrogen mixture issuing from the burner. This marks the completion of CFI-G Part 2!
Figure 1. Example CFI-G Inverse Butane Flame
This example image can be readily identified as an inverse flame because the soot is outside, rather than 
inside, of the flame. The soot is formed when the fuel combines with itself at high temperatures in the 
absence of oxygen. In this regard, the inverse flame is like a bubble separating the outer fuel from the 
inner oxygen, where the two reactants are consumed producing light, heat, and chemical products (e.g., 
carbon dioxide and water vapor). Flames of hydrocarbon fuels are naturally blue, while the high￾temperature soot glows red, orange, yellow, or even white depending on its temperature.
At ignition, this flame was all bright and sooty, but the system is not fully symmetric. There is some 
asymmetry to the burner flow, and there is heat loss to the tube supplying the gas to the porous spherical 
burner. As a result, the soot faded from the lower hemisphere, which in this image appears to be soot 
free. Meanwhile, the upper hemisphere remained enveloped in a layer of glowing soot. Tests like this 
have yielded valuable data for improving our understanding of how to control soot generation.
Week 27: Oct. 8-14
On GMT 285, Megan McArthur configured the ACME Chamber Insert to support an extra day of testing 
for CFI-G Part 1 (Cool Flames Investigation with Gases). Part 1 studies normal flames as opposed to inverse 
flames like Part 2. For normal flames, the gaseous fuel flows from the burner into a Combustion Chamber 
filled with diluted oxygen. The reverse is true for inverse flames, making them inside out. The purpose of 
this extra day is to recreate the test conditions in which we achieved cool flames in earlier testing. The 
goal of CFI-G is to study these low temperature flames to gain valuable insight into the combustion 
processes in engines. Also, to support this extra day of testing, Shane Kimbrough set the CIR Valve Timers 
and replaced the gas bottles at CIR Manifold #2 and CIR Manifold #4 on GMT 286 and Megan McArthur 
replaced the gas bottle at CIR Manifold #4 on GMT 287.
~~~~

### Pagina 67

Cita: [pdf_f6cce7cc08ca69c15599, p. 67]. Metodo: native.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
67
Increment 66
Week 1: Oct. 15-21
On GMT 291, we performed the last 12 tests for ACME CFI-G (Cool Flames Investigation with Gases) during 
an extra day of testing with normal flames. The purpose of this extra day was to recreate the test 
conditions in which we achieved cool flames in earlier testing, and we successfully achieved cool flames! 
In two tests, the butane hot flames extinguished due to radiative heat loss, but then seconds later they 
reignited. This extinction and reignition occurred several times during each of these tests. The butane 
reignited because a cool flame occurred between the hot flames. Cool flame chemistry is important for 
ignition in internal combustion engines and an improved understanding would aid the development of 
vehicles that experience less wear on engine parts, get better gas mileage, and create less pollution.
CAPTION TO VIDEO, WHICH IS NOT INCLUDED IN THIS LOG
This video clip is from the end of a test in which the hot butane flame repeatedly extinguishes and 
reignites. While the low-temperature cool flames between the hot flames aren’t visible in this 
video, they cause the closest thermocouple to warm enough to visibly glow prior to reignition.
Reignition causes the temperature to abruptly increase, but then it drops while the hot flame 
burns and weakens. When the hot flame extinguishes and transitions to a cool flame, the 
temperature starts increasing again until another temperature spike caused by the next 
reignition.
In another test, we saw evidence of a cool flame where the temperature temporarily rose after 
the hot flame extinguished but not enough to reignite a hot flame.
~~~~

### Pagina 68

Cita: [pdf_f6cce7cc08ca69c15599, p. 68]. Metodo: native.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
68
Appendix G. Crew Activity per Space Station Science Highlights
The subsequent text and images are from the weekly highlights prepared by the Lead Increment Scientist 
and made available via e-mail and online via www.nasa.gov/mission_pages/station/research/. 
With the major exception of the Space Station Science Highlights, links were generally not included in the 
excerpts herein because they typically go to secondary sources of information for the ACME project, for 
which the primary web site is https://www1.grc.nasa.gov/space/iss-research/iss-fcf/cir/acme/. 
Clarifications have been added in red.
2021 (for all of CFI-G)
First round (normal flames)
Week of March 8, 2021
Other investigations on which the crew performed work:
• ACME is a set of six independent studies of gaseous flames. ACME’s goals are to advance fuel 
efficiency and reduce pollutant production in practical combustion on Earth, and to improve 
spacecraft fire prevention.
Week of April 26, 2021
Observing flames
The Advanced Combustion via Microgravity Experiments (ACME) include six independent studies of 
flames that seek to improve fuel efficiency and reduce pollution from combustion on Earth and help 
prevent fires in spacecraft. ACME investigations are conducted in the space station’s Combustion 
Integrated Rack (CIR), which includes a combustion chamber, gas bottles, and five cameras for observing 
flames. The research aimed at spacecraft fire prevention examines different materials, including how to 
put them out when burning, conditions needed for a material to continue burning, and the effectiveness 
of existing methods to screen and select materials for spacecraft. The crew replaced controllers for ACME 
during the week.
Week of June 7, 2021
Other investigations on which the crew performed work:
• ACME includes six independent studies to improve fuel efficiency and reduce pollution from 
combustion on Earth and help prevent fires in spacecraft. The spacecraft fire prevention studies 
examine different materials, conditions needed for them to burn, how to extinguish them, and 
the effectiveness of methods to screen and select materials for spacecraft.
Note that only one of the six ACME experiments was focused on spacecraft fire safety and that was 
Burning Rate Emulator (BRE), not CFI-G.
~~~~

### Pagina 69

Cita: [pdf_f6cce7cc08ca69c15599, p. 69]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
69
Second round (inverse flames except for the final test day)
Week of July 12, 2021
Other investigations on which the crew performed work: 
• ACME is a set of six independent studies of gaseous flames intended to advance fuel efficiency 
and reduce pollutant production on Earth and improve spacecraft fire prevention. Currently, Cool 
Flames Investigation with Gases observes the chemical reactions of cool diffusion flames.
Week of July 19, 2021
This Space to Ground video is accessible via the following sites, where the CFI-G discussion appears 
halfway through the 3 minute clip.
https://www.youtube.com/watch?v=4q8yN1bSsr8
https://images.nasa.gov/details-jsc2021m000030_Space%20to%20Ground_380_210723
Week of July 26, 2021
Other investigations on which the crew performed work: 
• ACME includes six independent studies of flames that seek to improve fuel efficiency and reduce 
pollution from combustion on Earth and help prevent fires in spacecraft.
Week of August 2, 2021
Other investigations on which the crew performed work:
• Cool Flames Investigation with Gases, part of the ACME series of studies, observes chemical 
reactions of cool flames, which burn at lower temperatures. Nearly impossible to create in Earth’s 
gravity, cool flames are easily created in microgravity and studying them may improve 
understanding of combustion and fires on Earth.
~~~~

### Pagina 70

Cita: [pdf_f6cce7cc08ca69c15599, p. 70]. Metodo: native.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
70
Week of August 9, 2021
Other investigations on which the crew performed work:
• Cool Flames Investigation with Gases, part of the ACME series of studies, observes chemical 
reactions of cool flames, which burn at lower temperatures. Nearly impossible to create in Earth’s 
gravity, cool flames are easily created in microgravity and studying them may improve 
understanding of combustion and fires on Earth.
Week of August 16, 2021
Other investigations on which the crew performed work:
• Cool Flames Investigation with Gases, part of the ACME series of studies, observes chemical 
reactions of cool flames, which burn at lower temperatures. Nearly impossible to create in Earth’s 
gravity, cool flames are easily created in microgravity and studying them may improve 
understanding of combustion and fires on Earth.
Week of August 23, 2021
Other investigations on which the crew performed work:
• Cool Flames Investigation with Gases, part of the ACME series of studies, observes chemical 
reactions of cool flames, which burn at lower temperatures. Cool flames were first discovered 
aboard the space station in 2012 burning liquid fuel; more recently, the investigation created cool 
flames burning gaseous fuels. Studying these flames may improve understanding of combustion 
and fires on Earth.
Week of September 6, 2021
Other investigations on which the crew performed work: 
• Cool Flames Investigation with Gases, part of the ACME series of studies, observes chemical 
reactions of cool flames, which burn at lower temperatures. Nearly impossible to create in Earth’s 
gravity, cool flames are easily created in microgravity and studying them may improve 
understanding of combustion and fires on Earth.
Week of September 20, 2021
Other investigations involving the crew: 
• Cool Flames Investigation with Gases, part of the ACME series of studies, observes chemical 
reactions of cool flames, which burn at lower temperatures. Nearly impossible to create in Earth’s 
gravity, cool flames are easily created in microgravity and studying them may improve 
understanding of combustion and fires on Earth.
Week of September 27, 2021
Other investigations involving the crew: 
• Cool Flames Investigation with Gases, part of the ACME series of studies, observes chemical 
reactions of cool flames, which burn at lower temperatures. Nearly impossible to create in Earth’s 
gravity, cool flames are easily created in microgravity, and studying them may improve 
understanding of combustion and fires on Earth.
~~~~

### Pagina 71

Cita: [pdf_f6cce7cc08ca69c15599, p. 71]. Metodo: native.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
71
Week of October 4, 2021
Other investigations on which the crew performed work: 
• Cool Flames Investigation with Gases, part of the ACME series of studies, observes chemical 
reactions of cool flames, which burn at lower temperatures. Nearly impossible to create in Earth’s 
gravity, cool flames are easily created in microgravity, and studying them may improve 
understanding of combustion and fires on Earth.
Week of October 11, 2021
Coolest flames in space
The Advanced Combustion via Microgravity Experiments (ACME) project is a set of six independent studies 
of gaseous flames conducted in the Combustion Integrated Rack (CIR). The researchers’ goals are to gain 
information that can lead to improved fuel efficiency, reduced pollutant production in practical 
combustion on Earth, and improved spacecraft fire prevention. One of the ACME studies currently being 
conducted is known as the Cool Flames Investigation with Gases. A cool flame is one that burns at about 
600 degrees Celsius. A candle is about two times hotter, burning at around 1,400 degrees Celsius. The 
results of this investigation could lead to cleaner, more efficient internal combustion engines. This past 
week, a crew member was tasked with replacing a butane bottle in preparation for the experiment.
Week of October 18, 2021
Other investigations involving the crew: 
• Cool Flames Investigation with Gases, part of the ACME series of studies, observes chemical 
reactions of cool flames, which burn at lower temperatures. Nearly impossible to create in Earth’s 
gravity, cool flames are easily created in microgravity and studying them may improve 
understanding of combustion and fires on Earth.
~~~~

### Pagina 72

Cita: [pdf_f6cce7cc08ca69c15599, p. 72]. Metodo: native.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
72
Appendix H. Crew Activity per the ISS Daily Summary Report
This appendix was compiled from https://blogs.nasa.gov/stationreport. Headings were added identifying 
the investigation’s two rounds of testing, but CFI-G operations listed under the headings “All activities are 
complete unless otherwise noted” or “Completed Task List Activities” were not included in this report. 
Some days of crew activity were only listed in those ways and as a result this section does not 
comprehensively document crew activity in support of the CFI-G experiment. Minor additions were made 
in red to correct the names and abbreviations of ACME investigations.
2021 (for all of CFI-G)
First round (normal flames)
2021 March 9: GMT 068
Combustion Integrated Rack/Advanced Combustion via Microgravity Experiments (CIR/ACME): The 
crew performed the first part of the work needed to reconfigure the ACME chamber insert from Coflow 
Laminar Diffusion Flame (CLD Flame) support to Cool Flames Investigation with Gases (CFI-G) support, the 
next ACME experiment to be performed. Cool diffusion flames were discovered during droplet 
combustion experiments aboard the ISS in 2012, and this initiated a rapidly growing field of combustion 
research. A cool flame is one that burns at about 600 degrees Celsius. A typical candle is about two-and￾a-half times hotter, burning at around 1,400 degrees Celsius. Most internal combustion engines are 
designed using computer models that neglect cool flame chemistry, but ignition and flame propagation in 
engines depend on cool flame chemistry. Cool flame chemistry also has a significant impact on fuel octane 
and cetane numbers, whose understanding has large economic consequences.
2021 March 10: GMT 069
Combustion Integrated Rack (CIR)/Advanced Combustion via Microgravity Experiments (ACME): The 
crew performed the second part of the work needed to reconfigure the ACME chamber insert from Coflow 
Laminar Diffusion Flame (CLD Flame) support to Cool Flames Investigation with Gases (CFI-G) support, 
which is the next ACME experiment to be performed. Cool diffusion flames were discovered during 
droplet combustion experiments aboard the ISS in 2012, and this initiated a rapidly growing field of 
combustion research. A cool flame is one that burns at about 600 degrees Celsius. A typical candle is about 
two-and-a-half times hotter, burning at around 1,400 degrees Celsius. Most internal combustion engines 
are designed using computer models that neglect cool flame chemistry, but ignition and flame 
propagation in engines depend on cool flame chemistry. Cool flame chemistry also has a significant impact 
on fuel octane and cetane numbers, whose understanding has large economic consequences.
2021 March 16: GMT 075
Combustion Integrated Rack (CIR) / Advanced Combustion via Microgravity Experiments (ACME): The 
crew performed the steps necessary to lubricate the quick disconnect (QD) for the gas chromatograph 
argon gas bottle. They also replaced the N2/O2 gas bottle at manifold 2 and installed an ethane fuel bottle 
at the manifold 4 location. This was performed in support of the Cool Flames Investigation with Gases 
(CFI-G) experiment. Cool diffusion flames were discovered during droplet combustion experiments aboard 
the ISS in 2012, and this initiated a rapidly growing field of combustion research. A cool flame is one that 
burns at about 600 degrees Celsius. A typical candle is about three-and-a-half times hotter, burning at 
around 1,400 degrees Celsius. Most internal combustion engines are designed using computer models 
that neglect cool flame chemistry, but ignition and flame propagation in engines depend on cool flame
~~~~

### Pagina 73

Cita: [pdf_f6cce7cc08ca69c15599, p. 73]. Metodo: native.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
73
chemistry. Cool flame chemistry also has a significant impact on fuel octane and cetane numbers, whose 
understanding has large economic consequences.
2021 April 9: GMT 099
CIR/ACME/CFI-G (Combustion Integrated Rack/Advanced Combustion via Microgravity 
Experiments/Cool Flames Investigation with Gases): As a continuation of the on-going CFI-G experiment, 
the crew removed the 100% ethane fuel bottle and installed a 50% butane, 50% nitrogen fuel bottle. Cool 
diffusion flames were discovered during droplet combustion experiments aboard the ISS in 2012, and this 
initiated a rapidly growing field of combustion research. A cool flame is one that burns at about 600 
degrees Celsius. A typical candle is about three-and-a-half times hotter, burning at around 1,400 degrees 
Celsius. Most internal combustion engines are designed using computer models that neglect cool flame 
chemistry, but ignition and flame propagation in engines depend on cool flame chemistry. Cool flame 
chemistry also has a significant impact on fuel octane and cetane numbers, whose understanding has 
large economic consequences.
2021 April 19: GMT 109
Combustion Integrated Rack (CIR) – Fluids and Combustion Facility: The crew replaced the Manifold 2 
and 4 gas bottles for upcoming CIR operations. The CIR includes an optics bench, combustion chamber, 
fuel and oxidizer control, and five different cameras for performing combustion investigations in 
microgravity.
2021 April 28: GMT 118
ACME (Advanced Combustion via Microgravity Experiments): Crew replaced an ACME controller. The 
crew opened the rack doors and the combustion chamber of the ACME and then replaced the Fuel 
Controller. The Advanced Combustion via Microgravity Experiments (ACME) project is a set of six 
independent studies of gaseous flames to be conducted in the Combustion Integrated Rack (CIR). ACME’s 
primary and secondary goals are (1) improved fuel efficiency and reduced pollutant production in practical 
combustion on Earth and (2) spacecraft fire prevention through innovative research focused on materials 
flammability.
2021 May 7: GMT 127
CIR/ACME (Combustion Integrated Rack/Advanced Combustion via Microgravity Experiments): The 
crew replaced the 40% O2/60% N2 manifold bottle with a new bottle of the same composition. They also 
replaced the 30% butane/70% N2 bottle with a new bottle of the same composition. This was performed 
in support of the CFI-G (Cool Flames Investigation with Gases) experiment. Cool diffusion flames were 
discovered during droplet combustion experiments aboard the ISS in 2012, and this initiated a rapidly 
growing field of combustion research. A cool flame is one that burns at about 600 degrees Celsius. A 
typical candle is about three-and-a-half times hotter, burning at around 1,400 degrees Celsius. Most 
internal combustion engines are designed using computer models that neglect cool flame chemistry, but 
ignition and flame propagation in engines depend on cool flame chemistry. Cool flame chemistry also has 
a significant impact on fuel octane and cetane numbers, whose understanding has large economic 
consequences.
2021 May 18: GMT 138
CIR IPSU Replacement: Today, a crewmember replaced the failed FCF IPSU in the CIR (Combustion 
Integrated Rack), which included moving the FCF IPSU at position UML2 to replace the FCF IPSU at position
~~~~

### Pagina 74

Cita: [pdf_f6cce7cc08ca69c15599, p. 74]. Metodo: native.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
74
UML5. The Combustion Integrated Rack (CIR) includes an optics bench, combustion chamber, fuel and 
oxidizer control, and five different cameras for performing combustion investigations in microgravity.
2021 May 25: GMT 145
ACME (Advanced Combustion via Microgravity Experiments): A crewmember replaced CIR Manifold #4 
with a new C4H10 (Butane) and C2H6 (Ethane) bottles and replaced O2 bottles in Manifold #2. The 
Advanced Combustion via Microgravity Experiments (ACME) project is a set of six independent studies of 
gaseous flames to be conducted in the Combustion Integrated Rack (CIR). ACME’s primary and secondary 
goals are (1) improved fuel efficiency and reduced pollutant production in practical combustion on Earth, 
and (2) spacecraft fire prevention through innovative research focused on materials flammability.
2021 June 8: GMT 159
CIR/ACME (Combustion Integrated Rack/Advanced Combustion via Microgravity Experiments): The 
crew replaced a 40% O2, 60% N2manifold bottle with another bottle of the same composition. This was 
performed in support of the CFI-G part 1 (Cool Flames Investigation with Gases) experiment. Cool diffusion 
flames were discovered during droplet combustion experiments aboard the ISS in 2012, and this initiated 
a rapidly growing field of combustion research. A cool flame is one that burns at about 600 degrees 
Celsius. A typical candle is about three-and-a-half times hotter, burning at around 1,400 degrees Celsius. 
Most internal combustion engines are designed using computer models that neglect cool flame chemistry, 
but ignition and flame propagation in engines depend on cool flame chemistry. Cool flame chemistry also 
has a significant impact on fuel octane and cetane numbers, whose understanding has large economic 
consequences.
2021 June 14: GMT 165
Cool Flames Investigation with Gases (CFI-G): The crew replaced manifold #2 and #4 bottles with bottles 
of the same composition. This was performed in support of part 1 of the CFI-G experiment. Cool diffusion 
flames were discovered during droplet combustion experiments aboard the ISS in 2012, and this initiated 
a rapidly growing field of combustion research. A cool flame burns at about 600 degrees Celsius. A typical 
candle is about three-and-a-half times hotter, burning at around 1,400 degrees Celsius. Most internal 
combustion engines are designed using computer models that neglect cool flame chemistry, but ignition 
and flame propagation in engines depend on cool flame chemistry. Cool flame chemistry also has a 
significant impact on fuel octane and cetane numbers, whose understanding has large economic 
consequences.
Second round (inverse flames except for the final test day)
2021 July 2: GMT 183
Combustion Integrated Rack (CIR) / Advanced Combustion via Microgravity Experiments (ACME): The 
crew performed the steps necessary to access the ACME combustion insert and reconfigured from Cool 
Flames Investigation with Gases (CFI-G) part 1 to CFI-G part 2. This involved replacing the igniter tip, 
replacing three ACME flow controllers, etc. Cool diffusion flames were discovered during droplet 
combustion experiments aboard the ISS in 2012. This initiated a rapidly growing field of combustion 
research. A cool flame is one that burns at about 600 degrees Celsius. A typical candle is about two times 
hotter, burning at around 1,400 degrees Celsius. Most internal combustion engines are designed using 
computer models that neglect cool flame chemistry, but ignition and flame propagation in engines depend
~~~~

### Pagina 75

Cita: [pdf_f6cce7cc08ca69c15599, p. 75]. Metodo: native.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
75
on cool flame chemistry. Cool flame chemistry also has a significant impact on fuel octane and cetane 
numbers, whose understanding has large economic consequences.
2021 July 12: GMT 193
Combustion Integrated Rack (CIR) – Fluids and Combustion Facility: The crew removed the O2 Bottle 
from the CIR Manifold #2 rack and replaced it with a high percentage oxygen bottle containing 85% O2 and 
15% N2. The crew also replaced the fuel bottle in the CIR Manifold #4 rack with a bottle containing 100% 
C2H6 (Ethane). The CIR includes an optics bench, combustion chamber, fuel and oxidizer control, and five 
different cameras for performing combustion investigations in microgravity.
2021 July 19: GMT 200
Combustion Integrated Rack (CIR) – Fluids and Combustion Facility: The crew exchanged the manifold 
#4 bottle with a bottle containing 100% C2H6. The CIR includes an optics bench, combustion chamber, fuel, 
and oxidizer control, and five different cameras for performing combustion investigations in microgravity.
2021 July 26: GMT 207
Combustion Integrated Rack/Advanced Combustion via Microgravity Experiments (CIR/ACME): The 
crew removed a used 100% ethane (CH3-CH3) fuel bottle with a new bottle of the same composition. This 
will allow the continuation of the Cool Flames Investigation with Gases (CFI-G) part 2 test points. Cool 
diffusion flames were discovered during droplet combustion experiments aboard the ISS in 2012, and this 
initiated a rapidly growing field of combustion research. A cool flame is one that burns at about 600 
degrees Celsius. A typical candle is about two times hotter, burning at around 1,400 degrees Celsius. Most 
internal combustion engines are designed using computer models that neglect cool flame chemistry, but 
ignition and flame propagation in engines depend on cool flame chemistry. Cool flame chemistry also has 
a significant impact on fuel octane and cetane numbers, whose understanding has large economic 
consequences.
2021 Aug. 2: GMT 214
Combustion Integrated Rack/Advanced Combustion via Microgravity Experiments (CIR/ACME): The 
crew exchanged a used 85% O2/ 15% N2 bottle with a new one of the same composition; however, during 
the installation, a loose pressure relief valve body was found. The ground is discussing steps to re-tighten 
the valve body and proceed with operations. This will allow the continuation of the Cool Flames 
Investigation with Gases (CFI-G) part 2 test points. Cool diffusion flames were discovered during droplet 
combustion experiments aboard the ISS in 2012, and this initiated a rapidly growing field of combustion 
research. A cool flame is one that burns at about 600 degrees Celsius. A typical candle is about two times 
hotter, burning at around 1,400 degrees Celsius. Most internal combustion engines are designed using 
computer models that neglect cool flame chemistry, but ignition and flame propagation in engines depend 
on cool flame chemistry. Cool flame chemistry also has a significant impact on fuel octane and cetane 
numbers, whose understanding has large economic consequences.
2021 Aug. 10: GMT 222
Combustion Integrated Rack (CIR) – Fluids and Combustion Facility (FCF): The crew replaced the 
Manifold 4 fuel bottle with 1.00 liters of 100% C3H8 (Propane). The CIR includes an optics bench, 
combustion chamber, fuel and oxidizer control, and five different cameras for performing combustion 
investigations in microgravity.
~~~~

### Pagina 76

Cita: [pdf_f6cce7cc08ca69c15599, p. 76]. Metodo: native.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
76
2021 Aug. 16: GMT 228
Cool Flames Investigation with Gases: The crew replaced the Manifold 4 fuel bottle with 1.00 liters of 
100% C3H8 (Propane). Cool diffusion flames were discovered during droplet combustion experiments 
aboard the ISS in 2012, and this initiated a rapidly growing field of combustion research. A cool flame is 
one that burns at about 600 degrees Celsius. A typical candle is about three-and-a-half times hotter, 
burning at around 1,400 degrees Celsius. Most internal combustion engines are designed using computer 
models that neglect cool flame chemistry, but ignition and flame propagation in engines depend on cool 
flame chemistry. Cool flame chemistry also has a significant impact on fuel octane and cetane numbers, 
whose understanding has large economic consequences.
2021 Aug. 20: GMT 232
Cool Flames Investigation with Gases: A crewmember removed Manifold 2 O2 bottles with a bottle that 
contains 85% O2 and 15% N2. Cool diffusion flames were discovered during droplet combustion 
experiments aboard the ISS in 2012, and this initiated a rapidly growing field of combustion research. A 
cool flame is one that burns at about 600 degrees Celsius. A typical candle is about two times hotter, 
burning at around 1,400 degrees Celsius. Most internal combustion engines are designed using computer 
models that neglect cool flame chemistry, but ignition and flame propagation in engines depend on cool 
flame chemistry. Cool flame chemistry also has a significant impact on fuel octane and cetane numbers, 
whose understanding has large economic consequences.
2021 Aug. 23: GMT 235
Combustion Integrated Rack/Advanced Combustion via Microgravity Experiments/Cool Flames 
Investigation with Gasses (CIR/ACME/CFI-G): A crewmember exchanged a used 100% propane bottle 
with a new bottle of the same composition. Cool diffusion flames were discovered during droplet 
combustion experiments aboard the ISS in 2012, and this initiated a rapidly growing field of combustion 
research. A cool flame is one that burns at about 600 degrees Celsius. A typical candle is about two times 
hotter, burning at around 1,400 degrees Celsius. Most internal combustion engines are designed using 
computer models that neglect cool flame chemistry, but ignition and flame propagation in engines depend 
on cool flame chemistry. Cool flame chemistry also has a significant impact on fuel octane and cetane 
numbers, whose understanding has large economic consequences.
2021 Aug. 30: GMT 242
Combustion Integrated Rack/Advanced Combustion via Microgravity Experiments/Cool Flames 
Investigation with Gasses (CIR/ACME/CFI-G part 2): A crewmember exchanged a used 100% propane 
bottle with a new bottle of the same composition. Cool diffusion flames were discovered during droplet 
combustion experiments aboard the ISS in 2012, and this initiated a rapidly growing field of combustion 
research. A cool flame is one that burns at about 600 degrees Celsius. A typical candle is about two times 
hotter, burning at around 1,400 degrees Celsius. Most internal combustion engines are designed using 
computer models that neglect cool flame chemistry, but ignition and flame propagation in engines depend 
on cool flame chemistry. Cool flame chemistry also has a significant impact on fuel octane and cetane 
numbers, whose understanding has large economic consequences.
2021 Sept. 8: GMT 251
Advanced Combustion via Microgravity Experiments (ACME): A crewmember removed and replaced the 
ACME Igniter Tip #2. The ACME project is a set of six independent studies of gaseous flames to be 
conducted in the Combustion Integrated Rack (CIR). ACME’s primary and secondary goals are to (1)
~~~~

### Pagina 77

Cita: [pdf_f6cce7cc08ca69c15599, p. 77]. Metodo: native.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
77
improve fuel efficiency and reduce pollutant production in practical combustion on Earth, and (2) 
spacecraft fire prevention through innovative research focused on materials flammability.
2021 Sept. 10: GMT 253
Combustion Integrated Rack – Fluids and Combustion Facility (CIR): A crewmember replaced the FCF 
Hard Drive installed in the FCF Image Processor in the CIR. The crew photo documented the final 
configuration of the FCF Image Processor. The CIR includes an optics bench, combustion chamber, fuel 
and oxidizer control, and five different cameras for performing combustion investigations in microgravity.
2021 Sept. 13: GMT 256
Combustion Integrated Rack/Advanced Combustion via Microgravity Experiments/Cool Flames 
Investigation with Gasses (CIR/ACME/CFI-G part 2): Following successful repairs last week, this week the 
crew removed an empty propane fuel bottle and installed a butane fuel bottle, allowing the continuation 
of the experiment. Spherical Cool Diffusion Flames Burning Gaseous Fuels (Cool Flames Investigation with 
Gases) observes the chemical reactions of cool diffusion flames. Diffusion flames are created by supplying 
fuel to a burner and mixing in ambient air for combustion. Cool flames, which burn at extremely low 
temperatures, are nearly impossible to create in Earth’s gravity, but are easily created in microgravity; 
studying them may improve the understanding of combustion and fires on Earth.
2021 Sept. 22: GMT 265
Cool Flames Investigation with Gases: A crewmember replaced the Manifold #4 fuel bottle with a new 
bottle containing 100% Butane. Cool diffusion flames were discovered during droplet combustion 
experiments aboard the ISS in 2012, and this initiated a rapidly growing field of combustion research. A 
cool flame is one that burns at about 600 degrees Celsius. A typical candle is about two times hotter, 
burning at around 1,400 degrees Celsius. Most internal combustion engines are designed using computer 
models that neglect cool flame chemistry, but ignition and flame propagation in engines depend on cool 
flame chemistry. Cool flame chemistry also has a significant impact on fuel octane and cetane numbers, 
whose understanding has large economic consequences.
2021 Sept. 27: GMT 270
Combustion Integrated Rack/Advanced Combustion via Microgravity Experiments/Cool Flames 
Investigation with Gasses (CIR/ACME/CFI-G part 2): The crew removed an empty butane fuel bottle and 
installed a new butane fuel bottle, allowing the continuation of the experiment series. Spherical Cool 
Diffusion Flames Burning Gaseous Fuels (Cool Flames Investigation with Gases) observes the chemical 
reactions of cool diffusion flames. Diffusion flames are created by supplying fuel to a burner and mixing 
in ambient air for combustion. Cool flames, which burn at relatively low temperatures of ~600 deg C, are 
nearly impossible to create in Earth’s gravity, but are easily created in microgravity; studying them may 
improve the understanding of combustion and fires on Earth.
2021 Oct. 4: GMT 277
Cool Flames Investigation with Gases: A crewmember replaced the bottle in CIR Manifold #4 with 100 
percent C4H10 (Butane). Cool diffusion flames were discovered during droplet combustion experiments 
aboard the ISS in 2012, and this initiated a rapidly growing field of combustion research. A cool flame is 
one that burns at about 600 degrees Celsius. A typical candle is about two times hotter, burning at around 
1,400 degrees Celsius. Most internal combustion engines are designed using computer models that 
neglect cool flame chemistry, but ignition and flame propagation in engines depend on cool flame
~~~~

### Pagina 78

Cita: [pdf_f6cce7cc08ca69c15599, p. 78]. Metodo: native.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
78
chemistry. Cool flame chemistry also has a significant impact on fuel octane and cetane numbers, whose 
understanding has large economic consequences.
2021 Oct. 12: GMT 285
Advanced Combustion via Microgravity Experiments (ACME): A crewmember replaced the ACME 
Thermocouple Array with the ACME Chamber Insert partially installed in the chamber. The ACME 
Chamber was re-Inserted into the chamber, and the crew replaced three ACME controllers. The ACME 
project is a set of six independent studies of gaseous flames to be conducted in the Combustion Integrated 
Rack (CIR). ACME’s primary and secondary goals are (1) improve fuel efficiency and reduce pollutant 
production in practical combustion on Earth, and (2) spacecraft fire prevention through innovative 
research focused on materials flammability.
2021 Oct. 13: GMT 286
Combustion Integrated Rack (CIR): A crewmember replace the CIR Manifold #2 Bottle with a new bottle 
containing 40% O2 and 60% N2. The Manifold #4 Bottle was also replaced with a new bottle containing 
30% C3H8 and 70% N2. These bottle changes are in preparation of continued Cool Flame experiment 
runs. The CIR includes an optics bench, combustion chamber, fuel, and oxidizer control, and five different 
cameras for performing combustion investigations in microgravity.
2021 Oct. 14: GMT 287
Combustion Integrated Rack (CIR): A crewmember replaced the CIR Manifold #4 Bottle with a new bottle 
containing 30% C4H10 and 70% N2. The CIR includes an optics bench, combustion chamber, fuel and 
oxidizer control, and five different cameras for performing combustion investigations in microgravity.
~~~~

### Pagina 79

Cita: [pdf_f6cce7cc08ca69c15599, p. 79]. Metodo: native.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
79
Appendix I. Crew Activity per the NASA Space Station Blog
This section consists of excerpts from https://blogs.nasa.gov/spacestation/. Hyperlinks were generally not 
included.
2021 (for all of CFI-G)
First round (normal flames)
2021 April 29 - Crew-1 Splashdown Waved Off as Station Teems With Science
Fuel bottles supporting combustion experiments were swapped out ...
Second round (inverse flames except for the final test day)
2021 October 14 - Russian Trio Nears Departure, Rest of Crew Busy with Research, Lab 
Upkeep
The station’s three NASA flight engineers had their hands full today with a host of research and lab upkeep 
activities in the orbiting lab’s U.S. segment. Megan McArthur swapped fuel bottles inside the Combustion 
Integrated Rack ....
~~~~

### Pagina 80

Cita: [pdf_f6cce7cc08ca69c15599, p. 80]. Metodo: native.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
80
Appendix J. Crew Activity in Publicly Available NASA Photos
These photos of CFI-G operations are available from https://images.nasa.gov/. Additional photos from 
the ACME project, CIR facility, etc. can be found by searching that website.
Photo ID Date taken Summary description
iss064e040953 2021-03-09 Kate Rubins (NASA) with the ACME chamber insert on the workbench,
where the burner cannot be seen
iss064e040971 2021-03-09 Kate Rubins (NASA) with the ACME insert within the open Combustion 
Integrated Rack (CIR) chamber
iss065e047568 2021-05-18 Megan McArthur (NASA) with the Combustion Integrated Rack (CIR) 
pulled out but not rotated
iss065e156007 2021-07-02 Mark Vande Hei (NASA) with the ACME insert within open Combustion 
Integrated Rack (CIR) chamber, but barely visible. Akihiko Hoshide
(JAXA) is also visible, but was not working on CFI-G
iss065e156020 2021-07-02 Mark Vande Hei (NASA) with the ACME insert partially withdrawn from 
the open Combustion Integrated Rack (CIR) chamber. Akihiko Hoshide
(JAXA) is visible in the background, but was not working on CFI-G 
iss065e369687 2021-09-08 Mark Vande Hei (NASA) with the ACME insert within the open 
Combustion Integrated Rack (CIR) chamber
iss065e369648 2021-09-10 Mark Vande Hei (NASA) with the Combustion Integrated Rack (CIR) 
pulled out and rotated, but only seen in part and out of focus
iss065e369799 2021-09-10 Mark Vande Hei (NASA) with the Combustion Integrated Rack (CIR) 
pulled out and rotated
~~~~

### Pagina 81

Cita: [pdf_f6cce7cc08ca69c15599, p. 81]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_f6cce7cc08ca69c15599/p0081.jpg)

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
81
Appendix K. ACME Operations per @ISS_Research on Twitter
These tweets (from https://twitter.com/ISS_Research/) were from the period of the CFI-G experiment. 
2021 May 24: GMT 144

[Texto OCR de la imagen]
ACME/CFI-G Final Report (2022) | 21 November 2022
Appendix K. ACME Operations per @ISS_Research on Twitter
These tweets (from https://twitter.com/lSS Research/) were from the period of the CFI-G experiment.
2021 May 24: GMT 144
Get a closer look at one of the flames ignited for the
@Space_Station ACME CFI-G study! This imase shows
a hot flame of nitrogen-diluted propane in a
microgravity atmosphere of elevated oxygen. Without
buoyancy, soot remained in the flame longer and
formed the large clusters.
Glec.r. Rema-ch ard
Megan | O | Megyn • | 24
fre Zierce '-Ä5 cool! | our Cctnb-ztbr•.
kek. | it read/ far a cc.-tir.u•d stub/ cf oocå | ct-e-nct"'. What we
k:am ca-•id | to | burnrg rvcee effcent Hen-ol combst:on
5:36 • | 202' • Tw*ter | App
81
~~~~

### Pagina 82

Cita: [pdf_f6cce7cc08ca69c15599, p. 82]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_f6cce7cc08ca69c15599/p0082.jpg)

~~~~text
ACME/CFI-G Final Report (2022) | 21 November 2022
2021 June 29: GMT 180
ISS Research
@ISS Research
Things are heating up in space!
Aboard the @Space_Station, researchers are creating
flames in an attempt to study cool flames, which burn
at extremely low temperatures, and are nearly
impossible to create in Earth's gravity.
go.nasa.gov/30nOwai
0:24 9.*views
Flame Lit for Cool Flames Investigation with Gases on Space Station
Aboard the space station, researchers are creating flames in an attempt to study
cool flames, which burn at extremely Iow temperatures, and are nearly
impossible to create in Earth's gravity.
11:10 AM • Jun 29, 2021 • Twitter Media Studio
ISS Research
@ISS Research
In this clip, soot that forms at ignition escapes from
the flame, increasing the heat loss experienced. This
causes it to locally quench, creating a hole in the flame
and enhancing flammability. As a result, the flame
reforms closing the hole, but it opens again due to heat
loss.
11:16 AM Jun 29, 2021 • Twitter Web App
82
~~~~

### Pagina 83

Cita: [pdf_f6cce7cc08ca69c15599, p. 83]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_f6cce7cc08ca69c15599/p0083.jpg)

~~~~text
ACME/CFI-G Final Report (2022) | 21 November 2022
2021 July 16: GMT 197
ISS Research
@ISS Research
Researchers achieved a first aboard the
@Space_Station: creating the first gas burning
spherical cool flames. Improving our understanding of
cool flames, flames that burn at extremely low
temperatures, can have important economic
consequences on Earth. go.nasa.gov/3AJmhc4
0:21 24.2Kv<ews
Space Station Cool Flame Study
The hot flame created during a test for the Cool Flames Investigation with Gases
experiment is shown burning. After the flame appears to extinguish, a cool flame
is created.
4:30 PM • Jul 16, 2021 • Twitter Media Studio
83
~~~~

### Pagina 84

Cita: [pdf_f6cce7cc08ca69c15599, p. 84]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_f6cce7cc08ca69c15599/p0084.jpg)

~~~~text
ACME/CFI-G Final Report (2022) | 21 November 2022
2021 July 22: GMT 203
ISS Research
ass Research
Testing for @Space_Station combustion research has
shifted from normal flames to inverse flames, a first for
flame experiments in space! Oxidizer flows from the
burner into a combustion chamber filled with gaseous
fuel. As a result, these flames are effectively inside
out.
International Space Station and NASA Glenn Research
3:47 PM • Jul 22, 2021 • Twitter WebApp
ISS Research
@lSS_Research
Learn more about the Cool Flames Investigation with
Gases (CFI-G) experiment which is currently using
these inverse flames: go.nasa.gov/30nOwai
3:47 PM • Jul 22, 2021 • Twitter Web App
84
~~~~

### Pagina 85

Cita: [pdf_f6cce7cc08ca69c15599, p. 85]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_f6cce7cc08ca69c15599/p0085.jpg)

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
85
Appendix L. ACME Operations per Astronauts on Twitter
This tweet is from an ISS crew member who conducted operations in support of the CFI-G experiment. 
There may be others which are not included here.
Megan K. McArthur (@Astro_Megan) on Twitter, https://twitter.com/astro_megan/
2021 May 24: GMT 144

[Texto OCR de la imagen]
ACME/CFI-G Final Report (2022) | 21 November 2022
Appendix L. ACME Operations per Astronauts on Twitter
This tweet is from an ISS crew member who conducted operations in support of the CFI-G experiment.
There may be others which are not included here.
Megan K. McArthur | on Twitter, https://twitter.com/astro megan/
2021 May 24: GMT 144
Megan McArthur
@Astro_Megan
Last week's fire science was cool! | I worked on our
Combustion Integrated Rack, getting it ready for a
continued study of cool flame chemistry. What we learn
could lead to cleaner burning and more efficient
internal combustion engines. go.nasa.gov/30nOwai
5:28 PM May 24, 2021 Twitter Web App
85
~~~~

### Pagina 86

Cita: [pdf_f6cce7cc08ca69c15599, p. 86]. Metodo: native.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
86
Appendix M. Summary of the ISS data collection
The CFI-G data is all digital and includes both image and non-image data, where this is true for the other 
ACME experiments. To be clear, there was no collection of soot or other physical samples that were 
subsequently transported to the ground. 
The CFI-G image data includes images from the following cameras:
1. ACME DataCam, used with a clear fused-silica ‘filter’ and various zoom and focus settings (but 
those settings were consistent within each individual test)
2. CFI intensified camera, used always (or at least nearly so) with a formaldehyde filter for CFI-G
3. High-Bitdepth Multispectral (HiBMs) camera, equipped with a red filter corresponding to the 
opposing CIR illumination package, which was sometimes left off
The raw DataCam images are in a Halcon Iconic Object (hobj) format, while the images from the CFI, and 
HiBMs cameras are provided in a Tagged Image File (tif) format. In contrast, the analog video was 
recorded on the ground in a Transport Stream (ts) format.
The key non-imaging data from a test is a comma-delimited file that is described in detail in the Software 
Interface Design Description (ACME-DOC-010 Rev. D).
The raw data is currently archived at NASA and work is underway to make it available publicly through 
NASA’s Physical Science Informatics System (PSI).
~~~~

### Pagina 87

Cita: [pdf_f6cce7cc08ca69c15599, p. 87]. Metodo: native.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
87
Appendix N. Publications, presentations, awards, and outreach
Papers, etc. listed in italics are general to ACME rather than specific to the CFI-G experiment.
N.1 Publications and Presentations with ISS Results
Refereed Journal Articles
1. M. Kim, K.A. Waddell, P.B. Sunderland, V. Nayagam, D.P. Stocker, D.L. Dietrich, Y. Ju, F.A. 
Williams, P. H. Irace, R.L. Axelbaum, Spherical Gas-Fueled Cool Diffusion Flames, 
Proceedings of the Combustion Institute (2022) in press.
https://doi.org/10.1016/j.proci.2022.07.015
Conference Proceedings, Abstracts, Posters, Etc.
1. Dennis P. Stocker, Advanced Combustion via Microgravity Experiments on the International 
Space Station, Work-in-Progress Poster, 12th U.S. National Combustion Meeting, virtual, 24-
26 May 2021.
2. Dennis P. Stocker, Recent Research on Flames of Gaseous Fuel Aboard the International 
Space Station, Conference of the Japanese Society of Microgravity Application (JASMAC-33), 
virtual, 13-15 Oct. 2021, 11 pp.
3. Peter B. Sunderland, Transformative Combustion Research in the ACME Suite of ISS 
Experiments, 37th Annual Meeting of the American Society for Gravitational and Space 
Research, Baltimore MD, 3-6 Nov. 2021.
4. Dennis P. Stocker, Laminar Non-Premixed Flames of Gaseous Fuel Aboard the International 
Space Station, Spring Technical Meeting of The Central States Section of the Combustion 
Institute, Detroit, Mi, 15-17 May 2022, 10 pp.
5. M. Kim, K.A. Waddell, P.B. Sunderland, V. Nayagam, D.P. Stocker, D.L. Dietrich, Y. Ju, F.A. 
Williams., P. H. Irace, R.L. Axelbaum, The First Observations of Spherical Gas-Fueled Cool 
Diffusion Flames, Spring Technical Meeting of the Eastern States Section of The Combustion 
Institute, Orlando, 6 pp., 2022.
Theses and Dissertations
1. M. Kim, Spherical Gas-Fueled Cool Diffusion Flames, MS Thesis, University of Maryland, 
60 pp., May 2022.
N.2 Publications and Presentations (comprehensive list)
Papers, etc. in this section which include ISS results are enclosed in borders like this.
Refereed Journal Articles
1. M. Kim, K.A. Waddell, P.B. Sunderland, V. Nayagam, D.P. Stocker, D.L. Dietrich, Y. Ju, F.A. 
Williams, P. H. Irace, R.L. Axelbaum, Spherical Gas-Fueled Cool Diffusion Flames, 
Proceedings of the Combustion Institute (2022) in press.
https://doi.org/10.1016/j.proci.2022.07.015
2. K.A. Waddell, H. Lee, V. Nayagam, R.L. Axelbaum, P.B. Sunderland, Cool Diffusion Flames in 
a Stably Stratified Stagnation Flow, Combustion and Flame, submitted.
~~~~

### Pagina 88

Cita: [pdf_f6cce7cc08ca69c15599, p. 88]. Metodo: native.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
88
Conference Proceedings, Abstracts, Posters, Etc.
1. Dennis P. Stocker, Advanced Combustion via Microgravity Experiments on the International 
Space Station, Work-in-Progress Poster, 12th U.S. National Combustion Meeting, virtual, 24-
26 May 2021.
2. Dennis P. Stocker, Recent Research on Flames of Gaseous Fuel Aboard the International 
Space Station, Conference of the Japanese Society of Microgravity Application (JASMAC-33), 
virtual, 13-15 Oct. 2021, 11 pp.
3. Peter B. Sunderland, Transformative Combustion Research in the ACME Suite of ISS 
Experiments, 37th Annual Meeting of the American Society for Gravitational and Space 
Research, Baltimore MD, 3-6 Nov. 2021.
4. Dennis P. Stocker, Laminar Non-Premixed Flames of Gaseous Fuel Aboard the International 
Space Station, Spring Technical Meeting of The Central States Section of the Combustion 
Institute, Detroit, Mi, 15-17 May 2022, 10 pp.
Theses and Dissertations
1. M. Kim, Spherical Gas-Fueled Cool Diffusion Flames, MS Thesis, University of Maryland, 
60 pp., May 2022.
2. K.A. Waddell, Cool Diffusion Flames in Stagnation Flow, Ph.D. Dissertation, University of 
Maryland, in preparation.
N.3 Awards
In 2021, CFI-G Principal Investigator Peter Sunderland was inducted as a Fellow of the Combustion 
Institute for his “significant contributions to understanding laminar flame dynamics and soot
formation and oxidation.”
While the awards proceed the CFI-G experiment, CFI-G Co-Investigator Forman Williams was
recognized by the Combustion Institute with the Silver Combustion Medal (1978) and the Bernard 
Lewis Gold Medal (in 1990). He furthermore was induced in the inaugural 2018 class of Fellows of the 
Combustion Institute for his “pioneering investigations in energy and combustion including nitric
oxide emissions, spray and turbulent combustion, chemical kinetics and fire research.”
N.4 Outreach
NASA Project Scientist Dennis Stocker created the Space Flames Facebook page 
(www.facebook.com/space.flames) and Flickr site (https://www.flickr.com/photos/space-flames), 
where some entries are specific to CFI-G. He continues to administer these sites, where most content 
thus far has been about the ACME project of which CFI-G is a part. As an example of educational
outreach, a simple board game related to the ACME’s spherical flames experiments can be 
downloaded from https://www1.grc.nasa.gov/space/iss-research/iss-fcf/cir/acme/downloads/. 
ACME factsheets, papers, posters, and presentations providing a project overview and status can also 
be downloaded from that page. Printed copies of fact sheets have been distributed at meetings of 
The Combustion Institute and the American Society for Gravitational and Space Research (ASGSR).
The University of Maryland and Washington University in St. Louis promoted awareness of the CFI-G
investigation online, as can be seen via these links:
• ‘Cool Flame’ Discovered Aboard International Space Station
• ‘Cool flames’ ignited in space
~~~~

### Pagina 89

Cita: [pdf_f6cce7cc08ca69c15599, p. 89]. Metodo: native.

~~~~text
ACME/CFI-G Final Report (2022) 21 November 2022
89
• Fire Protection Experts Available to the Media
• Fires in Microgravity
• FPE Professor Peter Sunderland Designated PI on Upcoming NIST and NSF Projects
• FPE Prof Peter Sunderland discusses BRE experiments, currently aboard the ISS, with media.
• Sunderland Gives Invited Talk at ASGSR 2021 Symposium
• Unlocking the Mysteries of Fire ... in Space
• Unusual "cool flames" discovered aboard International Space Station
CASIS and NSF, which selected the experiment for spaceflight, promoted awareness of the research 
as can be seen through these links:
• Gravity’s grip on heat and fire to be studied in space
• Science in Space: NSF & ISS Briefing
• The National Science Foundation and the ISS National Lab Announce Three Selected Projects 
from Combustion and Thermal Transport Funding Opportunity Onboard the International 
Space Station
• Unusual "cool flames" discovered aboard International Space Station
Tweets and Facebook posts from the investigators’ organizations and NSF are found on subsequent 
pages, where there could easily be more.
Meanwhile, NASA promoted awareness of ISS combustion research with the video ‘The Power of 
Studying Combustion on the ISS’ which was posted on March 13, 2018.
Awareness of ISS combustion research, including the ACME project, was promoted on Oct. 15, 2018 
by The Combustion Institute in their online news article, “International Space Station (ISS) Combustion 
Experiments.”
A photo collage and 1-paragraph article on ACME by Michael Greshko titled “Cosmic Combustion” 
was published on page 22 of the Oct. 2022 issue of the National Geographic Magazine, for which there 
is an online version. While general to ACME, the article addresses CFI-G with a statement about the 
flames: “In microgravity they can swell into ethereal … orbs that can burn at a surprisingly cool 900 
degrees Fahrenheit (a gas stove burner’s high setting is about 3100o
F).” Despite its brevity, 
Sunderland and Stocker were both interviewed for the article.
Stocker is involved in a broad range of NASA educational outreach to students and teachers, Scouts 
of both genders, and the general public. His primary outreach focus is the fundamentals of 
microgravity and human spaceflight, for example through microgravity design challenges which he 
helps create and administer. But he periodically addresses other topics, e.g., where he sometimes 
speaks on ‘NASA and the Science of Superman’ – for example at the Superman Celebration in 
Metropolis, IL. In this regard, his NASA outreach is carried out locally, regionally, nationally, and 
online. For example, he regularly presents on microgravity at Space Center Houston’s Space 
Exploration Educators Conference (SEEC). He has exhibited the last five National Scout Jamborees, 
five national Boy Scout conferences, the last three national Girl Scout conventions, and the 2019 
World Scout Jamboree (which was held in the U.S.). Stocker has been a key lead for the agency in 
NASA’s participation in these Scouting events, where as an example the latter outreach is visually 
described at www.nasa.gov/feature/stem/world-scout-jamboree.html.
~~~~

### Pagina 90

Cita: [pdf_f6cce7cc08ca69c15599, p. 90]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_f6cce7cc08ca69c15599/p0090.jpg)

~~~~text
ACME/CFI-G Final Report (2022) | 21 November 2022
2021 July 15: GMT 196
Maryland Engineering
@ClarkSchool
A new class of fire, spherical cool diffusion flames or
"cool flames," has been documented aboard the
International @Space_Station. The discovery of these
flames—led by UMD's Peter Sunderland—could ignite
development of the combustion engine of the future.
go.umd.edu/cfiss
ISS Research and Univ. of Maryland
8:59 AM • Jul 15, 2021 • Twitter Web App
90
~~~~

### Pagina 91

Cita: [pdf_f6cce7cc08ca69c15599, p. 91]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_f6cce7cc08ca69c15599/p0091.jpg)

~~~~text
ACME/CFI-G Final Report (2022) | 21 November 2022
2021 July 15: GMT 196
UMD Right Now
@UMDRightNow
What is a "cool flame?" Researchers from
@ClarkSchool have discovered a new class of fire
aboard the International @Space_Station. Click below
to read more:
O Maryland Engineering O @ClarkSchool • Jul 15, 2021
A new class of fire, spherical cool diffusion flames or "cool flames," has been
documented aboard the International @Space_Station. The discovery of these
flames—led by I-JMD's Peter Sunderland—could ignite development of the
combustion engine of the future. go.umd.edu/cfiss
11:55 AM • Jul 19, 2021 • Twitter Web App
91
~~~~

### Pagina 92

Cita: [pdf_f6cce7cc08ca69c15599, p. 92]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_f6cce7cc08ca69c15599/p0092.jpg)

~~~~text
ACME/CFI-G Final Report (2022) | 21 November 2022
2021 July 20: GMT 201
WashU Tech Transfer
TECH
@WashUOTM
"Being able to perform experiments in microgravity
allowed us to observe a flame that just would not exist
on Earth. This type of discovery is what makes the
@Space_Station so invaluable to scientific
exploration." — Richard Axelbaum @WashUengineers
source.wustl.edu
'Cool flames' ignited in space - The Source - Washington U...
Richard Axelbaum in the McKelvey School of Engineering at
Washington University in St. Louis and collaborators have „
9:24 AM Jul 20, 2021 Twitter Web App
2021 July 27: GMT 208
National Science Foundation
@NSF
"Cool flames" in space?
discovered super low-temperature fire
on the @Space_Station - & changed our understanding
of what fire is. It could also lead to a new combustion
engine. bit.ly/3x4kZ8n
#NSFfunded
IO mm | 10 1
beta.nsf.gov
Unusual "cool flames" discovered aboard International Space Station
10:19 AM Jul 27, 2021 Twitter Web App
92
~~~~

### Pagina 93

Cita: [pdf_f6cce7cc08ca69c15599, p. 93]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_f6cce7cc08ca69c15599/p0093.jpg)

~~~~text
ACME/CFI-G Final Report (2022) | 21 November 2022
2021 Aug. 2: GMT 214
University of Maryland Department of Fire Protection Engineering
August 2, 2021
A. James Clark School Of Engineering
July 15, 2021
An entirely new class of fire, spherical cool diffusion flames or simply "cool flames," has been
documented aboard the International Space Station. The discovery of these dim, quiet flames
—led by Professor Peter Sunderland—could literally ignite development of the combustion
engine Of the future.
Read more: https://go.umd.edu/cfiss
0 16 | 2 Comments
2021 Aug. 3: GMT 215
Washington University in St. Louis McKelvey School of
Engineering
August 3, 2021 •
"Being able to perform experiments in microgravity allowed us to
observe a flame that just would not exist on Earth. This type of
discovery is what makes the Space Station so invaluable to scientific
exploration." - Richard Axelbaum, the Stifel & Quinette Jens Professor
of Environmental Engineering Science
Flane* 18 | Cml | IO
s | at s
i
ENGINEERING.WUSTL.EDU
'Cool flames' ignited in space
Experiments in microgravity allow Axelbaum, collaborators to obser...
93
~~~~
