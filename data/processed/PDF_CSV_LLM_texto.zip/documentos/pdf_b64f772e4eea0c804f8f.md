# S1101MFB0001_-ACME_Drawing_Tree

- Identificador: pdf_b64f772e4eea0c804f8f
- Investigaciones: PSI-20, PSI-22, PSI-23
- Tipo de documento: Engineering Documents
- Estado: processed
- Temas detectados automaticamente: ignition, hardware

## Fuentes

- [PSI-20_Engineering Documents_S1101MFB0001_-ACME_Drawing_Tree.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-20/Engineering%20Documents/PSI-20_Engineering%20Documents_S1101MFB0001_-ACME_Drawing_Tree.pdf)
- [PSI-22_Engineering Documents_S1101MFB0001_-ACME_Drawing_Tree.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-22/Engineering%20Documents/PSI-22_Engineering%20Documents_S1101MFB0001_-ACME_Drawing_Tree.pdf)
- [PSI-23_Engineering Documents_S1101MFB0001_-ACME_Drawing_Tree.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-23/Engineering%20Documents/PSI-23_Engineering%20Documents_S1101MFB0001_-ACME_Drawing_Tree.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_b64f772e4eea0c804f8f, p. 1]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_b64f772e4eea0c804f8f/p0001.jpg)

~~~~text
4 | 3 | 2
ACME Matrix
D
Sl 101 XXXXXXX
Chamber | Color Camera | Avionics | Ground Support and | Shipping
Insert | Package | Package | Non—Deliverable | and
Assembly | Test Equipment
Sl 101XXX2000-2999 | Sl 101XXX3000-3999 | Stowage
Sl 101XXX0001-1999 | Sl 101 xxx5000—5999
Sl 101 xxx4000—4999
On—Orbit | Launch | Common | Hoses | Assembly | Camera | Common | Assembly | Main | Power | Ground | Non—Deliverable | Flight | Shipping
c | Configuration | Configuration | Electrical | and QD | Configuration | System | Electrical | Configuration | Computer | Distribution | Support | Test/ Support | Stowage | Containers | c
Sl 101M0003—0099 | sli01xxxotoo—0199 | System | Assemblies | Sl 101M2000-2099 | Sl 101XXX2200-2299 | System | Sl 101XXX3000—3099 | System | System | Hardware | Equipment | Containers
Sl 101XXX3200—3299 | Sl 101XXX3400—3499 | Sl 101 xxx5500-5999
Sl 101M0200—0499 | Sl 101M0500—0599 | Sl 101 xxx2400—2499 | Sl 101 xxx4000—4499 | Sl 101XXX4500-4999 | 101 MX5000-5499
Housing | Filter | Housing | Data | Common
Mechanism | Storage | Electrical
Experiment | Burner | Analog | Measurement | Cooling | S1101M2100—2199 | System | S1101XXX3100—3199 | System | System
Mounting | Camera | Sl 101XXX2300-2399 | Sl 101XXX3300—3399 | Sl 101XXX3500-3599
System | System | System
Structure | System
Sl 101xxx1000—1099 | Sl 101xxxtmo—1299 | S1101XXX1eoo—1699 | S1101xmeoo—1899
S1101XXX1400-1499
Flow | Ignition | Diagnostic | E-Field
System | System | System | System
S1101XXX1100—1199 | S1101XXX1300—1399 | S1101XXX1soo—1S99 | S1101XXX1700—1799
B
CHG ZONE | DESCRIPTION | App/DATE
REVISIONS
ZIN TECHNOLOGIES | NATIONAL AERONAUTICS AND SPACE ADMINISTRATION
UNLESS OTHERWISE SPECIFIED
6745 ENGLE ROAD | JOHN H. GLENN RESEARCH CENTER
DIMENSIONS ARE IN INCHES
AIRPORT EXECUTIVE PARK | LEWIS FIELD
CLEVELAND, OHIO 44130 | CLEVELAND, OHIO
TOLERANCE ON | AN | 440 | ¯2200
.x | .xx | DESIGNER | P.GALANT 11/09/10
.xx | LEAD
. xx | A.DRAKE 11/09/10
ENGINEER
MATERIALS A.DRAKE
. xxx | .xxx | 11/09/10
REPRESENTIVE
FRACTI ON ± x/x | QUALITY | D.SEELEY 11/09/10
ACME
ANGULAR | ± x• XX' | SAFETY | N/A | FLIGHT DRAWING TREE
THIS DRAWING IS UNDER CONFIGURATION | p ROJECT
BREAK EDGES .XX-.XX | B.BOROWSKI 11/09/1
CONTROL: DO NOT REVISE WITHOUT APPROVED ECO | LEAD
CONTRACT NO. | SIZE | DRAWING NUMBER | REV | BLDG | AREA
DIMENSIONING AND | NNC09BA02B | ZIN | GRC
TOLERANCING PER | C | SIIOIMFBOOOI
APPROVED: L. FOLGER | DATE: 11/09/10 | DELIVERY ORDER | UNITS: | INCH
ASME YI 4.5M-1994
SPACE 110 | SCALE: | INITIAL REL DATE | SHEET | DISCIPLINE
PRIOR TO USE CHECK FOR ANY OUTSTANDING ECO's WITH CONFIGURATION MANAGEMENT OFFICE | NONE | 11/09/2010 | 1 OF 1 | M ECH
AutoCad
4 | 3
~~~~
