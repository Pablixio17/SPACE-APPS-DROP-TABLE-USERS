# 20346 test sheets

- Identificador: pdf_ef50be5a9c79f41b83c7
- Investigaciones: PSI-20
- Tipo de documento: Raw Data
- Estado: processed
- Temas detectados automaticamente: oxygen, pressure, ignition, hardware, soot

## Fuentes

- [PSI-20_Raw Data_20346 test sheets.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-20/Raw%20Data/PSI-20_Raw%20Data_20346%20test%20sheets.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_ef50be5a9c79f41b83c7, p. 1]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_ef50be5a9c79f41b83c7/p0001.jpg)

~~~~text
ACME / BRE - Science Test Sheet
est date: | CME test #: 2--03
Local time: | est of day#:
MT: 20 | 3 | Flame of day
Rack Officer (RO): | PD (ACME):
DMO (CIR): | Researcher:
TEST CONDITIONS | Control? | Rfully automated 'manual'
ü
Test type? o fiber ignition no-flame | standard other
ramp steppingæ | c]
Oxygen conc. ...c | % (vol, nominal) | Burner diameter: K25 mm 050 mm
Oxygen conc. | % (vol, per calc) | Fuel Bottle: | CH4 | 0/0 XIC2H4
Chamber pressure: | -7 psia CIR avg | Burner fuel conc.: 5b | %
(volume)
ent before? o no | to | psia | Fuel flow rate: a | slpm
(N2 basis)
Air' added? no yes, to _47.1— psia | N-2.-fl.ow-f&tey O
slpm
Iso just before? o fan GC scrub
FP? no fixed moving back-n-forth
INSTRUMENTATION | Gain: | DataCam
ops camera
RDataCam: | clear o BG7 0 CH* CH20 | ROI? Zfull o reduced | fps
Intensified: filter? clear Z.CH* o CH20 none | ROI? | o reduced | 22 fps
G,-HiBMs: backlight filter? no Ryes | CIR backlight? o no | fps.?-g45Q30
kyes
FLAME BEHAVIOR | Ignition? sustained flashes
only no
Flame o hole/opening o partially detached | oot@ignition | little lots
a none
Flame oscillating unsteady o | oot@middle | little lots
none | o
Out o ext. detect time out o temp. limit | oot@end | little lots
D none
POST-TEST CONDITIONS
xygen conc. | % (vol, per calc) | Oxidizer bottle pressure: | psia
alve safety timer | sec | Fuel bottle
pressure: | 7 psia
*GENERAL COMMENTS
27 August 2020
~~~~

### Pagina 2

Cita: [pdf_ef50be5a9c79f41b83c7, p. 2]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_ef50be5a9c79f41b83c7/p0002.jpg)

~~~~text
ACME / BRE - Science Test Sheet
est date: | CME test
Local time: | est of day#: 2—
MT: 20 346 | z/ | Flame of day #:
Rack Officer (RO): | PD (ACME):
DMO (CIR): | Researcher:
TEST CONDITIONS | Control?
R fully automated o 'manual'
Test type? fiber o ignition c] no-flame o | a | other
ramp stepping<standard
Oxygen conc. | % (vol, nominal) | Burner diameter: k25 | 50
mm | mm
xygen conc. | 0/0 (vol, per calc) | Fuel Bottle: | CH4 | % g.C2H45ö 0/0
Chamber pressure: 147 ' psia CIR | Burner fuel
avg | conc.: | so' % (volume)
ent before? Rno yes, to | psia | Fuel flow rate:
slpm (N2 basis)
Air' added? ano c] yes, to | psia | N2 flow rate:
slpm
Iso just before? *fan GC scrub
FP? noÅfixed o moving back-n-forth
INSTRUMENTATION | ain: —Q— DataCam
ops camera
ZDataCam: filter? *Clear BG7 CH* CH20 | ROI? | reduced
efull | fps
p Intensified: filter? | CH20 none | ROI? Efull reduced
fps
acklight filter? nozyes | CIR backlight? no | fE?-e45-a-3Q-,
yes
FLAME BEHAVIOR | ,t/q | Ignition? sustained flashes
only o no
Flame c] hole/opening partially detached | oot@ignition
none little lots
Flame oscillating unsteady | oot@middle
o none little o lots
Out o ext. detect time out temp. limit | oot@end
none c] little o lots
POST-TEST CONDITIONS
Oxygen conc. | % (vol, per calc) | Oxidizer bottle | psia
pressure:
alve safety timer | sec | Fuel bottle
pressure: | psia
*GENERAL COMMENTS
27 August 2020
~~~~

### Pagina 3

Cita: [pdf_ef50be5a9c79f41b83c7, p. 3]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_ef50be5a9c79f41b83c7/p0003.jpg)

~~~~text
ACME / BRE - Science Test Sheet
est date: | CME test#:
Local time: | est of day #:
MT: | Flame of day #:
TEST CONDITIONS | Control? | (fully automated 'manual'
Test type? fiber a ignition CJ no-flame ramp stepping A-standard o other
Oxygen conc. | D % (vol, nominal) | Burner diameter: | mm 50
mm
Oxygen conc. | % (vol, per calc) | Fuel Bottle: CH4 | 0/0 *C2H4 50 %
hamber pressure: | 78 psia CIR avg | Burner fuel conc.: | % (volume)
ent before? | o o yes, to | psia | Fuel flow rate: | 4 slpm (N2 basis)
Air' added?. no yes, to | psia | e: | O slpm
fiz_
Iso just before? | fan GC scrub
FP? o no fixed moving back-n-forth
INSTRUMENTATION | Gain: D DataCam _äL_ | camera
ops
DataCam: filter?yclear BG7 | CH20 | ROI? K full a reduced | fps
zlntensified: filter? clear | CH20 0 none | ROI? full reduced | fps
N
-g-H.iBMs: backlight filter? no—es | CIR backlight? no eyes fps?æ4-5-e-30
FLAME BEHAVIOR | Ignition? Asustained c] flashes only no
Flame hole/opening partially detached | Soot@ignition | none-Aittle lots
Flame oscillating o unstead | Soot@middle | none o little lots
Z
Out o ext. detect time out o temp. limit | oot@end | none little o lots
z
POST-TEST CONDITIONS
Oxygen conc. | % (vol, per calc) | Oxidizer bottle pressure: | S psia
alve safety timer | Z— sec | Fuel bottle pressure: | 04 psia
*GENERAL COMMENTS
27 August 2020
~~~~

### Pagina 4

Cita: [pdf_ef50be5a9c79f41b83c7, p. 4]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_ef50be5a9c79f41b83c7/p0004.jpg)

~~~~text
ACME / BRE - Science Test Sheet
est date: | CME test #:
Local time: | est of day
GMT: 20 | Flame of day#:
Z
TEST CONDITIONS | Control?
<fully automated 'manual'
Test type? fiber o ignition no-flame | E standard other
ramp stepping | o
xygen conc. -Jo % (vol, nominal) | Burner diameter:
r25 mm 50 mm
Oxygen conc. | O % (vol, per calc) | Fuel Bottle: | CH4 | % (C2H4
Chamber pressure: | 76 psia CIR | Burner fuel | %
avg | conc.: | (volume)
ent before? no yes, to | psia | Fuel flow rate:
OD | slpm (N2 basis)
Air' added? | o yes, to | psia | N-2-f4ew-rater | D
slpm
Iso just before? | fan o GC scrub
no o fixed moving D back-n-forth
INSTRUMENTATION | ain: | DataCam
ops camera
DataCam: filter? clear o BG7 ü CH* CH20 | ROI? R full reduced
fps
_
Zlntensified: filter? clear CH* CH20 none | ROI? Qfull reduced
o | fps
backlight filter? no Ayes | CIR backlight? no eyes fps? 15 30
FLAME BEHAVIOR | Ignition? (sustained flashes
o | only no
Flame hole/opening partially detached | oot@ignition
none little lots
Flame oscillating a unstead | oot@middle
none little lots
Out c] ext. detect time out o temp. limit | oot@end
none little lots
POST-TEST CONDITIONS
*GENERAL COMMENTS
27 August 2020
~~~~

### Pagina 5

Cita: [pdf_ef50be5a9c79f41b83c7, p. 5]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_ef50be5a9c79f41b83c7/p0005.jpg)

~~~~text
ACME / BRE - Science Test Sheet
est date: | a 2-0 | CME test#: 2-03
Local time: | est of day
GMT: 3 344 /&Zo | Flame of | #:
day
Rack Officer (RO): | S-)-evé_ L | PD (ACME):
6.
DMO (CIR): | Researcher:
TEST CONDITIONS | Control?
Q fully automated D 'manual'
Test type? fiber o ignition no-flame Cl | standard
ramp steppin | ü other
FP? | o fixed ü moving back-n-forth
INSTRUMENTATION | Gain: —O_ DataCam -3 r
ops camera
*DataCam: filter? Eclear BG7 D CH* CH20 | ROI? | reduced
Rfull | fps
Intensified: filter? cleark-CH* CH20 none | ROI? full reduced | 2.3
L | o | fps
.æ-Hi•BMs: backlight filter? no<yes | CIR backlight?
no Ryes f..p.s-?-æzs-g-aæ
POST-TEST CONDITIONS
Oxygen conc. | % (vol, per calc) | Oxidizer bottle
pressure: J Zee psia
alve safety timer | sec | Fuel bottle
pressure: | 40 | psia
*GENERAL COMMENTS
27 August 2020
~~~~

### Pagina 6

Cita: [pdf_ef50be5a9c79f41b83c7, p. 6]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_ef50be5a9c79f41b83c7/p0006.jpg)

~~~~text
ACME / BRE - Science Test Sheet
est date: | 22.0 | CME test#:
Local time: | / 75 | est of day
GMT: | O | Flame of day #:
Rack Officer (RO): | PD (ACME):
DMO (CIR): | Researcher:
TEST CONDITIONS | Control? | automated 'manual'
fully | o
Test type? fiber ignition no-flame | ü stepping standard other
ramp | o
Oxygen conc. | D % (vol, nominal) | Burner diameter: SQ5 mm a 50 mm
xygen conc. | % (vol, per calc) | Fuel Bottle: OCH4
Chamber pressure: | Z-psia CIR avg | Burner fuel conc.: | %
(volume)
ent before? | yes, to | psia | Fuel flow rate: DO | lpm
(N2 basis)
Air' added? A no yes, to | psia | N2 flow rate:
Ut) | slpm
Iso just before? | fan GC o scrub
FP? no A fixed moving back-n-forth
INSTRUMENTATION | ain: D | DataCam 3 |
ops camera
KDataCam: filter? x-clear BG7 | CH20 | ROI? full D reduced
R | fps
filter? clear | o CH20 none | o reduced | fps
æHiBM*backlight filter? o no <yes | CIR backlight? nokyes fp.s*-a4-5-n-3B
FLAME BEHAVIOR | Ignition? sustained flashes
only ü no
Flame hole/opening partially detached | oot@ignition | little
none | Clots
Flame ü oscillating o unsteady | Soot@middle | little lots
y | none | o
Out ext. detect 'time out o temp. limit | oot@end | Caone little lots
D
POST-TEST CONDITIONS
*GENERAL COMMENTS
27 August 2020
~~~~

### Pagina 7

Cita: [pdf_ef50be5a9c79f41b83c7, p. 7]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_ef50be5a9c79f41b83c7/p0007.jpg)

~~~~text
ACME / BRE - Science Test Sheet
est date: | 2DV2-O | CME test
Local time: | est of day #:
GMT: 2-0 3 | Flame of day #:
Rack Officer (RO): | PD (ACME):
DMO (CIR): | Researcher:
TEST CONDITIONS | ontrol?
Nully automated 'manual'
Test type? o fiber o ignition c] no-flame a | o | *standard other
ramp stepping
Oxygen conc. ZI-ZIZO % (vol, nominal) | Burner diameter: | 25 | 50
Z mm | mm
Oxygen conc. 3770 % (vol, per calc) | Fuel Bottle: CH4 | 0/6B-C2H45D %
Chamber pressure: )dZ5 psia CIR | Burner fuel | %
avg | conc.: | (volume)
ent before? no a yes, to | psia | Fuel flow rate: | eDCz4
slpm (N2 basis)
Air' added? L no yes, to | psia | N2 flow rate:
slpm
Iso just before? o fan GC scrub
no fixed moving back-n-forth
INSTRUMENTATION | Gain: | DataCam
ops camera
ZDataCam: filter? g-clear BG7 CH* CH20 | ROI? full
q | reduced | fps
_
*Æntensified: filter? clear LCH* CH20 none | ROI? full reduced
Z | o
F*tBM3.• backlight filter? no Ryes | CIR backlight?
no)a yes
FLAME BEHAVIOR | Ignition? {sustained
o flashes only no
Flame hole/opening partially detached | oot@ignition
none c] little Zlots
Flame oscillating ü unsteady C | i | oot@middle
none o little lots
Out ext. detect (time out temp. limit | oot@end | little
4 none o | lots
POST-TEST CONDITIONS
*GENERAL COMMENTS
27 August 2020
~~~~

### Pagina 8

Cita: [pdf_ef50be5a9c79f41b83c7, p. 8]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_ef50be5a9c79f41b83c7/p0008.jpg)

~~~~text
ACME / BRE - Science Test Sheet
est date: | / | 20 | CME test#:
•ZD | 3
Local time: | jz=3 | est of day | 8
GMT: | O 3 | Flame of day #:
TEST CONDITIONS | Control?
R fully automated o 'manual'
Test type? o fiber ignition c] no-flame | standard other
ramp steppingm | o
Oxygen conc. | % (vol, nominal) | Burner diameter: | 25 | 50
A mm | mm
Oxygen conc. | -2 % (vol, per calc) | Fuel Bottle: | CH4 | %
kC2H4 50 %
hamber pressure: / | psia CIR | Burner fuel | 0/0
avg | conc.: | (volume)
ent before? no yes, to | psia | Fuel flow rate: Ö-E
slpm (N2 basis)
Air' added? Eno o yes, to | psia | N2 flow rate:
slpm
Iso just before? | fan GC scrub
fixed moving back-n-forth
INSTRUMENTATION | Gain: t,) | DataCam
ops camera
DataCam: filter? {clear BG7 | CH20 | ROI? | reduced
Rfull | fps
Elntensified: filter? clear M CH* CH20 none | ROI? full reduced
ø | o | ZZ fps
HiBMs: backlight filter? no yes | CIR backlight? no | fps-?-üT5T36
zyes
FLAME BEHAVIOR | Ignition? | flashes
Z'sustained | only no
Flame hole/opening D partially detached | oot@ignition
none little<lots
Flame Zoscillating | o | oot@middle
<Qone little o lots
Out ext. detectÄtime out o temp. limit | oot@end
none little lots
POST-TEST CONDITIONS
Oxygen conc. | % (vol, per calc) | Oxidizer bottle pressure: /Zæ psia
alve safety timer | / 65 | sec | Fuel bottle
pressure: | psia
*GENERAL COMMENTS
27 August 2020
~~~~

### Pagina 9

Cita: [pdf_ef50be5a9c79f41b83c7, p. 9]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_ef50be5a9c79f41b83c7/p0009.jpg)

~~~~text
ACME / BRE - Science Test Sheet
est date: | CME test#: 30
Local time: | est of day #:
MT: | 2b | Flame of day#: 7
Rack Officer (RO): | PD (ACME):
DMO (CIR): | Researcher: | e„ÄSS.
TEST CONDITIONS | Control? | automated
ully | 'manual'
Test type? fiber o ignition o no-flame | stepping. standard other
ramp | o
Oxygen conc. | % (vol, nominal) | Burner diameter: (25 mm 50
mm
Oxygen conc. | 67 | % (vol, per calc) | Fuel Bottle: | CH4
Chamber pressure: / ff/ psia CIR avg | Burner fuel conc.. | %
, | (volume)
ent before? € no o yes, to | psia | Fuel flow rate: a i | slpm
(N2 basis)
Air' added? Ono yes, to | psia | N2 flow rate:
slpm
Iso just before? ßfan GC scrub
FP? no [Efixed moving o back-n-forth
INSTRUMENTATION | ain:
DataCam | ops camera
filter? *Clear c] BG7 | D CH20 | ROI? •4-full reduced
fps
filter? o clear CCH* CH20 none | ROI? Efull o reduced | Z.) fps
filter? no Lyes | CIR backlight? no | fps.?-a-æs-ff-30
E.yes
POST-TEST CONDITIONS
Oxygen conc. | % (vol, per calc) | Oxidizer bottle pressure: | psia
i
alve safety timer | b | sec | Fuel bottle
pressure: | psia
*GENERAL COMMENTS
acce
,4A.4v-o.«
27 August 2020
~~~~

### Pagina 10

Cita: [pdf_ef50be5a9c79f41b83c7, p. 10]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_ef50be5a9c79f41b83c7/p0010.jpg)

~~~~text
ACME / BRE - Science Test Sheet
est date: | test#: 3034Za4
Local time: | est of day#: | iD
GMT: | Flame of day#: g
TEST CONDITIONS | ontrol? | iGully automated ü 'manual'
Test type? fiber ignition o no-flame o ramp o stepping& standard other
Oxygen conc. | D % (vol, nominal) | Burner diameter: | 25 mm 0 50 mm
xygen conc. | % (vol, per calc) | Fuel Bottle: | CH4 | 0/0 SZC2H45ö %
Chamber pressure: .44 | psia CIR avg | Burner fuel conc.. | % (volume)
ent before? Z no o yes, to | psia | Fuel flow rate: | Oi4 slpm (N2 basis)
Air' added? | a yes, to | psia | N2 flow rate: 0 047 slpm
Iso just before? Afan GC scrub
FP? no Xfixed o moving back-n-forth
INSTRUMENTATION | ain: | Ö DataCam 2_1__ ops camera
QDataCam: filter? y-clear BG7 CH* CH20 | ROI? Efull o reduced | fps
Intensified: filter? o clear ECH* CH20 0 none | ROI?Äfull reduced | fps
ß44iBMs*acklight filter? no Zyes | CIR backlight? no Y-yes fps2-g45--a-30
FLAME BEHAVIOR | Ignition? Ksustained o flashes only no
Flame o hole/opening o partially detached | oot@ignition | none little lots
Flame oscillating o unstead | oot@middle Zhone little lots
Out o ext. detect time out temp. limit | oot@end | Znone c] little a lots
POST-TEST CONDITIONS
*GENERAL COMMENTS
Y-es+
27 August 2020
~~~~

### Pagina 11

Cita: [pdf_ef50be5a9c79f41b83c7, p. 11]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_ef50be5a9c79f41b83c7/p0011.jpg)

~~~~text
ACME / BRE - Science Test Sheet
est date: | ( \ | CME test#:
Local time: | est of day #:
MT: ZD | 34 | 20 $3 | Flame of day #:
TEST CONDITIONS | Control? | (fully automated o 'manual'
Test type? c] fiber ignition o no-flame ramp stepping p standard other
Oxygen conc. | % (vol, nominal) | Burner diameter: k 25 mm 50 mm
Oxygen conc. | % (vol, per calc) | Fuel Bottle: DCH4 | 0/0 AC2H49/0
Chamber pressure: | psia CIR avg | Burner fuel conc.: | O % (volume)
ent before? no yes, to | psia | Fuel flow rate: 00 | slpm (N2 basis)
Air' added? a no | to | psia | D slpm
Iso just before? o fan GC. scrub
FP? | moving ü back-n-forth
INSTRUMENTATION | ain: —a— DataCam | ops camera
*DataCam: filter? kclear BG7 CH* CH20 | ROI? *full reduced | fps
_
Antensified: filter? o clear q CH* CH20 0 none | ROI? full Cl reduced | fps
Q.HiBMs: backlight filter? no | CIR backlight? no ayes
FLAME BEHAVIOR | Ignition? Rsustained flashes only no
Flame o hole/opening *partially detached | Soot@ignition | none little lots
Flame•oscillating Zunsteady | oot@middle | none c] little o lots
Out *ext. detect time out c] temp. limit | oot@end | Gone o little lots
POST-TEST CONDITIONS
Oxygen conc. | % (vol, per calc) | Oxidizer bottle pressure: $50 psia
alve safety timer | D | sec | Fuel bottle pressure: | 38 | psia
*GENERAL COMMENTS
27 August 2020
~~~~

### Pagina 12

Cita: [pdf_ef50be5a9c79f41b83c7, p. 12]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_ef50be5a9c79f41b83c7/p0012.jpg)

~~~~text
ACME / BRE - Science Test Sheet
est date: | CME test#: & 3
Local time: | est of day
GMT: | 344 | Flame of day#:
Ö
TEST CONDITIONS | ontrol? | ('fully automated 'manual'
Test type? fiber ignition no-flame o ramp | c] other
Oxygen conc. | % (vol, nominal) | Burner diameter: | mm 50 mm
Oxygen conc. | u) | % (vol, per calc) | Fuel Bottle: | CH4
Chamber pressure: | .71 psia CIR avg | Burner fuel conc.: | % (volume)
ent before? no yes, to | psia | Fuel flow rate: | 4slpm (N2 basis)
Air' added? eno yes, to | psia | N2 flow rate: | O | slpm
Iso just before? *fan GC scrub
F P? no fixed Xmoving back-n-forth
INSTRUMENTATION | ain: | DataCam -31 | camera
ops
DataCam: filter? Eclear o BG7 CH* ü CH20 | ROI? R full o reduced | fps
_
Xlntensified: filter? clearg CH* CH20 none | ROI? *full reduced | &fps
cz.."BMs: backlight filter? no | CIR backlight? no | fps?æ4-s-a-3€
*yes
FLAME BEHAVIOR | Ignition? sustained o flashes only no
Flame hole/opening partially detached | oot@ignition | none little lots
Flame oscillating unsteady o | oot@middle | none o little lots
Ou | ext. detect o time out temp. limit | oot@end | o little lots
ønone
POST-TEST CONDITIONS
Oxygen conc. Z//-b % (vol, per calc) | Oxidizer bottle
pressure: 5Z_ psia
alve safety timer | sec | Fuel bottle pressure: | psia
*GENERAL COMMENTS
27 August 2020
~~~~

### Pagina 13

Cita: [pdf_ef50be5a9c79f41b83c7, p. 13]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_ef50be5a9c79f41b83c7/p0013.jpg)

~~~~text
ACME / BRE - Science Test Sheet
est date: | 2-020 | CME test#: 20>+13
Local time: | est of day#:
GMT: | 348 | Flame of day #:
TEST CONDITIONS | Control? | <fully automated 'manual'
Test type? o fiber ignition no-flame | stepping<standard other
ramp
xygen conc. —Z 5 % (vol, nominal) | Burner diameter: 'X 25 mm 0 50 mm
Oxygen conc. 2.4-67 % (vol, per calc) | Fuel Bottle: o CH4 | 0/0 C2H45'0 0/0
hamber pressure: / -7) psia CIR avg | Burner fuel conc.: | %
(volume)
ent before?zno yes, to | psia | Fuel flow rate: o_z59 slpm (N2 basis)
Air' added?ø no o yes, to | psia | N2 flow rate: | slpm
b_DZ
Iso just before? | an o GC scrub
FP? o no ixed moving o back-n-forth
INSTRUMENTATION | ain.• | D DataCam
ops camera
DataCam: filter? *dear BG7 0 CH* CH20 | ROI? (full reduced | fps
_
A Intensified: filter? c] clear QCH* CH20 none | ROI? éfull reduced
&NiBMs: backlight filter? no Äyes | CIR backlight? | no
no sayes fps?-a-t5T-30
FLAME BEHAVIOR | Ignition? sustained flashes
only no
Flame hole/opening partially detached | oot@ignition y-none little
o | Ots
Flame oscillating unsteady | Soot@middle (none little lots
ut a ext. detect time out a temp. limit | Soot@end | Sone a little lots
POST-TEST CONDITIONS
Oxygen conc. | % (vol, per calc) | Oxidizer bottle pressure: $53 psia
alve safety timer | sec | Fuel bottle | 360
pressure: | psia
*GENERAL COMMENTS
eqs«—
27 August 2020
~~~~

### Pagina 14

Cita: [pdf_ef50be5a9c79f41b83c7, p. 14]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_ef50be5a9c79f41b83c7/p0014.jpg)

~~~~text
ACME / BRE - Science Test Sheet
est date: | I | ZOZZ | CME test#:
203
Local time: | est of day #:
GMT: | Flame of day #: i
TEST CONDITIONS | Control? | Kfully
automated 'manual'
Test type? CJ fiber ignition no-flame o | o | (standard other
ramp stepping | c]
Oxygen conc. | % (vol, nominal) | Burner diameter: | 25 mm 50
g | mm
Oxygen conc. | % (vol, per calc) | Fuel Bottle: o CH4
hamber pressure: | 7 2—psia CIR | Burner fuel conc.: | %
avg | (volume)
ent before? no yes, to | psia | Fuel flow rate:
slpm (N2 basis)
Air' added? Zno o yes, to | psia | N2 flow rate: | QDZ4
slpm
Iso just before? | fan GC scrub
FP? no fixed ß«noving c] back-n-forth
INSTRUMENTATION | ain: | D DataCam | t
ops camera
Datacam: filter?ßclear BG7 | CH20 | ROI? full reduced
R | ü | fps
_
Xlntensified: filter? clear CH* CH20 none | ROI? Afull reduced
fps
D-Hi-BM5 backlight filter? no eyes | CIR backlight? no | fpQ-a4-S-g-3Q
E_yes
FLAME BEHAVIOR | Ignition? | ustained flashes
only no
Flame ü hole/opening partially detached | oot@ignition *none
little<lots
Flame oscillating unsteady o | oot@middle | little
none o | lots
ut ext. detect time out o temp. limit | oot@end | '(none little lots
POST-TEST CONDITIONS
Oxygen conc. 241S | % (vol, per calc) | xidizer bottle
pressure: | psia
alve safety timer | 45 | sec | Fuel bottle
pressure: | 78 psia
*GENERAL COMMENTS
27 August 2020
~~~~

### Pagina 15

Cita: [pdf_ef50be5a9c79f41b83c7, p. 15]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_ef50be5a9c79f41b83c7/p0015.jpg)

~~~~text
ACME / BRE - Science Test Sheet
est date: | CME test#: 2D34Z /-k5
Local time: | est of day#: | 5
i
GMT: | Flame of day #:
Rack Officer (RO): | .5us+,Ä | PD (ACME):
DMO (CIR): | Researcher:
TEST CONDITIONS | Control? | zfully automated 'manual'
Test type? fiber o ignition no-flame ramp c] stepping estandard other
xygen conc. | % (vol, nominal) | Burner diameter: X 25 mm 50 mm
Oxygen conc. | % (vol, per calc) | Fuel Bottle: | CH4 | 0/0 C2H45ö 0/0
hamber pressure: | _74 psia CIR avg | Burner fuel conc.: | %
(volume)
ent before? < no o yes, to | psia | Fuel flow rate: | slpm (N2 basis)
a-D
Air' added? Cno o yes, to | psia | N2 flow rate: | slpm
Iso just before? Han GC scrub
FP? no < fixed moving back-n-forth
INSTRUMENTATION | Gain: D DataCam | ( | camera
ops
(DataCam: filter? zclear BG7 CH* CH20 | ROI? (full o reduced | fps
_
Llntensified: filter? clearRCH* CH20 none | ROI?'Q full o reduced | fps
a-Hi.BMs;-backlight filter? no Ryes | CIR backlight? o n | fps?æ45.-L2-3Q
yes
FLAME BEHAVIOR | 4/ | Ignition? o sustained flashes
only o no
Flame hole/opening partially detached | oot@ignition | none little lots
o
Flame o oscillating o unsteady | oot@middle | little lots
a none | o
Out o ext. detect o time out o temp. limit | Soot@end | none little lots
o
POST-TEST CONDITIONS
Oxygen conc. | % (vol, per calc) | Oxidizer bottle pressure: S5Z psia
alve safety timer | Z— sec | Fuel bottle | 380
pressure: | psia
*GENERAL COMMENTS
Pcs
27 August 2020
~~~~
