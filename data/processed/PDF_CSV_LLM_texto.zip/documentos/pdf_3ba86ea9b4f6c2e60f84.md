# Cool Flames in Space_ a Hot Prospect on Earth_CFI

- Identificador: pdf_3ba86ea9b4f6c2e60f84
- Investigaciones: PSI-39
- Tipo de documento: Presentations
- Estado: processed
- Temas detectados automaticamente: cool_flames, droplets, extinction, oxygen, computational_models, pressure, ignition, microgravity, hardware, soot, solid_materials, operations

## Fuentes

- [PSI-39_Presentations_Cool Flames in Space_ a Hot Prospect on Earth_CFI.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-39/Presentations/PSI-39_Presentations_Cool%20Flames%20in%20Space_%20a%20Hot%20Prospect%20on%20Earth_CFI.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Pasajes de orientacion (extractivos, no resumen validado)

### abstract - pagina 10

ABSTRACT
Artkle history: | Experimental (bservations of anomalous combustion of n-heptane droplets burning in microgravity are
Received 17 May 2012 | reported. Following ignition. a relatively large n-heptane droplet first undergoes radiative extinction. that
Received in revised form 25 June 2012 | is. the visible flame | to exist because of radiant | loss. But the | continues to
ceases | energ• | droplet | experience
Accepted 17 July 2012
vigorous vaporization for an extended period according to a quasi-steady droplet-burning law. ending in
Availabk online 18 August 2012
a secondary extinction at a finite droplet diameter. after which a vapor cloud rapidly appears surrounding
the droplet. We hypothesize that the second-stage vaporization is sustained by Iow-temperature. soot-
Keywords: | "cool-flame" chemical heat | Measured | and extinction diameters
free, | release. | droplet burning rates | are
Droplet combustion
used to extract an effective heat release. overall activation enero. and pre-exponential factor for this
Cool flames
Alkane | low-temperature chemistry. and the values of the resulting parameters are found to be closer to those
chemistry
Microgravity | of "cool-flame" overall reaction-rate parameters. found in the literature. than to corresponding hot-flame
Extinction | parameters.
@ 2012 The Combustion Institute. Published by Elsevier Inc. All rights reserved.
Published after critical reviews from skeptical reviewers!

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_3ba86ea9b4f6c2e60f84, p. 1]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
“Cool Flames” in Space, a Hot Prospect on Earth!
Anomalous combustion of alkane fuel droplets in space
Vedha Nayagam
National Center for Space Exploration Research
Case Western Reserve University/NASA Glenn Research Center
Cleveland, Ohio 44135
2
nd Annual ISS Research and Development Conference
July 16-18, 2013 Denver, Colorado
~~~~

### Pagina 2

Cita: [pdf_3ba86ea9b4f6c2e60f84, p. 2]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Principal Investigator
Prof. Forman A. Williams, UCSD
Co- Investigators
Prof. C. Thomas Avedisian, Cornell
Prof. Mun Y. Choi, UConn
Prof. Frederick L. Dryer, Princeton
Prof. Tanvir Farouk, U South Carolina
Mr. Michael C. Hicks, NASA GRC
Dr. Vedha Nayagam, NCSER/CWRU
Prof. Benjamin D. Shaw, UC Davis
Project Scientist
Dr. Daniel L. Dietrich, NASA GRC
Dr. Paul V. Ferkul, NCSER/GRC
Ms. Victoria M. Bryg, NCSER/GRC
Project Manager
Mr. J. Mark Hickman, NASA GRC
Flame Extinguishment Experiment (FLEX) Science Team
~~~~

### Pagina 3

Cita: [pdf_3ba86ea9b4f6c2e60f84, p. 3]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
ISS FLEX Experiments - Background
• Microgravity droplet combustion experiments aimed at
understanding the flammability boundaries of liquid
fuels in a variety of ambient conditions – spacecraft fire
safety
• Sooting and non-sooting fuels are burned in nitrogen,
helium, carbon dioxide, and xenon environment at
various oxygen concentrations at different pressures
(effectiveness of fire suppressants in spacecraft
environments – CO2
is used in ISS)
• Conventional understanding has been that the droplet
flame can extinguish via two modes:
• Diffusive extinction (high Oxygen, small droplet) or
• Radiative extinction (low oxygen, large droplet)
• Pure evaporation following extinction
• Existing theories and numerical simulations supported
this view
ISS
1-g
~~~~

### Pagina 4

Cita: [pdf_3ba86ea9b4f6c2e60f84, p. 4]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
ISS FLEX Experiments
• Example of two modes of extinction: Droplet combustion experiment (DCE)
Space Lab Mission MSL-1
n-heptane in 30-70% oxygen-helium environment at 1 atm
diffusive
radiative
~~~~

### Pagina 5

Cita: [pdf_3ba86ea9b4f6c2e60f84, p. 5]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
ISS FLEX Experiments
• Droplet combustion experiment (DCE) Space Lab Mission (MSL-1)
n-heptane in 30-70% oxygen-helium environment at 1 atm
Radiative extinction
Diffusive extinction
Backlit images of the droplet
UV images of the flame
UV images of the flame
~~~~

### Pagina 6

Cita: [pdf_3ba86ea9b4f6c2e60f84, p. 6]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, sparse_text_or_visual_only, tiled_ocr_not_manually_verified.

[Imagen de la pagina](../imagenes/pdf_3ba86ea9b4f6c2e60f84/p0006.jpg)

~~~~text
ISS FLEX Experiments
Anomalous Combustion
~~~~

### Pagina 7

Cita: [pdf_3ba86ea9b4f6c2e60f84, p. 7]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_3ba86ea9b4f6c2e60f84/p0007.jpg)

~~~~text
Iss FLEX "Anomalous" Combustion
40 | 10
16
14
30
12
10
20
10
10 | 20 | 30
Time ( sec)
heptane droplet burning in air at 1 atm pressure
~~~~

### Pagina 8

Cita: [pdf_3ba86ea9b4f6c2e60f84, p. 8]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
ISS FLEX “Anomalous” Combustion
Three examples of 2nd stage combustion: heptane in air, 18-82%O2-N2, 18-67-15% O2-N2-CO2
More recent test show similar behavior in n-octane, and n-decane fuels
~~~~

### Pagina 9

Cita: [pdf_3ba86ea9b4f6c2e60f84, p. 9]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
ISS FLEX “Cool Flame” Combustion
• Over 50 years of microgravity droplet combustion experiments (drop￾towers, parabolic-flights, and space shuttle) and the 2nd stage low￾temperature combustion has never been observed
• Initial attempts at explaining this behavior using pure vaporization could
not agree with quasi-steady d-square law behavior. Diffusion controlled
surface catalytic reaction models required unacceptably high diffusion
coefficients for oxygen
• low heat release rate
• quasi-steady burning
• 2
nd extinction
• lower activation energy
Passes “the duck test” – it must be cool-flame supported combustion!
~~~~

### Pagina 10

Cita: [pdf_3ba86ea9b4f6c2e60f84, p. 10]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_3ba86ea9b4f6c2e60f84/p0010.jpg)

~~~~text
Iss FLEX "Cool Flame" Combustion
Combustion and Flame 159 (2012) 3583-3588
Contents lists available at SciVerse ScienceDirect
Cornbustion
and Flarne
Combustion and Flame
Fl .S,FVIFR | journal homepage: www.elsevier.com/locate/combustflame
Can cool flames support quasi-steady alkane droplet burning?
Vedha | Daniel L. Dietrich b, Paul V. Ferkula, Michael C. Hicksb, Forman A. Williams C
Nayagam
a Mitional Center | Space Exploration Research. Clevekznd, OH 44135, USA
bNASA Glenn Research Center, Cleveland, OH 44135 USA
Department of Mechanical and Aerosgzce Engineering. University Californül San | La pua, CA 92093.
ARTICLE INFO | ABSTRACT
Artkle history: | Experimental (bservations of anomalous combustion of n-heptane droplets burning in microgravity are
Received 17 May 2012 | reported. Following ignition. a relatively large n-heptane droplet first undergoes radiative extinction. that
Received in revised form 25 June 2012 | is. the visible flame | to exist because of radiant | loss. But the | continues to
ceases | energ• | droplet | experience
Accepted 17 July 2012
vigorous vaporization for an extended period according to a quasi-steady droplet-burning law. ending in
Availabk online 18 August 2012
a secondary extinction at a finite droplet diameter. after which a vapor cloud rapidly appears surrounding
the droplet. We hypothesize that the second-stage vaporization is sustained by Iow-temperature. soot-
Keywords: | "cool-flame" chemical heat | Measured | and extinction diameters
free, | release. | droplet burning rates | are
Droplet combustion
used to extract an effective heat release. overall activation enero. and pre-exponential factor for this
Cool flames
Alkane | low-temperature chemistry. and the values of the resulting parameters are found to be closer to those
chemistry
Microgravity | of "cool-flame" overall reaction-rate parameters. found in the literature. than to corresponding hot-flame
Extinction | parameters.
@ 2012 The Combustion Institute. Published by Elsevier Inc. All rights reserved.
Published after critical reviews from skeptical reviewers!
~~~~

### Pagina 11

Cita: [pdf_3ba86ea9b4f6c2e60f84, p. 11]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Cool Flames
Traditional view of cool flames (reason for skepticism)
• Historically cool flames are associated with premixed combustion leading to
ignition of hot fuel/air mixtures. (commonly encountered in car-engine knock)
cool flames -> ignition
hot flames -> cool flame combustion! (Never – until now!)
Visionary?
A history of cool flame research
by Prof. Griffiths* (~2002)
“cool flames – a hot prospect”
~~~~

### Pagina 12

Cita: [pdf_3ba86ea9b4f6c2e60f84, p. 12]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
• Combustion of hydrocarbons is a complex process and involves multiple
reactions involving free radicals
• The exact nature of the chemical pathways depend on molecular structure of
the fuel, pressure, and temperature among others
A simple model:
Cool Flames
~~~~

### Pagina 13

Cita: [pdf_3ba86ea9b4f6c2e60f84, p. 13]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_3ba86ea9b4f6c2e60f84/p0013.jpg)

~~~~text
ISS FLEX "Cool Flame" Numerical Validation
Numerical simulations and confirmation
of "cool-flame" combustion
~~~~

### Pagina 14

Cita: [pdf_3ba86ea9b4f6c2e60f84, p. 14]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
ISS FLEX “Cool Flame” Numerical Validation
• Numerical simulations by the Princeton Group (Farouk & Dryer)
- Full detailed chemical kinetics (Curran et al., 2002: Lawrence Livermore)
- Involves 1038 species and 2739 reactions
- Reduce mechanism with 128 species and 565 reactions using path flux analysis
~~~~

### Pagina 15

Cita: [pdf_3ba86ea9b4f6c2e60f84, p. 15]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Numerical simulations
Evolution of, flame temperature (n-heptane, do = 3.91 mm, air, atmospheric pressure)
Pure evaporation
hot chemistry only
includes low
temperature chemistry
Captures the low-temperature combustion – but how good is it?
cool flames!
~~~~

### Pagina 16

Cita: [pdf_3ba86ea9b4f6c2e60f84, p. 16]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
• Predicted droplet diameter and burning rate evolution compared experiments
Model => Curran chemistry with PFA reduction
Revised model => The reaction rates for the most sensitive reactions are modified
• QOOHO2
-> QOOH + O2
(was increased: A factor increased by 2)
• QOOHO2
-> Ketohydroperoxide + OH (was decreased: A factor decreased by 2).
Numerical simulations
~~~~

### Pagina 17

Cita: [pdf_3ba86ea9b4f6c2e60f84, p. 17]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
• Revised kinetics improves ignition delay and reactivity predictions in the low￾temperature region
Numerical simulations
Predicted shock tube ignition delay and flow reactor reactivity with
revised chemical kinetics model.
Droplet combustion improves predictions of results from other universally used
experimental techniques
~~~~

### Pagina 18

Cita: [pdf_3ba86ea9b4f6c2e60f84, p. 18]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_3ba86ea9b4f6c2e60f84/p0018.jpg)

~~~~text
Numerical simulations
Further confirmation of "cool-flame" 2nd stage burning by Italian researchers
XXXY-I Meeting of the Italian Section of the Combustion Institute
COOL FLAMES IN DROPLET COMBUSTION
A. Cuoci, A. Frassoldati, T. Faravelli, E. Ranzi
alberto.cuoci@polimi.it
Department of Chemistry, Materials, and Chemical Engineering "G. Natta"
Politecnico di Milano (Italy)
18 | 40
16 | Flame diameter | Run 2
of | 35
(maximum | 21% 02
14 | temperature) | 30
do=3.91 mm
12
25
10
20
15
Squared droplet
diameter
10 | 20 | 30
time Isl
~~~~

### Pagina 19

Cita: [pdf_3ba86ea9b4f6c2e60f84, p. 19]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, sparse_text_or_visual_only, tiled_ocr_not_manually_verified.

[Imagen de la pagina](../imagenes/pdf_3ba86ea9b4f6c2e60f84/p0019.jpg)

~~~~text
ISS FLEX Experiments
' Potential applications of "cool-flame" combustion
~~~~

### Pagina 20

Cita: [pdf_3ba86ea9b4f6c2e60f84, p. 20]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Potential applications
• Advanced low temperature combustion engines*
• Homogeneous charge compression ignition engine (HCCI)
• Provides low emissions and improved efficiency (~15% fuel savings)
• Major technical challenge is control of ignition timing
*Reitz, R.D., Combustion and Flame, 2013
~~~~

### Pagina 21

Cita: [pdf_3ba86ea9b4f6c2e60f84, p. 21]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Potential applications
• Fuel reforming technologies*
• Heavy fuels are partially oxidized (using “cool flame”) and used in
gaseous burners with reduced emission and good power modulation
and hydrogen for fuel cells
*Hartman et al., J. of Power Sources, 2003
Catalytic diesel reformer
• New burner technologies
• The possibility to use cool-mode combustion of individual droplets may lead
to entirely different design concepts of spray burners (A. Cuoci, et al., 2013)
~~~~

### Pagina 22

Cita: [pdf_3ba86ea9b4f6c2e60f84, p. 22]. Metodo: native.

~~~~text
Potential applications
• Fire safety
• On Earth spontaneous combustion and explosion of liquid fuel
vapors in chemical industry is a major concern
• In space “cool flame” can persist after hot flame extinction and
generate combustible vapor that can reignite (similar to smoldering
combustion in solid fuels)
• Recent results show re-ignition with decane
~~~~

### Pagina 23

Cita: [pdf_3ba86ea9b4f6c2e60f84, p. 23]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Concluding Remarks
• A new phenomenon where a hot flame extinction leads
to a low-temperature, “cool-flame” burning in
microgravity has been observed for the first time
• These cool flames produce partially oxidized fuel and
potentially re-ignite to hot flames posing fire safety
concerns in spacecraft environments
• Existing, widely-used detailed chemical kinetic models
do not accurately predict the 2nd stage cool flame
extinction and need further improvement
• Improved low temperature chemistry will have wide
ranging applications including advanced internal
combustion engine design and development
• The new phenomena may lead to new innovative
burner designs and fuel reforming technologies
~~~~

### Pagina 24

Cita: [pdf_3ba86ea9b4f6c2e60f84, p. 24]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Questions?
Diluent Manifold
Oxygen
Manifold
N2 Diluent
Manifold
Gaseous Fuel
Manifold
Adsorber
Cartridge
Chamber
CIR
MDCA
~~~~
