# Dissertation-PD-revised_

- Identificador: pdf_2ada277f4accf3ff7dca
- Investigaciones: PSI-20
- Tipo de documento: Reports
- Estado: processed
- Temas detectados automaticamente: oxygen, hardware, pressure, extinction, microgravity, operations, ignition, soot, solid_materials, smoke_detection, computational_models, droplets, cool_flames, electric_fields

## Fuentes

- [PSI-20_Reports_Dissertation-PD-revised_.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-20/Reports/PSI-20_Reports_Dissertation-PD-revised_.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Pasajes de orientacion (extractivos, no resumen validado)

### abstract - pagina 1

ABSTRACT
Title of Dissertation: BURNING EMULATIONS OF CONDENSED 
PHASE FUELS ABOARD THE 
INTERNATIONAL SPACE STATION 
Parham Dehghani,
Doctor of Philosophy,
2022
Dissertation directed by: Professor Peter B. Sunderland, 
and Professor James G. Quintiere
Department of Fire Protection Engineering
Little is known about the fire hazards of solids and liquids in microgravity. Ground-based tests are 
too short to overcome ignition transients and testing dozens of condensed fuels in orbit is 
prohibitively expensive. Burning rate emulation is one way to address this gap. It involves 
emulating condensed fuels with gases using a porous burner with embedded heat flux gages. This 
is a study of microgravity burning rate emulation aboard the International Space Station. The 
burner had porous round surfaces with diameter of 25 mm. The fuel mixture was gaseous ethylene, 
and it was diluted with various amounts of nitrogen. The resulting heats of combustion were 15 –
47.2 kJ/g. The flow rate, oxygen concentration in the ambient, and pressure were varied. Heat flux 
to the burner was measured with two embedded heat flux gages and a slug calorimeter. The 
effective heat of gasification was determined from the heat flux divided by the fuel flow rate. 
Radiometers provided the radiative loss fractions. A dimensional analysis based on radiation 
theory yielded a relationship for radiative loss fraction. RADCAL, a narrow-band radiation model,

### conclusion - pagina 53

conclusion from this study is that the BRE has indicated that steady burning can 
be achieved in microgravity for a flat surface of 25 mm diameter. Experiments have shown that 
burning could take place for more than 3 minutes with apparent steady blue hemispherical-like 
flames at atmospheres above 21 % oxygen. Theoretical analyses based on published work has 
corroborated that these long duration flames are nearly steady where it is shown that surface heat 
Figure 3.13. Heats of gasification calculated from the average of the two heat flux 
gauge measurements vs. fuel mixture mass flux
y	=	82.9	x	 y	=	6.81	x	-1.49 -1.52
R²	=	0.93
0.1
1
10
1 10
L (kJ/g)
ṁf"	(g/m2s)
Normal
Gravity
SE FT Xf XO2
p 
(bar)
N/A 1 0.4 1
N/A 1 0.34 1
1 0.34 0.56
1 0.265 0.7
N/A 1 0.21 1
0.5 0.4 1
0.5 0.34 0.56
0.5 0.265 0.7
N/A 0.5 0.21 1
∆ℎ! = $" 47.2 kJ/g

### summary - pagina 31

summary of the end-point conditions found. The most useful data in this 
table are the apparent steady results where the duration of the test was long, appeared steady and 
the fuel flow rate was shut down. The issue of their steadiness will be theoretically examined to 
provide some justification for further examining these data as steady. The usefulness of these 
steady data is in the determination of the derived heat of gasification (heat flux divided by mass 
flux) to relate to real solid fuels that could burn steadily in microgravity at this scale.

### objective - pagina 21

Objectives
A circular porous burner with gaseous fuel, called the Burning Rate Emulator (BRE), is 
developed to emulate the quiescent burning of condensed phase fuels. This 
burner is based on the previous emulators that were used for normal gravity and the drop tower 
experiments [4,10,46–48,55,56]. The premise of the BRE technique is that the emulation is 
achieved by matching four properties of a diffusion flame, i.e., heat of combustion, heat of 
gasification, surface temperature and smoke point. The former two properties are of primary

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_2ada277f4accf3ff7dca, p. 1]. Metodo: native.

~~~~text
ABSTRACT
Title of Dissertation: BURNING EMULATIONS OF CONDENSED 
PHASE FUELS ABOARD THE 
INTERNATIONAL SPACE STATION 
Parham Dehghani,
Doctor of Philosophy,
2022
Dissertation directed by: Professor Peter B. Sunderland, 
and Professor James G. Quintiere
Department of Fire Protection Engineering
Little is known about the fire hazards of solids and liquids in microgravity. Ground-based tests are 
too short to overcome ignition transients and testing dozens of condensed fuels in orbit is 
prohibitively expensive. Burning rate emulation is one way to address this gap. It involves 
emulating condensed fuels with gases using a porous burner with embedded heat flux gages. This 
is a study of microgravity burning rate emulation aboard the International Space Station. The 
burner had porous round surfaces with diameter of 25 mm. The fuel mixture was gaseous ethylene, 
and it was diluted with various amounts of nitrogen. The resulting heats of combustion were 15 –
47.2 kJ/g. The flow rate, oxygen concentration in the ambient, and pressure were varied. Heat flux 
to the burner was measured with two embedded heat flux gages and a slug calorimeter. The 
effective heat of gasification was determined from the heat flux divided by the fuel flow rate. 
Radiometers provided the radiative loss fractions. A dimensional analysis based on radiation 
theory yielded a relationship for radiative loss fraction. RADCAL, a narrow-band radiation model,
~~~~

### Pagina 2

Cita: [pdf_2ada277f4accf3ff7dca, p. 2]. Metodo: native.

~~~~text
yielded flame emissivities from the product concentrations, temperature, flame length, and 
pressure. Previously published analytical solutions to these flames allowed prediction of flame 
heights and radius, and when combined with the radiation empirical relationship led to corrections 
of total heat release rate from the flames due to radiative loss. Average convective and radiative 
heat flux were obtained from the analytical solution and a model based on the geometrical view 
factor of the burner surface with respect to the flame sheet, that were used to calculate heats of 
gasification. All flames burning in 21% by volume oxygen self-extinguished within 40 s. However, 
steady flames were observed at 26.5, 34, and 40% oxygen. The analytical solution was used to 
quantify flame steadiness just before extinction. The steadiest flames reached more than 94% of 
their steady-state heat fluxes and heights. A flammability map as a plot of heat of gasification 
versus heat of combustion was developed based on the measurement and theory for nominal 
ambient oxygen mole fractions of 0.265, 0.34, and 0.4.
~~~~

### Pagina 3

Cita: [pdf_2ada277f4accf3ff7dca, p. 3]. Metodo: native.

~~~~text
BURNING EMULATIONS OF CONDENSED PHASE FUELS ABOARD THE 
INTERNATIONAL SPACE STATION
by
 Parham Dehghani
Dissertation submitted to the Faculty of the Graduate School of the 
University of Maryland, College Park, in partial fulfillment
of the requirements for the degree of
Doctor of Philosophy
2022
Advisory Committee:
Professor Peter B. Sunderland, Chair
Professor James G. Quintiere, Co-chair
Professor Christopher P. Cadou
Dr. John L. de Ris
Professor Reinhard Radermacher
Professor Arnaud Trouve
~~~~

### Pagina 4

Cita: [pdf_2ada277f4accf3ff7dca, p. 4]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, sparse_text_or_visual_only, tiled_ocr_not_manually_verified.

[Imagen de la pagina](../imagenes/pdf_2ada277f4accf3ff7dca/p0004.jpg)

~~~~text
O Copyright by
Parham Dehghani
2022
~~~~

### Pagina 5

Cita: [pdf_2ada277f4accf3ff7dca, p. 5]. Metodo: native.

~~~~text
ii
Dedication
This thesis is dedicated firstly to the love of my life, “Roza” for her support and love! To 
my mother and brother for being always helpful and supportive, to my father for teaching me how 
to live. I am grateful to the kind support of my entire family and friends specially, my father-in￾law, mother-in-law, brother-in-law, my uncles, and aunts, and Jessi. I also give my special thanks 
to my senior friends Mr. Samsum Kashfi, and Pari S. Kashfi for their kind support.
No words can describe the love I have deep in my heart for my two adorable cats: Kopol 
and Lucy. 
And . . . COVID-19; although it caused us so many hardships, it gave me the opportunity 
to re-unite with my family.
~~~~

### Pagina 6

Cita: [pdf_2ada277f4accf3ff7dca, p. 6]. Metodo: native.

~~~~text
iii
Acknowledgements
I wish to thank my academic advisors, Prof. Peter B. Sunderland, and Prof. James G. 
Quintiere for kindly helping and guiding me to pursue my ambitions I am also grateful to the 
members of my dissertation committee: Drs. Chris Cadou., John L deRis, Peter.B. Sunderland, 
Reinhard Radermacher, and Jame Quintiere for generously offering their time, support, guidance, 
and good will. Learning from Prof. Quintiere, Prof. Sunderland, and Dr. deRis was a “once in a 
lifetime” experience. Discussions with Dr. H.R. Baum (especially his rendition of the original 
diffusion flame solution), D. P. Stocker, and Prof. A. Snegirev are greatly appreciated. I appreciate 
the time, and support of my other committee members for my dissertation proposal defense, Prof. 
Stanislav Stoliarov, and Prof. Bao Yang.
This investigation is funded by NASA’s ISS Research Program through agreement 
80NSSC20M0119. I am also grateful to the NASA engineering and operations teams, especially 
Angela Adams, Operations Lead; Melani Smajdek, Planning Lead; Dennis Stocker, Project 
Scientist; and Uday Hegde, Deputy Project Scientist. 
I am Thankful to the University of Maryland’s, Clark’s Foundation that recognized me as a 
Clark’s Doctoral Fellow, and to the UMD, Mechanical Engineering dept. for granting me the 
Dean’s fellowship for the Spring 2022. I also appreciate the travel fundings granted by the National 
Science Foundation (NSF), the Combustion Institute, the Clark’s Fellowship Program, and the 
UMD Graduate School that covered part of my expenses for attending and presenting at 
conferences. Some of the flame photograph sequences are from the compilations by Aviv Kalai.
~~~~

### Pagina 7

Cita: [pdf_2ada277f4accf3ff7dca, p. 7]. Metodo: native.

Calidad: table_structure_not_manually_validated.

~~~~text
iv
Table of Contents
Dedication....................................................................................................................................... ii
Acknowledgements........................................................................................................................ iii
1. Introduction............................................................................................................................... 13
1.1 Motivation........................................................................................................................... 13
1.2 Literature Review................................................................................................................ 14
1.3 Objectives ........................................................................................................................... 18
1.4 Roadmap and Timeline for Completion of Dissertation..................................................... 19
2. Description of Experiments ...................................................................................................... 21
2.1 Burner Surface Net Flame Heat Flux.................................................................................. 22
2.2 Flame Radiation.................................................................................................................. 25
2.3 Fuel Mass Flux.................................................................................................................... 25
2.4 Images................................................................................................................................. 26
2.5 Experimental Design........................................................................................................... 26
3 Experimental Results of Round 1 Tests..................................................................................... 28
3.1 End Point Results................................................................................................................ 28
3.2 Unsteady Results................................................................................................................. 30
3.3 Steady Results..................................................................................................................... 35
3.3.1 Heat Flux...................................................................................................................... 39
3.3.2 Flame Radiation Fraction 𝑿𝒓....................................................................................... 40
3.3.3 Flame Shape................................................................................................................. 43
3.4 Discussion of Results.......................................................................................................... 46
3.5 Chapter Summary ............................................................................................................... 50
4. Analytical Transient Solution for Constant Mass Flux............................................................. 52
4.1 Flame position..................................................................................................................... 54
4.2 Flame Temperature ............................................................................................................. 56
4.3 Convective heat flux ........................................................................................................... 56
4.4 Steady flame position: experiments compared to theory.................................................... 56
4.5 Prediction of flame radiation fraction ................................................................................. 59
4.6 Radiant fraction model formulation.................................................................................... 59
4.6.1 Model for emissivity and absorption coefficient ......................................................... 62
4.7 Correlation result ................................................................................................................ 66
4.8 Flame temperature as a measure of extinction.................................................................... 67
4.9 Prediction of heat flux......................................................................................................... 69
4.9.1 Convective heat flux .................................................................................................... 69
4.9.2 Flame incident radiative heat flux................................................................................ 71
4.9.3 Net heat flux to the burner ........................................................................................... 73
4.10 Overall general predictive process and illustration........................................................... 75
4.11 Flame Temperature ........................................................................................................... 76
~~~~

### Pagina 8

Cita: [pdf_2ada277f4accf3ff7dca, p. 8]. Metodo: native.

~~~~text
v
4.12 Flame Radiation Fraction.................................................................................................. 77
4.13 Flame size ......................................................................................................................... 79
4.14 Calculated convective heat flux ........................................................................................ 81
4.15 Calculated radiative heat flux ........................................................................................... 82
4.16.1 Heat of Gasification dependence on burning rate...................................................... 83
4.16.2 Heat of Gasification dependence on surface burning temperature ............................ 85
4.16.3 Heat of Gasification dependence on fire diameter..................................................... 86
4.17 Chapter Summary ............................................................................................................. 90
5. Analysis of the steadiness of the flames............................................................................... 93
5.1 Analysis of the steadiness of the flame heights.................................................................. 94
5.2-Dimensional analysis of the Radiative loss fraction based on radiation theory ................. 94
5.3 Calculated temperature at flame sheet ................................................................................ 96
5.4 Further analysis of the experimental data ........................................................................... 98
5.5 Flame size ........................................................................................................................... 98
5.6 Surface heat flux ............................................................................................................... 100
5.7 Flammability diagram....................................................................................................... 100
5.8 Chapter Summary ............................................................................................................. 104
6. Flammability Maps for Microgravity Flames on Top of a Flat Disk in a Quiescent Ambient106
6.2 Experimental results.......................................................................................................... 106
6.3 Summary of the endpoint results ...................................................................................... 107
6.4 An analysis of the steadiness of flames ............................................................................ 110
6.5 Measured surface heat flux at the r = 0, and 9.5 mm........................................................ 111
6.6 Heats of gasification ......................................................................................................... 112
6.7 The flammability maps..................................................................................................... 116
6.8 Critical heat release rate, and mass flux at extinction limits............................................. 134
6.9 Chapter summary.............................................................................................................. 135
7. Conclusions............................................................................................................................. 137
Appendix A. Corrections to the Calorimeter Heat Flux ............................................................. 141
Appendix B. Transient Flame Size and PMT with OH* Filter Assembly.................................. 145
Appendix C. Transient results, use of theory and example predictions...................................... 146
C.1 Flame Height.................................................................................................................... 146
C.2 Transient radiation fraction, and calculated flame temperature....................................... 146
C.3 Transient surface heat flux components:.......................................................................... 147
Appendix D: The parameters spreadsheet submitted to NASA operations team ....................... 149
Appendix E: Results obtained from Methane-Nitrogen ............................................................. 160
Appendix F: Results obtained by the 50 mm burner and Ethylene-Nitrogen mixture ............... 161
Bibliography ............................................................................................................................... 163
~~~~

### Pagina 9

Cita: [pdf_2ada277f4accf3ff7dca, p. 9]. Metodo: native.

~~~~text
vi
List of Figures
Figure 1.1. Numerical simulation of a flame ignited in atmospheric condition with mass flux of 
3.09 g/m2
s (test 19039H2) ............................................................................................................ 17
Figure 2.1 BRE burner image (left) and drawing (right). ............................................................. 22
Figure 2.2 Radiometer schematic ................................................................................................. 26
Figure 3.1. Color images of tests (a) 87B1(m′′ = 1.78 g/m2s), (b) 51D1 (m′′ = 2.55 g/m2s), and 
(c) 94K1 (m′′ = 6.95 g/m2s). All are at nominal conditions of XO2 = 0.34, Xf = 1, and p = 0.56 
bar. ................................................................................................................................................ 31
Figure 3.2. Heat flux and surface temperature for tests (Left) 94K1 and (Right) 87B1. Both are at 
nominal conditions of XO2 = 0.34, Xf = 1, and p = 0.56 bar......................................................... 32
Figure 3.3. Color images of tests (a) 39B3 (m′′ = 2.55 g/m2s) and (b) 51A1 (m′′ = 2.55 g/m2s). 
Both are at nominal conditions of Xf = 1, p = 1 bar and XO2 = 0.4 and 0.34, respectively. ......... 34
Figure 3.4. Color images of tests (a) 39D1 (m′′ = 2.54 g/m2s) and (b) 66G1 (m′′ = 2.45 g/m2s). 
Conditions are XO2 = 0.265 and 0.34, Xf = 1 and 0.5, and p = 1 and 0.56 bar, respectively........ 35
Figure 3.5. Steadiness of flame height for all the tests. ................................................................ 37
Figure 3.6. Steadiness of heat flux for all the tests. ...................................................................... 38
Figure 3.7. Measured local and average heat flux (measured by calorimeter [26], see appendix A) 
plotted with respect to fuel mixture mass flux for the FT tests. ................................................... 39
Figure 3.8. Flame radiant fraction vs. mass flux (a) and flame height (b) for all steady end-point 
results. ........................................................................................................................................... 43
Figure 3.9. Flame height vs. mass flux. ........................................................................................ 44
Figure 3.10. flame base radius vs. mass flux. ............................................................................... 45
Figure 3.11. Flame height vs. flame base radius........................................................................... 45
Figure 3.12. heats of gasification calculated from corrected calorimeter vs. mass flux............... 49
Figure 4.1. Measured vs. calculated flame height ........................................................................ 57
Figure 4.2. measured vs. predicted flame base radius, c =1 (Left) and c = 0.35 (Right).............. 59
Figure 4.3. Absorption coefficients normalized by partial pressures of combustion products of 
ethylene ......................................................................................................................................... 64
Figure 4.4. BRE flames emissivity vs. fuel mixture mass flux..................................................... 65
Figure 4.5. Radiant fraction correlation........................................................................................ 66
Figure 4.6. Calculated vs. measured radiant fraction.................................................................... 67
Figure 4.7. Flame temperature as a measure of extinction based on calculated radiant fraction . 69
Figure 4.8. Calculated convective heat flux compared to the average net flame heat flux based on 
calculated radiant fraction............................................................................................................. 70
Figure 4.9. Calculated flame radiative heat flux compared to the average net flame heat flux based 
on calculated radiant fraction........................................................................................................ 72
Figure 4.10. calculated average heat flux vs. measured average heat flux from calorimeter 
𝑞𝑐𝑜𝑛𝑣′′ + 𝑞𝑓, 𝑟′′ − 𝑞𝑟𝑟′′ .............................................................................................................. 74
Figure 4.11. calculated average heat flux vs. measured average heat flux from arithmetic average 
of the two heat flux sensors 𝑞𝑐𝑜𝑛𝑣′′ + 𝑞𝑓, 𝑟′′ − 𝑞𝑟𝑟′′ ................................................................. 75
~~~~

### Pagina 10

Cita: [pdf_2ada277f4accf3ff7dca, p. 10]. Metodo: native.

~~~~text
vii
Figure 4.12. Calculated flame temperature vs. mass flux for 25 mm burner and different oxygen 
mole fractions and p = 1 atm (Left) p = 0.5 atm (Right) .............................................................. 77
Figure 4.13. Calculated flame radiant fraction vs. mass flux for 25 mm burner and different oxygen 
mole fractions and p = 1 atm (Left) p = 0.56 atm (Right) ............................................................ 78
Figure 4.14. Measured radiant fraction vs. fuel mixture mass flux for 25 mm burner................. 79
Figure 4.15. Calculated flame height vs. mass flux for 25 mm burner and different oxygen mole 
fractions (Top) Calculated flame radius vs. mass flux for different oxygen mole fractions (Bottom)
....................................................................................................................................................... 80
Figure 4.16. Measured flame height vs. fuel mixture mass flux for 25 mm burner ..................... 81
Figure 4.17. Calculated flame convective heat flux vs. mass flux for 25 mm burner and different 
oxygen mole fractions and p = 1 atm (Left) p = 0.56 atm (Right)................................................ 82
Figure 4.18. Calculated radiative heat flux vs. mass flux for 25 mm burner and different oxygen 
mole fractions and p = 1 atm (Left) p = 0.56 atm (Right) ............................................................ 83
Figure 4.19. Calculated heats of gasification vs. mass flux for different oxygen mole fractions and 
p = 1 atm (Left) p = 0.56 atm (Right)........................................................................................... 84
Figure 4.20. Heats of gasification based on calculated total average surface heat flux vs. 
experimental fuel mixture mass flux and ambient conditions (Dashed line indicates experimental 
results trend-line for steady flames).............................................................................................. 85
Figure 4.21. Calculated heats of gasification vs. mass flux for different oxygen mole fractions and 
p = 1 atm (Left) p = 0.5 atm (Right) for surface temperature of 350 ºC and surface diameter of 25 
mm ................................................................................................................................................ 86
Figure 4.22. Calculated heats of gasification vs. mass flux for different oxygen mole fractions and
p = 1 atm (Left) p = 0.5 atm (Right) for a burner of 50 mm in diameter...................................... 87
Figure 4.23. Calculated heats of gasification vs. mass flux for different oxygen mole fractions and 
p = 1 atm (Left) p = 0.5 atm (Right) for a burner of 100 mm in diameter.................................... 88
Figure 4.24. Heat of gasification composite for size (25, 50, 100 mm diameter), surface 
temperature (80 and 350 ºC), heat of combustion (47.2 and 23.6 kJ/g), and ambient conditions 
(0.56 and 1 bar ambient pressure; 0.21, 0.34 and 0.40 oxygen mole fractions)........................... 89
Figure 5.1. Radiative loss fraction empirical correlation resulted from a dimensional analysis of 
radiometry..................................................................................................................................... 96
Figure 5.2. Calculated flame temperature at flame sheet, cp = 1.24 J/g K.................................... 97
Figure 5.3. Calculated vs. measured, flame heights (top) and flame aspect ratio (bottom) ......... 99
Figure 5.4. Flammability map (heats of gasification vs. fuel mixture mass flux) for micro and 
normal gravity data for the surface diameter of 25 mm.............................................................. 102
Figure 6.1. Steadiness of flames estimated by the analytical solution to BRE flames generated by 
the 25 mm BRE burner and ethylene-diluent mixture ................................................................ 110
Figure 6.2. Measured heat flux at the center and the offset location on the surface at the endpoints 
of steady flames generated by the 25 mm BRE burner and ethylene-diluent mixture ............... 111
Figure 6.3. Calculated radiative and convective heat flux for steady flames generated by the 25 
mm BRE burner and ethylene-diluent mixture........................................................................... 113
Figure 6.4. Calculated vs. measured average heat flux for steady flames generated by the 25 mm 
BRE burner and ethylene-diluent mixture .................................................................................. 114
Figure 6.5. Contribution of heat flux components to calculated heat of gasification for steady 
flames generated by the 25 mm BRE burner and ethylene-diluent mixture............................... 115
~~~~

### Pagina 11

Cita: [pdf_2ada277f4accf3ff7dca, p. 11]. Metodo: native.

~~~~text
viii
Figure 6.6. Calculated vs. measured heats of gasification for steady flames generated by the 25 
mm BRE burner and ethylene-diluent mixture........................................................................... 116
Figure 6.7. Absorption coefficients normalized by partial pressures of combustion products of 
ethylene ....................................................................................................................................... 118
Figure 6.8. Radiative loss fraction empirical correlation resulted from a dimensional analysis of 
radiometry................................................................................................................................... 120
Figure 6.9. The flammability map for nominal XO2 of 0.4 along with trends of calculated Xr, and 
calculated Tf at flame sheet for steady flames generated by ethylene-diluent mixture and 25 mm 
burner. ......................................................................................................................................... 125
Figure 6.10. The flammability map for nominal XO2 of 0.34 along with trends of calculated Xr, and 
calculated Tf at flame sheet for steady flames generated by ethylene-diluent mixture and 25 mm 
burner. ......................................................................................................................................... 126
Figure 6.11. The flammability map for nominal XO2 of 0.265 along with trends of calculated Xr, 
and calculated Tf at flame sheet for steady flames generated by ethylene-diluent mixture and 25 
mm burner................................................................................................................................... 127
Figure 6.12. The calculated flame temperature plotted against L/∆h_c for nominal oxygen mole 
fractions of 0.4, 0.34, and 0.265 ................................................................................................. 128
Figure 6.13. The flammability map for nominal XO2 of 0.4, 0.34, and 0.265 along with real material 
properties shown as colored crosses. .......................................................................................... 131
Figure 6.14. Flammability regions dependency on the ambient nominal XO2, shown for the critical 
flame temperatures of 1100 K, to 1400 K................................................................................... 132
Figure 6.15. The effect of Tcr on flammability maps for XO2= 0.265, 0.34, and 0.4 (shown for the 
critical flame temperatures of 1100 K, to 1400 K)..................................................................... 133
Figure 6.16. Critical heat release rate as a function of heat of combustion shown for different XO2
for the two extinction limits (radiative extinction, and small flame extinction limit). ............... 134
Figure 6.17. Critical burner mass flux as a function of heat of combustion shown for different XO2
for the two extinction limits (radiative extinction, and small flame extinction limit). The fit shown 
corresponds to the small flame limit........................................................................................... 135
Figure A.1. Flame configurations for analyzing heat flux from 2 to 1 and 3 ............................. 141
Figure A.2. Calorimeter vs. corrected calorimeter ..................................................................... 144
Figure B.1 Transient flame length, base radius and PMT heat flux with OH* assembly .......... 145
Figure C.1. Calculated vs. measured transient flame heights of 19070C1 and 20352A2 .......... 146
Figure C.2. Radiative loss fraction empirical correlation for steady flames generated by the 25 mm 
BRE burner and ethylene-diluent mixture .................................................................................. 147
Figure F.1. Preliminary examination of calculated flame temperatures obtained by the 50 mm 
burner.......................................................................................................................................... 162
~~~~

### Pagina 12

Cita: [pdf_2ada277f4accf3ff7dca, p. 12]. Metodo: native.

Calidad: table_structure_not_manually_validated.

~~~~text
ix
List of Tables
Table 2.1. Design parameters for BRE-ISS round 1 experiments. ............................................... 27
Table 3.1. Summary of the ISS tests............................................................................................. 29
Table 3.2 . Materials close to BRE heats of combustion and corresponding heats of gasification
....................................................................................................................................................... 49
Table 6.1. Summary of the endpoint results ordered by XO2 for ethylene-nitrogen flames. ordered 
by XO2, dashes indicate where no radiation data is available, the end conditions are self￾Extinguished (SE), Fuel Terminated (FT), and Fuel Terminated with Oscillations (FTO) ....... 107
Table 6.2. Some of the commonly used materials heats of combustion and heats of gasification
..................................................................................................................................................... 130
Table 7.1 Effect of atmosphere, heat of combustion and mass flux on burning parameters...... 139
Table D.1. An example of the patameters table submitted to NASA operations team before each 
test point day. Only two test points parameters are shown......................................................... 149
Table D.2. Explanation of the parameters used in the parameters spreadsheet (table D.1)........ 152
Table E.1. Test results obtained from Methane-Nitrogen mixture and 25 mm burner............... 160
Table F.1. Test results obtained by the 50 mm burner and ethylene-nitrogen mixture. ............. 161
~~~~

### Pagina 13

Cita: [pdf_2ada277f4accf3ff7dca, p. 13]. Metodo: native.

~~~~text
x
List of Abbreviations
𝐴 Surface area
𝑏 Copper plate diameter measured at its half thickness
𝐵 Spalding B number
𝑐 Specific heat
𝑐! Gas specific heat
𝐷" Ambient mass diffusivity
𝑑# Radiometer distance to the flame volume centroid
𝑑$ Radiometer distance to the intersecting point between normal axis to the burner and radiometer 
surface
𝑑% Radiometer distance to the center of the burner surface
𝑒& Thermal effusivity
𝐹%→( View factor of the burner surface with respect to the radiometer
𝐹#→% AAA
𝐹%→# View factor of the flame sheet with respect to the burner surface
𝐹𝑇 Fuel Terminated
𝐻 Thickness of the copper plate
ℎ The vertical distance from the burner surface to the radiometer elevation
ℎ) effective heat transfer coefficient between semi-infinite back and plate
ℎ(*+ effective heat transfer coefficient between the sensor rod and plate
𝐾 Gas conversion factor
𝑘 Thermal conductivity
𝐿 Heat of gasification
(𝑚𝑐),-heat capacity of copper
𝑀̇ Total mass flow rate
𝑚̇ Mass flow rate
𝑚̇
.. Mass flux
𝑝 Ambient pressure
𝑃𝑒/ Peclet number
𝑄̇ Heat loss rate
𝑞̇
.. Heat flux
𝑅 Burner surface radius
𝑟 Radial location on the burner surface
𝑟# Radius of the flame measured at its base
𝑆𝐸 Self-Extinguished
𝑆 Stoichiometric molar air-fuel ratio
𝑇 Temperature
𝑡 time
𝑡& burn-time
𝑉 Sensor output voltage, and Volumetric flow rate
𝑋 Mole fraction
𝑋( Radiant fraction
𝑥 vertical distance from burner center
𝑌 Mass fraction
𝑌0& Fuel mass fraction at the burner surface
~~~~

### Pagina 14

Cita: [pdf_2ada277f4accf3ff7dca, p. 14]. Metodo: native.

~~~~text
xi
𝑦# Flame height
𝑍 Mixture fraction
Greek
𝛼 Absorptivity or Fuel-ambient air mass ratio
𝛽 Radiative heat flux to the top surface divided by radiative heat flux to the Bevel edge of the burner
∆ℎ/ Enthalpy of combustion
𝜖 Emissivity
𝜃# The angle between radiometer normal axis and radiometer-flame centroid line
𝜃( Burner surface and radiometer connecting line angle WRT horizontal
𝜅 Absorption coefficient
Effective absorption coeficient
𝜆 Dimensionless mass flux = 1̇
!!
"#
$%&'(
𝜇 Radiative heat flux divided by convective heat flux to the top surface of the burner
𝜉 Ellipsoidal coordinate
𝜉# Ellipsoidal coordinate at flame sheet
𝜌 Density
𝜎 Stephan-Boltzmann constant
𝜏 Dimensionless time = 3)4
5*
Ω Dimensionless radiation fraction variable
Subscripts
60 +60 radiometer
𝑏 Back of the copper plate
𝐶𝑂2 Carbon-dioxide
𝑐 Convective heat flux
𝑐𝑎𝑙 Average heat flux to the burner surface (Calorimeter)
𝑐𝑟𝑐 Corrected calorimeter
𝑐𝑡𝑟 Center of the burner surface
𝑐𝑜𝑛𝑣𝑒𝑐𝑡𝑖𝑜𝑛 Convective heat flux
𝑒𝑥𝑡 external
𝑓 flame sheet or fuel 
𝑔 Burner gas or combustion products gas
𝐻 Heat flux sensors 
𝐻2𝑂 Water vapor 
𝑚𝑖𝑥 Fuel mixture 
𝑜 Without radiation loss
𝑂2 Oxygen
𝑜𝑓𝑓 Offset position on burner surface (𝑟 = 9.5 mm)
𝑝𝑟 predicted
𝑟 Radiation
𝑟𝑟 re-radiation
𝑟𝑜𝑑 Heat flux sensor rod
κ!
~~~~

### Pagina 15

Cita: [pdf_2ada277f4accf3ff7dca, p. 15]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_2ada277f4accf3ff7dca/p0015.jpg)

~~~~text
Burner surface
st | Steady state
sensor | Heat flux sensor
Ambient
Ellipsoid aspect ratio at the burner surface
xn
~~~~

### Pagina 16

Cita: [pdf_2ada277f4accf3ff7dca, p. 16]. Metodo: native.

~~~~text
13
1. Introduction
1.1 Motivation
Human-crew space missions presented the possibility of many hazards, notably fires. A 
significant amount of research has been carried out on the characteristics of fire in normal gravity. 
However, it has been observed that the behavior of microgravity fires might be quite different. 
Some experiments have suggested that it might be easier to burn condensed phase fuels in 
microgravity. This highlights the need for an in-depth analysis of condensed fuel flames in 
quiescent artificial atmosphere in microgravity condition i.e., aboard the International Space 
Station (ISS).
The recent urgency in fire control and safety is due to a fire on the Russian Mir space 
shuttle where an oxygen generator caused the blaze [1–3]. It was later found that the fire probably 
extinguished due to the depletion of oxygen supply. This sustained fire is a cause of concern, and 
the scenario calls for precautionary and preventive measures. To prevent a fire from starting in a 
spacecraft, it is necessary to study the conditions of flame development. The logical starting point 
is the case of a laminar diffusion flame in a quiescent environment.
There are a number of variables that alter the way a fire spreads in a space vehicle. The 
effect of buoyancy is seen on Earth as the surrounding air is entrained in by convection which 
gives the flame an upward pointed shape. The negligible buoyancy in microgravity causes the 
flames to have a more hemispherical or bubble-like shape. The presence of forced convection, 
which aides in the spread of fire, comes from the ventilation in the spacecraft. The hemispherical 
shape of the diffusion flame also affects the soot behavior and the release of gases, which in turn 
affects the radiation losses from the flame. 
The flammability of various materials being transported into space is assessed through a 
series of normal gravity tests designed by NASA [4]. These tests aren’t sufficient to lay out the
~~~~

### Pagina 17

Cita: [pdf_2ada277f4accf3ff7dca, p. 17]. Metodo: native.

~~~~text
14
characteristics of a flame in reduced gravity conditions [1]. The burning of numerous fuels has 
been tested in microgravity conditions and it is well documented [5–9]. The ideal scenario is to 
perform routine burn tests aboard the International Space Station (ISS) of potential materials, but 
this is not practical.
In the proposed study, an innovative technique is suggested to study the burning of 
condensed phase fuels. A gaseous burner known as the Burning Rate Emulator (BRE) has been
developed to emulate the characteristics of a condensed fuel flame in a quiescent atmosphere. This 
emulation is theoretically achieved by matching four characteristic properties: heat of gasification, 
heat of combustion, surface temperature and smoke point for the same burner flow rate. BRE
burner can provide a practical method to study the flammability of various materials aboard 
spacecraft.
1.2 Literature Review
Since the beginning of human aspirations for space flight, concerns and incidents have 
made the possibility of fire hazard a real concern [1–3]. Yet over the past decades, we still have 
limited knowledge of the full extent of fires in microgravity [4,10]. Extensive studies have been 
made on very small materials and burners, but these usually include flames with assisted ambient 
flows. We have long known that materials can burn in-place and spread by ambient flow with 
sufficient oxygen in all gravity conditions [6–9,11–30]. While spacecraft will have movement in 
its atmosphere, it is small and random. In microgravity, opposed flow flame spread provides its 
own flow in a quiescent atmosphere [18,26–28,31–33]. What has been deficient is the 
understanding of burning in-place on a surface in a quiescent atmosphere [10]. Anecdotal early 
Kimzey experiments showed that small items of plastics could burn, and controlled experiments 
of a candlewick flame could sustain burning for about an hour in microgravity [34,35]. Also, we 
have learned that liquid droplets can burn quasi-steadily, and steady burning theory is reasonably 
predictive although, the onset of cool flames can augment the burning[36–43].
~~~~

### Pagina 18

Cita: [pdf_2ada277f4accf3ff7dca, p. 18]. Metodo: native.

~~~~text
15
Fire growth is a combination of three distinct processes: (1) ignition, (2) burning in-place, 
and (3) spread. In microgravity, we have a good understanding of opposed flow flame spread, and 
our knowledge of concurrent spread is also in good shape, as we have a good understanding of 
how items burn with a specified ambient flow. Ignition can also be adequately understood in 
microgravity given an insulting heat flux. In normal gravity, ignition time is reasonably predicted 
by theory that even neglects heat loss, so the process only depends on heat flux and material 
properties. The current study began based on the premise that material properties can be defined 
for fire growth computations, and they can be measured. Indeed, the NASA designated Test 2 is 
the Cone Calorimeter that allows for these property measurements. The NASA Test 1 [44], in 
regulatory use, considers the measure of upward spread in 1-g and at higher than normal oxygen
mole fractions as the defining safety criterion for material use in spacecraft. Our work is aimed at 
employing Test 2 [45] with a procedure for measuring properties in conjunction with the 
theoretical prediction of burning in microgravity.
The current study was begun some years ago to investigate efficiently the possible burning 
of simulated flat surfaces using a burner [10,46–49]. The burner gases allow ease of ignition and 
the setting of a steady flow rate. It has been also learned that even starting with a steady flow rate, 
the corresponding flame in microgravity grows for some time before an apparent steady state is 
perceived. Early drop facility microgravity experiments for 5-second duration suggested steady 
flame heat flux might occur within that time, but the flame continued to grow [10]. It was suspected 
that the blue flames seen would increase radiation loss as they grew and lead to radiation 
extinction.
Our experiments in this document are all transient. But if a steady state is achieved, the 
data can be interpreted to represent a real material burning. The burner allows control of a fuel 
mixture that defines the heat of combustion per mixture mass (i.e., ethylene diluted with nitrogen 
can provide a range of heats of combustions up to 47.2 kJ/g which is the case of pure fuel). A 
measurement of the flame heat flux back to the burner allows computation of the heat of 
gasification, a key property appropriate to steady burning for an evaporative material. Even with
~~~~

### Pagina 19

Cita: [pdf_2ada277f4accf3ff7dca, p. 19]. Metodo: native.

~~~~text
16
more complex pyrolysis and charring, an evaporative model leads to good estimates of time 
average burning in transient cases. The surface temperature of the burner relates to the material 
vaporization temperature, but this is a weak dependent parameter on the burning process, as it does 
not significantly affect ignition, and its associated radiative heat flux is usually relatively small 
compared to flame heat fluxes. We have hypothesized that the heats of combustion and 
gasification, both material properties, are key to defining flammability but as flame radiation is 
known to be significant in normal Earth gravity, we have added the smoke point. With these three 
parameters, our work has shown successful emulation of plastics and liquid pool fires of 25 and 
50-mm diameters [4,10,46–54]. In microgravity radiation from soot does not appear to be 
important, but the fuel’s products of water and carbon dioxide, as well as the fuel itself should be 
important for radiation. In short, the problem is to obtain the experimental flammability map (heats 
of gasification vs. fuel mixture mass flux, and eventually vs. heat of combustion) that allows 
obtaining the heat of combustion and heat of gasification to match with those of real materials 
[51,55,56]. 
Numerical simulations for 5 tests conducted at normal atmosphere was able to successfully 
predict, heat flux, flame existence duration, flame size and radiative heat loss. All these tests led 
to some instabilities, flame oscillation before self-extinguishment. Description of the extinction 
process including instabilities, was another the key achievements of this study [50,57]. The steady 
growth of a flame with mass flux of 3.09 g/m2
s (Xf = 1) ignited in atmospheric condition was 
numerically simulated and compared with experiments (DRM22 mechanism, time instants and 
peak temperatures are indicated) shown in Fig. 1.1. In the plots of each simulation, the color scale 
corresponds to the net radiative emission, and the lines were the iso-contours of the volumetric
~~~~

### Pagina 20

Cita: [pdf_2ada277f4accf3ff7dca, p. 20]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
17
heat release rates 1, 2, 4, … MW/m3
. The first frame was taken 4.5 s after the igniter was retracted. 
Time increment between the frames (both experimental and numerical) is 3s. Spatial scale and 
location of the burner surface were also the same. The flame partial extinction and re-ignition 
(oscillations before self-extinction) was captured in the simulations. Analysis of transient 
dynamics of flame disintegration after the local extinction shows formation of the hook-like 
(bibrachial) structure of flame edge after the extinction onset. When the re-ignition occurs, a 
classical triple flame develops and propagates along the stoichiometric surface thereby recovering 
the original flame shape. The partial extinction-re-ignition was repeated for a number of times 
before the flame was self-extinguished completely. 
The BRE experiments onboard the ISS allowed long duration flames in microgravity. The 
set of 122 ethylene mixture flames of ISS tests provided 49 flames that did not self-extinguish 
before the fuel flow was terminated intentionally. The constant fuel flow duration was set to 3 
minutes for most of the cases and one flame was allowed to burn for 5 minutes. The surface heat 
flux and flame radiation measurements led to finding a correlation for radiative heat loss fraction 
Figure 1.1. Numerical simulation of a flame ignited in atmospheric condition with 
mass flux of 3.09 g/m2
s (test 19039H2)
~~~~

### Pagina 21

Cita: [pdf_2ada277f4accf3ff7dca, p. 21]. Metodo: native.

~~~~text
18
Xr. It will then be treated as lost energy and will be used to correct the heat of combustion used in 
the ellipsoidal model to analytically predict flame size, surface heat flux and steady state 
temperature. The other major finding was the flammability map that showed plastics can burn 
steadily in place in microgravity. The achievements of this study so far include analysis of the 
experimental results of round 1-ISS tests [50–52]. The major findings of this paper are correlation 
of radiative loss fraction with flame length, the flammability map and emulation of PMMA, and 
Nylon [51]. 
The steady data will be used to assess the predictive modeling. The experimental conditions 
range over mass fluxes from 1 to 12 g/m2
s, ethylene-nitrogen fuel mixtures of 15% and 100% 
ethylene, oxygen concentrations of 0.21 to 0.40, and pressures of 0.565 to 1 bar. The modeling is 
based on an analytic transient analysis developed with demonstrated numerical accuracy and good 
predictions with 5-s microgravity data. Here, that model will be modified by adjusting the heat of 
combustion, in that purely convective model, by its radiative heat loss. The flame radiative fraction 
is used to make this adjustment. It is shown that a model for the radiative fraction can be developed 
with dependence on an empirical constant. Given the radiative fraction, flame heat fluxes and 
flame temperature can be computed, while flame shape is independent of such. The flame 
temperature range of 1100 K to 1200 K with radiation loss will be used as a criterion for a stable 
flame or steady burning. The radiation code RADCAL is used to develop a model to predict flame 
emissivity and absorption coefficient. It is also shown that it is possible to predict the conditions 
for steady burning from known fuel properties, atmospheric conditions, and fuel diameter [52].
1.3 Objectives
A circular porous burner with gaseous fuel, called the Burning Rate Emulator (BRE), is 
developed to emulate the quiescent burning of condensed phase fuels. This 
burner is based on the previous emulators that were used for normal gravity and the drop tower 
experiments [4,10,46–48,55,56]. The premise of the BRE technique is that the emulation is 
achieved by matching four properties of a diffusion flame, i.e., heat of combustion, heat of 
gasification, surface temperature and smoke point. The former two properties are of primary
~~~~

### Pagina 22

Cita: [pdf_2ada277f4accf3ff7dca, p. 22]. Metodo: native.

~~~~text
19
significance while the other two are examined for normal gravity tests. The objectives of this study 
are as listed below.
- Characterize the burners before data gathering experiments to insure having a good 
understanding of the measurement techniques used onboard the ISS.
- Planning two rounds of microgravity tests to record data by changing different 
parameters, i.e., Fuel mixture mass flux, chamber ambient oxygen mole fraction, 
chamber pressure, fuel type and the burner size. 
- Correlate the experimental results by employing relevant steady-state theory and analyze 
the burner as a condensed fuel emulator in microgravity to obtain the flammability map. 
- Modify the slug calorimeter calibration constants [48] to account for the heat absorbed by 
the burner rim. 
- Examine the dependency of the BRE slug calorimeter on the burn time.
- Convert all data recorded in each round of testing and analyze by segregation of data for 
identifying correlations.
- Modify the radiative fraction correlation, found by dimensional analysis, to account for 
several more independent factors, i.e., Chamber pressure and oxygen mole fraction. It 
requires a working knowledge of RADCAL[58,59] by Grosshandler, a narrow band 
model used for radiation calculation.
- Analyze flame temperature by utilizing ellipsoidal theory [49,60]
- Analyze and estimate the average emissivity associated with each flame.
- Obtaining a flammability map for microgravity condition to address fire safety of 
spacecrafts
1.4 Roadmap and Timeline for Completion of Dissertation
The first round of ISS tests preparation, data gathering, and data analysis led to publishing 
two journal papers and one other journal collaboration which are explained in sections 2-5. 
The second round of ISS tests provided valuable set of data to analyzed. The remaining 
time until graduation is dedicated to objectives introduced in section 1.3. The new results will be
~~~~

### Pagina 23

Cita: [pdf_2ada277f4accf3ff7dca, p. 23]. Metodo: native.

~~~~text
20
converted to engineering units. Average of the two measured heat fluxes are used to obtain heats 
of gasification. The radiative loss fraction is retrieved from radiometer’s measured data and is 
defined as the ratio of total radiation loss rate to total heat release rate from the flame.
The ISS experiments provided enough data to publish the three journal papers, two 
presentations and one poster competition [50–54,60] as discussed in the literature review. Also, 
another paper has been accepted at the Proceeding of the Combustion Institute [60]. Another 
journal paper discussing the flammability map in microgravity is expected to be submitted.
~~~~

### Pagina 24

Cita: [pdf_2ada277f4accf3ff7dca, p. 24]. Metodo: native.

~~~~text
21
2. Description of Experiments
The BRE experiments aboard the International Space Station (ISS) were conducted in the 
Combustion Integrated Rack (CIR) under the Advanced Combustion via Microgravity 
Experiments (ACME) program. Conducting the experiments required a collaboration between the 
UMD and NASA operations, and engineering team. The UMD team consisted of prominent faculty 
advisors (Dr. Quintiere, Dr. Sunderland, and Dr. de Ris), and students. The author of this thesis 
was the leading Ph. D. student for the BRE experiments aboard the ISS. Four undergraduate, and 
four graduate students collaborated with the analysis of this project under supervision of the faculty 
advisors and the leading student. 
The NASA team was responsible for providing the experimental apparatus, sending the 
equipment to the ISS, and installation of the hardware required for each experiment. The 
experiments were performed automatically by using a software developed by NASA team. Some 
tasks required human interaction on the space station such as, changing the fuel and oxygen gas 
bottles, installation of burners and specific hardware required for each experiment. NASA team 
also supported the UMD team by reviewing, revising and providing information as needed.
The UMD team was responsible for:
1. Preprocessing of the experiments: 
a. Calibration of the heat flux sensors, radiometers, and slug calorimeter.
b. Identifying the working conditions of the sensors, mass flow meters and burners 
to ensure successful ignition and data recording on the test point days
c. Identifying design parameters and develop a test matrix that could provide 
enough data for the objectives of this study
d. Submitting the test parameters sheet (Appendix D) to NASA operations team 
two business days before each test point day. The total number of parameters 
were 69 that included, volumetric flow rates of fuel and nitrogen, ambient 
conditions for each test, camera settings, igniter position, etc. The parameter 
sheet was effectively the test matrix for each test point day, but with 
significantly more detail that helped NASA operations team to run the tests on 
the test day.
~~~~

### Pagina 25

Cita: [pdf_2ada277f4accf3ff7dca, p. 25]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
22
2. There were two rounds of tests. Each round consisted of 8 test point days that took 12 
hours per day. The NASA operations team was responsible for running the tests, record 
the imaging and non-imaging data, and uploading the data on a cloud-based drive. The 
UMD team was responsible for:
a. Monitoring the tests and make changes to the parameters sheet as needed
b. Performing an initial analysis of the data provided shortly after each test
3. Analysis of the data and publication
A gaseous fuel BRE burner, with top surface diameter of 25 mm, is used. The burner top 
surface is made of a perforated copper sheet with 125 holes with diameters of 1.2 mm. A ceramic 
flow straightener ensures uniform fuel mass over the surface. Figure 1 shows a photograph of the 
burner and a schematic of the burner top and two heat flux sensors. 
2.1 Burner Surface Net Flame Heat Flux
Heat flux is measured locally by two Medtherm Schmidt-Boelter heat flux sensors flushed 
with the burner surface (at r = 0 and 9.5 mm) along with their surface temperatures, as they are not 
Figure 2.1 BRE burner image (left) and drawing (right).
Radiation from 
CO2 and H2O
Center heat flux 
gauge at r = 0 mm
Insulation
Offset heat flux 
gauge at r = 9.5 mm
Flame sheet
Copper 
surface
Center Thermocouple 
at r = 4.5 mm
Offset thermocouple 
at r = 10.4 mm
Flame height yf
25 mm 
BRE burner
igniter
4.7 mm
~~~~

### Pagina 26

Cita: [pdf_2ada277f4accf3ff7dca, p. 26]. Metodo: native.

~~~~text
23
water-cooled. The copper surface shown in Figure (2.1) schematic is designed to have a uniform 
temperature and to act as a calorimeter to measure the total average heat flux over the burner. (A 
fault in its design exposed the edges to the flame and caused significant uncertainty in directly 
measuring the heat flux over the projected burner face area. A correction procedure helped to 
improve this measurement.) Two K-type thermocouples located at r = 4.7 and 10.4 mm record the 
surface temperature of the copper top. The details of the burner surface and the location of the heat 
flux sensors and thermocouples are shown in Figure 2.1. The measurement objective is to obtain 
the average net heat flux to the burner surface from the calorimeter and the local sensor 
measurements.
The calorimeter was calibrated with a known radiant heat flux in the manner described 
previously by Markan et al [48]. The equation for its reduction to the net burner heat flux is given 
as in Eq. (2.1). 
𝑞̇
!"#
$$ =
> ( 𝑚 𝑐 )%& B 𝑑𝑇'
𝑑𝑡 F + 𝜖 𝜎 𝐴' ( 𝑇'
) − 𝑇*
)) + ℎ 𝐴' ( 𝑇' − 𝑇*) + 𝑄̇
+ + 𝑄̇
,-. + 𝑄̇
/L
𝐴'
(2.1)
Where the first three terms on the RHS represent absorbed by the copper plate, surface re￾radiation, and free convection from copper plate (zero in micro-gravity). 𝐴', 𝐴,-. 𝑎𝑛𝑑𝐴/ are 
respectively, the burner face-area (573 mm2
), heat flux sensor side-wall area that transfers heat to 
the back of the burner (40 mm2
), and back-face of the copper plate (573 mm2
). 𝑄̇
+ ,𝑄̇
,-. 𝑎𝑛𝑑𝑄̇
/
are heat absorbed by burner gaseous flow, heat conducted to the sensor rod (geometrical details 
shown in [48]), and heat transferred to the back of the burner face which are given by Eqns. (2.2 
to 2.4).
𝑄̇
+ = 𝑚̇
+ 𝑐+ ( 𝑇' − 𝑇/ ) , (2.2)
𝑄̇
,-. = ℎ,-. 𝐴,-.( 𝑇' − 𝑇,-. ) , 𝑎𝑛𝑑 (2.3)
𝑄̇
/ = ℎ/ 𝐴/ ( 𝑇' − 𝑇/ ) (2.4)
~~~~

### Pagina 27

Cita: [pdf_2ada277f4accf3ff7dca, p. 27]. Metodo: native.

~~~~text
24
where 𝑇/ and ℎ/ are back temperature calculated by Eq. (2.5), and heat transfer coefficient 
to the back of the copper surface. Equations (2.1 to 2.5) are derived in [49]. 
𝑇/ = 𝑇* +
ℎ/
𝑒/
P 1.5 ( 𝑇' − 𝑇/ ) Q ( 𝑇' − 𝑇/ ) 𝑑𝑡
0
1
R
1.3
. (2.5)
hb, hrod, eb and (mc)Cu are found by equating Eq. (2.1) to the average net heat flux which is 
determined by the two heat flux sensors during calibration of the calorimeter. The detailed 
calibration apparatus and procedure are described in [48]]. The root mean squared difference 
between RHS of Eq. (2.1) and known average heat flux is minimized by a commercial equation 
solver.; respectively found to be 386 W/m2
-K, 22 W/m2
-K, 5525 W-s0.5/m2
-K, and 7.98 J/K. The 
𝑞̇
!"#
$$ obtained here includes heat absorbed to the bevel edge of the top surface. That needs to be 
eliminated to account solely for the average absorbed face-area heat flux (see appendix A).
The two heat flux sensors are calibrated using a NIST standard [55,61]. The sensors have 
the original Medtherm paint while the copper burner top is painted with a more robust paint 
(Rustoleum). The sensor and copper painted surface emissivities were measured as unity and 
their corresponding absorptivities are 0.91 and 0.94 [61].
The desired net flux includes the radiation and convection from the flame minus the re￾radiation of the burner surface. The corrections to the sensor heat flux have been derived previously 
and are presented in Eqns. (2.6, and 2.7) [10,46,47] .
𝑞̇
450
$$ = 𝑞̇
'54'-,
$$ + ( 𝛼' − 𝛼6 ) 𝑞̇
7,,
$$ − 𝜖' 𝜎 ( 𝑇'
) − 𝑇*
) )
+𝜖6 𝜎 ( 𝑇6
) − 𝑇*
) ) + ℎ/( 𝑇6 − 𝑇' ) (2.6)
ℎ/ =
⎣
⎢
⎢
⎡
𝑞̇
'54'-,
$$ + 𝜖 𝜎 ( 𝑇6
) − 𝑇*
) )
𝑌9: ∆ℎ!,9:
𝑐;
− ( 𝑇6 − 𝑇* )
⎦
⎥
⎥
⎤
. (2.7)
~~~~

### Pagina 28

Cita: [pdf_2ada277f4accf3ff7dca, p. 28]. Metodo: native.

~~~~text
25
The second term on the RHS contains the unknown incident flame radiation heat flux 
multiplied by the difference in absorptivities. It was to be eliminated by using the same paint on 
the sensor and burner, but that did not happen. The term is neglected in the equation, and it can be 
shown to be small accounting for less than 1% of the net heat flux as the 𝑞̇
7,,
$$ ranges from 1.9 to 
5.5 <=
>! and average absorbed heat flux ranges from 6.5 to 15.7 <=
>!. 
2.2 Flame Radiation
Several radiometers are oriented to view the burner flame and surface from distances of 
roughly 160 and 200 mm. The radiometers (Dexter Research Inc.) have a viewing window made 
of BaF: and the void volume between the sensing surface and the window is filled with argon [61]. 
The radiometers were calibrated by NASA using a black-body radiation source and varying 
temperature and aperture size. Two of the radiometers are used for radiation analysis and their 
calibration equations are (0.00114𝑉 − 0.001481)𝑊 𝑐𝑚: ⁄ and 
(0.001798𝑉 − 0.002307)𝑊 𝑐𝑚: ⁄ [62,63]. There are two other radiometers available on BRE 
radiometer array, but for most of the cases their measured heat fluxes were out of range. The 
radiometers were used to determine the sensor normal radiant heat flux from both the flame and 
the burner. This could then be used to estimate the total radiation lost by the flame. The radiometry 
schematic is shown in Figure 2.
2.3 Fuel Mass Flux 
The fuel nitrogen mixture mass flux simulates condensed phase burning. If the flame is 
steady, the net average flame heat flux divided by this mass flux gives the theoretical heat of 
gasification of the condensed phase burning material. The fuel mixture volumetric flow rate is 
measured by a Hastings instrument HFM-300 with maximum flow rate of 0.2 and 0.5 slpm 
nitrogen-based for low and high mass flux experiments respectively. The mass flow controllers 
are calibrated by nitrogen meaning that if other gases are used, an appropriate gas conversion factor 
must be used. The gas conversion factors used for these experiments are computed from Eqn. (2.9), 
and the volumetric flow rate of fuel mixture is calculated by using Eqn. (2.8) [64], where KN2 = 1, 
and 𝑉̇
represents volumetric flow rate.
~~~~

### Pagina 29

Cita: [pdf_2ada277f4accf3ff7dca, p. 29]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
26
𝑉̇
>?@ = 𝐾>?@
𝐾A:
𝑉̇
A: (2.8)
1
𝐾>?@
= 𝑋7
𝐾7
+
1 − 𝑋7
𝐾A!
(2.9)
2.4 Images
Videos are recorded at 30 fps by the operations-camera that is placed inside the chamber. 
Still images are extracted from these frames to illustrate flame dynamics. The image sequences 
used here are created by using these images.
2.5 Experimental Design
Experiments were conducted onboard the international space station (ISS) to ensure 
possibility of long duration flames in microgravity condition. The g-level attained in ISS is less 
than μ-g [65]. A total of 149 successful ignitions were obtained. Twenty-nine of the flames lasted 
Figure 2.2 Radiometer schematic
radiometer dn
mm
df
mm
ds
mm
θr
deg.
θf
deg.
+60 154 160 ± 
1.5 160.5 5 21
offset 204 206 ± 2 208 2 55
~~~~

### Pagina 30

Cita: [pdf_2ada277f4accf3ff7dca, p. 30]. Metodo: native.

Calidad: table_structure_not_manually_validated.

~~~~text
27
for a perceived steady state of 120 seconds or more (up to 300 seconds). The rest of the cases 
started to develop instabilities followed by self-extinguishment. 
The burner is installed in a quiescent chamber that is nominally 100-liter capsule before 
any hardware is installed where the hardware would fill about 15-liters of its volume. Ethylene, 
and nitrogen-diluted ethylene are used as fuel mixture that represent heats of combustion range of 
15 and 47.2 kJ⁄g [66–68]. The ambient pressure, oxygen concentration and fuel mixture mass flow 
rate are changed to explore their effects on burning. Three of the atmospheres are nominal NASA 
selected atmospheres of pressure and oxygen for human habitat in space flight: 21 % oxygen and 
1 bar, 26.5% and 0.7 bar and 34 % and 0.565 bar [69]. The mass flux settings and ambient 
conditions used for these experiments are summarized in Table 2
Table 2.1. Design parameters for BRE-ISS round 1 
experiments.
Quantity Values
𝑚̇
>?@
$$ 1 - 12 g / m2
-s
XO2 0.21 - 0.4
Xf 0.15 to 1
p 0.56 - 1 bar
~~~~

### Pagina 31

Cita: [pdf_2ada277f4accf3ff7dca, p. 31]. Metodo: native.

Calidad: table_structure_not_manually_validated.

~~~~text
28
3 Experimental Results of Round 1 Tests
Burning experiments are analyzed for 59 successfully ignited tests using a gas burner 
(BRE) to emulate the steady burning of 25 mm diameter flat surface materials. More than half of 
the tests resulted in long burns of at least 2 and as long as 5 minutes. Mixtures of ethylene and 
nitrogen allow for 23.6 and 47.2 kJ/g heats of combustion (LHV). Ambient conditions range from 
40 to 21 % oxygen and pressures of 1 to about 0.4 bar. NASA human habitat atmospheres have 
been used. Generally, it has been found that oxygen levels of 26 % and above can allow steady 
flames. The flames are thin blue in color and grow slowly over time for minutes. Some self￾extinguish, some had periodic oscillations, and others appear to have become steady and were shut 
down. Theoretical analyses show the shutdown flames were steady in growth, and all of the test 
endpoints were more than 94 % of steady state in flame heat flux. Flame heat flux for set mass 
flux allowed the estimation of heats of gasification to relate to steady solid materials that might 
burn in microgravity. Radiometers allowed the computation of flame radiative fraction that 
appeared to correlate well with the measured flame height. Results are shown for heat flux, flame 
height and base radius, radiative fraction as a function of fuel mixture mass flux, and various 
oxygen and pressure atmospheres.
3.1 End Point Results
Table 3.1 gives a summary of the end-point conditions found. The most useful data in this 
table are the apparent steady results where the duration of the test was long, appeared steady and 
the fuel flow rate was shut down. The issue of their steadiness will be theoretically examined to 
provide some justification for further examining these data as steady. The usefulness of these 
steady data is in the determination of the derived heat of gasification (heat flux divided by mass 
flux) to relate to real solid fuels that could burn steadily in microgravity at this scale.
~~~~

### Pagina 32

Cita: [pdf_2ada277f4accf3ff7dca, p. 32]. Metodo: native.

Calidad: table_structure_not_manually_validated.

~~~~text
29
Table 3.1. Summary of the ISS tests.
test pt.
XO2 Xf p 𝑚̇
"" 𝑞̇
#$%
"" 𝑞̇
&''
"" 𝑞̇
#()
"" 𝑞̇
#(),#%# "" yf rf 𝑞̇
%,,-
"" 𝑞̇
%,&''
"" Xr tb end pt.
bar g/m condition 2
s kW/m2 kW/m2 kW/m2 kW/m2 mm mm s
39B3 0.38 1 1.01 2.55 6.52 3.51 14.41 -
1 22.9 20 - - - 180 FT2
39A1 0.40 1 1.01 3.84 5.38 2.73 12.75 - 33.0 23.3 - - - 120 FT
56A1 0.40 0.5 1.03 4.46 6.27 3.75 14.4 5.89 22.3 17.7 - 60.86 0.58 180 FT
63A1 0.39 0.5 1.02 6.04 4.54 2.41 12.74 - 42.0 21.2 - - - 300 FT
56A2 0.39 0.5 1.04 6.39 4.54 2.36 11.65 - 34.9 25.5 - - - 180 FT
63B1 0.38 0.5 1.02 8.94 3.73 1.76 9.83 - 62.5 22.3 - - - 151 SE3
63C1 0.36 0.5 1.02 12.14 3.17 1.45 8.41 - 80.0 24 - - - 92 SE
51A1 0.34 1 1.02 2.55 5.18 2.9 11.1 - 24.5 20.9 - - - 180 FT
51B1 0.33 1 1.02 3.06 4.79 1.46 9.94 - 28.8 23.4 - - - 99 SE
51C3 0.32 1 1.02 3.83 4 2.27 9.04 - 41.8 25.7 - - - 66 SE
87D1 0.32 1 0.57 1.18 9.27 5.7 14.6 12.18 10.7 14.5 39.2 24.52 0.439 180 FT
87C1 0.33 1 0.57 1.47 7.51 4.46 14.6 8.37 15.5 17.3 - 40 0.59 180 FT
87B1 0.34 1 0.57 1.78 7.05 4.09 14.4 8.14 16.8 17.8 - 46.43 0.57 180 FT
87A1 0.36 1 0.57 2.07 6.6 3.58 14.7 11.19 19.8 19.4 - 56.32 0.605 180 FT
51D1 0.34 1 0.57 2.55 4.92 2.57 11.76 - 27.2 22.8 - - - 180 FT
51F1 0.32 1 0.57 3.07 4.08 2.15 9.44 - 37.6 28 - - - 131 SE
51G1 0.30 1 0.57 3.83 3.64 2.09 8.055 - 42.9 26.6 - - - 67 SE
94H1 0.35 1 0.57 5.43 3.15 1.66 7.28 - 59.1 34.6 - - - 47 SE
94J1 0.33 1 0.57 5.95 2.96 1.62 7.19 - 58.2 35.4 - - - 37 SE
94K1 0.30 1 0.57 6.95 2.92 1.67 6.75 - 74.0 34.6 - - - 36 SE
66D5 0.34 0.5 0.58 1.76 11.2 6.81 13.2 15.65 6.3 13 21.17 12.93 0.332 180 FT
66D4 0.35 0.5 0.58 1.79 8.21 5.39 13.9 10.83 11.3 14.1 38.9 24.55 0.575 180 FT
66D3 0.35 0.5 0.58 2.05 10.1 6.72 13.8 13.67 8.4 12.9 27.81 17.25 0.346 180 FT
66F1 0.36 0.5 0.57 2.18 9.64 6.39 14.2 13.69 9.1 13.4 29.54 18.46 0.345 180 FT
66G1 0.35 0.5 0.57 2.45 8.2 5.37 13.3 9.06 11.4 14.5 38.1 23.75 0.407 180 FT
66J1 0.33 0.5 0.57 3 6.61 4.11 13.2 8.1 15.2 16.4 - 32.5 0.48 FT
70A1 0.36 0.5 0.57 3.43 6.5 4.32 13.6 6.22 16.5 16.8 - 39.2 0.511 114 FT
70B1 0.35 0.5 0.57 3.95 5.52 3.35 12.5 5.62 20.9 18.4 - 49.51 0.563 120 FT
70C1 0.34 0.5 0.57 4.42 4.61 2.7 12 7.0 25.6 20.4 - 60.12 0.616 120 FT
56D2 0.34 0.5 0.57 4.5 4.54 2.5 12.05 - 41.8 20.2 - 58.61 0.605 180 FT
70D1 0.36 0.5 0.57 4.95 4.48 2.5 12 - 28.1 21 - - - 180 FT
56D3 0.33 0.5 0.57 6.38 3.32 1.66 9.03 - 42.6 38.6 - - - 137 SE
39C1 0.26 1 0.99 3.84 3.2 2.33 7.43 - 38.1 28.5 - - - 26 SE
39D1 0.25 1 0.99 2.54 3.8 2.75 8.65 - 43.5 28.2 - 62.23 0.56 14 SE
87K1 0.25 1 0.71 1.04 7.13 4.1 10.65 12.46 12.6 14.9 36.63 21.27 0.435 180 FT
94G1 0.26 1 0.71 1.17 6.7 3.8 10.1 11.56 15.25 16.6 38.95 24.63 0.455 180 FT
87J2 0.26 1 0.71 1.176 6.63 3.85 10.76 11.99 14.2 16 40.5 25.64 0.492 180 FT
87H1 0.27 1 0.71 1.48 5.95 3.27 10.49 10.56 17.7 18.4 - 36.36 0.567 180 FT
94F1 0.27 1 0.71 1.66 5.33 2.95 9.67 - 25.5 20.4 - 39.84 0.558 133 SE
87G1 0.28 1 0.71 1.79 5.05 2.93 10.04 - 29.9 22.4 - 46.82 0.6 160 SE
94D1 0.28 1 0.71 2.14 4.66 2.62 8.89 - 30.4 23.5 - 54.9 0.585 80 SE
51K1 0.25 1 0.69 3.83 3.17 2.11 6.8 - 44.6 27.2 - - - 25 SE
63F1 0.26 0.5 1.01 8.91 2.88 1.7 6.81 - 59.5 22.8 - - - 32 SE
63G1 0.25 0.5 1.02 12.13 2.92 1.57 6.62 - 72.7 23.4 - - - 28 SE
63D1 0.27 0.5 1.01 6.03 3.41 2.3 7.22 - 44.1 22 - - - 33 SE
56B1 0.25 0.5 1.01 4.46 3.71 2.58 7.62 - 27.3 21.1 - 49.06 0.504 38 SE
70L1 0.27 0.5 0.71 1.74 6.92 4.16 9.5 11.64 10.4 12.7 29.24 18.12 0.358 180 FT
70H1 0.27 0.5 0.71 1.94 7.22 4.16 9.8 11.71 11.9 13.8 29.25 18.13 0.425 180 FT
70K1 0.28 0.5 0.71 2.27 6.52 4.06 10.2 10.70 13.3 15.1 36.45 22.22 0.395 120 FT
56F1 0.25 0.5 0.69 4.45 3.48 1.88 8.62 - 28.9 23.4 - 51.73 0.53 42 SE
56G1 0.24 0.5 0.69 5.09 3.11 1.66 8.12 - 28.0 24.5 - 58.72 0.521 35 SE
94A4 0.21 1 1.02 1.156 6.8 4.58 7.38 - 18.7 15.8 29.72 18.52 0.365 37 SE
94A2 0.22 1 1.02 1.43 6.33 4.17 7.67 - 16.0 18 - 26.61 0.416 30 SE
94A1 0.22 1 1.02 1.861 5.3 3.58 7.97 - 21.6 21.1 - 40.89 0.499 21 SE
39H1 0.19 1 1.02 3.06 3.9 2.67 7.24 - 25.0 23.9 - 51.3 0.384 17 SE
39H2 0.18 1 1.02 3.06 4.06 2.7 7.1 - 25.5 24.7 - 50.83 0.38 17 SE
39F1 0.20 1 1.02 3.83 3.07 2.38 6.6 - 33.0 24.9 - - - 16 SE
39G1 0.20 1 1.02 5.128 2.31 1.42 7.42 - 60.0 28 - - - 13 SE
56C1 0.22 0.5 1.02 4.45 3.05 2.45 6.82 - 28.1 22 - 41.18 0.42 19 SE
1. Radiometer data not available
2. Flow-Terminated (considered as steady)
3. Self-Extinguished
~~~~

### Pagina 33

Cita: [pdf_2ada277f4accf3ff7dca, p. 33]. Metodo: native.

Calidad: table_structure_not_manually_validated.

~~~~text
30
3.2 Unsteady Results
Unsteady results help in illustration of transient behavior of flames as well as distinguishing 
between steady and self-extinguished flames by observation of transient data and flame images. 
Data on the heat flux devices and four video cameras recorded the flame images over the time of 
a test after ignition. Although steady data is the main objective of this work, it is revealing to 
examine these transient data. For illustration three tests will be discussed here: 87B1, 51D1 and 
94K1 of Table 3.1. They have the same nominal atmospheres, 0.34 oxygen mole fraction and 0.56 
bar pressure. As the mass flux is increased: 1.78, 2.55 and 6.95 g/m2
s, the flame grows taller and 
finally extinguishes at the highest flow rate. The self-extinguished flames occurred above 3 g/m2
s 
and they all showed periodic growth and decay before final flame cessation. The video frame 
sequences are shown in Figure 3.1. They have been edited to give the best images, but in all cases, 
the color of the flames after early ignition effects, are blue. In some cases, apparent soot particles 
are disgorged through the flame (see Figure 3.1c at 6 s). In Figures 3.1a, and 3.1b, the flames grow 
and reach steady state before they were intentionally shutdown at about 3 minutes. This had to be 
done to conserve fuel and maintain reasonably constant atmospheres. The flame grows both 
radially and vertically in the images, and as the flow rate is increased the flame overhangs below 
the burner surface around the exposed burner copper edge and similar trend were observed by Ban 
et. al. General shape of the flames were also observed in ref [70] where the experiments took place 
in 1-g and their general shape were similar to those observed in current study. Figure 3.1c shows 
these effects more strongly, but now at 20 s the flame begins to partially extinguish. It periodically 
moves from full to partial in existence until complete elimination at 34 s.
~~~~

### Pagina 34

Cita: [pdf_2ada277f4accf3ff7dca, p. 34]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_2ada277f4accf3ff7dca/p0034.jpg)

~~~~text
31
FT
FT
SE
Figure 3.1. Color images of tests (a) 87B1(ṁ
$$ = 1.78 g/m:s), (b) 51D1 
(ṁ
$$ = 2.55 g/m:s), and (c) 94K1 (ṁ
$$ = 6.95 g/m:s). All are at nominal 
conditions of XO2 = 0.34, Xf = 1, and p = 0.56 bar.

[Texto OCR de la imagen]
(a)
O s (iViitön) | 30s | 120. | 181 S (flow
(b)
20s | 60 S | '20s | 182 (flow
IOS | 12 s
21 s | 24 s | 23 s
32 s | 33 s | 34 s (ext•mOa)
Figure 3.1. Color images of tests (a) 87Bl(1i1" = 1.78 g/m2s), (b) 51DI
(rid' = 2.55 g/m2s), and (c) 94K I Oil" = 6.95 g/m2s). All are at nominal
conditions ofX02 0.34, | l, and p 0.56 bar.
31
~~~~

### Pagina 35

Cita: [pdf_2ada277f4accf3ff7dca, p. 35]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
32
The unsteady heat flux data are shown in the left plot of Figure 4, for the high flow rate, 
and the right plot of same figure, for the low flow rate case in Fig 3.1. The uncorrected transient 
calorimeter results are shown, as only the end points were corrected in Appendix A. These results 
reveal several unexpected characteristics. First, the center heat flux is higher than the “offset” 
sensor at 9.5 mm compared to the burner radius of 12.5 mm. One might expect the opposite based 
on the proximity of the flame to the surface; yet flame radiation from the product gases depends 
on on volume rather than distance. Second, the heat flux sensors and calorimeter net heat flux 
values all start very high and decrease to somewhat of an asymptote. In Figure 3.2 (Right), an 
effect prevalent in many tests, the two local gages drop sharply then gradually until an abrupt 
upward change occurs, followed by a smooth curve. This is believed to be due to early water 
condensation on the gages from the combustion products in contact with a relatively cool sensor. 
The small void space between the sensor and copper top can be a favorable condensation site. The 
liquid water acts as a barrier to conduction into the gage. The flame begins to evaporate water, 
further reducing the heat into the gage until it is dry. Then the dry gage suddenly senses the true 
flame heat flux. This effect was also demonstrated in our laboratory at 1-g. Third, after the water 
Figure 3.2. Heat flux and surface temperature for tests (Left) 94K1 and (Right) 87B1. Both are 
at nominal conditions of XO2 = 0.34, Xf = 1, and p = 0.56 bar.
~~~~

### Pagina 36

Cita: [pdf_2ada277f4accf3ff7dca, p. 36]. Metodo: native.

Calidad: table_structure_not_manually_validated.

~~~~text
33
effects, the measurements follow a smooth slow decay as we would expect. In Figure 3.2 (Left) at 
the high flow rate, it appears heading for an asymptote but becomes periodic before self-extinction, 
and in Figure 3.2 (Right) at the lower flow rate, the descent appears asymptotic. Fourth, the smooth 
curve heat flux values following their early descent, have values inversely related to the steady 
mass flux, e.g., 15 kW/m2 for 1.78 g/m2
s and about 7 kW/m2 for 6.95 g/m2
s; this is a typical trend. 
The transient copper temperature is measured by the two thermocouples on the surface (see Figure 
2.1) and both measured values were almost equal. Therefore, the arithmetic average of the two 
local temperature measurement is used as the copper temperature in Figure 3.2. Moreover, The 
transient flame length, base radius and Photomultiplier Tube (PMT) with OH* filter assembly [71]
for test point 66D5 are presented in appendix B which illustrates the asymptotic behavior of steady 
BRE flames. 
Reexamining the flame behavior for an approximate constant mass flux, but with variations 
in the pressure, oxygen, and fuel concentration (or heat of combustion of the fuel mixture). 
According to Table 3.1 and by comparing Figures 3.3a, 3.3b and 3.4a, one could see the effect of 
nominal ambient oxygen mole fraction as it ranged from 0.4 to 0.265 with other parameters kept 
constant. In some tests that were shutdown, an apparent steady periodic behavior was 
demonstrated. This is shown in Figure 3.3b at 1 bar in which the periodic flame extinctions 
continue for nearly 1 minute before fuel shutdown, yet for the same of the conditions in Figure 
3.3b except with an atmospheric pressure of 0.56 bar there was no periodic behavior observed.
Perhaps this is a pressure effect indicating the flames are more stable at the lower pressure.
Finally, one could see the effect of fuel mole fraction by looking at Figures 3.3b and 6b. 
They show flames at nominal ambient oxygen mole fraction of 0.34 and decreasing ethylene mole 
fraction from 1 to 0.5. All these image sequences suggest that higher oxygen, lower pressure, and 
lower heats of combustion tend to generate more stable flames that could reach steady state or last 
longer. Higher ambient oxygen concentration and lower pressure will result in higher flame 
temperature and higher radiative heat loss respectively, while fuel dilution with an inert (here we 
used nitrogen) caused flames to get smaller in size and thus decreased radiative heat loss at same
~~~~

### Pagina 37

Cita: [pdf_2ada277f4accf3ff7dca, p. 37]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_2ada277f4accf3ff7dca/p0037.jpg)

~~~~text
34
fuel mixture mass flux. This is still under further investigation and will be discussed in more detail 
later.
Figure 3.3. Color images of tests (a) 39B3 (ṁ
$$ = 2.55 g/m:s) and (b) 51A1
(ṁ
$$ = 2.55 g/m:s). Both are at nominal conditions of Xf = 1, p = 1 bar and XO2
= 0.4 and 0.34, respectively.

[Texto OCR de la imagen]
fuel mixture mass flux. This is still under further investigation and will be discussed in more detail
later.
Ils | 14s | 20s
(a)
ISOs
O s (ipe«n) | 12 s | 20s | 40 s
(b)
90 s | 129s
178 s | 182 s | FT )
Figure 3.3. Color images of tests (a) 39B3 (lid' = 2.55 g/m2s) and (b) 51 Al
Oil" = 2.55 g/m2s). Both are at nominal conditions of | 1, p 1 bar and x02
0.4 and 0.34, respectively.
34
~~~~

### Pagina 38

Cita: [pdf_2ada277f4accf3ff7dca, p. 38]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
35
3.3 Steady Results
Here the end point data that did not self-extinguish in the time of the test will be examined. 
In order to justify their use as “steady” or nearly steady, a theoretical analysis can be used as a 
measure. It has been previously shown that analytical
Figure 3.4. Color images of tests (a) 39D1 (ṁ
$$ = 2.54 g/m:s) and (b) 
66G1 (ṁ
$$ = 2.45 g/m:s). Conditions are XO2 = 0.265 and 0.34, Xf = 1 and 
0.5, and p = 1 and 0.56 bar, respectively.
~~~~

### Pagina 39

Cita: [pdf_2ada277f4accf3ff7dca, p. 39]. Metodo: native.

Calidad: table_structure_not_manually_validated.

~~~~text
36
Unsteady theory has been a good predictor of tests [49]. The analytical solution to this 
theory gives the mixture fracture, Z. The solution is based on classical diffusion flame theory with 
the assumption of unity Lewis number for the steady problem. Then it is shown in [49] that a 
transient term can accurately be added to the steady solution. This gives the following approximate 
analytical solution for the mixture fraction in Eq. (3.1). 
𝑍 = h
1 − exp [
2 𝜆
𝜋
tanBCq 𝜉7 s − 𝜆 ]
1 − exp( −𝜆 ) u erfc y 𝜉7
2 √𝜏
| , (3.1)
where the complementary error function contains the unsteady term that reflects the transient 
behavior of mixture fraction in space where it approaches unity as burn-time is increased. 
Equations 3.2 to 3.4 represent dimensionless time, ambient mass diffusivity and dimensionless 
mass flux, respectively.
𝜏 = 𝐷*𝑡
𝑅: , (3.2)
𝐷* = 𝑘
𝜌𝑐;
, 𝑎𝑛𝑑 (3.3)
𝜆 = 𝑚̇
$$
4𝑘
𝜋𝑐;𝑅
. (3.4)
The dimensionless flame position, 𝜉7, is found by the stoichiometric value of the mixture 
function, and this is also the dimensionless flame height. Therefore, from the experimental end 
point data, the value of erfc can be evaluated. Theoretically a value of 1 is steady. Figure 3.5 shows 
the results for all the end point data. It clearly shows that the data that did not self-extinguish have 
values of nearly unity, while those that self-extinguished, range from 0.2 to 0.9 monotonically as 
time increases. Constant properties of nitrogen at 1400 K are used to obtain steadiness (erfc) of 
the flame heights.
Comparing the heat flux growth illustrated in Figure 3.6, with the flame growth in Figure 
3.5, it can be observed that the flame grows more slowly than changes in the heat flux. Theory 
shows that [49] the near surface effects approach steady conditions faster than those farther away.
~~~~

### Pagina 40

Cita: [pdf_2ada277f4accf3ff7dca, p. 40]. Metodo: native.

Calidad: figures_not_digitized, table_structure_not_manually_validated.

~~~~text
37
This can be assessed for the data in Table 3.1 by examining the unsteady solution for the convective 
heat flux at the center (see Eq. 3.5). Eq. 3.6 represent the unsteady part of the theoretical convective 
heat flux [49]. 
𝑞̇
'
$$(𝑟 = 0) = − <
D >( 𝑇' − 𝑇* ) − ∆F. G/0
H !1
L 𝐴∈J1 . (3.5)
The unsteady part of the theoretical convective heat flux [49] is expressed as
𝐴∈J1 = 1
√𝜋 𝜏
+
2 𝜆
𝜋 P exp( −𝜆 )
1 − exp( −𝜆 ) R . (3.6)
The steadiness factor, i.e., the ratio of the steady to unsteady values is expressed as
Figure 3.5. Steadiness of flame height for all the tests.
0
0.1
0.2
0.3
0.4
0.5
0.6
0.7
0.8
0.9
1
0 50 100 150 200 250 300 350
steadiness	of	flame	height	
burn	time	(s)
!! = 2.7×10"# m2/s for 02 12 3! = 1400 K
SE FT Xf XO2
p 
(bar)
N/A 1 0.4 1
N/A 1 0.34 1
1 0.34 0.56
1 0.265 0.7
N/A 1 0.21 1
0.5 0.4 1
0.5 0.34 0.56
0.5 0.265 0.7
N/A 0.5 0.21 1
∆ℎ% = 8& 47.2 kJ/g
~~~~

### Pagina 41

Cita: [pdf_2ada277f4accf3ff7dca, p. 41]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
38
𝑋K,'0 =
2 𝜆
𝜋 > exp( −𝜆 )
1 − exp( −𝜆 ) L
1
√𝜋 𝜏
+ 2 𝜆
𝜋 > exp( −𝜆 )
1 − exp( −𝜆 ) L
. (3.7)
The steadiness of the heat flux results is presented in Figure 3.6, with nitrogen properties 
at 850 K used to evaluate the constant property parameters. (The constant property solution 
requires judgment in selecting properties and near wall and near flame temperatures have been 
used relating the data to theory). The results clearly show that even for the unsteady self￾extinguished data, the heat flux is 80% or more of its steady value. It is suggested that these self￾extinguished heat flux values could be used to indicate materials that seek steady burning but die 
out as the flame grows. From here on let us just examine primarily the “steady” end points.
Figure 3.6. Steadiness of heat flux for all the tests.
0.8
0.82
0.84
0.86
0.88
0.9
0.92
0.94
0.96
0.98
1
0 50 100 150 200 250 300 350
Heat	Flux	steadiness	
X!,"#
burn	time	(s)
! = 0.055 W/mK and	.! = 1.126 J/gK for N2 at 9 = 850 K
SE FT Xf XO2
p 
(bar)
N/A 1 0.4 1
N/A 1 0.34 1
1 0.34 0.56
1 0.265 0.7
N/A 1 0.21 1
0.5 0.4 1
0.5 0.34 0.56
0.5 0.265 0.7
N/A 0.5 0.21 1
∆ℎ# = =$ 47.2 kJ/g
~~~~

### Pagina 42

Cita: [pdf_2ada277f4accf3ff7dca, p. 42]. Metodo: native.

Calidad: figures_not_digitized, table_structure_not_manually_validated.

~~~~text
39
A commercial equation solver was utilized to equate calculated flame height (Derived from 
Eq. 3.1), and surface heat flux (Eq. 3.5) with corresponding measured quantities which resulted in 
finding the “best” constant properties used for each case.
3.3.1 Heat Flux
The local sensor and average net heat flux results from Table 3.1 for the “quasi-steady” 
data are used. The calorimeter heat flux values have been corrected to eliminate the unwanted 
heating of the copper burner exposed edge non-flow portion. The details are shown in Appendix 
A. Here the steady data end points are plotted against mass flux in Figure 3.7 for the local sensors 
and the corrected average calorimeter net heat fluxes.
Figure 3.7. Measured local and average heat flux (measured by calorimeter [26], see 
appendix A) plotted with respect to fuel mixture mass flux for the FT tests.
~~~~

### Pagina 43

Cita: [pdf_2ada277f4accf3ff7dca, p. 43]. Metodo: native.

Calidad: table_structure_not_manually_validated.

~~~~text
40
Let us delineate the trends in the heat flux plots as a function of the mass flux, atmospheric 
oxygen and pressure, and fuel concentration in the fuel mixture stream. The latter represents the 
heat of combustion. First the local values will be examined. Center heat flux was about 50 % higher 
than offset located at r = 9.5 mm. Both heat fluxes decrease as the mass flux is increased. (This is 
associated with the flame located further from the surface). Heat fluxes increase nearly directly 
proportional to oxygen concentration. (But no steady data for 21 % oxygen). Heat fluxes increase 
as the heat of combustion decreases; nearly inversely related. (This is associated with flame 
height). Data at nominal 0.34 XO2, pure fuel, and fixed mass flux 2.55 g/m2
s show a very slight 
increase in heat flux with pressure (This is insignificant and inconclusive).
Let us now examine the average heat flux from the calorimeter. Figure 3.7 shows only the corrected 
data, and those data are less than the total collected because needed radiation information was not 
available for all the tests. The corrected data generally reduced the original data by up to a factor 
of 3 in a few cases, but the trend of the corrected data is now consistent with the local data to give 
us confidence that the correction is sound. The trends for the average heat flux are similar to the 
local data. Corrected average heat flux can be 20 to 70 % higher than the local center heat flux. 
Heat flux decreases with mass flux, increases with XO2 and decreases with fuel mole fraction. Also, 
data at nominal 0.34 XO2, pure fuel, and fixed mass flux 2.55 g/m2
s show a very slight decrease in 
heat flux with pressure. (This is insignificant and inconclusive).
3.3.2 Flame Radiation Fraction 𝑿𝒓
Two radiometers (+60 and offset) were used to determine the radiation coming from the 
flame and the burner surface. The heat flux measured by each radiometer is presented in table 3.1. 
Saturation of the radiometers limited their use and therefore not all tests have results in Table 3.1. 
Figure 2.2 shows a schematic of the radiometer orientations as well as the details of the distances 
and angles elaborated.
The radiant rate of energy to the sensor is found from the radiometer’s normal component 
of heat flux 𝑞̇
,
$$ with respect to the vector from the flame centroid located at the half of the flame 
height, see Eq. (3.8). Optically thin flame sheet with a point source of radiation with uniform
~~~~

### Pagina 44

Cita: [pdf_2ada277f4accf3ff7dca, p. 44]. Metodo: native.

Calidad: table_structure_not_manually_validated.

~~~~text
41
radiant intensity is assumed. This is justified because the radiometer distance is large compared to 
the flame size. The energy recorded by the radiometer is composed of flame 𝑞̇
7,,
$$ and burner surface 
re-radiation 𝑞̇
',,
$$ which is given by Eq. (3.10). The burner surface re-radiation is eliminated to give 
the flame radiant energy as shown by Eq. (3.9). 
𝑄̇
7,, = 4𝜋𝑑7
:𝑞̇
7,,
$$ (3.8)
𝑞̇
7,,
$$ = 𝑞̇
,
$$ − 𝑞̇
',,
$$ (3.9)
𝑞̇
',,
$$ = 𝜖'𝜎𝐹'B,𝐴'(𝑇'
) − 𝑇*
))𝑐𝑜𝑠𝜃7
𝑐𝑜𝑠𝜃,
(3.10)
The view factor between the burner surface and radiometer is given by Eq. (3.11). X and Y 
are calculated from geometrical details of the radiometry setup [72,73], given as
𝐹,→' = 𝑋
2 P 1 + 𝑋: + 𝑌:
Ñ(1 + 𝑋: + 𝑌:): − 4𝑌: − 1R , 𝑎𝑛𝑑 (3.11)
𝑋 = ℎ
𝑏 , 𝑌 = 𝑎
𝑏 , (3.12)
with a being the radius of the burner, h the vertical distance from the burner surface to the 
radiometer elevation, and b the horizontal distance to the radiometer. The radiant fraction is then 
computed from the known combustion energy as
𝑋, = 𝑄̇
7,,
𝑚̇
$$∆ℎ!𝜋𝑅: = 4𝜋𝑑7
:(𝑞̇
,
$$ − 𝑞̇
',,
$$ )
𝑚̇
$$∆ℎ!𝜋𝑅: . (3.13)
The measured radiant fractions are given in Table 3.1 where radiometer data were useable. 
The end-point data were used just before fuel termination (FT) or self-extinction (SE) at the peak 
in oscillating flames.
~~~~

### Pagina 45

Cita: [pdf_2ada277f4accf3ff7dca, p. 45]. Metodo: native.

~~~~text
42
The flame is blue in all these tests as shown in Figs. 3.1, 3.3 and 3.4. This is common for 
microgravity burning with little or no soot. Therefore, the radiation comes from the gases above 
and below the blue flame. Figures 3.8a and3.8b show the “steady” and self-extinguished end-point 
data where radiation fraction could be determined from the radiometers. The trends of Figure 3.8a 
show that the fuel mole fraction (or heat of combustion) dominates over XO2 and pressure. The 
radiant fraction is nearly directly related to the heat of combustion with the pure fuel nearly twice 
as high as the diluted fuel mixture. It might appear that “steady” flames cannot have a radiant 
fraction above about 60%. Extinction of microgravity flames has been associated with radiation 
loss and subsequent flame temperature drop. For now, this relationship is not examined. 
It will be seen that flame height is also directly related to the heat of combustion. So, it 
suggests that radiant fraction might be more directly related to flame height. Moreover, there is a 
similarity between flame height and radius, so flame height might be a representation for volume 
and radiation losses from the aggregate of flame gases. Such a plot is presented in Figure 3.8b. 
Here a logarithmic correlation is given for the “steady” data only, but the figure includes the data 
just before extinction as well. The extinguished data somewhat follow the correlation, but we will 
interpret the correlation to hold for the “steady” end point flame, not for self-extinguished cases. 
The extinguished data range from about 0.5 – 0.8 for low XO2 (21 and 26.5%). While these are 
relatively high values of radiant loss fraction, there does not appear to be a critical value for 
extinction.
~~~~

### Pagina 46

Cita: [pdf_2ada277f4accf3ff7dca, p. 46]. Metodo: native.

~~~~text
43
3.3.3 Flame Shape
The flame shape nearly follows the previous theory of half oblate ellipse as demonstrated 
by Markan et. al.[49]. Both the height and radius grow with time as shown in Figures 3.9 and 3.10. 
The flame radius pulls in at the edge of the burner, distorting it from the theoretical ellipse. It may 
either standoff or extend a small distance below the burner face. Here we plot the flame height, 
the distance vertically from the center of the burner, and the radius, the radial distance along the 
face of the burner. Figures 3.9 and 3.10, show the results for the steady flames as a function of 
mass flux. As with the radiant fraction, the flame height and radius at “steady” state are primarily 
grouped by heat of combustion and increase with mass flux and heat of combustion. It is known 
from theory that the flame radius is a singular function of its length. In spite of not perfectly 
following the elliptical theory, this similarity is shown for the “steady” data in Figure 3.11.
Figure 3.8. Flame radiant fraction vs. mass flux (a) and flame height (b) for all steady end￾point results.
y	=	0.25ln(x)	- 0.18
R²	=	0.84
0
0.1
0.2
0.3
0.4
0.5
0.6
0.7
0.8
0 20 40 60
Flame	radiation	fraction
flame	height	(mm)	
0
0.1
0.2
0.3
0.4
0.5
0.6
0.7
0.8
0 1 2 3 4 5
Flame	radiation	fraction
Fuel	mixture	mass	flux	(g/m2s)
SE FT Xf XO2
p 
(bar)
N/A 1 0.34 0.56
1 0.265 0.7
N/A 1 0.21 1
N/A 0.5 0.4 1
N/A 0.5 0.34 0.56
0.5 0.265 0.7
N/A 0.5 0.21 1
∆ℎ! = $" 47.2 kJ/g
~~~~

### Pagina 47

Cita: [pdf_2ada277f4accf3ff7dca, p. 47]. Metodo: native.

~~~~text
44
Figure 3.9. Flame height vs. mass flux.
0
5
10
15
20
25
30
35
40
45
0 1 2 3 4 5 6 7
Flame	height	(mm)
Fuel	mixture	mass	flux	(g/m2s)
FT Xf XO2
p 
(bar)
1 0.4 1
1 0.34 1
1 0.34 0.56
1 0.265 0.7
0.5 0.4 1
0.5 0.34 0.56
0.5 0.265 0.7
∆ℎ! = $" 47.2 kJ/g
~~~~

### Pagina 48

Cita: [pdf_2ada277f4accf3ff7dca, p. 48]. Metodo: native.

~~~~text
45
Figure 3.10. flame base radius vs. mass flux.
0
5
10
15
20
25
0 1 2 3 4 5 6 7
Flame	base	radius	(mm)
Fuel	mixture	mass	flux	(g/m2s)
FT Xf XO2
p 
(bar)
1 0.4 1
1 0.34 1
1 0.34 0.56
1 0.265 0.7
0.5 0.4 1
0.5 0.34 0.56
0.5 0.265 0.7
∆ℎ! = $" 47.2 kJ/g
Figure 3.11. Flame height vs. flame base radius
0
5
10
15
20
25
0 20 40 60
Flame	base	radius	(mm)
Flame	length	(mm)
FT Xf XO2
p 
(bar)
1 0.4 1
1 0.34 1
1 0.34 0.56
1 0.265 0.7
0.5 0.4 1
0.5 0.34 0.56
0.5 0.265 0.7
∆ℎ! = $" 47.2 kJ/g
~~~~

### Pagina 49

Cita: [pdf_2ada277f4accf3ff7dca, p. 49]. Metodo: native.

~~~~text
46
3.4 Discussion of Results
In the previous section the results have been presented and their trends have been discussed.
The measurements have been used to compute the local and average net heat fluxes to the burner 
and derive the flame radiant fractions. The primary objective of this study is to determine if, and 
under what conditions, steady flames can occur in microgravity. We believe this is the first-time 
steady burning has been observed for a flat surface of 25 mm diameter in a quiescent atmosphere. 
Previously a tiny cylindrical candlewick has been observed to burn steadily [34,35]. The 
significance here for the burner is that steady burning can be related to condensed fuel properties 
through the theory of steady burning. Our hypothesis in this work has been to demonstrate that 
four fuel properties control steady condensed phase burning. This has been demonstrated in 1-g 
experiments by showing that burning rate, flame shape and color could be matched between real 
condensed phase fuels and a burner as discussed herein [46,55,56]. The four fuel properties 
required for matching in the 1-g experiments are heat of combustion, heat of gasification (L), fuel 
surface temperature and smoke point respectively.
The burner steady endpoint surface temperatures ranged from 40 to 120 0
C. These 
temperatures are relatively low for solid-phase fuels such as non-charring plastics that would apply 
directly here but, in the theory of steady burning the surface temperature is a relatively weak 
property compared to 1 and 2 above. In addition, the smoke point is likely irrelevant in 
microgravity, as it controls the radiation due to soot and that is not present in the microgravity 
flames seen. Consequently, the heat of combustion and the heat of gasification associated with the 
steady burner flames should represent the key solid fuel properties that can govern steadily burning 
in microgravity at 25 mm diameter. This has important safety implications.
The heat of combustion in these experiments varies from 23.6 kJ/g for Xf = 0.5 and 47.2 
kJ/g for Xf = 1 based on ethylene. This is a range representative of many plastics. The question 
now is to evaluate the heat of gasification. Ideally the calorimeter net heat flux is the way to 
compute the heat of gasification, L. The theory of steady burning gives
~~~~

### Pagina 50

Cita: [pdf_2ada277f4accf3ff7dca, p. 50]. Metodo: native.

~~~~text
47
𝐿 = 𝑞̇
$$
!-4M5!0?-4 + 𝑞̇
$$
7,, − 𝑞̇
$$
,,
𝑚̇
$$ (3.14)
where the quantities shown in Eq. (3.14) are the average values of convective heat flux, flame 
radiative heat flux back to the surface and surface re-radiation over the burner, respectively. Not 
having a clean calorimeter average value due to edge heating, we resort to two ways to estimate 
the average net heat flux to the burner: first, calorimeter corrected value and second, arithmetic 
average of the two local net heat fluxes.
The results are shown in Figures 3.12 and 3.13. Both plots indicate a decreasing, somewhat 
inverse asymptotic-like curve, for heat of gasification with mass flux. It is surprising that the data 
cluster about a nearly singular trend. Also, both plots show the heat of gasification is up to 20 % 
higher for the lower heat of combustion 23.6 kJ/g. The results of Auth [55,56] who used the BRE 
in 1-g are added to Figures 3.12 and 3.13. The 1-g results for propane-nitrogen mixtures have the 
opposite behavior with heats of gasification decreasing with heat of combustion for the same mass 
flux. This could be due to the significance of soot radiation in the 1-g flames. But again, the data 
mostly cluster about one trend except for very low heat of combustion. The 1-g corresponding heat 
of combustion data shift far to the right and down from the microgravity data of Figures 3.12 and 
3.13. For example, the 1-g data would indicate (𝐿, 𝑚̇”) points of about 2 kJ/g, 30 g/m2
s, and 0.5 
and 10. Moreover our previous work in a 5- s drop facility suggested similar data trends but with 
an apparent vertical asymptote at about 3 g/m2
s, rather than 1 as shown here. Obviously, the current 
data at durations of minutes over 5- s are more accurate. Moreover, it has been shown that the ISS 
heat flux data even at self-extinction are theoretically nearly steady. Figures 3.12 and 3.13 include 
the heats of gasification derived from the self-extinguished endpoint data as well. Remarkably, the 
self-extinguished not data follow the same trend as the steady data.
Let us interpret Figures 3.12 and 3.13 in terms of the flammability of real materials in 
microgravity. Typical melting plastics have heats of gasification ranging from about 2 to 3 kJ/g, 
with effective heats of gasification for charring plastics above 4 kJ/g. Some selected literature
~~~~

### Pagina 51

Cita: [pdf_2ada277f4accf3ff7dca, p. 51]. Metodo: native.

Calidad: table_structure_not_manually_validated.

~~~~text
48
values for materials with heats of combustion in the BRE range are listed in Table 3.1 [67,74]. 
Figures 3.12 and 3.13. would suggest that polyethylene (PE) and polypropylene (PP) would burn 
in microgravity at about 3 g/m2
s. Nylon and PMMA would burn at about 2.5 g/m2
s, and the 
phenolic glass fiber composite would burn at about 1 g/m2
s. These are very low values and if they 
occurred in 1-g they would be near the critical conditions for burning [75,76]. Indeed, Auth [55,56]
finds that at 25 mm diameter, PMMA burns steadily at 19 g/m2
s, and PE and PP both burn at about 
6 g/m2
s. It is doubtful that the phenolic-glass composite could burn without extra external heating 
in 1-g. Yet, Figures 3.12 and 3.13 suggest it could burn in microgravity. The implication is that 
materials can burn more easily in microgravity than in normal gravity but with much lower burning 
rates.
Fires on Earth in normal gravity become big, sustained fires because of heating from the 
fire’s surroundings. Fire on Earth is difficult generally to initiate in solids because of only 21 % 
oxygen in the atmosphere. In the current study it is seen that also in microgravity, this oxygen 
concentration did not favor ‘steady” burning. Can we expect fires to grow in microgravity so that 
as they heat their surroundings they can be reinforced as on the earth? The key to that answer is 
what controls the microgravity fire as it increases in size? Will flame radiation extinguish it? These 
questions need to be fully answered before fire safety in microgravity is understood.
One important fire safety consideration, based on the findings of this study, is that solid 
materials with heats of combustion in the range 23.6 to 47.2 kJ/g and heats of gasification from 
about 1 to 10 kJ/g can burn in microgravity. The NASA alternative flammability Test 2 using the 
Cone Calorimeter can measure these material properties [77,78]. As this study develops a more 
complete understanding, NASA may wish to put more emphasis into Test 2.
~~~~

### Pagina 52

Cita: [pdf_2ada277f4accf3ff7dca, p. 52]. Metodo: native.

Calidad: figures_not_digitized, table_structure_not_manually_validated.

~~~~text
49
Figure 3.12. heats of gasification calculated from corrected calorimeter vs. mass flux
y	=	82.9	x	-1.52
y	=	10.04x-1.34
R²	=	0.88
0.1
1
10
1 10
L (kJ/g)
ṁf"	(g/m2s)
Normal
Gravity
SE FT Xf XO2
p 
(bar)
N/A 1 0.4 1
N/A 1 0.34 1
1 0.34 0.56
1 0.265 0.7
N/A 1 0.21 1
0.5 0.4 1
0.5 0.34 0.56
0.5 0.265 0.7
N/A 0.5 0.21 1
∆ℎ! = $" 47.2 kJ/g
Table 3.2 . Materials close to BRE heats of combustion 
and corresponding heats of gasification
Material LHV, kJ/g L, kJ/g
PE 43.4 1.9
PP 44 2.0
Nylon 28.8 1.5, 2.4
PMMA 24.2 1.6, 2.3
Phenolic glass fibers 22.0 7.3
~~~~

### Pagina 53

Cita: [pdf_2ada277f4accf3ff7dca, p. 53]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
50
3.5 Chapter Summary
The primary conclusion from this study is that the BRE has indicated that steady burning can 
be achieved in microgravity for a flat surface of 25 mm diameter. Experiments have shown that 
burning could take place for more than 3 minutes with apparent steady blue hemispherical-like 
flames at atmospheres above 21 % oxygen. Theoretical analyses based on published work has 
corroborated that these long duration flames are nearly steady where it is shown that surface heat 
Figure 3.13. Heats of gasification calculated from the average of the two heat flux 
gauge measurements vs. fuel mixture mass flux
y	=	82.9	x	 y	=	6.81	x	-1.49 -1.52
R²	=	0.93
0.1
1
10
1 10
L (kJ/g)
ṁf"	(g/m2s)
Normal
Gravity
SE FT Xf XO2
p 
(bar)
N/A 1 0.4 1
N/A 1 0.34 1
1 0.34 0.56
1 0.265 0.7
N/A 1 0.21 1
0.5 0.4 1
0.5 0.34 0.56
0.5 0.265 0.7
N/A 0.5 0.21 1
∆ℎ! = $" 47.2 kJ/g
~~~~

### Pagina 54

Cita: [pdf_2ada277f4accf3ff7dca, p. 54]. Metodo: native.

~~~~text
51
flux tend to approach its steady value faster than flame size. Moreover, it is shown that lower fuel 
mole fractions (or heats of combustion) and higher ambient oxygen concentrations help flames 
burn for longer durations. Further analyses of the heat fluxes measured have allowed the estimation 
of the heat of gasification property associated with the steady tests. The findings suggest that solids 
of 25 mm diameter surfaces with heats of combustion from about 23.6 to 47.2 kJ/g, and heats of 
gasification of 1 to 10 kJ/g can steadily burn in microgravity. Many commercial materials have 
these properties. In microgravity, flames with lower heats of combustion, were closer to the burner 
surface which resulted in higher surface heat flux and larger heats of gasification accordingly 
which was a trend not seen in our 1-g experiments. 
Flame radiation fractions are obtained by radiative heat fluxes measured at endpoints for steady 
and at the peak of oscillating flames prior to self-extinction for self-extinguished flames. It is 
observed that all steady flames radiation fractions remained below 0.6. In addition, it has been 
found that the flame radiation fraction for the steady flames correlates well with the flame height. 
Future work will develop this relationship further to include other parameters and utilize it with 
previously published theoretical models to predict the steady outcome in general. Hopefully, that 
analysis will give a more complete answer to the potential for fire growth in microgravity.
~~~~

### Pagina 55

Cita: [pdf_2ada277f4accf3ff7dca, p. 55]. Metodo: native.

~~~~text
52
4. Analytical Transient Solution for Constant Mass Flux
Burning experiments are analyzed for 29 steady burning flames using a gas burner (BRE) 
to emulate condensed phase burning of 25 mm diameter flat surface. Mixtures of ethylene and 
nitrogen allow for 23.6 and 47.2 kJ/g heats of combustion (LHV). Ambient conditions range from 
21 to 40 % oxygen and pressures of 0.56 to 1 bar. The results are compared to predictions from 
analytic models developed to determine the flame radiation fraction, flame convective and 
radiative heat fluxes, flame shape, and heats of gasification for steady burning. Steady burning is 
theoretically decided by ensuring the flame temperature is above a critical value of 1100 K. Good 
agreement is achieved between experiment and predicted steady results. Further computations are 
made to determine the effect of ambient pressure and oxygen on burning for heats of combustion 
of 23.6 and 47.2 kJ/g, diameters up to 100 mm, and vaporization temperatures of 80 and 350 ºC. 
It is found that for the range of analyzed conditions, heats of gasification of about 1 to 5 kJ/g, 
steady burning would result over a range of about 1 to 6 g/m2s. Low pressure appears to yield 
more stable flames. The results have implications on how the fire safety of materials in 
microgravity should be determined.
The complete solution for the unsteady purely diffusive burning of an oblate ellipsoidal 
surface with a uniform surface mass flux in time is given by Markan et al[49]. The results are 
summarized here because the formulas will be used throughout the paper as modified to include 
the heat of combustion reduced by a flame radiation loss fraction, Xr, the ratio of radiant energy 
lost by the flame to its combustion energy. The use of representing flame radiation effect by 
reducing the heat of combustion essentially assumes “a transparent flame” according to Jiang et al 
[79]. The original solution is based on thin flame theory with Schwab-Zeldovich variables giving 
the mixture fraction as given in Eq. (4.1)
𝑍 = 𝑐;(𝑇 − 𝑇*) + ∆ℎ! (𝑌9 − 𝑌9,*)/𝑆
𝑐;(𝑇' − 𝑇*) − ∆ℎ! 𝑌9,*/𝑆 (4.1)
The temperature 𝑇 and oxygen mass fraction 𝑌9 are combined into this mixture fraction 
variable, where 𝑌9,* is the ambient oxygen mass fraction, ∆ℎ! is the heat of combustion per mass 
of the prescribed fuel-diluent stream, 𝑐; is the specific heat of the gas and 𝑆 is the stoichiometric 
ratio which denotes the mass of oxygen consumed per unit mass of fuel-diluent stream. It is
~~~~

### Pagina 56

Cita: [pdf_2ada277f4accf3ff7dca, p. 56]. Metodo: native.

~~~~text
53
assumed that the Lewis number Le ≡ 𝑘/𝜌𝑐; 𝒟 = 1. Also, the diffusivity, 𝒟, is equal and replaced 
by the thermal diffusivity, . Properties are constant, but the numerical choice of properties 
will be based on a temperature judgment, as convective heat flux will depend on properties near 
the surface, and flame shape will depend on properties near the flame. In the original work, a 
convective Peclet number (Pec) is defined in terms of the total mass flow rate ( ) over the entire 
ellipsoidal surface (top and bottom) which is given by Eq. (4.2) and (4.3). 
𝑃𝑒! = 𝑀̇
4𝜋𝑐𝜌𝒟 (4.2)
𝑃𝑒! = 𝑀̇
4𝜋𝑅𝜌𝒟 = 2𝑚̇
$$𝜋𝑅:
4𝜋𝑅𝑘/𝑐;
= 𝑚̇
$$𝑐;𝑅
2𝑘 (4.3)
In the current paper we replace the Peclet number by the dimensionless mass flux (𝜆) from one 
side of flattened ellipsoid to define the burner surface (see Eq. (4.4)).
𝜆 = 𝑚̇
$$
é 4𝑘
𝜋𝑐;𝑅è
(4.4)
Here is a prescribed constant, however, in the steady state burning theory, the corresponding 
burning eigenvalue is equivalently found in terms of the solid fuel properties and B number as 
given by Eq. (4.5)
𝜆 = ln(1 + 𝐵) (4.5)
where Eq. (4.6)
𝐵 ≝ (𝑌9,* (1 − 𝑋,)∆ℎ!/𝑆 − 𝑐;(𝑇' − 𝑇*)
𝐿>
(4.6)
is the effective B number and Eq. (4.7)
𝐿> ≝ 𝐿 − 𝑞̇
7,,
$$ + 𝑞̇
5
$$ − 𝑞̇
,,
$$
𝑚̇
$$ (4.7)
is the effective heat of gasification. In typical solutions for steady burning problems, the results 
are given in terms of the fuel properties: heat of combustion, heat of gasification, vaporization 
temperature; and in term of ambient conditions: oxygen, pressure and temperature. Here, for the 
burner, the solution is given in terms of l over L. This is a subtle, but distinct difference. In 
steady state, the substitution of Eq. (5) makes the two forms identical. But in the BRE experiments 
k / ρc
p
M!
λ
~~~~

### Pagina 57

Cita: [pdf_2ada277f4accf3ff7dca, p. 57]. Metodo: native.

~~~~text
54
we do not know L appriori. In BRE and in steady burning of an evaporating liquid or solid, the 
heat of gasification, L, (a material property) is found by Eq. (4.8)
𝐿 = 𝑞̇
450
$$
𝑚̇
$$ (4.8)
where 𝑞̇
450
$$ is measured; it is generally composed of
𝑞̇
450
$$ = 𝑞̇
7,!
$$ + 𝑞̇
7,,
$$ − 𝑞̇
,,
$$ + 𝑞̇
5@0,, $$ (4.9)
Where each component is defined as:
𝑞̇
7,!
$$ : Flame convective heat flux
𝑞̇
7,,
$$ ∶ Flame incident radiative heat flux
𝑞̇
,,
$$ ∶ Surface radiative loss heat flux
𝑞̇
5@0,, $$ ∶ Incident external radiative heat flux
The external radiative heat flux is not present in the experiments but could be included in 
the theory to follow. It is well known that external radiation in room fires on Earth plays an 
important and perhaps essential role in the fire development. In the theoretical development herein, 
the net heat flux will be decomposed into two predictive components: one for radiation and one 
for convection or pure diffusion. 
4.1 Flame position
The solution for the transient mixture fraction is given as in Eq. (4.10)
𝑍 = h
1 − exp ï
2𝜆
𝜋
arctan(𝜉) − 𝜆ñ
1 − exp[−𝜆] u erfc é 𝜉
2√𝜏
è (4.10)
with 𝜏 being the dimensionless time B𝜏 = N20
D! F and 𝐷*, the mass diffusivity of ambient air 
é𝐷* = <
O!1
è. In terms of the ellipsoidal coordinate, 𝜉 that can be expressed in cylindrical 
coordinates (x, r) as
~~~~

### Pagina 58

Cita: [pdf_2ada277f4accf3ff7dca, p. 58]. Metodo: native.

Calidad: table_structure_not_manually_validated.

~~~~text
55
𝜉 = 1
√2𝑅
ï𝑥: + 𝑟: − 𝑅: + Ñ(𝑥: + 𝑟: − 𝑅:): + (2𝑥𝑅):ñ
C
: (4.11)
It can be shown that at r = 0, 𝜉(𝑥, 0) = @
D
.
The fuel and oxygen are separated by the infinitesimally thin flame sheet that is located where 
oxygen and fuel become zero by equating the mixture fraction to its stoichiometric value which is 
shown by Eq. (4.12)
𝑍 = 𝑍7 = 𝑌9,*
𝑆𝑌P/ + 𝑌9,*
(4.12)
With fuel mass fraction at surface given by Eq. (4.13)
𝑌P/ = 1 − (1 + 𝛼)
𝛼
𝑒BQ (4.13)
where 𝛼 = 𝑆/𝑌9,* .
By setting the mixture fraction equal to its value at the flame, the flame position is given for a 
given value of 𝜉 in time.
It is important to observe that the solution for the flame position is primarily controlled by 
diffusion, 𝜌𝐷 = 𝑘/𝑐;, and stoichiometry, S. This follows as ∆ℎ!/𝑆 = ∆ℎ9 , the heat of combustion 
per unit mass of oxygen consumed, is generally almost constant, and taken in this analysis for the 
experimental fuel, ethylene as 13.76 kJ/g. The flame position has no dependence on flame radiation 
because it is governed solely by diffusive effects. This will prove extremely advantageous as it 
was found that the measured flame radiative fraction is a strong function of the flame height for 
steady burning [51]. Explicitly the complete transient flame position, in terms of the mixture 
fraction on the flame sheet, can be computed from Eq. (4.14)
𝑍7 = 𝑌9,*
𝑆𝑌P/ + 𝑌9,*
= h
1 − exp ï
2𝜆
𝜋
arctanq𝜉7s − 𝜆ñ
1 − exp[−𝜆] u erfc y 𝜉7
2√𝜏
| (4.14)
Let us complete listing of the theoretical steady solutions for flame temperature and convective 
heat flux. These now depend on the flame radiative fraction.
~~~~

### Pagina 59

Cita: [pdf_2ada277f4accf3ff7dca, p. 59]. Metodo: native.

Calidad: table_structure_not_manually_validated.

~~~~text
56
4.2 Flame Temperature
The theoretical flame temperature can be calculated by Eq. (4.15) with Tf representing the 
flame temperature
𝑐;q𝑇7 − 𝑇*s = é 1
𝛼𝑌P/ + 1
è ò𝑐;(𝑇' − 𝑇*) + 𝑌P/(1 − 𝑋,)∆ℎ!ô (4.15)
Based on Eq. (13), note the flame temperature dependence on 𝜆.
4.3 Convective heat flux 
The average steady convective heat flux is given as shown by Eq. (4.16)
𝑞̇
! ööö$$ö = y 4𝑘
𝜋𝑅𝑐;
| õ λ
𝑒Q −1
ùP
∆ℎ!(1 − 𝑋,)𝑌9,*
𝑆 − 𝑐;(𝑇' − 𝑇*)R (4.16)
The average convective heat flux is one term needed to derive L in Eq. (4.8). But to 
illustrate the nature of the transient effect on the convective heat flux, the transient local value is 
given by Eq. (17)
𝑞̇
!
$$(𝑟,𝑡) =
B
𝑘
𝑅F >(𝑇' − 𝑇*) − ∆ℎ!(1 − 𝑋, )𝑌9,*
𝑆𝑐;
L> 1
√𝜋𝜏
+ B
2𝜆
𝜋 F õ exp[−𝜆]
1 − exp[−𝜆]
ùL
û1 − B
𝑟
𝑅F
:
(4.17)
In Reference [49] it was shown that the transient toward steady conditions is relatively fast 
for the heat flux, but slower for the flame growth. In the following, these solutions will be 
examined against the steady data of reference [51]. To complete the solution for all quantities 
except flame position, a means is necessary to allow the prediction of the flame radiative fraction. 
This will be empirically developed shortly in section 4.
4.4 Steady flame position: experiments compared to theory
The flame height along the axis normal to the burner at r = 0 is given by Eq. (4.18)
𝑥7
𝑅 = tan h
𝜋
2 ü1 +
ln B 𝛼
𝛼 + 1F
𝜆 †u (4.18)
~~~~

### Pagina 60

Cita: [pdf_2ada277f4accf3ff7dca, p. 60]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
57
For a given mass flux, value of 𝜌𝐷 = 𝑘/𝑐; taken at nitrogen properties of 1400 K, and 
stoichiometry, S found from 𝑆 = ∆ℎ!/∆ℎ9, the steady axis flame height can be calculated. For the 
experimental conditions the steady values are compared to those measured.
Figure 4.1 shows a direct comparison between the measured steady and predicted flame 
heights. The properties were evaluated at 1400 K for nitrogen based on optimizing the results. As 
the choice of properties in a constant property solution requires judgment, we justify this choice 
since the flame position is in a domain of the flame temperature and select this high value with 
some justification. It can be seen from the figure, that for a wide range of mass flux, oxygen and 
pressure conditions, the results show good accuracy for the predictions. It should be emphasized 
that the prediction holds for fuels with heats of combustion of 23.6 and 47.2 kJ/g. The effect of 
oxygen is also accounted for over a range of mole fractions of 0.265 to 0.40, realizing that at 0.21 
the flames tended to extinguishment before any steady state could be reached.
Limited theoretical results have been examined to show that the theoretical oblate 
ellipsoidal flame shape is not completely satisfied in the experiments. As experimental images 
Figure 4.1. Measured vs. calculated flame height
~~~~

### Pagina 61

Cita: [pdf_2ada277f4accf3ff7dca, p. 61]. Metodo: native.

~~~~text
58
show the flames growing to ellipsoidal and even spherical shapes away from the base, but the 
measured flame radius at the burner surface (x = 0) is over-predicted [49]. So, the ellipsoidal shape 
is not satisfied near the base. The formula for the base flame radius is given by Eq. (4.19)
𝑟7
𝑅 = °1 + B
𝑥7
𝑅 F
:
(4.19)
The similarity of the dimensionless base radius with the flame height is shown for the data. The 
prediction can be assessed in Figure 4.2. The theory clearly under-predicts, but the similarity is 
evident. A modification of the formula in Eq. (4.20) gives an improved result and clearly shows 
the similarity. The value of the constant c is 0.35.
𝑟7
𝑅 = °1 + 𝑐 B
𝑥7
𝑅 F
:
(4.20)
It may depart from the theoretical ellipsoidal solution as for that case the problem is 
symmetric about the long axis while for the burner this is not the case, and only one side applies.
~~~~

### Pagina 62

Cita: [pdf_2ada277f4accf3ff7dca, p. 62]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
59
4.5 Prediction of flame radiation fraction
It was observed in the analysis of the data that the measured flame radiant fraction of the 
steady flames was a primary function of the flame height [51]. This prompted us to examine herein 
a theoretical basis for the radiant fraction cast in dimensionless terms. It will be shown that this 
exploration leads to a much more general correlation for the flame radiant fraction in terms of 
more variables than just flame height. Providing a prediction of Xr will then allow us to 
theoretically compute flame temperature at steady state, flame convective heat flux and model 
flame radiative heat flux from the initial information. This is how we will develop an approximant 
complete steady solution.
4.6 Radiant fraction model formulation
The radiation lost by the flame, with no visible soot, can be attributed to the products of 
combustion and their distributed temperature within a volume around the flame. The combustion
products radiative heat flux is distributed through a surface area enclosing this volume. The rate 
of radiation lost by the flame can be represented in terms of a temperature, the gas emissivity, and 
Figure 4.2. measured vs. predicted flame base radius, c =1 (Left) and c = 0.35 (Right)
~~~~

### Pagina 63

Cita: [pdf_2ada277f4accf3ff7dca, p. 63]. Metodo: native.

~~~~text
60
its enveloping area. A dimensionless formulation is made based on homogeneous grey gas 
radiation for a representative path height. The flame radiative fraction is defined as the ratio of the 
rate of radiant energy lost from the flame with the rate of energy released by combustion (see Eq. 
(4.21)). 
𝑋, = 𝑄̇
,
𝑄̇
!
(4.21)
The combustion energy rate is straightforward and represented in terms of the mass flux and heat 
of combustion as shown by Eq. (4.22):
𝑄̇
! = 𝑚̇
$$𝜋𝑅: Δℎ! (4.22)
The rate of heat by radiation given off from the flame can be roughly written as Eq. (4.23) [80–
82]
𝑄̇
,» 𝜀7𝜎𝑇7
)𝐴7 (4.23)
where 𝜀7 is emissivity of the radiating gas, Tf is a representative flame temperature, Af is the flame 
enclosing surface area. The emissivity is given in terms of the absorption coefficient computed 
from the gas partial pressures and temperature. It is clear Eq. (4.23) is approximate but should be 
considered as representing the maximum temperature and gas concentrations over the scale of the 
region around the flame, to be taken as the flame length. An integrated form of Eq. (4.23) will 
have these terms with some distribution and stretching of geometry. With a hope of similarities in 
distributions, the final results might be considered general for the fuel used here. An examination 
of this theoretical framework will be assessed when empirically related to the current experimental 
measurements for Xr.
The following scale approximations are made, anticipating the derivation of an empirical 
dimensionless formula to be derived from data. The path length is taken as the flame height, and 
the flame area is taken as its square:
𝑙 = 𝑥7, the flame height, and Eq. (4.24) is used to estimated flame surface area.
𝐴7» 𝑥7
: (4.24)
Let these terms be selected to best represent the problem with the intention to identify the 
controlling dimensionless groups for Xr.
~~~~

### Pagina 64

Cita: [pdf_2ada277f4accf3ff7dca, p. 64]. Metodo: native.

~~~~text
61
Consider our ethylene flames at various fuel mole fractions, Xf , in a nitrogen mixture; 
various ambient oxygen mole fractions, XO, and atmospheric pressure, p. Stoichiometry for 
complete combustion is justified, as no soot is observed and the chemical reaction is shown by 
Eq. (4.25):
é𝐶:𝐻) + RCBS3!45T
S3!45
𝑁:è + 3 B𝑂: + CBS6
S6
𝑁:F → 2𝐶𝑂: + 2𝐻:𝑂 + é3 CBS6
S6
+ RCBS3!45T
S3!45
è 𝑁: (4.25)
The partial pressure for water vapor and carbon dioxide, are to be equal, and given as shown by 
Eq. (4.26).
𝑝6!9 = 𝑝%6! =
⎩
⎨
⎧ 2
2 + 2 + 3 é
1 − 𝜒9!
𝑋9!
è +
1 − 𝑋%!65
𝑋%!65 ⎭
⎬
⎫
𝑝 (4.26)
In general, the partial pressures of the radiating species considered, water vapor and carbon 
dioxide, can be expressed in terms of total pressure, the mole fractions of pure fuel in the supply 
mixture, and the oxygen in the ambient. Here we just consider ethylene as that was the fuel used 
in the BRE experiments. Therefore, in the following there is an implicit fuel effect implied. 
Moreover, the fuel itself can be a radiation participant and that fuel effect is assumed to be 
contained in any correlation with the BRE ethylene data here.
The radiation from the flame will be represented here in terms of the stoichiometry values 
of the water vapor and carbon dioxide associated with a path length. The pathlength is taken as the 
flame height, xf. These might be considered extremes but should be representative scales given 
similarity for these particular flames by theory.
The emissivity of the flame gases is then represented as given by Eq. (4.27)
𝜀7 = 1 − 𝑒BU7@7 (4.27)
The total combustion energy release rate is written as shown by Eq. (4.28)
𝑄̇
! = 𝑚̇
$$𝜋𝑅: Δℎ! (4.28)
Then the radiation fraction becomes (see Eq. (4.29))
𝑋, »
𝜎𝑇7
)(1 − 𝑒U7@7)𝑥7
:
𝑚̇
$$𝜋𝑅: Δℎ!
(4.29)
where the temperature can be evaluated from the theory as given in Eq. (4.15) or
~~~~

### Pagina 65

Cita: [pdf_2ada277f4accf3ff7dca, p. 65]. Metodo: native.

Calidad: table_structure_not_manually_validated.

~~~~text
62
𝑇7
𝑇*
= 1 +
>B 𝑇'
𝑇*
− 1F + 𝑌P,/ é ∆ℎ!
𝑐;𝑇*
è (1 − 𝑋,)L
(𝛼𝑌P/ + 1) (4.30)
and is a function of Xr.
Arranging as dimensionless quantities to represent Xr gives an implicit relationship (g is an 
unknown function) for Xr, as the flame temperature depends on it (see Eq. (4.31)).
𝑋, = 𝑔 P
1
𝜋 y 𝜎𝑇*
)
𝑚̇
$$ Δℎ!
| (1 − 𝑒U7@7) B
𝑥7
𝑅 F
:
é
𝑇7
𝑇*
è
)
R (4.31)
We could make the substitution for the flame temperature and obtain an implicit theoretical 
solution for Xr. This would be tedious and may not be accurate in the end. As an alternative, let us 
make the RHS of Eq. (30) as a known quantity by defining a known characteristic temperature, 
Tf,o , with no radiation loss as given by Eq. (4.32)
𝑇7,-
𝑇*
= 1 +
>B 𝑇'
𝑇*
− 1F + 𝑌P,/ é ∆ℎ!
𝑐;𝑇*
èL
q𝛼𝑌P,/ + 1s (4.32)
Now a dimensionless flame radiation parameter Ω in terms of known quantities that also are 
dimensionless is found from Eq. (4.33). In other words, Xr is a function of Ω, 𝑋, = 𝑓(Ω) with
Ω = y 𝜎𝑇*
)
𝑚̇
$$ Δℎ!
| (1 − 𝑒BU7@7) B
𝑥7
𝑅 F
:
é
𝑇7,-
𝑇*
è
)
(4.33)
The emissivity or absorption coefficient now needs to be determined as all other terms are 
known or can be computed, i.e., Eq. (4.18).
4.6.1 Model for emissivity and absorption coefficient
A common way to evaluate emissivity for CO2 and H2O gases is to use Hottel’s charts 
[82,83]. In doing so, one must select a path length for a given partial pressure and temperature. 
The absorption coefficient can then be found from Eq. (4.27). It is pointed out by deRis [84] that 
for flames without soot, the absorption coefficient will depend on path length, approaching the 
Planck value in the small limit. The Planck absorption coefficient for CO2 is about 10 (m-bar)-1
and 2 (m-bar)-1 for H2O at 1400 K [74,83]. Note the absorption coefficient of Eq. (4.27) can be
~~~~

### Pagina 66

Cita: [pdf_2ada277f4accf3ff7dca, p. 66]. Metodo: native.

~~~~text
63
determined from the Planck value by multiplying it by the partial pressure of the gas. Ultimately, 
we would like to have a relationship for the absorption coefficient in terms of the partial pressures 
of CO2 and H2O 
Following encouraging estimations from the Hottel charts, we sought a more easily used 
computational method and used RADCAL [58,59] to calculate the gas mixture emissivity. 
RADCAL is a narrow-band model often used to estimate emissivity and absorption coefficient for 
these gases. The absorption coefficient of RADCAL is found by calculating the received intensity 
at a point located at a distance 𝑙 by taking into account the emission from the participating gas at 
temperature 𝑇+ with the surroundings at a fixed blackbody temperature of 300 K. The total 
emissivity calculated by RADCAL yields an also effective absorption coefficient defined in the 
same way as Eq. (4.27) for a given path length, l.
RADCAL was run for partial pressures of water vapor and carbon dioxide from Eq. (4.26), 
ambient temperature (300 K), radiating gas temperature selected at 1400 K, no soot, and path 
length, l. Operating with the RADCAL code for the set of fuel and ambient pressure and oxygen 
conditions as our ISS experimental data, a general relationship is found for the absorption 
coefficient. Specifically, this was put in terms of 𝜅̃as a function principally of path length. Here a 
modified absorption coefficient, 𝜅̃is defined as
𝜅̃≝
𝜅
𝑝%9: + 𝑝6:9
(4.34)
This parameter is similar in form but not identical to the Planck mean absorption coefficient 
and is motivated because the absorption coefficient tends to be dependent on the gas partial 
pressure. Figure 4.3 shows that for the steady data set with 9 conditions examined in this way by 
using RADCAL. As indicated by deRis [84], a singular relationship results for the modified 
absorption coefficient as a function of path length. The optically thin mean Planck value for CO2
is about 10 (m-bar)-1 and 2 (m-bar)-1 for H2O at 1400 K, respectively [83]. It can be observed that 
these numbers compare in order of magnitude to the 8.5 (m-bar)-1 for a path length of 10-6 m in 
Figure 4.3. The result of this singular graph is empirical and only holds for the BRE data examined 
here for ethylene, but it can be computed for other fuels, and we have shown singular curves hold,
~~~~

### Pagina 67

Cita: [pdf_2ada277f4accf3ff7dca, p. 67]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
64
𝜅̃(𝑙). It should be mentioned that multiple data points overlap in the figure, and do not obviously 
reveal the results of the collapsed data curve.
From Figure 4.3 we now have an empirical and convenient way to compute the needed 
emissivity term in Eq. (4.23). It should be pointed out that the path height used in this analysis was 
the flame height. It varies for the BRE data from about 5 to 50 mm, indicating a modified 
absorption coefficient of about 7.5 to 4.5 (m-bar)-1
, respectively. This corresponds to emissivity in 
the range of 0.01 to 0.1, as shown in Figure 4.4 for the steady BRE data. Also Figure 4.4 reveals 
all of the steady data used in Figure 4.3 but is not evident due to overlapping symbols. If the 
experimental data of Figure 4.3 are used to compute the emissivity from the correlation of Figure 
4.3, then those data are presented as shown in Figure 4.4. For high oxygen and pressures the flames 
Figure 4.3. Absorption coefficients normalized by partial pressures of combustion 
products of ethylene
~~~~

### Pagina 68

Cita: [pdf_2ada277f4accf3ff7dca, p. 68]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
65
can survive with emissivities as high as 0.09 and flame heights of 40 mm, but for lower oxygen 
and pressures the emissivities are lower: 0.01 to 0.04.
The absorption coefficient can be computed from the fitted Eqns. (4.35 and 4.36)
¶
𝜅̃(mBCbarBC) = 7.96𝑒BV.W3@7 𝑓𝑜𝑟 𝑥7 ≤ 0.1 m
𝜅̃(mBCbarBC) = 0.94𝑥7
B1.3) 𝑓𝑜𝑟 𝑥7 > 0.1 m
(4.35)
𝜅(𝑚BC) =
⎩
⎨
⎧ 4
2 + 2 + 3 B
1 − 𝑋9
𝑋9 F +
1 − 𝑋%!65
𝑋%!65 ⎭
⎬
⎫
𝑝(𝑏𝑎𝑟). 𝜅̃(𝑚BC𝑏𝑎𝑟BC) (4.36)
Figure 4.4. BRE flames emissivity vs. fuel mixture mass flux
~~~~

### Pagina 69

Cita: [pdf_2ada277f4accf3ff7dca, p. 69]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
66
4.7 Correlation result
All the terms in Eq. (33) for Ω can now be computed as known quantities. The accuracy of 
the correlation is now explicitly demonstrated in the plot for steady experimental data as shown in 
Figure 4.5 where the flame radiation fraction is shown to approximate a singular function of Ω. A 
best-fit equation for the steady data is given as 
𝑋, = 0.0633 ln(Ω) + 0.452 (4.37)
This result together with Figure 4.3, now allow a full prediction of the microgravity steady 
burning. Let us examine this process and its accuracy.
The steady theory [49], Eq. (4.18), allows the computation of flame height for a given burner 
radius in terms of k/cp, S and oxygen mass fraction of the atmosphere. This is done for properties 
of nitrogen at 1400 K. Figure 4.3 and Eq. (4.37) allow the computation of the flame radiation 
fraction for steady flames. Figure 4.6 shows the prediction of the flame radiation fraction with the 
experimental measurements. The prediction is within 10 % of the experiment.
Figure 4.5. Radiant fraction correlation
~~~~

### Pagina 70

Cita: [pdf_2ada277f4accf3ff7dca, p. 70]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
67
Now additional quantities can be computed; namely, the flame temperature Eq. (4.15) and 
the convective flame heat flux Eqns. (4.16, 4.17). An estimation of the flame radiative heat flux is 
also needed to complete the theoretical determination of the heats of gasification that correspond 
to steady microgravity burning.
4.8 Flame temperature as a measure of extinction
Given now the flame radiative fraction, the flame temperature can be computed from Eq. 
(4.15). This is key to determining if the flame can survive. The extinction of a diffusion flame is 
commonly governed by the Damkohler number, as the ratio of the time for diffusion divided by 
the time for the chemical reaction. More completely it is controlled by the energy release of the 
chemical reaction and the heat loss from the system by both diffusion and radiation. In all cases 
the flame temperature is most critical as it governs all of these processes. The flame temperature 
can be computed from Eq. (4.15). It is well known that the flame cannot survive below a critical 
temperature [67,75,76,85–91]. This has been examined in References [75,76] using the same type 
Figure 4.6. Calculated vs. measured radiant fraction
~~~~

### Pagina 71

Cita: [pdf_2ada277f4accf3ff7dca, p. 71]. Metodo: native.

~~~~text
68
of burner in normal gravity for a variety of gaseous fuels relying on flame temperature to predict 
extinction. The flame temperature becomes a surrogate for the Damkohler number, and in this case 
addresses both diffusive and radiative heat losses as described by Eq. (4.13). In normal gravity for 
buoyancy driven flames a critical temperature of 1600 K is accepted in the literature [67,75,76]. It 
is known that the critical flame temperature is a function of the local flame strain rate [85,90,91]
where 1600 K corresponds to about a strain rate of 10 s-1
, and 1100 K to a strain rate of 1 s-1
. The 
former is used for purely buoyant flames in 1-g, and the latter is commonly used in microgravity 
as an extinction criterion [85–91]. Figure 4.7 shows the computed values of flame temperature for 
the ISS steady data [51] where the radiation fraction is predicted for all of the steady data (Figure 
4.6). The data points with lower heats of combustion have higher flame temperature because the 
flames radiation fraction varies inversely with the heat of combustion. We will examine these 
trends more carefully later using the predictive model in a more appropriate display. For now, it is 
clear from Figure 4.7 that all the steady results theoretically correspond to flame temperatures 
above 1100 K. This is now a straightforward predictive tool to assess whether steady burning in 
microgravity can occur.
~~~~

### Pagina 72

Cita: [pdf_2ada277f4accf3ff7dca, p. 72]. Metodo: native.

Calidad: figures_not_digitized, table_structure_not_manually_validated.

~~~~text
69
4.9 Prediction of heat flux
Now that we can compute the flame radiation fraction from known quantities with respect 
to the fuel and atmosphere, the convective and radiative components of the flame hat flux can be 
estimated.
4.9.1 Convective heat flux
The convective heat flux follows from the purely diffusive solution, but with the radiation loss 
accounted for now by reducing the heat of combustion according to the fraction of energy 
remaining in the flame system. The equation is repeated here for continuity. 
𝑞̇
! ööö$$ö = y 4𝑘
𝜋𝑅𝑐;
| õ λ
𝑒Q −1
ùP
∆ℎ!(1 − 𝑋,)𝑌9,*
𝑆 − 𝑐;(𝑇' − 𝑇*)R (4.38)
Figure 4.7. Flame temperature as a measure of extinction based on calculated radiant fraction
~~~~

### Pagina 73

Cita: [pdf_2ada277f4accf3ff7dca, p. 73]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
70
It depends primarily on the properties k/cp, the radiant fraction, the mass flux, and the atmospheric 
oxygen concentration. It also depends on pressure through Xr. The properties here are evaluated 
for nitrogen at 350 K. Again, this choice is by optimization and judgment, and might be justified 
as the convective heat flux is due to the gradient of temperature at the relatively cold wall of the 
burner. Figure 4.8 shows this computed convective heat flux compared to the net flame heat flux
measured for the steady data set. The experimental data are the arithmetic average of two-point 
measurements on the burner surface as described for the experimental apparatus in ref [51]. The 
difference with the computed convection could be attributed to the flame’s radiative component. 
Most of the convective prediction is about 50 % lower than the total measured net heat flux. 
Figure 4.8. Calculated convective heat flux compared to the average net flame heat 
flux based on calculated radiant fraction
~~~~

### Pagina 74

Cita: [pdf_2ada277f4accf3ff7dca, p. 74]. Metodo: native.

~~~~text
71
4.9.2 Flame incident radiative heat flux
We now construct a model for the flame radiative heat flux consistent with the flame 
radiation fraction predictable to us. Half of the radiation leaving the gases engulfing the flame goes 
either towards or away from the burner surface. Although the radiation comes from a gas volume 
region around the flame, the exchange with the burner surface is assumed to act on view factor 
principles, as if the radiation comes only from the flame surface (optically thin flame sheet is 
assumed). Consider the thin flame sheet and estimate the flame sheet surface area and utilizing the
radiation view factor algebra with the reciprocity rule. Then one can obtain an estimation of the 
average radiative heat flux that impinges onto the burner surface. The view factor of the flame (f) 
with respect to the burner surface (s), 𝐹'→7 ,is close to unity because the flame mostly covers over 
the surface. In some cases, the flame stands off a distance 𝛿7 from the surface reducing this view 
factor slightly. The approximate view factor is estimated from Eq. (4.39).
𝐹'→7 = 1 − arctanq𝛿7/𝑟7 s
𝜋
(4.39)
We will consider 𝛿7 small and negligible. The view factor from the flame to the burner is now 
given by reciprocity rule (Eq. (4.40)):
𝐹7→' = 𝐹'→7 𝐴'
𝐴7
(4.40)
And the flame sheet surface area, Af, is estimated by assuming a half ellipsoid shape for the flame 
and that area is calculated by Eq. (4.41).
𝐴7 = ü
2𝜋 B𝑟7
X.: + 2q𝑟7𝑥7s
C.Y
F
3 †
C
C.Y
(4.41)
The flame incident radiative heat rate to the burner surface is now given as the view factor 
to the surface times ½ the energy radiated away from the flame. The corresponding heat flux over 
the circular burner surface of radius, R, is then found as shown by Eq. (4.42).
𝑞̇
7,, öö$$
ööö = 𝐹7→'𝑄̇
,/2
𝜋𝑅: = 𝐹7→'𝑋,𝑚̇
$$∆ℎ!
2 (4.42)
~~~~

### Pagina 75

Cita: [pdf_2ada277f4accf3ff7dca, p. 75]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
72
The results for the computed radiation heat flux are compared to the average of the measured heat 
flux by two heat flux sensors in Figure 4.9. The computed radiation flux to the burner surface is 
seen to be nearly equal to the measured total heat flux for low heat flux but as low as 1/3 for higher 
overall heat fluxes. Next, we can now see how the computed net heat flux compares to that 
measured.
Figure 4.9. Calculated flame radiative heat flux compared to the average net flame 
heat flux based on calculated radiant fraction
~~~~

### Pagina 76

Cita: [pdf_2ada277f4accf3ff7dca, p. 76]. Metodo: native.

~~~~text
73
4.9.3 Net heat flux to the burner
The net flame heat flux to the burner can be computed from Eq. (4.9) with the re-radiation 
component given as 
𝑞̇
,,
$$ = 𝜀'𝜎(𝑇'
) − 𝑇*
)) (4.43)
where 𝜀' = 1 [61] and 𝑞̇
,,
$$ varies from 0.14 to 1 kW/m2 for all of the experimental data based on 
the direct measurement of the surface temperature. The measured surfaces temperatures are 
generally below 100 ºC. 
The net heat flux depends primarily on flame height, mass flux and heat of combustion. 
There is a pressure effect through the flame emissivity. The results for the steady net heat flux data 
are shown in Figures 4.10 and 4.11 that are based on measured calorimeter net heat flux [48] and 
arithmetic average of the two local sensors on the burner surface [51], respectively. As one sees 
the calorimeter values are higher than the average of the two-point values [51]. We have high 
confidence in the point values, but recognize an arithmetic average is assumed. The calorimeter 
measure was supposed to capture the true integrated average of the heat transfer, but its operation 
was compromised, and a theoretical correction had to be imposed. Its confidence is lower than 
point sensor result. In Figure 4.11 the prediction is within about 20 % for most of the averaged 
point data. We think we have the essence of the flame radiative and convective components 
understood based on this result.
~~~~

### Pagina 77

Cita: [pdf_2ada277f4accf3ff7dca, p. 77]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
74
Figure 4.10. calculated average heat flux vs. measured average heat flux from 
calorimeter q𝑞̇
!-4M öö$$
ööööö + 𝑞̇
7,, ööö$$öö − 𝑞̇
,,
$$ s
~~~~

### Pagina 78

Cita: [pdf_2ada277f4accf3ff7dca, p. 78]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
75
4.10 Overall general predictive process and illustration
In this section the solution computations will be explored to show the effect of pressure, 
oxygen concentration, and heat of combustion. Values chosen are motivated by the experimental 
conditions. In summary, the following conditions are selected:
• Atmospheric pressure: 0.56 and 1 bar
• Atmospheric oxygen mole fraction: 021, 0.265 0.34 and 0.40, representing NASA 
considered atmospheres [65,92].
• Material heat of combustion: 23.6 and 47.2 kJ/g, representing a wide range of plastics.
Figure 4.11. calculated average heat flux vs. measured average heat flux from arithmetic 
average of the two heat flux sensors q𝑞̇
!-4M öö$$
ööööö + 𝑞̇
7,, ööö$$öö − 𝑞̇
,,
$$ s
~~~~

### Pagina 79

Cita: [pdf_2ada277f4accf3ff7dca, p. 79]. Metodo: native.

~~~~text
76
• Material vaporization temperature: 80 ºC (Later 350 ºC is considered.)
• Also, properties are chosen for nitrogen at 1400 K in computing flame size, k/cp = 65 g/s￾m: and 350 K in computing convective heat flux, k/cp = 21.5 g/s-m.
The computation process proceeds as follows:
1. The atmospheric conditions are specified for a given fuel-nitrogen mixture. This will fix 
the mass flux and heat of combustion.
2. The flame height is computed, Eq. (4.18), then the absorption coefficient, Eqns. (4.35, 
4.36), non-dimensional radiation term “Ω” from Eq. (4.33) and the flame radiation fraction, 
Eq. (4.37).
3. The flame temperature is then computed from Eq. (4.15). If it is above 1100 K, then the 
flame is considered as a stable steady flame.
4. The convective and radiative heat fluxes can then be computed by Eqn. (4.16 and 4.42). 
4.11 Flame Temperature
Flame temperature is key, as it will theoretically indicate cases above 1100 K that are 
expected to be steady [85–91]. This allows a flammability mapping to be made to ultimately 
consider real solid fuel ranges for heat of combustion and heat of gasification properties that 
indicate the possibility of steady burning in microgravity at specific atmospheric conditions of 
oxygen concentration and pressure. (Of course, the solid fuel’s vaporization temperature needs to 
also be accounted for, but as its effect is relatively small, it will be fixed at a small value of 80 ºC, 
representative of the experiments.) Figure 12 shows the results. Actually, the flame radiative 
fraction must be computed first, before the flame temperature is computed. In doing so, all the 
values of radiation fraction are used in computing the flame temperature, but the results in Figure 
12 are terminated at 1100 K. In subsequent computations the results will reflect those conditions 
above 1100 K.
It is striking in Figure 12 that the lower atmospheric pressure yields a wider range of 
burning conditions. This suggests that lower pressure favors burning. Some overall observations 
follow flame temperature, greater than 1100 K and indicates steady burning
~~~~

### Pagina 80

Cita: [pdf_2ada277f4accf3ff7dca, p. 80]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
77
• Happens more likely at low pressure
• Happens more likely at lower heats of combustion (because Xr increases)
• Happens more likely at higher oxygen concentrations
• Happens more likely at higher surface temperatures (But we might explore this effect later).
4.12 Flame Radiation Fraction
The flame radiation fraction can be computed from the given parameters and the results 
are shown in Figure 4.13. Steady experimental data are also included in the figure. Here the results 
are shown only for the stable flames with flame temperatures above 1100 K. Also, the experimental 
results are included to show the trends are in harmony with the theory, and the theory is 
extrapolated to higher steady mass fluxes. The complete set of experimental data points are shown 
in Figure 4.14 [51]. The trends are similar in magnitude for the low mass flux, but the data do not 
show the theoretical leveling off at higher mass fluxes The lower pressure atmosphere can support 
much higher burning rates. The results even show burning can exist at 21 % oxygen for very low 
mass flux values.
Figure 4.12. Calculated flame temperature vs. mass flux for 25 mm burner and different 
oxygen mole fractions and p = 1 atm (Left) p = 0.5 atm (Right)
~~~~

### Pagina 81

Cita: [pdf_2ada277f4accf3ff7dca, p. 81]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
78
Some qualitative results can be discerned. 
Flame Radiative Fraction:
• Increases sharply with mass flux, then levels off
• Can support higher burning mass flux at the lower pressure
• Increases with oxygen mole fraction except for very low mass flux
• Decreases with heat of combustion by about 50 % to 15 % as the burning mass flux 
increases where the heat of combustion drops by from about 47.2 to 23.6 kJ/g.
Figure 4.13. Calculated flame radiant fraction vs. mass flux for 25 mm burner and different 
oxygen mole fractions and p = 1 atm (Left) p = 0.56 atm (Right)
~~~~

### Pagina 82

Cita: [pdf_2ada277f4accf3ff7dca, p. 82]. Metodo: native.

~~~~text
79
4.13 Flame size
Here the flame height on the burner central-axis and the flame base radius are computed. 
The “c-correction” is used for the radius. The results are shown in Figure 4.15 along with some 
limited data. So, there is a pressure effect here as well, as bigger flames can exist at lower pressures. 
Figure 16 shows the complete steady flame height data over a similar range of conditions but note 
that it only ranges over 1 to 6 g/m2
s. The theory and the data are in harmony, but the theoretical 
plot reveals many more steady flame possibilities. It should be noted that experimental flames had 
a maximum flame height of about 40 mm, but theoretical flames at low pressure and high oxygen 
could extend to 120 mm. Some observations:
Flame size
• Increases with mass flux
• Decreases with oxygen concentration
• Increases with 𝑆 = ∆ℎ!/∆ℎ-@ or heat of combustion
Figure 4.14. Measured radiant fraction vs. fuel mixture mass flux for 25 mm burner
0.3
0.4
0.5
0.6
0.7
0.8
0 1 2 3 4 5 6
Flame	radiantion fraction
Fuel	mixture	mass	flux	(g/m2s)	
FT 
∆ℎ!
(kJ/g) XO2
p 
(bar)
47.2 0.4 1
47.2 0.34 1
47.2 0.34 0.56
47.2 0.265 0.7
23.6 0.4 1
23.6 0.34 0.56
23.6 0.265 0.7
~~~~

### Pagina 83

Cita: [pdf_2ada277f4accf3ff7dca, p. 83]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_2ada277f4accf3ff7dca/p0083.jpg)

~~~~text
80
• Bigger flames possible at lower pressure
Figure 4.15. Calculated flame height vs. mass flux for 25 mm burner and different 
oxygen mole fractions (Top) Calculated flame radius vs. mass flux for different oxygen 
mole fractions (Bottom)

[Texto OCR de la imagen]
• Bigger flames possible at lower pressure
120
p = I atm | p = 0.56 atm
EIOO
80
60
Ahc
FT | 02
47.2 0.4
20 | 47.2 0.34 056
o 23.6 0.4
A 23.6 0.34 056
80
E 70
60
50
R = 12.5 mm
40 | Line Sha | X
021
30 | - 0.265
0.34
20 | 0.4
Line
u 10 | solid | 47.2
double-solid | 23.6
10 | 15 0 2 4 6 8 1012 1416 18202224
Fuel mixture mass flux (g/m2s) | Fuel mixture mass flux (g/m2s)
Figure 4.15. Calculated flame height vs. mass flux for 25 mm burner and different
oxygen mole fractions (Top) Calculated flame radius vs. mass flux for different oxygen
mole fractions (Bottom)
80
~~~~

### Pagina 84

Cita: [pdf_2ada277f4accf3ff7dca, p. 84]. Metodo: native.

~~~~text
81
4.14 Calculated convective heat flux
The calculated convective heat flux is primarily affected by the radiation fraction, and thus 
through pressure. Figure 4.17 shows the theoretical results. The low-pressure flames can survive 
to higher mass fluxes. They decrease with mass burning rate and range from 10 to 0.1 kW/m2
, a 
very low value for Earth flames. Some observations:
Convective heat flux:
• Decreases with mass flux
• Increases with ambient oxygen mole fraction
• Decreases with heat of combustion
Figure 4.16. Measured flame height vs. fuel mixture mass flux for 25 mm burner
0
5
10
15
20
25
30
35
40
45
0 1 2 3 4 5 6
Flame	height	(mm)
Fuel	mixture	mass	flux	(g/m2s)	
FT 
∆ℎ!
(kJ/g) XO2
p 
(bar)
47.2 0.4 1
47.2 0.34 1
47.2 0.34 0.56
47.2 0.265 0.7
23.6 0.4 1
23.6 0.34 0.56
23.6 0.265 0.7
~~~~

### Pagina 85

Cita: [pdf_2ada277f4accf3ff7dca, p. 85]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
82
4.15 Calculated radiative heat flux
The radiative heat flux depends primarily on the flame radiative fraction and the flame size. 
Figure 4.18 shows the theoretical results. The radiation drops rapidly with burning rate.
Some observations similar to convection:
Radiative heat flux:
• Decreases with mass flux
• Increases with ambient oxygen mole fraction
• Decreases with heat of combustion
• Has similar pressure dependence, except lower ambient pressure allows longer burn time
Figure 4.17. Calculated flame convective heat flux vs. mass flux for 25 mm burner 
and different oxygen mole fractions and p = 1 atm (Left) p = 0.56 atm (Right)
~~~~

### Pagina 86

Cita: [pdf_2ada277f4accf3ff7dca, p. 86]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
83
4.16 Heat of gasification, L
The key parameter after all this analysis is the heat of gasification. While an ideal quantity 
for the steady burning of thick solids with evaporative pyrolysis characteristic, it serves as an 
approximate property that indicates the ability of a material to release flammable gases upon 
heating. It is computed from Eq. (4.8) where the burning mass lux is specified, and the heat fluxes 
can be computed from the steady flame theory. Typical non-charring plastics have L values of 2 
to 3, with charring materials effectively higher. So applicable realistic solids might range from 1 
to 5 [67,74]. 
4.16.1 Heat of Gasification dependence on burning rate
Figure 4.19 gives results where the surface vaporization temperature was representative of 
the experimental burner emulator, 80 ºC with some representative experimental data. Here L 
increases with oxygen and decreases with heat of combustion. A plot of heat of combustion vs 
Figure 4.18. Calculated radiative heat flux vs. mass flux for 25 mm burner and different oxygen 
mole fractions and p = 1 atm (Left) p = 0.56 atm (Right)
~~~~

### Pagina 87

Cita: [pdf_2ada277f4accf3ff7dca, p. 87]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
84
heat of gasification for the various atmospheric conditions over the range L: 1 to 5 kJ/g and Dhc: 
23.6 to 47.2 kJ /g would give a flammability mapping of what solids could burn in microgravity. 
Figure 20 shows how the complete steady data yielded the L plot. The data generally follow the 
theoretical trends for the effect of pressure, oxygen, and heat of combustion.
Figure 4.19. Calculated heats of gasification vs. mass flux for different oxygen mole 
fractions and p = 1 atm (Left) p = 0.56 atm (Right)
~~~~

### Pagina 88

Cita: [pdf_2ada277f4accf3ff7dca, p. 88]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
85
4.16.2 Heat of Gasification dependence on surface burning temperature
Let us examine how a more realistic vaporization temperature might affect these results. A 
temperature representative of burning plastics is selected as 350 ºC for illustration. The surface 
temperature affects surface re-radiation heat flux and the net heat flux accordingly. Heat of 
gasification is decreased when surface temperature is increased for a given mass flux. Figure 4.21 
gives these results. They are similar to Figure 4.19, but only are steady for a lower range of burning 
rates. 
Figure 4.20. Heats of gasification based on calculated total average surface heat flux vs. 
experimental fuel mixture mass flux and ambient conditions (Dashed line indicates 
experimental results trend-line for steady flames)
~~~~

### Pagina 89

Cita: [pdf_2ada277f4accf3ff7dca, p. 89]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
86
4.16.3 Heat of Gasification dependence on fire diameter
Now examine the effect of the diameter of the burning material. The diameter is doubled 
twice from 25 mm to 50 mm to 100 mm. Figures 4.22 and 4.23 show the results. For the range of 
realistic L values, the effect of size does not significantly change the results. Indeed, a careful 
examination over the 25 to 100 mm range shows nearly the same results of L for mass flux over 1 
to 5 g/m2
s. For a wide range of plastics, L values of 1 to 5 kJ/g and heats of combustion of 23.6 
and 47.2 kJ/g can be representative.
Figure 4.21. Calculated heats of gasification vs. mass flux for different oxygen mole fractions 
and p = 1 atm (Left) p = 0.5 atm (Right) for surface temperature of 350 ºC and surface diameter 
of 25 mm
~~~~

### Pagina 90

Cita: [pdf_2ada277f4accf3ff7dca, p. 90]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
87
Figure 4.22. Calculated heats of gasification vs. mass flux for different oxygen mole fractions 
and p = 1 atm (Left) p = 0.5 atm (Right) for a burner of 50 mm in diameter
~~~~

### Pagina 91

Cita: [pdf_2ada277f4accf3ff7dca, p. 91]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
88
There is a subtle effect of size. The time to reach steady conditions is much longer as the 
burning diameter increases. The factor erfc B Z
:√\
F controls the time for the flame to grow to its 
steady value, with that when erfc B Z
:√\
F = 1. If 𝜉 is related to the flame height and considered of 
the O(1), then erfc (0.01) = 0.99. 
1
2√𝜏
= 0.01 𝑜𝑟 𝜏 = 2500
𝜏 = 𝐷*𝑡
𝑅: ,𝐷* = 𝑘
𝜌𝑐;
𝐷*𝑡
𝑅: = 2500 , 𝐷* = 2.7 𝑥 10B) m:/s
Time to steady state = 10R2
(mm)2 at 99% steady
Figure 4.23. Calculated heats of gasification vs. mass flux for different oxygen mole fractions 
and p = 1 atm (Left) p = 0.5 atm (Right) for a burner of 100 mm in diameter
~~~~

### Pagina 92

Cita: [pdf_2ada277f4accf3ff7dca, p. 92]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
89
for R = 12.5 mm steady time is estimated as 1560 s; for 25 mm 6250 s; and for 50 mm 25000 s. 
These are astounding times, but this is math, and not physics. In practical terms for about 95 % of 
steady state, the 
Time to steady state = 0.4R2
(mm)2 at 95 % steady
gives for R = 12.5 mm an effective estimated steady time of 63 s; for 25 mm 250 s; and for 50 mm 
1000 s. In any event, the gas-phase transient in flame size depends strongly on the burning radius. 
However, the time governing the flame heat flux achieving steady conditions is much shorter. 
Experimental data is needed here to fully understand the effect of size on burning time.
A close examination of the theoretical and experimental results for the heat of gasification 
suggests some similarity for the results, especially over the range of realistic fuels in the range of 
1 to 5 kJ/g. Figure 4.24 shows a composite for the extreme (maximum and minimum) curves for 
each of the three material sizes (12.5, 25 and 50 mm) and surface temperature of 350 o
C to bracket 
the results and to show this footprint. All the graphs, varying in pressure, oxygen, heat of 
combustion, surface temperature and size to 100 mm in diameter cover the same portion of the 
Figure 4.24. Heat of gasification composite for size (25, 50, 100 mm diameter), surface
temperature (80 and 350 ºC), heat of combustion (47.2 and 23.6 kJ/g), and ambient conditions 
(0.56 and 1 bar ambient pressure; 0.21, 0.34 and 0.40 oxygen mole fractions)
~~~~

### Pagina 93

Cita: [pdf_2ada277f4accf3ff7dca, p. 93]. Metodo: native.

~~~~text
90
results with the mass flux varying from about 1 to 5 g/m2
s. This is a remarkable result. It says 
that burning in microgravity for surfaces up to 100 mm in diameter will typically range from about 
1 to 5 g/m2
s. 
4.17 Chapter Summary
An analytical solution, based on classic diffusion flame theory, was used to analyze microgravity 
flames generated by a gaseous fuel-charged burner that emulates condensed-phase fuels burning. 
An empirical analysis based on flame radiation theory and measurements allowed us to correlate 
flame radiative loss fraction with a dimensionless parameter, Ω. The parameter includes the effects 
of ambient conditions (i.e., ambient pressure, oxygen mole fraction), fuel heat of combustion, 
surface temperature, and flame emissivity. (See Eqns. (4,18,32-36).) Since BRE flames in 
microgravity do not contain soot, it is assumed that flame emissivity only depends on carbon 
dioxide and water vapor. However, the empirical parameter Ω does depend on the fuel, and here 
only ethylene-nitrogen mixtures were examined. RADCAL was used at a nominal flame 
temperature (1400 K) to determine the emissivity for a given path length taken as the center flame 
height. It was shown that if the RADCAL output absorption coefficients is divided by sum of the 
partial pressures of radiating component combustion products, all data will collapse on an 
empirical curve that suggests it only varies with path length. The path length is taken as the center 
flame height calculated analytically. Being able to calculate radiation fraction allows us to compute 
flame temperature in which 1100 K is taken as a criterion for flame extinction [10–14]. It also 
allows calculation of convective heat flux with a radiation correction on the heat of combustion. 
The radiation heat flux is computed based on geometrical view factor analysis along with Xr to 
give the available radiant heat flux that impinges on the surface. The net heat flux composed of 
the algebraic sum of convective, radiative and re-radiation from surface allows the heat of 
gasification to be computed for a specified fuel-mixture mass flux. The effect of burner size and 
surface temperature (350 ºC that represents real fuels burning) are also investigated. It is shown 
that as burner diameter is increased, flame radiant fraction is increased and heats of gasification 
are decreased in an asymptotic-like behavior. Surface temperature introduces substantial change 
in heat of gasification in which re-radiation heat loss decreases the burning rates, i.e., Figures 19
~~~~

### Pagina 94

Cita: [pdf_2ada277f4accf3ff7dca, p. 94]. Metodo: native.

Calidad: table_structure_not_manually_validated.

~~~~text
91
and 21. However, external radiation can offset this effect, and increase the mass flux. As in Earth￾based fires, external radiation is the key to massive fire growth; it is likely this can be an issue in 
microgravity as well. The analytical algorithm given in this paper has been shown to accurately 
predict steady conditions of burning for a surface of 25 mm diameter and has been examined for 
larger diameters. This analysis gives one a powerful analytical tool to predict the steady burning 
in microgravity as a function of fuel properties and ambient conditions. 
Let us examine the trends suggested by the theoretical results in terms of ambient conditions, fuel 
properties, and surface diameter. Table 1 shows the increase (+) and decrease (-) trends for the 
key parameters of burning as a function of specified burning rate, pressure, oxygen atmosphere, 
and heat of combustion. Ambient pressure effects are minor, and it affects the range of burning 
conditions, but not the overall burning rate. The effect of dropping the atmospheric pressure tends 
to expand the range of burning to higher burning rates. This is significant, as NASA seeks to 
provide habitable atmospheres of lower pressure and higher oxygen levels. Such a move will 
enhance the burning conditions. 
The purpose of this burner emulation approach was to exploit an efficient way to study burning in 
a quiescent microgravity atmosphere. We already knew that materials would burn with a directed 
oxygen flow, so an examination of quiescent conditions under pure diffusion flame conditions was 
thought to be essential. While steady burning might be thought as an ideal state, it is the end state 
for many material fires. The key representative property of the steady state is the heat of 
gasification. This is exact for vaporizing solids and approximant under real pyrolysis conditions. 
In any case, the heat of gasification gives an indication of the energy needed to form a fuel gas for 
burning. In the burning emulation, the mass flux was specified, and the heat of gasification was 
derived, in the real problem, the heat of gasification is given and the question of burning arises. 
This question is resolved by use of the empirical flame extinction temperature. Indeed, the flame 
temperature is independent of the heat of gasification in the solution used herein but depends on 
the mass flux instead. 
The mass flux does depend on L, as well as the flame temperature, surface re-radiation, and 
external radiant heat fluxes. Hence radiant heat transfer as the flame grows controls burning and
~~~~

### Pagina 95

Cita: [pdf_2ada277f4accf3ff7dca, p. 95]. Metodo: native.

~~~~text
92
extinction. Therefore, the algorithm should be cast in terms of the ambient conditions, including 
external radiation, and fuel properties to determine if burning is possible and at what rate. Although 
It is not straightforward to invert this process, the final results presented herein can be inverted 
into a flammability map that would give the burning conditions for a given fuel in terms of its 
Heat of combustion
Heat of gasification
Burning temperature
and for given ambient oxygen mole fraction and pressure with also consideration of external 
radiant heat flux. NASA Flammability Test 2, the Cone Calorimeter or equivalent, has the means 
to classify materials into these properties. This is a pathway for establishing a science-based fire 
safety evaluation methodology for materials used in spacecraft. A follow up analysis to this paper 
should investigate these fire conditions and safety implications for space flight materials.
~~~~

### Pagina 96

Cita: [pdf_2ada277f4accf3ff7dca, p. 96]. Metodo: native.

~~~~text
93
5. Analysis of the steadiness of the flames
The likelihood of steady burning in microgravity is examined with Burning Rate Emulation 
(BRE) using a gas burner with a flat 25 mm diameter porous surface with two embedded heat flux 
sensors. The data are greatly expanded from a previous work. The fuel mixture used in this analysis 
are ethylene and ethylene diluted with nitrogen resulting in a range of heats of combustion from 
12 to 47.2 kJ/g. An analytical solution of these flames was utilized to compute their steadiness, 
temperatures at flame sheet, and sizes. 103 flames were ignited in an ambient with nominal oxygen 
mole fractions of 0.21, 0.265, 0.34 and 0.40. 49 of those flames burned for the entire duration of 
the test before the fuel supply was terminated, while the remainder self-extinguished. The flames 
attained at least 90% of their asymptotic heights for all 49 fuel terminated flames. An estimated 
critical steady flame temperature ranging from 1100 to 1200 K was observed segregating the 
sustained and self-extinguished flames. Flame temperatures for the 49 terminated flames were 
above the critical temperature range indicating sustained steady burning, whereas below they self￾extinguished. The measured flame sizes, and radiative loss fractions are reported at the endpoint 
of the terminated tests. An empirical correlation of the radiative loss fraction with W, a 
dimensionless parameter, was obtained that allows prediction for real fuels at steady burning in 
microgravity. A flammability diagram, as a plot of the emulated fuel heat of gasification with its 
burning mass flux, for the range of steady data, is presented comparing how real fuels might burn 
steadily in normal and microgravity conditions. The results suggest that fuel mass flux burning 
rates would be about 3 to 4-times higher in 1-g. The heats of gasification and combustion of some 
real fuels are presented and compared against the burner flames.
The steadiness of the flame heights is examined by utilizing the theoretical solution to these 
flames [49,51]. A critical flame temperature range of 1100 K to 1200 K was found to distinguish 
between the extinction and the 49 terminated flames becoming steady where the critical 
temperature in 1-g is 1600 K [75,85–88,91,91].
~~~~

### Pagina 97

Cita: [pdf_2ada277f4accf3ff7dca, p. 97]. Metodo: native.

~~~~text
94
5.1 Analysis of the steadiness of the flame heights
The theoretical solution to these flames is based on the classical diffusion flames theory and 
was used to estimate the steadiness of the flame heights [49,51,52]. The 49 fuel terminated flames 
reached 0.953 of their asymptotic height before fuel termination with standard deviation of 0.019 
[49,51,52]. The theoretical steady flame height is consistent with transient data extrapolated by 1/t
~ 0. It should be noted that the prediction of flame height does not depend on radiation, but other 
parameters, such as the flame temperature, does depend on flame radiation [52]. In these 
calculations a specific heat of 1.23 kJ/kg K was used.
5.2-Dimensional analysis of the Radiative loss fraction based on radiation theory
A dimensional analysis of the radiation data of steady flames led to an empirical correlation 
flame radiation fraction, Xr with Ω, a dimensionless parameter [52]. Since the flames are blue and 
sootless, the dimensionless parameter depends on the partial pressures of CO2 and H2O for 
complete combustion, flame size, and oxygen. The correlation is used to reduce the heat of 
combustion term in the theory to account for the flame radiative heat loss in calculation of the 
flame temperature (see Eq. (5.3)). 
The second term in the Ω formula is the flame emissivity and k represents the absorption 
coefficient of radiative gasses in the combustion products. Since the flames are sootless, and as 
pointed out by de Ris [84], for flames without soot, the absorption coefficient depends on path 
length, approaching the Planck limit at zero path length [74,83].
RADCAL [58,59], a narrow-band model, was used to estimate emissivity and absorption 
coefficient for combustion products. It was run for stoichiometric combustion of ethylene, shown 
by Eq. (5.1), that resulted in partial pressures of water vapor and carbon dioxide calculated by Eq. 
(5.2). The partial pressures resulted from Eq. (5.2) are responsible for flame radiation and thus, are 
used as the inputs to RADCAL. The emissivity for ethylene is computed as 1 − 𝑒BU7@7 where, 𝜅̃
is the normalized absorption coefficient (when obtained 𝜅 is divided by the sum of partial pressures 
of H2O and CO2) [52]. It was shown in [23] in detail that for sootless BRE flames 𝜅̃depends only 
on path length (flame height is taken as the path length for BRE flames) given by 𝜅̃=
~~~~

### Pagina 98

Cita: [pdf_2ada277f4accf3ff7dca, p. 98]. Metodo: native.

~~~~text
95
7.96𝑒BV.W3@7 for 𝑥7 < 0.1m. absorption coefficient, 𝜅 , required for obtaining the emissivity for 
ethylene flames is computed from
𝜅 = h )
)]X^
89:6!
:6! _]
89:3!45
:3!45
u 𝑝. 𝜅̃. Figure 3 shows the radiative loss fraction correlation. 
The third dimensionless group of Ω is the normalized flame height squared, 
(xf / R)2
. The last term of Ω is q𝑇7,-⁄𝑇*s
) where Tf,o is the flame temperature (Tf) given by Eq. (3) 
without the radiative heat loss term (1 - Xr). One instead could have used Tf (Eq. (3)) in calculation 
of Ω which makes the Xr correlation an implicit problem (𝑋, = 𝑓 (Ω(𝑋,)), and f is the output of 
the correlation and found by passing the best fit from the data points.] The radiative heat loss term 
was removed from Ω to define the Xr an explicit function of Ω (i.e., 𝑋, = 𝑓 (Ω) with known or 
calculable parameters.
Quantity Xr derived from remote radiometry [51] and Ω are inputs to Fig. 3 to examine a 
correlation (the output). The relationship between the variables is based on radiation theory and 
the correlation shown as a power law fit, obtained empirically by the method of least squares) then 
supplies a general predictive tool. Substitution of Ω into the correlation (𝑋, = 0.49Ω1.C:) leads to 
prediction of Xr. Fig. 5.1 shows the radiative loss fraction empirical correlation.
~~~~

### Pagina 99

Cita: [pdf_2ada277f4accf3ff7dca, p. 99]. Metodo: native.

~~~~text
96
𝐶:𝐻) +
1 − 𝑋%!65
𝑋%!65
𝑁: + 3𝑂: +
3 − 3𝑋9:
𝑋9:
𝑁: →
2𝐶𝑂: + 2𝐻:𝑂 +
3 − 3𝑋9:
𝑋9:
+
1 − 𝑋%!65
𝑋%!65
𝑁: (5.1)
𝑝6!9 = 𝑝%6! = 2𝑝
3/𝑋9: + 1/X`:a)
(5.2)
5.3 Calculated temperature at flame sheet
Eq. (5.3) is used to calculate the flame temperature at flame sheet and at steady state. Xr is 
computed from the correlation of Fig. 5.1, in which Ω is determined using the theoretical steady 
solution for flame height, the estimated endpoint oxygen concentration, and the prescribed mass 
flux and heat of combustion [52]. It is observed in Fig. 5.2 that a critical temperature range of 1100 
to 1200 K segregates the steady and self-extinguished flames. The extinction data never become 
steady, as their computed steady state has a temperature below the critical value. The details of 
each parameter used in Eq. (5.3) is discussed in [49,52]. 
Figure 5.1. Radiative loss fraction empirical correlation resulted from a dimensional analysis of 
radiometry
y	=	0.49x0.12
R²	=	0.87
0.2
0.4
0.8
0.01 0.1 1 10 100
Xr
Ω
Ω = #$!
"
%̇
##∆ℎ$
1 − +%&!'!
,(
-
) $(,+
$!
"
FT ∆ℎ"
kJ/g XO2
p 
(bar)
35.9 0.4 1
23.6 0.4 1
15.6 0.4 1
35.9 0.34 1
15.6 0.34 1
47.2 0.34 0.56
23.6 0.34 0.56
15.6 0.34 0.56
11.8 0.34 0.56
47.2 0.265 0.7
23.6 0.265 0.7
15.6 0.265 0.7
~~~~

### Pagina 100

Cita: [pdf_2ada277f4accf3ff7dca, p. 100]. Metodo: native.

~~~~text
97
𝑐;q𝑇7 − 𝑇*s = 1
𝛼𝑌P/ + 1ò𝑐;(𝑇' − 𝑇* ) + 𝑌P/(1 − 𝑋,)∆ℎ!ô (5.3)
Fuel mass fraction YFb at the burner surface and dimensionless mass flux are found from Eqns. 
(5.4, 5.5)
𝑌P/ = 1 − 𝑒BQ(1 + 𝛼)/𝛼 (5.4)
𝜆 = 𝑚̇
$$
4𝑘/(𝜋𝑐; 𝑅) (5.5)
Where, 𝛼 = 𝑆/𝑌9:,* and 𝑆 = ∆ℎ!/∆ℎ!,9:.
Figure 5.2. Calculated flame temperature at flame sheet, cp = 1.24 J/g K
500
600
700
800
900
1000
1100
1200
1300
1400
1500
0 1 2 3 4 5 6 7 8 9 10 11 12 13
Calculated	flame	temperature	(K)
fuel	mixture	mass	flux	(g/m2s)
SE FT ∆ℎ!
kJ/g XO2
p 
(bar)
47.2 0.4 1
N/A 35.9 0.4 1
32.1 0.4 1
23.6 0.4 1
15.6 0.4 1
47.2 0.34 1
N/A 35.9 0.34 1
N/A 32.1 0.34 1
N/A 23.6 0.34 1
N/A 15.6 0.34 1
47.2 0.34 0.56
23.6 0.34 0.56
15.6 0.34 0.56
11.8 0.34 0.56
N/A 47.2 0.265 1
N/A 23.6 0.265 1
47.2 0.265 0.7
N/A 32.1 0.265 0.7
23.6 0.265 0.7
15.6 0.265 0.7
N/A 47.2 0.25 1
N/A 32.1 0.25 1
N/A 23.6 0.25 1
N/A 15.6 0.25 1
N/A 47.2 0.21 1
N/A 23.6 0.21 1
N/A 15.6 0.21 1
Critical Temperature range
~~~~

### Pagina 101

Cita: [pdf_2ada277f4accf3ff7dca, p. 101]. Metodo: native.

~~~~text
98
5.4 Further analysis of the experimental data 
Let us still consider the data set containing the 49 terminated flames as steady and explore the 
endpoint data. The measured flame height, and aspect ratio (height divided by radius) will be 
shown and compared to the computed values in the next section and in the end, a flammability 
diagram (heats of gasification vs. fuel mixture mass flux) is shown that includes micro- and normal 
gravity data.
5.5 Flame size
The flame heights and radius are measured from the center of the burner to the edge of the flame
sheet at the end of each test point. The analytical solution for these flames allowed computation of 
these dimensions by providing appropriate cp and k where the properties of nitrogen at 1400 K, 
that is a representative temperature to these flames, were chosen. Eqns. (5.6, 5.7) were used to
~~~~

### Pagina 102

Cita: [pdf_2ada277f4accf3ff7dca, p. 102]. Metodo: native.

~~~~text
99
calculate flame height and radius at the endpoints of the tests. The empirical constant c used in Eq. 
(5.7) is used to adjust the calculated radius with measured value. The correction is needed because 
the theoretical model does not allow a flame below the burner surface while in the experiment, the 
flame could expand on the side of the burner below its surface. Fig. 5.3 show the calculated heights 
against measured values at the top. The calculated vs. measured aspect ratio, flame heights divided 
by flame radius, are presented at the bottom of Fig. 5.3. The accuracy of the analytical model 
Figure 5.3. Calculated vs. measured, flame heights (top) and flame aspect ratio (bottom)
0
10
20
30
40
0 10 20 30 40
calculated	
xf (mm)
measured	xf (mm)
0
1
2
0 1 2
calculated	
xf /	rf	
measured	xf /	rf
FT ∆ℎ!
kJ/g XO2
p 
(bar)
47.2 0.4 1
35.9 0.4 1
32.1 0.4 1
23.6 0.4 1
15.6 0.4 1
47.2 0.34 1
35.9 0.34 1
15.6 0.34 1
47.2 0.34 0.56
23.6 0.34 0.56
15.6 0.34 0.56
11.8 0.34 0.56
47.2 0.265 0.7
23.6 0.265 0.7
15.6 0.265 0.7
~~~~

### Pagina 103

Cita: [pdf_2ada277f4accf3ff7dca, p. 103]. Metodo: native.

Calidad: table_structure_not_manually_validated.

~~~~text
100
introduced in [49,52] is justified by comparing calculated flame dimensions against those 
measured in the experiments. The dashed line shown in Fig. 5.3 facilitates this comparison.
𝑥7
𝑅 = tan ¶
𝜋
2 y1 +
ln(𝛼/(𝛼 + 1))
𝜆 |æ (5.6)
𝑟7/𝑅 = û1 + 𝑐q𝑥7/𝑅s
: (5.7)
5.6 Surface heat flux
Two heat flux sensors are embedded to the surface of the burner at the center and at an 
offset location, 9.5 mm from the center. The resulting measured surface heat flux is a summation 
of convective and radiative heat flux from the flame minus the surface re-radiation (see Eq. (5.10)). 
Corrections to the sensor measurements were made to account for differences in sensor and burner 
surface temperatures and have been derived previously and discussed in [10,46–48,55]. The typical 
transient measured heat fluxes of two tests that led to termination (steady state) and self-extinction 
are shown and discussed in [51]. The center sensor always measured higher values and the ratio 
of the center to offset measured values increase with mass flux indicative of radiation dominance 
over conduction as the flame gets bigger.
5.7 Flammability diagram
An arithmetc average of the measured net heat fluxes at the burner surface, as shown by Eq. 
(5.8), were used to obtain the heats of gasification. 
𝑞̇
450
" = 0.5 𝑞̇
!0,
" + 0.5 𝑞̇
,JV.3 >> " (5.8)
In general, Eq. (5.9) is used to calculate heats of gasification
~~~~

### Pagina 104

Cita: [pdf_2ada277f4accf3ff7dca, p. 104]. Metodo: native.

~~~~text
101
𝑚̇
$$𝐿 = 𝑞̇
450
$$ (5.9)
The heats of gasification reported in Fig. 6 are experimentally obtained by using Eqns. (5.8, 5.9). 
In general, the net heat flux consists of four terms as shown in Eq.(5.10) and would allow a 
theoretical [52] derivation of L, not shown in this paper.
𝑞̇
450
" = 𝑞̇
7,!
" + 𝑞̇
7,,
" − 𝑞̇
,,
" + 𝑞̇
5@0,, " (5.10)
𝑞̇
7,!
" : Flame convective heat flux
𝑞̇
7,,
" ∶ Flame incident radiative heat flux
𝑞̇
,,
" ∶ Surface radiative loss heat flux
𝑞̇
5@0,, " ∶ Incident external radiative heat flux that is not present in this analysis
The significance of the steady burning data allows for interpreting the heat of gasification 
corresponding to the steady burning of a real fuel having the associated heats of combustion and 
gasification. Many real fuels satisfy this theoretical steady burning result, and others approximate 
it. The flammability diagram shown in ref. [51] is updated with the results obtained in the second 
round of tests aboard the ISS. The data measured in 1-g and discussed in [55] is added to the plot 
for comparison between micro- and normal gravity burning. As deducted from Fig. 5.4, the 
burning rate in normal gravity is about 3 to 4 times higher than microgravity. The figure shows 
how fuels with a given heat of combustion and gasification would burn for a 25 mm flat disk in an 
ambient oxygen mole fraction XO2 and, pressure, p. The heats of gasification range from fuels 
associated as liquids (0.5 – 1.5 kJ/g) and solids (greater than 1.5 kJ/g). Liquid fuels burning in 
microgravity conditions should be absorbed into an inert matrix. 
If the small effect of fuel vaporization temperature is neglected, real fuels corresponding 
to heats of combustion and gasification can be identified among the BRE data of Fig. 5.4. The 
microgravity steady data are shown on the left of the figure from mass flux of 1 to 6.4 g/m2
s and 
normal gravity trendline is shown on the right of the figure starting from mass flux of 2.1 and up 
to 30.6 g/m2
s. The descending trend of heat of gasification with burner gas flow rate looks similar
~~~~

### Pagina 105

Cita: [pdf_2ada277f4accf3ff7dca, p. 105]. Metodo: native.

~~~~text
102
for both gravity conditions indicating that increasing mass flow rates results in larger flames where 
the flame sheet is further from the burner surface and thus, the convective heat flux to the fuel 
source is decreased which was also discussed in Fig. 9 of [51] (see Eqns. (8) to (10)). It is observed 
that at a constant heat of gasification (shown by a horizontal line on Fig. 5.4) and heat of 
combustion that could represent real material properties, the burning rate in 1-g is approximately 
3 to 4 times greater compared to µ-g. The difference is justified by considering the role of gravity 
in the creation of buoyancy. Buoyancy on the ground causes high radially inward velocities that 
sweep the flame close to the surface. This causes much higher convective heat fluxes than in the 
pure conduction of microgravity. In microgravity, natural convection is absent and hot combustion 
Figure 5.4. Flammability map (heats of gasification vs. fuel mixture mass flux) for micro 
and normal gravity data for the surface diameter of 25 mm
y = 7.07x-1.26
R² = 0.81
y = 39.533x-1.291
R² = 0.9973
0.1
1
10
1 10 100
heat	of	gasification	(kJ/g)
fuel	mixture	mass	flux	(g/m2s)
1-g data
!-g data
Phenolic/glass fiber (45%), ∆ℎ!=22 kJ/g
Wallpaper on rigid PU, ∆ℎ!=18.9 kJ/g
PS, ∆ℎ!=	35.8	kJ/g
PMMA, ∆ℎ!=	24.2	kJ/g
Acetone, ∆ℎ!=	30.8	kJ/g
Ethanol, ∆ℎ!=	26.8	kJ/g
Methanol, ∆ℎ!=	19.8	kJ/g	
Acrylic fiber, ∆ℎ!=	27.5	kJ/g
Wool, ∆ℎ!=	19.5	kJ/g
Polyester/glass fiber (30%), ∆ℎ!=	19.5	kJ/g
Epoxy, ∆ℎ!=	25	kJ/g
Epoxy/glass fiber (69%) , ∆ℎ!=	27.5	kJ/g
Nylon 6, ∆ℎ!=	28.8	kJ/g
1-g
∆ℎ4
kJ/g XO2
p 
(bar)
43.7 0.21 1
35 0.21 1
26.2 0.21 1
17.5 0.21 1
0-g
∆ℎ4
kJ/g XO2
p 
(bar)
47.2 0.4 1
35.9 0.4 1
32.1 0.4 1
23.6 0.4 1
15.6 0.4 1
47.2 0.34 1
35.9 0.34 1
15.6 0.34 1
47.2 0.34 0.56
23.6 0.34 0.56
15.6 0.34 0.56
11.8 0.34 0.56
47.2 0.265 0.7
23.6 0.265 0.7
15.6 0.265 0.7
~~~~

### Pagina 106

Cita: [pdf_2ada277f4accf3ff7dca, p. 106]. Metodo: native.

~~~~text
103
products move by thermal expansion and diffusion that form hemispherical shaped flames 
compared to the tall vertical flames in 1-g. Therefore, higher surface heat flux in 1-g, results in 
higher mass vaporization rate for a given material. The heats of gasification and combustion for 
some real fuels are taken from [68] and shown as horizontal dashed lines on Fig. 5.4. As the 
horizontal dashed-lines, indicating real fuel properties, cross the microgravity and 1-g trendlines 
and if intersecting data point can be found with the same heat of combustion, the two key properties 
for emulation are matched. Also, shown are some dashed lines ending with red crosses, 
representing real materials listed in [55,56]. For instance, if one takes the line representing PMMA,
the burning rate measured in -1-g is 18.5 g/m2
s, the heat of gasification is 1.6 kJ/g and the heat of 
combustion is 24.2 kJ/g. The green open circle (1-g) and blue triangle (µ-g) are the closest 
emulated flames to PMMA burning in normal gravity with 21% oxygen and microgravity with 
34% oxygen, respectively 
It was shown that an increase in the ambient pressure increases the partial pressures of the 
combustion products and therefore the resulting absorption coefficient,k, and flame emissivity, 𝜖
are enhanced. As a result, the radiative heat loss and flame luminosity are increased which causes 
the flame temperature to decrease. In other words, reduced ambient pressure enhances the fire 
hazard in microgravity in a quiescent ambient. Quantities D, a, 1/r, n, and k are proportional to 
1/p, but 𝜌D is independent of p. In the experimental presentation of this paper, it can be dug out 
that over 0.56 to 1 atm there appears to be a negligible effect as discussed in [21,23]. For example, 
in Fig.6 the two points near L=1.6 and 𝑚”
̇ = 2.6 correspond to the same conditions but p = 0.56, 
and 1 atm. In the theoretical analysis [23], little difference was discerned due to the pressure 
differences, and it was shown that pressure reduction led to expansion of the flammable mass 
burning rate 𝑚̇
$$, i.e., the highest flammable 𝑚̇
$$is increased as p is decreased [23].
An Uncertainty analysis was performed on the microgravity data points of Fig. 6. The 
sources of uncertainty as given by Eqns. (5.8,5.9) are the measured heat flux and flow rates. The 
heat flux sensors are manufactured by Medtherm, and the flow meters are made by Teledyne 
Hastings (model: HFC-302D). The manufacturer’s reported uncertainties for the raw measurement
~~~~

### Pagina 107

Cita: [pdf_2ada277f4accf3ff7dca, p. 107]. Metodo: native.

~~~~text
104
of each instrument were used to obtain the uncertainty of measured heat flux and fuel and nitrogen 
flow rates. The formulation introduced in [93,94] was utilized to compute the propagation of 
uncertainties to L and 𝑚̇
$$. The normalized uncertainty of the reported heats of gasification (𝛿𝐿/𝐿)
ranged from 4.5% to 17.5% with a mean value of 5.7% and standard deviation of 2.9%. The 
normalized uncertainty of 𝑚̇
$$ (𝛿𝑚̇
$$/ 𝑚̇
$$) varied from 1.3% to 17% and with a mean value, and 
standard deviation of 3.1%, and 3.6%, respectively. In short, the representative uncertainty that 
covers 95% of the errors for all data points would be:
ω% = ω£% ± 2𝜎 (5.11)
Where, ω is the normalized uncertainty of all measurands. 
Same approach was performed to obtain uncertainty associated with heats of combustion 
(varied by changing the fuel-nitrogen mixture dilution) and measured radiative loss fraction Xr. 
The radiative heat flux was measured by Dexter research 2M wide angle radiometers and the error 
analysis performed by NASA was used for the uncertainty of the raw radiative heat flux 
measurements. The resulting uncertainties of Xr, and ∆ℎ! are: 𝛿𝑋,⁄𝑋, = 10.11% ± 9.6%, and 
𝛿∆ℎ!⁄∆ℎ! = 3.68% ± 6.86%
5.8 Chapter Summary
The flammability of 25 mm diameter flat disk-shaped condensed-phase material is examined 
in microgravity for steady burning. The BRE using a gas fuel supplied burner with two embedded 
heat flux sensors is an efficient method to study burning in microgravity. The fuel mixture used in 
this study was ethylene and ethylene diluted with nitrogen to give a range of heats of combustion 
per unit gram of the fuel mixture of about 12 to 47.2 kJ/g. An analytical solution to these flames 
was utilized to compute their steadiness, flame temperatures, and heights with good accuracy. 103 
flames were successfully ignited in a quiescent ambient with nominal oxygen mole fractions of 
0.21, 0.26, 0.34 and 0.40. 49 of those flames burned for the entire duration of the test before the 
fuel supply was terminated intentionally, while the remainder self-extinguished including all the 
flames burning in air (i.e., 0.21 nominal oxygen mole fraction). Elevated ambient oxygen 
concentrations above normal air enhances the flammability of materials while ambient pressure 
(not discussed here) had a negligible effect [21, 23]. The 49 terminated flames reached 95.3% of
~~~~

### Pagina 108

Cita: [pdf_2ada277f4accf3ff7dca, p. 108]. Metodo: native.

~~~~text
105
their asymptotic value with a standard deviation of 1.9%. A steady critical flame temperature range 
of 1100 to 1200 K was observed that segregates the conditions of the steady and self-extinguished 
flames. Flame temperatures for the 49 terminated flames were above the critical flame temperature 
range indicating sustained burning. The flame size, and radiative loss fractions are reported at the 
endpoint of the tests. A dimensional analysis of the radiation data resulted in an empirical 
correlation of the radiative loss fraction, Xr with, W, a radiation dimensionless parameter. 
Arithmetic average of the two measured surface heat fluxes were used to compute the heats of 
gasification that resulted in a flammability diagram for microgravity data. The measured heats of 
gasification in normal gravity were added to the plot. A comparison between flammability of 
micro- and normal gravity showed that materials burn about 3 to 4 times faster on the ground.
A theoretical methodology used herein could be applied to predict the burning rate of flat 
surfaces in microgravity. The effect of burning diameter and external radiation can be explored for 
various real fuels in steady burning under different ambient conditions. We recommend this be 
done.
~~~~

### Pagina 109

Cita: [pdf_2ada277f4accf3ff7dca, p. 109]. Metodo: native.

~~~~text
106
6. Flammability Maps for Microgravity Flames on Top of a Flat Disk in 
a Quiescent Ambient
The current criteria for material selection for use in spacecrafts is based on NASA test 1, an upward 
flame spread over a real material sample in a controlled environment in 1-g. However, there is no 
scientific basis to extrapolate the results of this test to microgravity condition. The induced flow 
because of buoyancy presence in normal gravity flames is in favor of steady flames, a condition 
that is not applicable to flames in µ-g. The inherent material properties that control flammability 
should not change with gravity field and this is essential for extrapolation of 1-g test results to µ￾g. BRE emulates condensed phase fuels by matching four material properties Dhc, L, ls, and Tb. 
The first two quantities are used for analysis of BRE results in microgravity[50–54,60]. The flames 
in this study are sootless and laminar smoke point is not applicable to µ-g results. 1-g emulations 
between the burner and real fuels were very good when matching L, Dhc, ls, with Tb not matched 
[4,10,46,47,55,56]. The Tb is the uncontrolled surface temperature Ts for BRE. Our theory allows 
for including Tb in predictions [52]. This study provides a flammability map based on Dhc, and L
for each nominal ambient XO2. These properties can be effectively measured by the Cone 
Calorimeter: NASA Test 2, not currently used to determine flammable hazard in space. 
Flammability maps are obtained for each XO2 used in this analysis (i.e., 0.4, 0.34, and 0.265). The 
extinction limits were obtained based on the criteria of setting a critical flame temperature range 
of 1100 K to 1200 K. The flammable zone will be the area where flames have flame temperatures 
above this range. Two extinction limits was obtained based on theory [52,60], radiative extinction, 
and small flame (convective) extinction limit. 
6.2 Experimental results
Flame heights and radius, radiative loss fraction correlation and calculated flame temperature for 
steady flames were reported and discussed in the previous section. Analysis of the measured heat
~~~~

### Pagina 110

Cita: [pdf_2ada277f4accf3ff7dca, p. 110]. Metodo: native.

Calidad: table_structure_not_manually_validated.

~~~~text
107
fluxes by the two-surface embedded heat flux sensors are included in this section. A flammability 
map (as a plot of Dhc vs. L) is introduced for each nominal ambient XO2. 
6.3 Summary of the endpoint results
The measured values of heat flux, flame height and radius, radiative loss fraction, oscillation 
onset time for the self-extinguished test points and burn time for all the tests are presented in 
table 6.1.
Table 6.1. Summary of the endpoint results ordered by XO2 for ethylene-nitrogen flames. ordered 
by XO2, dashes indicate where no radiation data is available, the end conditions are self￾Extinguished (SE), Fuel Terminated (FT), and Fuel Terminated with Oscillations (FTO)
XO2
before 
test
XO2
after 
test ∆hc p 𝑚̇′′ 𝑞̇
+,-
.. 𝑞̇
/00
.. yf rf
Xr before 
oscilations
Osc. 
Time
Ext 
Time/end 
time
end 
condition
test ID kJ/g bar g/m2
-s kW/m2 kW/m2 mm mm s s
20346L4 0.36 0.3575 16.4 1.055 6.38 4.97 2.45 19.1 16.78 0.539 - 39 SE
20358B1 0.39 0.3771 47.2 1.06 3.99 4.97 2.45 25.56 19.84 - 63.93 113.9 SE
19039A1 0.3972 0.3839 47.2 1.05 3.84 5 3 33 23.3 - - 123 FT
19039B3 0.3834 0.371 47.2 1.055 2.55 6.52 3.51 22.9 20 - - 180 FT
20352A8 0.3634 0.3631 35.5 1.06 5.94 4.3 1.5 38.5 28.95 - 40.7 80.13 FTO
20339A0 0.3752 0.3728 35.3 1.055 4.24 8.4 6.47 18.37 16 0.41 13.28 13.51 SE
20352A3 0.381 0.3729 35.7 1.05 2.94 6.68 3.71 15.94 15.91 0.602 - 137.47 FT
20352A5 0.3729 0.3776 36 1.047 1.91 7.93 4.69 16.02 14.75 0.644 - 134.18 FT
20352A6 0.3776 0.3634 36.3 1.04 1.42 10.5 7.04 10 13.02 0.422 - 131.36 FTO
20358B1-1 0.3771 0.3672 32 1.045 3.93 5.8 3.1 24.32 20.8 - - 135.62 FT
19063C1 0.3618 0.3474 23.6 1.06 12.16 3.17 1.45 80 23.97 - 44.97 147.2 SE
19063B1 0.3786 0.3618 23.6 1.055 8.92 3.73 1.76 62.5 22.25 - 22.4 89 SE
19056A2 0.3881 0.3745 23.6 1.055 6.39 4.54 2.36 34.9 22.5 - - 180 FT
19063A1 0.3949 0.3739 23.6 1.055 6.00 4.54 2.41 42 21.2 - 106 300 FTO
19056A1 0.398 0.3881 23.6 1.055 4.46 6.27 3.75 22.3 17.7 0.62 - 180 FT
20346A5 0.3809 0.377 23.6 1.05 4.43 6.05 3.43 20.26 18.28 0.595 - 96.53 FT
20358A1 0.3978 0.39 23.7 1.043 3.91 7.24 4.4 17.37 16.97 0.5792 - 132.28 FT
20352A1 0.3943 0.3874 24.7 1.043 3.39 7.52 4.4 16.35 19.71 0.543 - 135.03 FT
20352A2 0.3874 0.381 24.7 1.045 3.39 7.21 4.63 17.37 16.32 0.558 - 133.43 FT
20346A3 0.389 0.3862 23.6 1.045 2.98 8.44 5.65 10.11 13.17 0.501 - 127.8 FT
20346A4 0.3862 0.3809 23.6 1.045 2.95 8.57 3.34 10.32 13.24 0.443 - 64.5 FT
20346L3-1 0.36 0.3575 15.8 1.07 8.94 4 2.3 24.93 18.19 - 47.33 95.23 FTO
20346L3 0.3671 0.36 15.7 1.067 8.91 4.2 2.4 23.81 17.87 - 55.33 95.13 FTO
20346L1 0.377 0.3743 15.8 1.05 4.40 7.22 4.74 10.88 13.48 0.486 - 95.04 FT
20346L2 0.3743 0.3671 15.9 1.05 4.40 6.9 2.61 11.52 13.55 0.453 - 95.21 FT
20358B3 0.36720.36193 15.5 1.045 3.92 7.64 4.9 13.42 15.26 0.522 - 157.18 FT
20358B4 0.3619
3 0.3575 9.3 1.043 3.91 9.5 6.17 8.33 13 0.316 - 122.23 FT
~~~~

### Pagina 111

Cita: [pdf_2ada277f4accf3ff7dca, p. 111]. Metodo: native.

~~~~text
108
XO2
before 
test
XO2
after 
test ∆hc p 𝑚̇′′ 𝑞̇
+,-
.. 𝑞̇
/00
.. yf rf
Xr before 
oscilations
Osc. 
Time
Ext 
Time/end 
time
end 
condition
20358D2 0.3401 0.3319 47.2 1.05 3.97 4.54 1.58 28.44 22.82 - 41.3 66.5 SE
20352D1 0.3507 0.3404 35.7 1.05 3.94 5.01 2.36 29.15 26.5 - 71.9 121.05 FTO
20352D2 0.3404 0.3346 36 1.04 1.91 7.6 4.68 13.95 15.4 0.503 - 135.33 FT
20352D3 0.3346 0.3307 36.5 1.04 1.25 10.7 6.92 9.21 12.45 0.377 - 120.73 FT
20358D3 0.3319 0.3237 32 1.05 3.93 4.9 2.6 21.77 18.33 - 68.23 132.08 FTO
20358D1 0.3501 0.3401 23.7 1.05 7.92 3.93 2.16 32.58 22.19 - 44.67 76.13 SE
20352F3 0.3306 0.3249 15.4 1.045 4.41 5.86 3.48 14.54 14.57 0.503 - 138.34 FT
20358D5 0.3208 0.3164 15.7 1.045 3.95 6.42 4.04 14.47 15.92 0.4897 - 131.32 FT
21020A1 0.3499 0.3404 15.6 0.595 3.92 6.75 4.5 13.17 15.36 0.44 - 133.64 FT
20358D4 0.3237 0.3208 9.4 1.04 3.91 8.12 4.74 7.44 11.03 0.3278 98.33 111.21 FTO
19094K1 0.3511 0.3495 47.2 0.57 6.96 2.92 1.67 74 34.64 - 20.72 36 SE
19094J1 0.3525 0.3511 47.2 0.57 5.93 2.96 1.62 58.2 35.42 - 29.5 37 SE
19094H1 0.3541 0.3525 47.2 0.57 5.41 3.15 1.66 59.1 34.57 - 37.7 47 SE
19051C3 0.3152 0.3066 47.2 0.57 3.84 4 2.27 41.8 25.71 - 48.5 66 SE
19051G1 0.2979 0.2831 47.2 0.57 3.84 3.64 2.09 42.9 26.6 - 43.8 67 SE
19051B1 0.3262 0.3163 47.2 0.57 3.07 4.79 1.46 28.8 23.42 - 63.5 99 SE
19051F1 0.3178 0.2979 47.2 0.57 3.07 4.08 2.15 37.6 27.95 - 94.8 131 SE
19051A1 0.3391 0.3262 47.2 0.565 2.55 5.18 2.9 24.5 20.9 - - 180 FT
19051D1 0.3394 0.3178 47.2 0.565 2.55 4.92 2.57 27.2 22.8 - - 180 FT
20261F2 0.3187 0.3925 47.2 0.604 2.45 4.9 7.6 9.3 11.86 - - 130.2 FT
19087A1 0.3604 0.3428 47.2 0.604 2.06 6.6 3.58 19.8 19.4 0.63 - 180 FT
20261B1 0.3488 0.3362 47.2 0.604 1.96 6.3 3.5 17.55 16.26 0.584 - 131.03 FT
19087B1 0.3428 0.3276 47.2 0.604 1.78 7.05 4.09 16.8 17.8 0.6 - 180 FT
19087D1 0.315 0.3049 47.2 0.604 1.78 9.27 5.7 10.7 14.5 0.48 - 180 FT
20261D2 0.331 0.3196 47.2 0.606 1.75 6.4 3.75 15.63 16.29 0.571 - 130.37 FT
19087C1 0.3276 0.315 47.2 0.606 1.47 7.51 4.46 15.5 17.3 0.608 - 180 FT
19056D3 0.3282 0.3098 23.6 0.565 6.39 3.32 1.66 42.6 38.6 - 58.5 137 SE
19070D1 0.3598 0.3419 23.6 0.565 4.94 4.48 2.5 28.1 21 - - 180 FT
19070C1 0.342 0.331 23.6 0.605 4.43 4.61 2.7 25.6 20.4 0.63 - 120 FT
19070B1 0.3524 0.342 23.6 0.605 3.95 5.52 3.35 20.9 18.4 0.57 - 120 FT
19070A1 0.361 0.3524 23.6 0.605 3.43 6.5 4.32 16.5 16.8 0.52 - 114 FT
19066J1 0.3429 0.3324 23.6 0.605 2.95 6.61 4.11 15.2 16.4 0.5 - 180 FT
19066G1 0.3519 0.3429 23.6 0.605 2.44 8.2 5.37 11.4 14.5 0.43 - 180 FT
19066F1 0.3599 0.3519 23.6 0.605 2.18 9.64 6.39 9.1 13.4 0.385 - 180 FT
19066D3 0.3586 0.3503 23.6 0.605 2.02 10.1 6.72 8.4 12.9 0.355 - 180 FT
19066D4 0.3503 0.3436 23.6 0.605 1.80 8.21 5.39 9 14.1 0.6 - 180 FT
19066D5 0.3436 0.3367 23.6 0.605 1.73 11.2 6.81 6.3 13 0.31 - 180 FT
19056D2 0.3448 0.3282 23.6 0.6 4.49 4.54 2.5 41.8 20.19 0.595 - 180 FT
21020B2 0.3316 0.3184 15.7 0.61 11.97 2.75 1.4 40.75 22.1 - 25.83 61.1
21020C1 0.3118 0.2951 15.6 0.615 7.93 3.3 1.8 32.29 20.77 - 48.9 128.43
21020B1 0.3404 0.3316 15.7 0.6 3.95 6.4 4.2 14.5 15.67 0.478 - 130.8 FT
21020B3 0.3184 0.3118 15.6 0.6 2.91 7.8 4.8 10.82 13.71 0.377 - 132.7 FT
20261G1 0.3925 0.2978 12.5 0.613 6.63 4.2 2.22 - 118.3 129.9
20261C1 0.3362 0.331 12.2 0.6 2.73 10.4 5.73 7.5 11 0.284 - 130.7 FT
20261G2 0.2978 0.2917 11.9 0.611 2.66 3.8 2.8 19.77 16.48 0.5417 65.23 65.23 FT
19039C1 0.2607 0.2534 47.2 0.707 3.84 3.2 2.33 38.1 28.46 - 18.4 26 SE
19051K1 0.251 0.244 47.2 0.707 3.84 3.17 2.11 44.6 27.17 - 18.8 25 SE
19039D1 0.2534 0.2488 47.2 1.055 2.55 3.8 2.75 43.5 28.15 0.56 32.2 40.7 SE
20261J1 0.2861 0.2753 47.2 0.741 2.45 4 1.6 23.92 17.98 - 52.7 88.37 SE
19094D1 0.2785 0.2705 47.2 0.74 2.14 4.66 2.62 30.4 23.52 0.59 67.9 78.7 SE
20261J2 0.2686 0.262 47.2 0.741 1.96 4.5 1.5 20.08 19.14 - 74.5 76.53 SE
19087H1 0.2708 0.2605 47.2 0.74 1.78 5.95 3.27 17.7 18.4 0.57 - 180 FT
20261J3 0.262 0.2554 47.2 0.742 1.75 4.68 2.7 23.06 21.82 - 81.4 86 SE
~~~~

### Pagina 112

Cita: [pdf_2ada277f4accf3ff7dca, p. 112]. Metodo: native.

~~~~text
109
XO2
before 
test
XO2
after 
test ∆hc p 𝑚̇′′ 𝑞̇
+,-
.. 𝑞̇
/00
.. yf rf
Xr before 
oscilations
Osc. 
Time
Ext 
Time/end 
time
end 
condition
19094F1 0.2705 0.2614 47.2 0.707 1.67 5.33 2.95 25.5 20.41 0.56 117.85 133 SE
19087G1 0.2825 0.2708 47.2 0.707 1.47 5.05 2.93 29.9 22.42 0.6 141.63 160 SE
19094G1 0.2614 0.2524 47.2 0.74 1.19 6.7 3.8 15.25 16.6 0.49 - 180 FT
19087J2 0.2602 0.2513 47.2 0.74 1.19 6.63 3.85 14.2 16 0.49 - 180 FT
19087K1 0.2513 0.2433 47.2 0.74 1.03 7.13 4.1 12.6 14.9 0.46 - 180 FT
21020D3 0.2581 0.2542 32 0.74 3.86 3.4 1.8 - 27 31.7 SE
19063G1 0.2585 0.2535 23.6 0.71 12.16 2.92 1.57 72.7 23.4 - 11.8 28 SE
19063F1 0.2628 0.2585 23.6 0.71 8.95 2.88 1.7 59.5 22.76 - 18.4 32 SE
19063D1 0.2662 0.2628 23.6 0.71 6.03 3.41 2.3 44.1 22.03 - 18.7 33 SE
19056G1 0.2431 0.2392 23.6 0.74 5.10 3.11 1.66 28 24.48 0.52 23.45 35 SE
19056B1 0.254 0.2511 23.6 1.055 4.46 3.71 2.58 27.3 21.06 0.5 23.1 38 SE
19056F1 0.2471 0.2431 23.6 0.74 4.46 3.48 1.88 28.9 23.44 0.53 31.85 42 SE
19070K1 0.2782 0.2735 23.6 0.74 2.25 6.52 4.06 13.3 15.1 0.44 - 120 FT
19070H1 0.2735 0.2672 23.6 0.74 1.93 7.22 4.16 11.9 13.8 0.42 - 180 FT
19070L1 0.2672 0.2619 23.6 0.74 1.73 7.5 4.6 10.4 12.7 0.39 - 180 FT
21020F2 0.2648 0.2581 15.7 0.748 11.97 2.4 1.4 42.95 20.42 - 36.57 37.27 SE
21020F1 0.2716 0.2648 15.7 0.743 7.96 2.77 1.73 32.76 20.53 0.544 20.3 57.76 SE
21020D1 0.2796 0.2758 15.5 0.734 3.92 3.8 2.26 24.61 21.36 0.765 62.5 74.34 SE
21020D2 0.2758 0.2716 15.6 0.732 2.91 6 3.76 12.38 14.5 0.397 - 102.7 FT
20261H2 0.2753 0.2686 12.5 0.743 6.63 3.04 1.86 25.5 21.8 0.536 53.4 73.63 SE
20261H1 0.2917 0.2831 11.9 0.73 2.66 8.4 2.6 9.51 12.63 0.221 20.6 83.8 SE
20279J3 0.2467 0.2454 1.033 6.9 4.7 15.73 17.5 0.338 5.77 5.77 SE
20279J4 0.2454 0.2442 1.032 7.8 5 11.79 14.16 0.283 5.57 6.37 SE
20279J5 0.2442 0.2406 1.033 8.2 5.1 12.2 14.29 0.28 5.67 5.83 SE
20358G6 0.2448 0.2416 47.2 1.045 3.97 3.04 2.26 34.27 25.04 - 12.83 17.83 SE
20358G7 0.2416 0.2394 32 1.045 3.86 3.6 2.6 28.44 22.54 - 14.37 18.07 SE
20358G1 0.2508 0.2495 23.7 1.045 3.91 3.25 1.78 32.79 22.3 - 13.9 32.03 SE
20346H1 0.2536 0.2487 23.6 1.04 3.03 3.95 2.44 16.15 17.06 0.483 45.64 55.17 SE
20346H2 0.2487 0.2473 23.6 1.04 3.03 4 2.7 16.01 16.99 0.478 42.67 55.64 SE
20358G4 0.247 0.2455 15.5 1.04 3.92 4.07 3.38 13.13 13.55 0.33 11.1 28.87 SE
20358G2 0.2495 0.2478 15.5 1.04 3.92 4.05 2.93 16.64 17.38 0.476 27.94 32.67 SE
20346H4 0.2458 0.2457 15.5 1.035 2.89 5.3 4.3 10.25 13.24 0.36 29.13 47 SE
20346H3 0.2473 0.2458 15.5 1.035 2.89 5.5 3.9 11.17 14.19 0.368 33.8 49.37 SE
20346H5 0.2457 0.3874 13.2 2.23 not useful
20358G5 0.2455 0.2448 4.6 1.04 7.95 3.45 2.8 12.71 12.89 0.374 7.8 9.53
20358G3 0.2478 0.247 9.4 1.04 3.91 4.06 3.16 16.22 16.68 0.675 23.8 40.73
19039G1 0.1967 0.1904 47.2 1.01 5.13 2.31 1.42 60 27.96 - - 13 SE
19039F1 0.2009 0.1967 47.2 1.05 3.81 3.07 2.38 33 24.84 - 8.94 16 SE
19039H1 0.1867 0.184 47.2 1.05 3.07 3.9 2.67 25 23.87 0.38 13.21 17 SE
19039H2 0.184 0.1815 47.2 1.05 3.07 4.06 2.7 25.5 24.73 0.38 14.31 17 SE
19094A1 0.2209 0.2179 47.2 1.05 1.86 5.3 3.58 21.6 21.05 0.5 17.1 21 SE
19094A2 0.2179 0.2152 47.2 1.05 1.47 6.33 4.17 16 18.03 0.42 27.3 30 SE
19094A4 0.215 0.2124 47.2 1.05 1.16 6.8 4.58 18.7 15.76 0.37 31.33 37 SE
19056C1 0.2152 0.2133 23.6 1.05 4.58 3.05 2.45 28.1 21.94 0.42 13.42 19 SE
21020G4 0.2195 0.2186 15.6 1.037 3.92 3.85 2.85 20.22 19.12 0.505 13.8 14.84 SE
21020G3 0.2203 0.2195 15.6 1.039 2.86 4.8 3.35 19.04 18.3 0.625 14.94 16.44 SE
~~~~

### Pagina 113

Cita: [pdf_2ada277f4accf3ff7dca, p. 113]. Metodo: native.

~~~~text
110
6.4 An analysis of the steadiness of flames
The main objective of this analysis is to get a flammability map based on material 
properties, L and Δℎ!. For the problem of burner with constant mass flux, the heat of gasification 
can only be obtained from steady flames. Therefore, the analytical solution to these flames that is 
based on classical diffusion flames theory, is used to estimate the steadiness of these flames. 
Obviously, those flames can only be found from the set of fuel terminated tests. It is shown that 
the 49 fuel terminated flames reached 0.953 of their asymptotic height before fuel termination with 
standard deviation of 0.019 and the results are shown in Fig. 6.1. The state of the self-extinguished 
flames showed that they ranged from about 0.5 to 0.9 of their computed steady value, indicating 
they were relatively far from being steady at extinguishment.
Figure 6.1. Steadiness of flames estimated by the analytical solution to BRE flames generated 
by the 25 mm BRE burner and ethylene-diluent mixture 
0.5
0.6
0.7
0.8
0.9
1
0 100 200 300 400
lf /	lf,	st
Burn	time	(s)
SE FT Xf XO2
p 
(bar)
1 0.4 1
N/A 0.76 0.4 1
0.68 0.4 1
0.5 0.4 1
0.33 0.4 1
1 0.34 1
N/A 0.76 0.34 1
N/A 0.68 0.34 1
N/A 0.5 0.34 1
N/A 0.33 0.34 1
1 0.34 0.56
0.5 0.34 0.56
0.33 0.34 0.56
0.25 0.34 0.56
N/A 1 0.265 1
N/A 0.5 0.265 1
1 0.265 0.7
N/A 0.68 0.265 0.7
0.5 0.265 0.7
0.33 0.265 0.7
N/A 1 0.25 1
N/A 0.68 0.25 1
N/A 0.5 0.25 1
N/A 0.33 0.25 1
N/A 1 0.21 1
N/A 0.5 0.21 1
N/A 0.33 0.21 1
∆ℎ! = $" 47.2 kJ/g
~~~~

### Pagina 114

Cita: [pdf_2ada277f4accf3ff7dca, p. 114]. Metodo: native.

~~~~text
111
6.5 Measured surface heat flux at the r = 0, and 9.5 mm 
The heat fluxes at the center and offset location on the burner surface are measured at the 
end point of steady flames and reported against burner mass flux. The measured heat fluxes are 
corrected to account for the difference between the sensor and burner surface temperature . It is 
shown that as the mass flux is increased the flame grows and gets further from the surface and thus 
the surface heat flux is decreased. The center to offset heat flux ratio is increased as mass flux is 
increased. It suggests the dominance of surface radiative heat flux as the flames grow. Fig. 6.2 
shows the two local net heat flux measurements for all 49 steady flames; this is a complement to 
the same figure shown in [4,10,30,81,82].
Figure 6.2. Measured heat flux at the center and the offset location on the surface at the 
endpoints of steady flames generated by the 25 mm BRE burner and ethylene-diluent mixture 
0
2
4
6
8
10
12
0 2 4 6 8 10
heat	flux	(kw/m2s)
fuel	mixture	mass	flux	(g/m2s)
FT ∆ℎ!
kJ/g XO2 p (bar)
47.2 0.4 1
35.9 0.4 1
32.1 0.4 1
23.6 0.4 1
15.6 0.4 1
47.2 0.34 1
35.9 0.34 1
15.6 0.34 1
47.2 0.34 0.56
23.6 0.34 0.56
15.6 0.34 0.56
11.8 0.34 0.56
47.2 0.265 0.7
23.6 0.265 0.7
15.6 0.265 0.7
Solid symbols: CTR HF
Open symbols: Offset HF
~~~~

### Pagina 115

Cita: [pdf_2ada277f4accf3ff7dca, p. 115]. Metodo: native.

~~~~text
112
6.6 Heats of gasification
The heat of gasification, L, is obtained by dividing the arithmetic average of the two 
measured net heat flux at the surface (Fig. 6.2) by fuel mixture mass flux (See Eqn. (6.1)) Eqn. 
(6.2) elaborates the surface net heat flux, 𝑞̇
450
$$ , components that can be calculated. The computation 
algorithm first introduced in [52] allows computation of heat of gasification by calculating the heat 
flux components shown by Eqns. (6.2 to 6.5). 
𝐿 = 𝑞̇
450
$$
𝑚̇
$$ (6.1)
where the RHS consists of four terms (see Eq. (6.2))
𝑞̇
450
" = 𝑞̇
7,!
" + 𝑞̇
7,,
" − 𝑞̇
,,
" + 𝑞̇
5@0,, " (6.2)
𝑞̇
7,!
" : Flame convective heat flux
𝑞̇
7,,
" ∶ Flame incident radiative heat flux
𝑞̇
,,
" ∶ Surface radiative loss heat flux
𝑞̇
5@0,, " ∶ Incident external radiative heat flux that is not present in this analysis
The average of each component can be calculated by Eqns. (6.3 to 6.5)
~~~~

### Pagina 116

Cita: [pdf_2ada277f4accf3ff7dca, p. 116]. Metodo: native.

Calidad: table_structure_not_manually_validated.

~~~~text
113
𝑞̇
! ööö$$ö = y 4𝑘
𝜋𝑅𝑐;
| õ λ
𝑒Q −1
ùP
∆ℎ!(1 − 𝑋,)𝑌9,*
𝑆 − 𝑐;(𝑇' − 𝑇*)R (6.3)
𝑞̇
7,, öö$$
ööö = 𝐹7→'𝑄̇
,/2
𝜋𝑅: = 𝐹7→'𝑋,𝑚̇
$$∆ℎ!
2 (6.4)
𝑞̇
,,
$$ = 𝜀'𝜎(𝑇'
) − 𝑇*
)) (6.5)
where 𝑆 = ∆F.
∆F6!
, and 𝐹7→' is the geometrical view factor of the burner surface (subscript s) with 
respect to the flame sheet (subscript f).
Figure 6.3. Calculated radiative and convective heat flux for steady flames generated by the 
25 mm BRE burner and ethylene-diluent mixture
0
1
2
3
4
5
6
7
8
9
0 2 4 6 8
Average convective heat flux (kJ/g)
fuel mixture mass flux (g/m2s)
0
1
2
3
4
5
6
7
8
9
0 2 4 6 8
Average convective heat flux (kJ/g)
fuel mixture mass flux (g/m2s)
0
1
2
3
4
5
6
7
8
9
0 2 4 6 8
Average steady heat flux (kW/m2)
fuel mixture mass flux (g/m2
s)
!̇
!!
",$ !̇
!!
",% !̇
!!
FT ∆ℎ!
kJ/g XO2 p (bar)
47.2 0.4 1
35.9 0.4 1
32.1 0.4 1
23.6 0.4 1
15.6 0.4 1
47.2 0.34 1
35.9 0.34 1
15.6 0.34 1
47.2 0.34 0.56
23.6 0.34 0.56
15.6 0.34 0.56
11.8 0.34 0.56
47.2 0.265 0.7
23.6 0.265 0.7
15.6 0.265 0.7
~~~~

### Pagina 117

Cita: [pdf_2ada277f4accf3ff7dca, p. 117]. Metodo: native.

~~~~text
114
The average flame convective heat flux is calculated by using the analytical solution introduced in
[10,46–48,55]. Total radiative heat loss is measured by remote radiometers and the radiative loss 
fraction is correlated with a dimensionless parameter, W, and it is used to estimate the average 
radiative heat flux to the surface [52]. The average radiative heat flux is estimated by using the 
geometrical view factor of the fuel source with respect to the flame sheet, a quantity that 
determines the ratio of the total flame radiation impinging the surface. The re-radiation from the 
surface is calculated by using Eq. (6.5) with surface emissivity of unity. The trends of calculated 
average radiative, and convective heat flux against mass flux are presented and compared with the 
trend of average heat flux vs. mass flux in Fig. (6.3). It is shown that as mass flux is increased, the 
flame size gets larger and in general, the portion of total radiative heat that impinges the surface is 
increased. It explains the reason for the radiative heat flux becoming dominant over the surface as 
mass flux is increased. Accuracy of computation algorithm is supported by comparing the 
calculated, and measured heats of gasification, shown in Fig. (6.4). 
Figure 6.4. Calculated vs. measured average heat flux for steady flames generated by the 25 
mm BRE burner and ethylene-diluent mixture
0
2
4
6
8
10
12
0 2 4 6 8 10 12
Calculated	average	heat	flux	(kW/m2)	
Measured	average	heat	flux	(kW/m2)
FT ∆ℎ!
kJ/g XO2 p (bar)
47.2 0.4 1
35.9 0.4 1
32.1 0.4 1
23.6 0.4 1
15.6 0.4 1
47.2 0.34 1
35.9 0.34 1
15.6 0.34 1
47.2 0.34 0.56
23.6 0.34 0.56
15.6 0.34 0.56
11.8 0.34 0.56
47.2 0.265 0.7
23.6 0.265 0.7
15.6 0.265 0.7
~~~~

### Pagina 118

Cita: [pdf_2ada277f4accf3ff7dca, p. 118]. Metodo: native.

~~~~text
115
Now, the heat flux components presented in Fig. (6.3) are divided by mass flux to present their 
contribution to the L. The results are shown in Fig. (6.5) and the computed heats of gasification 
are compared with measured counterparts in Fig. (6.6) to show the accuracy of the computation 
algorithm [52]. The scatter of radiative heat flux against mass flux is reduced significantly because 
of dividing by mass flux. Variations in ∆ℎ! among the steady data causes the scatter of radiative 
heat flux when shown just against mass flux (Fig. (6.3)). There is a descending trendline for each 
∆ℎ! when surface heat flux is analyzed. As heat flux is divided by fuel mixture mass flux (as shown 
Figure 6.5. Contribution of heat flux components to calculated heat of gasification for steady 
flames generated by the 25 mm BRE burner and ethylene-diluent mixture
0.01
0.1
1
10
0 2 4 6 8 10
fuel	mixture	mass	flux	(g/m2s)
0.01
0.1
1
10
0 2 4 6 8 10
fuel mixture mass flux (g/m2s)
!̇ L !!
",$
#̇
!!
0.1
1
10
0 5 10
(kJ/g)
fuel mixture mass flux (g/m2
s)
!̇
!!
",%
#̇
!!
FT ∆ℎ!
kJ/g XO2 p (bar)
47.2 0.4 1
35.9 0.4 1
32.1 0.4 1
23.6 0.4 1
15.6 0.4 1
47.2 0.34 1
35.9 0.34 1
15.6 0.34 1
47.2 0.34 0.56
23.6 0.34 0.56
15.6 0.34 0.56
11.8 0.34 0.56
47.2 0.265 0.7
23.6 0.265 0.7
15.6 0.265 0.7
~~~~

### Pagina 119

Cita: [pdf_2ada277f4accf3ff7dca, p. 119]. Metodo: native.

~~~~text
116
in Fig. 6.5), the effect of ∆ℎ! is removed and the data collapse into a finer region. However, in 
addition to ∆ℎ!, XO2, and Xr (and slightly p) are still affecting the trends shown in Fig. (6.5)
6.7 The flammability maps
Two of the key material properties that are used to emulate condensed phase burning are heat of 
combustion and heat of gasification. In diagrams that were shown in previous chapters [51], the 
heat of gasification was plotted against fuel mixture mass flux. The heat of combustion was found 
from the legend of the plot and emulation was performed by drawing horizontal lines (to match 
the heat of gasification) through the diagram and matching the real fuel properties with a data point 
with similar heat of combustion at the crossing location. This was shown and explained in the 
previous chapter. In this chapter, both material properties are presented as the axis of the plot 
enabling one to place real material properties as “points” on the plot and emulation is performed 
Figure 6.6. Calculated vs. measured heats of gasification for steady flames generated by the 25 
mm BRE burner and ethylene-diluent mixture
0
1
2
3
4
5
6
7
8
9
10
0 2 4 6 8 10
calculated	
L (kJ/g)
measured	L (kJ/g)
FT ∆ℎ!
kJ/g XO2
p 
(bar)
47.2 0.4 1
35.9 0.4 1
32.1 0.4 1
23.6 0.4 1
15.6 0.4 1
47.2 0.34 1
35.9 0.34 1
15.6 0.34 1
47.2 0.34 0.56
23.6 0.34 0.56
15.6 0.34 0.56
11.8 0.34 0.56
47.2 0.265 0.7
23.6 0.265 0.7
15.6 0.265 0.7
~~~~

### Pagina 120

Cita: [pdf_2ada277f4accf3ff7dca, p. 120]. Metodo: native.

~~~~text
117
when a burner generated flame data point and the real material data point fall reasonably close to 
each other on the plot. 
Before addition of real material properties to the flammability maps, the trends observed in the 
plots are discussed (See Fig. 6.7 to 6.9). The flammability map is obtained for each ambient 
nominal XO2. The data points fall in between two extinction limits:
1. Radiative extinction limit: It is observed for large flames where the mass flux is increased 
and radiative heat loss increases [51], or the radiative fraction increases with mass flux, the 
flame grows until the chemical reaction stops (see Figs. 6.9 to 6.11, middle plot, where 
moving to the left of the plots is equivalent to increase in mass flux). The red curves shown 
on each flammability map indicate the radiative extinction limit and shown as a range that 
correspond to critical temperature range of 1100 to 1200 K [60]. The curves have a 
theoretical basis that is discussed in [52] and briefly explained herein:
The ∆ℎ!, and YO2 are given and varied through the range corresponding to the experiments. The 
Flame height and radius are computed by using Eqns. (6.6, 6.7). Parameter “c” in Eq. (6.7) is used 
to correct the computed flame radius to match the measurement [34].
𝑥7
𝑅 = tan h
𝜋
2 ü1 +
ln B 𝛼
𝛼 + 1F
𝜆 †u (6.6)
𝑟7
𝑅 = °1 + 𝑐 B
𝑥7
𝑅 F
:
(6.7)
Where 𝜆 = 𝑚̇
$$⁄4𝑘/(𝜋𝑐; R), and 𝛼 = ∆ℎ!/∆ℎ!,9:𝑌9,*. Radiative loss fraction, Xr, was obtained 
based on the steady data points at their end points. The steady data was correlated with a 
dimensionless parameter, shown by Eq. (6.8), which is based on radiation theory. A power function 
fit was passed through the data points when Xr was plotted against W based on the method of least 
squares. 𝜅7is found from [52], flame height are computed from Eq. (6.6), and (6.7), and 𝑇7,- is the
~~~~

### Pagina 121

Cita: [pdf_2ada277f4accf3ff7dca, p. 121]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
118
calculated flame temperature assuming no radiative heat loss and is given by: 𝑐;q𝑇7,- − 𝑇*s =
1⁄1 + 𝑎𝑌P/ ò𝑐;(𝑇' − 𝑇*) − 𝑌P/∆ℎ!ô.
W = (𝜎𝑇*
) 𝑚̇
$$ ⁄ Δℎ!)(1 − 𝑒BU7@7)q𝑥7⁄𝑅s
:
q𝑇7,-⁄𝑇*s
) (6.8)
From Figure 6.7 one can find the absorption coefficient, and then the emissivity term in W. 
It should be pointed out that the path length shown on the absicissa, is flame height. It varies for 
the BRE data from about 5 to 50 mm, indicating a modified absorption coefficient of about 7.5 to 
4.5 (m-bar)-1
, respectively. This corresponds to emissivity in the range of 0.01 to 0.1.
Figure 6.7. Absorption coefficients normalized by partial pressures of combustion products of 
ethylene
~~~~

### Pagina 122

Cita: [pdf_2ada277f4accf3ff7dca, p. 122]. Metodo: native.

Calidad: table_structure_not_manually_validated.

~~~~text
119
The absorption coefficient can be computed from the fitted Eqns. (6.9 and 6.10). where the 
Eq. (6.10) includes the sum of partial pressures of water vapor and carbon dioxide, 𝑝6!9 = 𝑝%6! =
¶2
2 + 2 + 3q1 − 𝑋9! 𝑋9! ⁄ s + 1 − 𝑋%!65 𝑋%!65
Å ⁄ æ 𝑝.
¶
𝜅̃(mBCbarBC) = 7.96𝑒BV.W3@7 𝑓𝑜𝑟 𝑥7 ≤ 0.1 m
𝜅̃(mBCbarBC) = 0.94𝑥7
B1.3) 𝑓𝑜𝑟 𝑥7 > 0.1 m
(6.9)
𝜅(𝑚BC) =
⎩
⎨
⎧ 4
2 + 2 + 3 B
1 − 𝑋9
𝑋9
F +
1 − 𝑋%!65
𝑋%!65 ⎭
⎬
⎫
𝑝(𝑏𝑎𝑟). 𝜅̃(𝑚BC𝑏𝑎𝑟BC) (6.10)
And Radiative loss fraction is found from Fig. 6.8, and Eq. (6.11)
𝑋, = 0.49Ω1.C: (6.11)
Now one can compute the components of surface heat flux, the quantities required for computation 
of L. The heat flux components were initially introduced in Eqns. (6.2-6.5) but are presented here 
for convenience in following the concept. The net heat flux contains four components where 
external radiation is not present in these experiments (See Eq. (6.12)). 
𝑞̇
450
$$ = 𝑞̇
7,!
$$ + 𝑞̇
7,,
$$ − 𝑞̇
,,
$$ + 𝑞̇
5@0,, $$ (6.12)
The average convective heat flux is computed by using the analytical solution to these flames 
[49,52] shown by Eq. (6.13).
𝑞̇
! ööö$$ö = y 4𝑘
𝜋𝑅𝑐;
| õ λ
𝑒Q −1
ùP
∆ℎ!(1 − 𝑋,)𝑌9,*
𝑆 − 𝑐;(𝑇' − 𝑇*)R (6.13)
~~~~

### Pagina 123

Cita: [pdf_2ada277f4accf3ff7dca, p. 123]. Metodo: native.

~~~~text
120
Where heat conductivity, k, and specific heat, cp, are those of Nitrogen at 1400 K. Average 
radiative heat flux is computed using a geometrical model based on radiation view factor of the 
burner surface with respect to the flame sheet, 𝐹7→' (See Eq. (6.15)), that leads to calculation of 
the portion of total radiative heat loss that impinges the surface, which is given by Eq. (6.14)
𝑞̇
7,, öö$$
ööö = 𝐹7→'𝑄̇
,/2
𝜋𝑅: = 𝐹7→'𝑋,𝑚̇
$$∆ℎ!
2 (6.14)
Where
𝐹7→' = P;→7 c;
c7
(6.15)
The 𝐹'→7 = 1, and the flame sheet surface area, Af, is estimated by assuming a half ellipsoid shape 
for the flame and that area is calculated by Eq. (6.16).
𝐴7 = ü
2𝜋 B𝑟7
X.: + 2q𝑟7𝑥7s
C.Y
F
3 †
C
C.Y
(6.16)
The re-radiative heat flux is calculated from Eq. (6.17), where surface emissivity is unity, and
surface temperature is assumed to be 353.15 K, a representative surface temperature.
Figure 6.8. Radiative loss fraction empirical correlation resulted from a dimensional analysis of 
radiometry
y	=	0.49x0.12
R²	=	0.87
0.2
0.4
0.8
0.01 0.1 1 10 100
Xr
Ω
Ω = #$!
"
%̇
##∆ℎ$
1 − +%&!'!
,(
-
) $(,+
$!
"
FT ∆ℎ"
kJ/g XO2
p 
(bar)
35.9 0.4 1
23.6 0.4 1
15.6 0.4 1
35.9 0.34 1
15.6 0.34 1
47.2 0.34 0.56
23.6 0.34 0.56
15.6 0.34 0.56
11.8 0.34 0.56
47.2 0.265 0.7
23.6 0.265 0.7
15.6 0.265 0.7
~~~~

### Pagina 124

Cita: [pdf_2ada277f4accf3ff7dca, p. 124]. Metodo: native.

~~~~text
121
𝑞̇
,,
$$ = 𝜀'𝜎(𝑇'
) − 𝑇*
)) (6.17)
Where 𝑎 = ∆ℎ!⁄∆ℎ!,-𝑌-,*, and c is a correction factor that makes the predicted flame radius equal 
to measured counterparts and is found to be 0.35. Now we apply the extinction criteria to the steady 
flame temperature formula (Eq. (6.18)). The Tf is set to the critical value of 1100, or 1200 K, and 
one solves for the corresponding L and ∆ℎ!, for a given 𝑌9:. But Eqns. (6.6 to 6.18) are a set of 
implicit equations that should be solved numerically and by substituting values. The steady mass 
flux, 𝑚̇
$$at the extinction point defined by a critical flame temperature of 1100 or 1200 K. The 
equations are solved numerically to obtain the radiative extinction limit. The procedure starts by 
setting 𝑌9:, substituting a range of ∆ℎ! (0 to 47.2 kJ/g), and finding the mass flux that leads to 
𝑇7 = 𝑇!, = 1100, or 1200 K. 
In order to find the mass flux, the Microsoft Excel built-in optimizer toolkit, solver is utilized to 
minimize the resulting 𝑇7 difference with the critical temperature (i.e., minimizing q𝑇7 − 𝑇!,s
:
).
𝑐;q𝑇7 − 𝑇*s = 1
1 + 𝑎𝑌P/
ò𝑐;(𝑇' − 𝑇*) − 𝑌P/∆ℎ!(1 − 𝑋,)ô (6.18)
Now, a radiative extinction limit range is found for each 𝑋9:.
The procedure to compute the extinction limits is summarized here. Assuming steady state, we 
iterate mass flux and calculate L that corresponds to high mass flux, or radiative extinction limit.
• Given parameters: XO2, p, Ts, and ∆ℎ!. 
• Thirteen Equations: Flame height, Xr, Tf, 𝑞̇
#,/ ff..
fff, 𝑞̇
#,( fff..ff, 𝑞̇
((
.. , L with Tf chosen as 1100 K or 
1200 K
• The number of unknowns is thirteen (𝑥7, 𝑟7, 𝜅, 𝐹7→', Ω, Af, Xr, Tf, 𝑞̇
#,/ fff..ff, 𝑞̇
#,( ff..
fff, 𝑞̇
((
.. , 𝑚̇
.., L,) 
The Eqns. (6.6 to 6.18) have enough information to solve for mass fluxes that satisfy the 
nonlinear algebraic set.
• Excel solver is utilized to guess mass flux and converge to a value that corresponds to the 
critical Tf (1100 K or 1200 K); It results in the points on the radiative limit.
~~~~

### Pagina 125

Cita: [pdf_2ada277f4accf3ff7dca, p. 125]. Metodo: native.

~~~~text
122
2. Small flame extinction limit range is obtained by following the same procedure for the 
radiative extinction limit, i.e., through Eqns. (6.6 to 6.17). As will be shown in the Figs. 
6.9 to 6.11, middle plot, flames can be extinguished from radiative heat loss and heat loss 
to the burner surface. Both extinction limits correspond to flame cooling down to the 
mentioned critical flame temperature range. Therefore, the optimizer outputs are two mass
fluxes, the maximum 𝑚̇
$$ that corresponds to radiative extinction limit, and the minimum 
𝑚̇
$$that corresponds to small flames extinction limit.
3. Pure convective extinction limit is a hypothetical ideal case, obtained based on refs. 
[67,76]where small flames are assumed to have no radiative heat loss (and thus no radiative 
heat flux to the fuel source) and the conductive heat loss to the fuel source causes the flame 
temperature to drop down and chemical reaction stops. The convective extinction limit is 
found by plugging in the critical flame temperature of 1100 K in the analytic solution for 
flame temperature and neglecting Xr, 𝑞̇
,,
$$ , and 𝑐;(𝑇' − 𝑇*). The formulation is shown in 
Eqns. 6.19 to 6.21. 
𝐿> = 𝐿 + 𝑞̇
,,
$$
𝑚̇
$$ (6.19)
𝑐;q𝑇7 − 𝑇*s = Δℎ! − 𝐿> − 𝑐;(𝑇' − 𝑇*)
1 +
Δℎ!
Yd:Δℎ!,9:
(6.20)
Δℎ! = 𝑐;q𝑇7 − 𝑇*s + 𝐿
1 − 𝑐;q𝑇7 − 𝑇*s
Yd:Δℎ!,9:
(6.21)
On each flammability map shown in Figs. 6.9 to 6.12, two red curves indicate radiative extinction 
limit range for 1100 and 1200 K, and the two light blue curves correspond to small flame extinction 
limit range, accordingly. The pure convective extinction limit shows an ideal case where flames 
are so small that negligible radiative heat loss is emitted from the flames. The critical flame 
temperature of 1100 K, results in a larger flammable zone, i.e., the zone in between the two outer 
extinction limits, and the 1200 K results in a smaller flammable zone. As the ambient 𝑋9: is
~~~~

### Pagina 126

Cita: [pdf_2ada277f4accf3ff7dca, p. 126]. Metodo: native.

~~~~text
123
decreased the flammable zone area is decreased and the critical extinction range is increased. This 
shows 
Where Δℎ!,9: = Δℎ!⁄𝑆 = 13.76 𝑘𝐽⁄𝑔. There are also theoretically prediction curves shown on 
each plot shown by either dashed or solid-colored lines indicating the general trend. For the 
theoretical lines, the calculated L introduced in previous section are used.
Figs. (6.9 to 6.11) presents three flammability maps for ambient nominal XO2 of 0.4, 0.34 and 
0.265 shown in the top. The p was shown to have minimal effect on burning conditions [51,52]. 
The three ambient conditions are chosen to match the conditions where, steady flames were 
observed in the experiments. The dashed horizontal lines shown on the plots indicate theoretical 
predictions for the range of flammability for each heat of combustion. The criterial for identifying 
steady flames were like that shown in the previous chapters, using a critical temperature range of 
1100 to 1200 K. The radiative extinction limit shifts to the higher L, that is equivalent to lower 
mass burning rate, as heat of combustion is increased resulting in a slopped line shown on the 
flammability maps. The reason is that as heat of combustion is increased the flame size gets larger 
for the same mass burning rate. Therefore, the radiative extinction limit occurs at higher heats of 
gasification as heat of combustion is increased. 
The radiative loss fraction, Xr, can be predicted by using the correlation introduced in [52]
that was adjusted by adding more data [60]. The trends of Xr against L are shown for each 
∆ℎ!introduced in the flammability maps (The middle plot of Figs. 6.9 to 6.11). It illustrates the 
trend of Xr for each horizontal line on the flammability maps (indicating constant heat of 
combustion). At low L as expected, the self-extinguished data points are observed until the first 
steady flames are observed at Xr of ~ 0.65 for XO2 of 0.4, ~ 0.6 for XO2 of 0.34 and ~ 0.55 for XO2
of 0.265. Xr is decreased monotonically with L and is increased with ∆ℎ!. The modeled Xr shown 
by colored lines confirms these trends.
~~~~

### Pagina 127

Cita: [pdf_2ada277f4accf3ff7dca, p. 127]. Metodo: native.

~~~~text
124
The flame temperatures at flame sheet, Tf ,assuming complete reaction are calculated [49,52]
and shown on the bottom plots of Figs. 6.9 to 6.11. The trends shown by calculated Tf, are 
accompanied by more scatter that reveals the limitations of using a theoretical model that uses 
constant properties (i.e., cp and k for Nitrogen at 1400 K) to estimate flame properties. However, 
it gives valuable information of how flame temperature behaves by changing heats of combustion 
and heats of gasification, as the two key material properties used for burning emulations. 
Calculated Tf is increased by heat of combustion but first increases by heat of gasification until it 
reaches to its peak and then starts to decrease suggesting a parabolic shaped curves when plotted 
against heat of gasification. The reason for having a dome shaped curve is that there is a tradeoff 
between the sources of flame heat loss. For low heats of gasification, the flames are closer to their 
radiative extinction limit and cool down due to radiative heat loss compared to the small flames 
with higher heats of gasification, where heat loss to the fuel source is dominant and causes flame 
cooling down. At some point, the two sources of heat loss provide a situation in favor of Tf and 
thus, steady burning. The peak temperature moves to the right of the plots as heat of combustion 
is increased. By comparing the plots presented in the bottom of Figs. 6.9 to 6.11, one finds out that 
decreasing the ambient nominal XO2 decreases the steady flame temperature. Theoretical 
predictions shown by solid-colored lines confirm such a trend.
~~~~

### Pagina 128

Cita: [pdf_2ada277f4accf3ff7dca, p. 128]. Metodo: native.

~~~~text
125
Figure 6.9. The flammability map for nominal XO2 of 0.4 along with trends of calculated Xr, and 
calculated Tf at flame sheet for steady flames generated by ethylene-diluent mixture and 25 mm 
burner.
open SE
solid Steady
Flame size
∆ℎ!
0
10
20
30
40
50
0 1 2 3 4 5 6 7 8
Heat	of	combustion	(kJ/g)
Small	Flame	Ext.	Limit	Range
Pure	Conv.	Ext.	Limit
Flame Size
Rad.	Ext.	Limit	Range
0
0.2
0.4
0.6
0.8
1
0 1 2 3 4 5 6 7 8
Xr
Heat	of	gasification	(kJ/g)
1100
1200
1300
1400
1500
0 1 2 3 4 5 6 7 8
Calculated	flame		temperature(K)
Heat	of	gasification	(kJ/g)
Flame size
colors
∆"!
(kJ/g)
Black 47.2
Blue 35.6
Red 23.6
Green 15.6
XO2 =	0.4
Line Type
Ext. 
Limit 
Temp.
Dashed 1200 K
Solid 1100 K
~~~~

### Pagina 129

Cita: [pdf_2ada277f4accf3ff7dca, p. 129]. Metodo: native.

~~~~text
126
Figure 6.10. The flammability map for nominal XO2 of 0.34 along with trends of calculated Xr,
and calculated Tf at flame sheet for steady flames generated by ethylene-diluent mixture and 25 
mm burner.
0
5
10
15
20
25
30
35
40
45
50
0 1 2 3 4 5 6 7 8
Heat	of	combustion	(kJ/g)
0
0.2
0.4
0.6
0.8
1
0 1 2 3 4 5 6 7 8
Xr
Heat	of	gasification	(kJ/g)
∆ℎc
1100
1200
1300
1400
1500
Calculated	flame		temperature(K)
0 1 2 3 4 5 6 7 8
Heat	of	gasification	(kJ/g)
open SE
solid Steady
XO2 =	0.34
colors
∆#!
(kJ/g)
Black 47.2
Blue 35.6
Red 23.6
Green 15.6
Flame size
Flame size
Flame size
Small	Flame	Ext.	Limit	Range
Rad. Ext. Limit Range
Pure	Conv.	Ext.	Limit
Line Type
Ext. 
Limit 
Temp.
Dashed 1200 K
Solid 1100 K
~~~~

### Pagina 130

Cita: [pdf_2ada277f4accf3ff7dca, p. 130]. Metodo: native.

~~~~text
127
Figure 6.11. The flammability map for nominal XO2 of 0.265 along with trends of calculated Xr, 
and calculated Tf at flame sheet for steady flames generated by ethylene-diluent mixture and 25 
mm burner
0
5
10
15
20
25
30
35
40
45
50
0 1 2 3 4 5 6 7 8
Heat	of	combustion	(kJ/g)
0
0.2
0.4
0.6
0.8
1
0 1 2 3 4 5 6 7 8
Xr
Heat	of	gasification	(kJ/g)
1100
1200
1300
1400
1500
0 1 2 3 4 5 6 7 8
Calculated	flame		temperature(K)
Heat	of	gasification	(kJ/g)
colors
∆"!
(kJ/g)
Black 47.2
Blue 35.6
Red 23.6
Green 15.6
open SE
solid Steady
XO2 =	0.265
∆ℎ!
Flame size
Flame size
Flame size
Rad. Ext. Limit Range
Pure	Conv.	Ext.	Limit
Line Type
Ext. 
Limit 
Temp.
Dashed 1200 K
Solid 1100 K
~~~~

### Pagina 131

Cita: [pdf_2ada277f4accf3ff7dca, p. 131]. Metodo: native.

Calidad: table_structure_not_manually_validated.

~~~~text
128
Figs. 6.9 to 6.11 elaborated the trends of Tf and Xr for each XO2 and ∆ℎ!. Now, the effect of XO2 on 
the Tf is shown in Fig. 6.10. As expected, oxygen enriched environments, generally increase the 
flame temperature which is more hazardous. To minimize the effect of ∆ℎ!, and see the effect of 
XO2 more clearly, the abscissa of the plots shown in Fig. 6.12, is chosen to be 𝐿/∆ℎ! which resulted 
in collapsing the Tf curves in a narrower range. However, ∆ℎ! still affects these curves through 
changing the Xr which explains the small horizontal displacement of these curves.
Table 6.2 shows some of the widely used material L and ∆ℎ!. These quantities are material 
properties and thus can be obtained by cone calorimeter in normal gravity as explained in the 
introduction. The BRE experiments are focused on emulating such material generated flames by 
matching L, ∆ℎ!, Tb, and ls (laminar smoke point). Again, Tb is the material burning temperature 
that is related to the un-controlled burner surface temperature. It was shown that the normal gravity 
emulations were successful without matching Tb. Smoke point was not applicable to microgravity 
flames because no soot was observed at steady state and emulation was performed by matching 
the two significant material properties, L and ∆ℎ!, that are used as the axis of the flammability 
maps for XO2 of 0.265, 0.34, and 0.4. This allows showing material properties as “crosses” on the 
flammability maps while the other colored symbols are burner generated flames, all shown in Fig. 
6.13. For example, let us take PMMA that is close to a yellow circle (XO2 of 0.4), a green triangle 
(XO2 of 0.34), and a red square (XO2 of 0.265). For the first two case, the corresponding test is the 
Figure 6.12. The calculated flame temperature plotted against L/∆hc for nominal XO2 of 0.4, 
0.34, and 0.265
0 0.05 0.1 0.15 0.2 0.25 0.3
!/∆ℎ!
0 0.05 0.1 0.15 0.2 0.25 0.3
!/∆ℎ!
1100
1150
1200
1250
1300
1350
1400
1450
1500
0 0.05 0.1 0.15 0.2 0.25 0.3
Calculated	Tf (K)
!/∆ℎ!
open SE
solid Steady
XO2 = 0.4 XO2 = 0.34 XO2 = 0.265
Flame size
∆ℎ!
colors
∆%"
(kJ/g)
Black 47.2
Blue 35.6
Red 23.6
Green 15.6
Flame size Flame size
Rad. Ext.
Kinetic Ext.
Rad. Ext.
Kinetic Ext.
Rad. Ext.
Kinetic Ext.
~~~~

### Pagina 132

Cita: [pdf_2ada277f4accf3ff7dca, p. 132]. Metodo: native.

~~~~text
129
PMMA emulated flame and since it falls in the flammable zone, the region in between the radiative 
and pure convective extinction limits shown by slopped lines, it suggests that PMMA burns 
steadily at XO2 of 0.4, and 0.34. But, for the last case, XO2 of 0.265, since the PMMA point falls in 
the extinction zone, the region to the left of radiative extinction limit.
In general, materials that fall in the flammable region identified in Figure 6.13, that have high ∆ℎ!
and low L, such as PE and PP impose more risk to the fire-safety of spacecrafts because of higher 
heat release rate, and larger size that can better reach the surrounding and have more radiation 
emittance, an important factor for fire growth and spread.
The radiative, small flame, and pure convective extinction limits are based on theory [52], and 
there are some steady flames in the extinction region. Also, the horizontal double solid line 
indicates the minimum ∆ℎ!, required for ignition that was observed in the experiments. It shown 
that the minimum ∆ℎ!, required for ignition increases slightly from 10 to 12, and 13 when XO2 is 
decreased from 0.4, to 0.34, and 0.265, respectively. This limitation is due to the approximate 
nature of the calculated values, especially, average surface radiative heat flux. Also, the 𝑌9: are 
assumed to be constant and at their nominal values of 0.43, 27, and 29 compared to the actual 
experimental values that deviate up to 10% from their nominal value at the end of each test. This 
explains the inaccuracy observed in the flammability maps related to the extinction limits.
~~~~

### Pagina 133

Cita: [pdf_2ada277f4accf3ff7dca, p. 133]. Metodo: native.

Calidad: table_structure_not_manually_validated.

~~~~text
130
Table 6.2. Some of the commonly used materials heats of combustion and heats of gasification
[67,74]
Materials Δℎ/
kJ/g
L
kJ/g
Liquids
Acetone 30.8 0.63
Ethanol 26.8 1.00
Methanol 19.8 0.74
Ordinary Polymers
Epoxy 25 2.3
PE, Polyethylene 43.4 1.9
HDPE, High density polyethylene 40 2.0, 2.2
PP, Polypropylene 44 2.0
Nylon 6 28.8 1.4
PMMA 24.2 1.6
Textiles
Acrylic fiber 27.5 4.6
Wool 19.5 3.9
~~~~

### Pagina 134

Cita: [pdf_2ada277f4accf3ff7dca, p. 134]. Metodo: native.

~~~~text
131
Now, all the extinction limits for each XO2, and for the critical flame temperatures of 1100 K, and 
Figure 6.13. The flammability map for nominal XO2 fractions of 0.4, 0.34, and 0.265 
along with real material properties shown as colored crosses.
0
5
10
15
20
25
30
35
40
45
50
0 1 2 3 4 5 6 7 8
Heat	of	combustion	(kJ/g)
Heat	of	gasification	(kJ/g)
0
5
10
15
20
25
30
35
40
45
50
0 1 2 3 4 5 6 7 8
Heat	of	combustion	(kJ/g)
Heat	of	gasification	(kJ/g)
0
5
10
15
20
25
30
35
40
45
50
0 1 2 3 4 5 6 7 8
Heat	of	combustion	(kJ/g)
Heat	of	gasification	(kJ/g)
PE
PP
HDPE
Acetone Nylon 6
Epoxy
PMMA
Acrylic fiber
Methanol
Wool
Rad. Ext. Limit Range
Pure	Conv.	Ext.	Limit
PE PP
HDPE
Acetone Nylon 6
PMMA Epoxy
Acrylic fiber
Methanol
Wool
Rad. Ext. limit Range
Pure	Conv.	Ext.	Limit
PE
PP
HDPE
Acetone Nylon 6
Epoxy PMMA
Acrylic fiber
Methanol
Wool
Rad. Ext. Limit Range
Pure	Conv.	Ext.	Limit
Small	Flame	Ext.	Limit	Range
Small	Flame	Ext.	Limit	Range
Small	Flame	Ext.	Limit	Range
SE FT ∆ℎ!
kJ/g XO2
p 
(bar)
47.2 0.4 1
N/A 35.9 0.4 1
32.1 0.4 1
23.6 0.4 1
15.6 0.4 1
47.2 0.34 1
N/A 35.9 0.34 1
N/A 32.1 0.34 1
N/A 23.6 0.34 1
N/A 15.6 0.34 1
47.2 0.34 0.56
23.6 0.34 0.56
15.6 0.34 0.56
11.8 0.34 0.56
N/A 47.2 0.265 1
N/A 23.6 0.265 1
47.2 0.265 0.7
N/A 32.1 0.265 0.7
23.6 0.265 0.7
15.6 0.265 0.7
Line Type
Ext. 
Limit 
Temp.
Dashed 1200 K
Solid 1100 K
XO2 = 0.4
XO2 = 0.34
XO2 = 0.265
~~~~

### Pagina 135

Cita: [pdf_2ada277f4accf3ff7dca, p. 135]. Metodo: native.

~~~~text
132
1200 K are shown in Fig. 6.14. First, generally the flammability region is decreased when the XO2
is decreased, i.e., the extinction limits get closer to each other as oxygen concentration is reduced. 
The radiative extinction limit does not change much when the Tcr = 1100 K but it changes 
significantly when Tcr = 1200 K, and for the lowest XO2. On the other hand, the small flame 
extinction limit always tends to narrow down the flammability region as XO2 is reduced which 
suggests the higher dependency of this limit to the ambient oxygen. The same approach was used 
to plot the extinction limits and thus, a theoretical flammability region for XO2 = 0.15, which 
confirmed that there is no flammable region for that ambient condition.
The choice of critical temperature affects the flammability region. The widely used range as 
discussed herein is 1100 to 1200 K. However, the computation algorithm allows obtaining a 
flammability region based on the given critical temperature. The flammability map was shown for 
critical temperatures of 1100, 1200, 1300, and 1400 K. The extinction limits get closer to each 
other as the critical temperature is increased. For the Tcr = 1300, and 1400 K, no flammable zone 
was found at XO2 = 0.265, and XO2 = 0.265, and 0.34, respectively. The maximum achievable flame 
temperature in an ambient with XO2 = 0.4, was found to be 1420 K. In other words, for the ambient 
conditions considered in this study, the flame temperatures did not exceed 1420 K. The effect of 
Figure 6.14. Flammability regions dependency on the nominal XO2, shown for the critical 
flame temperatures of 1100 K, to 1400 K
0
10
20
30
40
50
60
0 2 4 6 8 1012141618
Heat	of	Gasification	(kJ/g)
Tcr = 1400 K
XO2 = 0.4
0
10
20
30
40
50
60
0 2 4 6 8 1012141618
Heat	of	Gasification	(kJ/g)
XO2 = 0.34, 0.4
Tcr = 1300 K
0
10
20
30
40
50
60
0 2 4 6 8 1012141618
Heat	of	Gasification	(kJ/g)
XO2 = 0.265, 0.34, 0.4
Tcr = 1200 K
0
10
20
30
40
50
60
0 2 4 6 8 1012141618
Heat	of	Combustion	(kJ/g)
Heat	of	Gasification	(kJ/g)
Tcr = 1100 K
XO2 = 0.265, 0.34, 0.4
~~~~

### Pagina 136

Cita: [pdf_2ada277f4accf3ff7dca, p. 136]. Metodo: native.

~~~~text
133
critical temperature on the flammability maps for ambient with XO2 = 0.265, 0.34, and 0.4 are 
shown in the Fig. 6.15.
Figure 6.15. The effect of Tcr on flammability maps for XO2= 0.265, 0.34, and 0.4 (shown 
for the critical flame temperatures of 1100 K, to 1400 K)
0
10
20
30
40
50
60
0 3 6 9 12 15 18
Heat	of	Combustion	(kJ/g)
Heat	of	Gasification	(kJ/g)
XO2 =0.4
0
10
20
30
40
50
60
0 3 6 9 12 15 18
Heat	of	Combustion	(kJ/g)
Heat	of	Gasification	(kJ/g)
Tcr = 1100 to1300 K
XO2 =0.34
0
10
20
30
40
50
60
0 3 6 9 12 15 18
Heat	of	Combustion	(kJ/g)
Heat	of	Gasification	(kJ/g)
Tcr = 1100 to1200 K
XO2 =0.265
Tcr = 1100 to1400 K
~~~~

### Pagina 137

Cita: [pdf_2ada277f4accf3ff7dca, p. 137]. Metodo: native.

~~~~text
134
6.8 Critical heat release rate, and mass flux at extinction limits
The critical heat release rate, 𝑚̇
$$∆ℎ!, corresponding to the critical flame temperatures (1100 K or 
1200K) used in this analysis is plotted against heat of combustion. It is observed that for the small 
flame extinction limit, the critical heat release rate corresponding to both critical temperatures 
approaches ~40 kW/m2
. Critical HRR at extinction was also observed in [75,95]. However, for the 
radiative extinction limit the critical heat release rates increase significantly with XO2 (See Fig. 
6.16).
Critical mass flux at the extinction limits is plotted and shown in Fig. 6.17. At the small 
flame extinction limit, the critical mass flux does not change with XO2 except that as XO2 is 
decreased the combustible range for heat of combustion decreases. In other words, higher oxygen 
concentration allows for materials with lower heats of combustion burn. Therefore, the critical 
mass flux as a function of ∆ℎ! for the small flame extinction limit can be defined with a single 
power-law fit as shown in the Fig. 6.17, similar to what was obtained in [75]. At the radiative 
extinction limit, the critical mass flux, increase with oxygen for a given ∆ℎ!. Also, the flammable 
range of ∆ℎ! is increased with 𝑋9:.
Figure 6.16. Critical heat release rate as a function of heat of combustion shown for different 
XO2 for the two extinction limits (radiative extinction, and small flame extinction limit). 
0
20
40
60
80
100
120
140
160
0 20 40 60
Critical heat release rate (kW/m2)
Heat of combustion (kJ/g)
Rad. Ext.
Small Flame Ext.
Tcr = 1200 K
0
20
40
60
80
100
120
140
160
0 20 40 60
Critical heat release rate (kW/m2
)
Heat of combustion (kJ/g)
Small Flame Ext.
Rad. Ext.
Tcr = 1100 K
colors !!"
Black 0.4
Blue 0.34
Red 0.265
~~~~

### Pagina 138

Cita: [pdf_2ada277f4accf3ff7dca, p. 138]. Metodo: native.

~~~~text
135
6.9 Chapter summary
A gas fuel supplied burner (BRE) was used to emulate burning of real solid and liquid fuels in
microgravity to address the concerns regarding fire safety of spacecrafts. The burner had a porous 
surface that allowed gas mixture flowing which represents real material gasification. The gaseous 
fuel used in this study were ethylene and ethylene diluted with nitrogen to generate a range of heat 
of combustion (LHV) from 10 kJ/g to 47.2 kJ/g. The BRE was installed inside a chamber that 
allowed ignition of flames in a controlled environment. The oxygen mole fraction and pressure 
were varied to study its effect on the flammability of the fuel mixture flow. The nominal ambient 
oxygen mole fractions used in this study were 0.4, 0.34, 0.265, 0.25, and 0.21 with ambient 
pressures of 1, 0.7, and 0.56 bar. Three of the atmospheres used were conditions that NASA is 
considering for human habitat in space crafts. Several cameras recorded still images and videos of 
the tests. Two heat flux sensors and two K-type thermocouples embedded to the burner surface 
were used to measure surface heat flux and temperature at the center and approximately 10 mm 
from the center of the burner. Several remote radiometers measured radiative heat flux from the 
flames that led to computation of radiative loss fractions, a quantity that was used to correct the 
Figure 6.17. Critical burner mass flux as a function of heat of combustion shown for different 
XO2 for the two extinction limits (radiative extinction, and small flame extinction limit). The 
fit shown corresponds to the small flame limit
y = 41.87x-0.97
R² = 1.00
0.3
3
30
0 20 40 60
Critical mass flux (g/m2s)
Heat of combustion (kJ/g)
Rad. Ext.
Small Flame Ext.
Tcr = 1200 K
colors !!"
Black 0.4
Blue 0.34
Red 0.265
y = 35.87x-0.96
R² = 1.00
0.3
3
30
0 20 40 60
Critical mass flux (g/m2s)
Heat of combustion (kJ/g)
Rad. Ext.
Small Flame Ext.
Tcr = 1100 K
~~~~

### Pagina 139

Cita: [pdf_2ada277f4accf3ff7dca, p. 139]. Metodo: native.

~~~~text
136
heat of combustion in the analytical solution to the BRE flames. A critical temperature range of 
1100 to 1200 K, was chosen to distinguish between self-extinguished and steady flames. 146
flames were ignited aboard the international space station. All flames that were ignited at nominal
XO2 of 0.25, and 0.21 self-extinguished within 90 seconds. 46 flames burned for the entire duration, 
three minutes for most of the cases, before the fuel supply was terminated intentionally. These 
flames were close to their steady state value, and it was shown by the analytical solution, with their 
size being 94% of their steady state value on average and standard deviation of 1.9%. Average 
measured heat flux was used to obtain heats of gasification, a key parameter for fuel emulation. A 
dimensional analysis of the radiative loss fraction Xr based on radiation theory led to an empirical 
correlation. A geometrical model was used to estimate surface average radiative heat flux that 
resulted in computation of heat of gasification when added to the calculated convective and re￾radiative surface heat flux. The computed heats of gasification were compared with measured 
counterparts for the steady flames indicating good accuracy of the model used. Finally, a 
flammability map, as a plot of Dhc vs. L (the two key properties of materials that are used for 
emulation) was obtained for each nominal oxygen mole fraction, based on the experimental data 
and the theoretical predicted trends were shown for elaboration. Two extinction limits were 
introduced that identifies the flammability region. The radiative extinction limit was obtained 
empirically, by passing a line through a range that segregates self-extinguished and steady flames. 
The kinetic extinction limit was obtained theoretically for small flames, having small radiative 
heat loss. The properties of some of the real solids and liquids were shown on the flammability 
maps to study their flammability.
~~~~

### Pagina 140

Cita: [pdf_2ada277f4accf3ff7dca, p. 140]. Metodo: native.

~~~~text
137
7. Conclusions
Burning emulation in microgravity is investigated through a series of tests aboard the 
International Space Station to study flammability of condensed phase materials in quiescent 
atmosphere to improve safety of spacecrafts against fire hazard. Two sizes of the Burning Rate 
Emulator (BRE) were utilized to emulate burning of condensed phase materials with porous flat 
surfaces of 25 mm and 50 mm in diameter. Ethylene, and a diluted mixture of these fuels with 
nitrogen at different concentrations were used to achieve a range of heats of combustion of up 
to LHV of 50 kJ/g. The fuel mixture mass flux, ambient mixture and ambient pressure were among 
the design parameters. Radiation measurements were performed to obtain flame radiative loss 
fractions. A dimensional analysis of radiation fraction led to an empirical correlation. RADCAL, 
a narrow band radiation model, was utilized to obtain flame emissivity by executing the code with 
partial pressures of products, flame length, flame temperature and ambient pressure being input 
parameters. The correlation allowed correction of total heat release rate from the flames due to 
radiative loss and when combined with the analytical solution to these flames, allowed prediction 
of flame heights, radius, average convective and radiative heat flux that were used to calculate 
heats of gasification. In the burning emulation, the mass flux was specified, and the heat of 
gasification was derived, in the real problem, the heat of gasification is given and the question of 
burning arises. This question is resolved by assuming a flame extinction temperature.
More than half of the tests resulted in long burns of at least 2 and as long as 5 minutes. 
Generally, it has been found that nominal oxygen mole fractions of 26 % and above can lead to 
steady flames which are thin blue in color and grow slowly over time for minutes. Theoretical 
analysis showed the shutdown flames were effectively steady in size, and all of the test endpoints 
were more than 94 % of steady state in flame heat flux based on theoretical estimation of flame 
steadiness. The key representative property of the steady state is the heat of gasification. This is 
exact for vaporizing solids and approximant under real pyrolysis conditions. Surface heat flux for 
set mass flux allowed the estimation of heats of gasification to relate to steady solid materials that 
might burn in microgravity. PMMA and POM were successfully emulated based on the 
flammability map achieved. Radiometers allowed the computation of flame radiative fraction that
~~~~

### Pagina 141

Cita: [pdf_2ada277f4accf3ff7dca, p. 141]. Metodo: native.

~~~~text
138
appeared to correlate well with the measured flame height which led to a more accurate correlation 
based on dimensional analysis by also taking into account the effect of fuel and ambient mixture 
and ambient pressure. Heat flux, flame height and base radius, radiative fraction as a function of 
fuel mixture mass flux, and several ambient mixtures and pressures are presented as experimental 
findings. 
It is observed that for all steady flames, radiation fractions remained below 0.6 for the 
steady flames and correlate with the flame height. The dimensional analysis on the radiation 
parameter Ω confirms that it does depend on the fuel, and here only ethylene-nitrogen mixtures 
were examined. It is shown that if the RADCAL output absorption coefficients are divided by sum 
of partial pressures of water vapor and carbon dioxide, all data will collapse on an empirical curve 
that suggests it only depends on path length for a given hydrocarbon. Being able to calculate 
radiation fraction led to computation of flame temperature in which 1100 K is taken as a criterion 
for flame extinction. The radiation heat flux to the surface is computed based on a geometrical 
view factor analysis performed on calculated flame size along with the correlated Xr to calculate 
radiant heat flux to the surface. The net heat flux is composed of the algebraic sum of convective, 
radiative and re-radiation from surface which allows computation of heats of gasification. Burner 
size, surface temperature (350 ºC that represents real fuels burning) effects on the theoretical 
flammability map (L vs 𝑚̇
>?@
$$ ) are also investigated. It is shown that as burner diameter is 
increased, flame radiant fraction is increased, and heats of gasification are decreased. Surface 
temperature introduces substantial change in heat of gasification in which re-radiation heat loss
decreases the burning rates. However, external radiation can offset this effect, and increase the 
mass flux. As in Earth-based fires, external radiation is the key to massive fire growth; it is likely 
this can be an issue in microgravity as well. The analytical algorithm given in this thesis has been 
shown to predict steady conditions of burning for a surface of 25 mm diameter and has been 
examined for larger diameters. This analysis gives one a powerful analytical tool to predict the 
steady burning in microgravity as a function of fuel properties and ambient conditions.
~~~~

### Pagina 142

Cita: [pdf_2ada277f4accf3ff7dca, p. 142]. Metodo: native.

Calidad: table_structure_not_manually_validated.

~~~~text
139
The trends suggested by the theoretical predictions in terms of ambient conditions, fuel 
properties, and surface diameter are presented in Table 6.1 that shows 
the increase (+) and decrease (-) trends for the key parameters of burning as a function of specified 
burning rate, pressure, oxygen concentration, and heat of combustion. The effect of dropping the 
atmospheric pressure tends to expand the range of burning to higher burning rates. As NASA seeks 
to provide habitable atmospheres of lower pressure and higher oxygen levels. Such a move will 
exacerbate the burning conditions. The steady flame temperature is independent of the heat of 
gasification as given herein but depends on the mass flux. The mass flux does depend on L, as well 
as the steady flame temperature, surface radiative and convective heat flux, re-radiation, and 
external radiant heat flux. Surface radiative heat flux is inversely proportional to the mass flux
(and thus, flame size) but it is decreased at a higher rate compared to convection and re-radiation. 
Furthermore, it is the only heat flux component that is affected by ambient mixture and pressure 
as well as hydrocarbon properties. Hence, radiative heat transfer is responsible for determining 
extinction and in case of sustained burning, the mass flux. Therefore, the algorithm should be cast 
in terms of the ambient conditions, including external radiation, and hydrocarbon properties to 
determine if burning is possible and at what rate. The significant result of theoretical aspect of this 
study is presented herein as a flammability map that would give burning conditions for a given 
fuel in terms of its heat of combustion, heat of gasification and burning temperature.
A flammability map as a plot of heat of gasification vs. heat of combustion was developed 
based on the measurement and theory for nominal ambient oxygen mole fractions of 0.265, 0.34, 
and 0.4. The flammability maps were bounded by two extinction limits, radiative, and small flame 
Table 7.1 Effect of atmosphere, heat of combustion and mass flux on burning parameters
Parameters Pressure
Ambient Oxygen
mole fraction
Fuel Heat of 
Combustion
Burning 
mass flux
Flame radiation fraction + and expands + + +
Flame size expands - + +
Convective heat flux expands + - -
Radiation heat flux expands + - -
Heat of gasification expands + - -
~~~~

### Pagina 143

Cita: [pdf_2ada277f4accf3ff7dca, p. 143]. Metodo: native.

~~~~text
140
extinction limits. The extinction limits were theoretically obtained by applying critical flame 
temperature of 1100 K or 1200 K. The flammable zone consists of flames with temperatures higher 
than these values. Several real materials were emulated by matching their properties with the 
flammability maps. The development of flammability maps based on Dhc, and L, properties that 
can be effectively measured by the Cone Calorimeter, suggests NASA to use Test 2 to determine 
flammable hazard in space. Also, the effects of external radiation, and real material chemistry are 
suggested as subjects for future studies.
~~~~

### Pagina 144

Cita: [pdf_2ada277f4accf3ff7dca, p. 144]. Metodo: native.

Calidad: figures_not_digitized, table_structure_not_manually_validated.

~~~~text
141
Appendix A. Corrections to the Calorimeter Heat Flux
The exposed side of the copper burner top provided an unwanted heat flux surface. It should 
have been insulated. The calorimeter can only successfully provide an average surface heat flux to 
the top flat flow area of the copper by eliminating the edge heating. This is done by the following 
analysis. It has been done for all the steady endpoints by utilizing the radiative fraction as predicted 
by the correlation in Figure 3.7b. This allowed for using all of the steady data, and not just where 
radiometers worked. Table 3.1 shows that there is very good agreement between the measured 
radiation fractions and those predicted by the correlation.
The radiation is analyzed in terms of view factors with the flame treated as a surface, 2, as 
shown in Figure A.1. Two cases need to be investigated in this analysis: (a) the flame extends 
below the flow area, surface 1; and (b) the flames standoff surface 1. Video images of the flames 
allowed measurements for the dimensions a and b along with the flame height and radius are given 
in Table 3.1.
The analysis proceeds in several steps. (See nomenclature for guidance). Dependence of 
convective flame heat flux to surfaces 1 and 3 is inversely related to distance from the flame:
𝑞̇
$$
C,! ∝
1
𝑦7
é 𝜆
𝑒Q − 1
è (𝐴. 1)
Flame below (adjusted for not full coverage over H)
Figure A.1. Flame configurations for analyzing heat flux from 2 to 1 and 3
H
yf
rf
a
rf
Surface 1: Burner surface
Surface 2: Flame sheet
Surface 3: Burner bevel edge
yf
b
~~~~

### Pagina 145

Cita: [pdf_2ada277f4accf3ff7dca, p. 145]. Metodo: native.

Calidad: table_structure_not_manually_validated.

~~~~text
142
𝑞̇
$$
X,! ∝
𝑏
𝐻
q𝑟7 − 𝑅s (𝐴. 2)
Flame above (considering the average distance 3 is from the flame)
𝑞̇
$$
X,! ∝
1
𝑎 + B
𝐻
2F
(𝐴. 3)
Flame radiant heat rate and heat flux to surface 3
𝑞̇
X
$$ = 𝑋,𝑄̇
!
2 𝐹:X (𝐴. 4)
𝐹:X = 𝐴X
𝐴:
𝐹X: (𝐴. 5)
𝑞̇
X,,
$$ = 𝑋,𝑄̇
!
2𝐴:
𝐹X: (𝐴. 6)
𝐹X: ≈ 1 − 𝑅
𝑟7
< 1 (𝐴. 7)
Ratio of radiation heat flux to convection heat flux for surface 1 Theoretical convection is given 
as 
𝑞̇
C,! ööö$$öö = y 4𝑘
𝜋𝑅𝑐;
| P
∆ℎ!(1 − 𝑋,)𝑌9,*
𝑆− 𝑐;(𝑇' − 𝑇*) R (𝐴. 8)
Theoretical radiation is given as 
𝑞̇
C,,
$$ = 𝑋,𝑄̇
!
2𝐴:
𝐹C: (𝐴. 9)
where A2 is the flame area based on the surface of a semi-ellipse defined by semi-major axis yf and 
semi-minor axis, rf. If the flame resides above the burner surface, Eq. A.10 is used to obtain the 
view factor
𝐹C: ≈ 1 −
arctan é𝑎
𝑟7
è
𝜋
(𝐴. 10)
And when the flame is below the surface,
𝐹C: = 1 (𝐴. 11)
For the following, define 
λ
eλ −1
⎛
⎝
⎜
⎞
⎠
⎟
~~~~

### Pagina 146

Cita: [pdf_2ada277f4accf3ff7dca, p. 146]. Metodo: native.

Calidad: table_structure_not_manually_validated.

~~~~text
143
𝜇 = 𝑞̇
C,,
$$
𝑞̇
C,!
$$ (𝐴. 12)
The correction algorithm is given as follows:
𝑞̇
C
$$ = 𝛿𝑞̇
!"#
$$ (𝐴. 13)
𝛿 = (1 + 𝜇)(𝐴C + 𝐴X)
(𝐴C + 𝛼𝐴X) + 𝜇(𝐴C + 𝛽𝐴X) (𝐴. 14)
For the flames above the burner, we use eq. A.15
𝛼 = 𝑞̇
X,!
$$
𝑞̇
C,!
$$ = Õ 1
𝛼 + B
𝐻
2F
Œ / P
1
𝑦7
é 𝜆
𝑒Q − 1
èR (𝐴. 15)
And for the flames below the burner, we use eq. A.16
𝛼 = 𝑞̇
X,!
$$
𝑞̇
C,!
$$ = Õ
𝑏
𝐻
𝑟7 − 𝑅Œ / P
1
𝑦7
é 𝜆
𝑒Q − 1
èR (𝐴. 16)
𝛽 = 𝑞̇
X,,
$$
𝑞̇
C,,
$$ (𝐴. 17)
𝜇 = y
𝑞̇
C,,
$$
𝑞̇
C,!
$$ |
0F5-,e
(𝐴. 18)
The results for the heat flux to surface 1 alone (corrected calorimeter heat flux), 𝑞̇
!"#,!,! $$ , and the 
original calorimeter heat flux, 𝑞̇
!"#
$$ .are presented in table 3.1. Also, calorimeter data are shown in 
figure A.2 for those tests that radiation measurements were available.
~~~~

### Pagina 147

Cita: [pdf_2ada277f4accf3ff7dca, p. 147]. Metodo: native.

~~~~text
144
Figure A.2. Calorimeter vs. corrected calorimeter
0
2
4
6
8
10
12
14
16
0 2 4 6 8 10 12 14 16
calorimeter	(kW/m
2)	
Corrected	calorimeter	(kW/m2)	
FT Xf XO2
p 
(bar)
1 0.34 0.56
1 0.265 0.7
0.5 0.4 1
0.5 0.34 0.56
0.5 0.265 0.7
∆ℎ! = $" 47.2 kJ/g
~~~~

### Pagina 148

Cita: [pdf_2ada277f4accf3ff7dca, p. 148]. Metodo: native.

~~~~text
145
Appendix B. Transient Flame Size and PMT with OH* Filter Assembly
In-order to illustrate the asymptotic behavior of BRE microgravity steady flames, the transient 
plots of flame length, base radius and PMT with OH* filter assembly (that represents flame 
luminosity) of test point 66D5 are presented in Figure B.1. The details of PMT calibration and 
schematic is presented in ref [55].
Figure B.1 Transient flame length, base radius and PMT 
heat flux with OH* assembly
0
1
2
3
4
5
6
7
8
9
-40 0 40 80 120 160 200
length	(mm)
time	(s)
Flame	length
Flame	base	radius
0
0.2
0.4
0.6
0.8
1
1.2
-40 0 40 80 120 160 200
Irradiance	(kW/m
2
)
time	(s)
PMT-310	nm
~~~~

### Pagina 149

Cita: [pdf_2ada277f4accf3ff7dca, p. 149]. Metodo: native.

~~~~text
146
Appendix C. Transient results, use of theory and example predictions
In this chapter, the theory introduced in is used to predict transient flame height, Xr, calculated Tf, 
and surface heat flux components.
C.1 Flame Height
The analytic theory, that was used to obtain the closeness of the flame size to its asymptotic value, 
can predict transient flame height. The results of two tests are shown in Figure 1. Initially the size 
deviate from measured values but as the flames grow, the calculated value becomes more accurate. 
At the endpoint of all steady tests the predicted flame heights matched measured counterparts.
C.2 Transient radiation fraction, and calculated flame temperature 
The analytical solution for the steady flame temperature was combined with transient radiation 
fraction and flame height to estimate the transient flame temperature at flame sheet. 
Figure C.1. Calculated vs. measured transient flame heights of 19070C1 and 20352A2
0
5
10
15
0 20 40 60 80 100
Flame height (mm)
time (s)
Measured
Calculated
0
5
10
15
20
0 20 40 60 80 100 120
Flame height (mm)
time (s)
Measured
Calculated
~~~~

### Pagina 150

Cita: [pdf_2ada277f4accf3ff7dca, p. 150]. Metodo: native.

~~~~text
147
C.3 Transient surface heat flux components:
The surface net heat flux was measured by two het flux sensors, and the analytical solution 
algorithm was used to compute surface average convective, radiative, and re-radiation heat flux. 
The results are shown for two tests in Fig. 3.
Figure C.2. Radiative loss fraction empirical correlation for steady flames generated by the 
25 mm BRE burner and ethylene-diluent mixture 
1000
1100
1200
1300
1400
1500
1600
1700
1800
0
0.2
0.4
0.6
0.8
1
0 20 40 60 80 100
Tf (K)
Xr
time (s)
Measured Xr
Calculated Xr
Calcuted Tf 1000
1100
1200
1300
1400
1500
1600
1700
0
0.2
0.4
0.6
0.8
1
0 20 40 60 80 100 120
Tf (K)
Xr
time (s)
Measured Xr
Calculated Xr
Calculated Tf
~~~~

### Pagina 151

Cita: [pdf_2ada277f4accf3ff7dca, p. 151]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_2ada277f4accf3ff7dca/p0151.jpg)

~~~~text
8 | 12
—Net HF center | —Net HF center
7 | —Net HF offset | —Net HF offset
—Radiative HF | 10 | —Radiative HF
—Convective HF | —Convective HF
—Re-radiative HF | Re-radiative HF
5
6
2
1
0 | 0
0 | 20 | 40 | 60 | 80 100 120 140 | 0 | 20 | 40 | 60 | 80 100 120 140
time (s) | time (s)
Figure C.3. Surface measured heat flux at r 0 and 9.5 mm from center, and transient
average heat flux components
148
~~~~

### Pagina 152

Cita: [pdf_2ada277f4accf3ff7dca, p. 152]. Metodo: native.

Calidad: table_structure_not_manually_validated.

~~~~text
149
Appendix D: The parameters spreadsheet submitted to NASA operations 
team
The parameters spreadsheet submitted to NASA operations team three business days before each 
test point day is presented in the table D.1 with each parameter’s meaning explained in the table 
D.2.
Table D.1. An example of the patameters table submitted to NASA operations team before each 
test point day. Only two test points parameters are shown. 
Parameter Name 1st test point 2nd test point
testpointName 21028A1 21028B1
preIgnitionDataTimeSec 0 0
postFlameDataTimeSec 15 15
useIPSUs TRUE TRUE
ipsuTimeoutSec 40 40
useAcmeCamera TRUE TRUE
useIntensifiedCamera TRUE TRUE
ipsu1ArchiveRate 2 2
dataCameraPreIgnitionExposureUs 1000000 1000000
dataCameraTestExposureUs 50000 50000
analogCameraPreIgnitionShutter 2 2
analogCameraTestShutter 2 2
intensifierGainAmplitude 50000 50000
preIgnitionImageTimeSec 0 0
postFlameImagingTimeSec 3 3
useBracketedExposures FALSE TRUE
bracketingImagesPerExposure 1 1
bracketingNumberOfExposures 4 4
bracketingExposureStartUsec 5000 5000
bracketingExposureMultiplierTimes100 200 200
igniterIgnitionPosition 2300 2300
igniterPreheatPowerV 3 3
igniterPreheatTimeMs 2000 2000
igniterIgnitionPowerV 3.75 3.75
igniterIgnitionDurationMs 3000 3000
igniterDelayBeforeRetractMs 3000 3000
~~~~

### Pagina 153

Cita: [pdf_2ada277f4accf3ff7dca, p. 153]. Metodo: native.

~~~~text
150
igniterRetractVelocityCountsPerSec 3000 3000
useIgnitionDetection TRUE TRUE
extinctionDetectionStopsTest TRUE TRUE
pmt1Gain 6 6
pmt2Gain 6.25 6.25
pmt3Gain 6.25 6.25
fiberIgnitionPosition 0 10000
fiberTestPosition 0 18500
fiberMoveDuringTest FALSE FALSE
fiberSegmentDistance 100 100
fiberVelocity 3000 3000
fiberAcceleration 1000 1000
fiberDeceleration 0 0
fiberHoldDurationSec 1 1
fiberCycles 100 100
useFoma TRUE TRUE
flowTimeoutSec 160 160
nitrogenPriming1DurationSec 0 0
nitrogenPriming2DurationSec 0 0
fuelFlowIgnitionDeltaMs 26000 40000
stabilizationTime1Sec 4 4
stabilizationTime2Sec 4 4
fuelBottleIgnitionFlowRateN2Slpm 0.077 0.0513
nitrogenIgnitionFlowRateN2Slpm 0.0947 0.0632
fuelBottleTestFlowRateN2Slpm 0.077 0.0513
nitrogenTestFlowRateN2Slpm 0.0947 0.0632
ignitionToTestRampTimeSec 1 1
constantFlowTimeSec 90 90
numberOfRampHolds 0 0
rampSizePercent -20 -20
rampDurationSec 2 2
holdDurationSec 10 10
temperatureLimitCriticalC 300 300
temperatureLimitC 250 250
useCenterThermocouple TRUE TRUE
useOffsetThermocouple TRUE TRUE
useCenterFluxThermocouple TRUE TRUE
useOffsetFluxThermocouple TRUE TRUE
~~~~

### Pagina 154

Cita: [pdf_2ada277f4accf3ff7dca, p. 154]. Metodo: native.

~~~~text
151
preflowFlowDurationSecs 0 5
preflowFuelRateSlpm 0 0
preflowNitrogenRateSlpm 0 0.16
preflowWaitDurationSecs 0 300
Additional Required Information 
(hover over cells for instructions)
Estimated Burn Time (sec) 90 90
Additional Parameters (hover over 
cells for instructions and options for 
completing these parameters)
Chamber & GC Operations
chamber fill pressure (psia) 14.7
chamber fill O2% 40
chamber fill N2% 60
GC Sample (Before, After or No) No No
GC Sample Method (O2, Byproducts or 
Both) N/A N/A
Recirculation (After or No) No No
HiBMS Camera
use HiBMS Camera? no no
HiBMS Exposure (ms) 33 33
HiBMS Illumination (backlight) 65 65
HiBMS Gain (V) 1 1
HiBMS Binning 1x1 1x1
ACME Data Camera
dataCamera Gain 16 0
dataCamera Zoom 30000 30000
dataCamera Focus 13750 13750
dataCamera Iris 0 0
dataCamera Filter FS FS
Intensified Camera
Intensified Camera Frame Rate 23 23
~~~~

### Pagina 155

Cita: [pdf_2ada277f4accf3ff7dca, p. 155]. Metodo: native.

Calidad: table_structure_not_manually_validated.

~~~~text
152
ACME Analog Camera (downlink 
video)
Analog Camera Gain 31 dB 31 dB
Estimated Flow Calculations
Valve Timer Time (seconds) 128 142
Est. Nitrogen Flow (liters) 0.2020 0.1629
Est. Fuel Flow Using All Parameters 
(liters) 0.1643 0.1214
Est. Fuel Flow Using Est. Burn Time 
(liters) 0.1155 0.0770
Table D.2. Explanation of the parameters used in the parameters spreadsheet (table D.1)
Parameter 
Name
Defaul
t 
Value
Typical 
Value
Limits on 
Value
Relation to Other 
Parameters
Meaning of Parameter
testpointNam
e
NONE YYGMT
xx
must be 7 
characters 
(even if not 
using IPSU1)
test point name that will be used by 
the IPSUs and ACME Data File (in 
the image and data file names and 
directories)
YY = last 2 digits of year, GMT = 
GMT day, xx = A1, B1, C1, etc.
preIgnitionDa
taTimeSec
0 0 time (in seconds) ACME Data File 
records data before IPSUs open test 
point and start archiving images
postFlameDat
aTimeSec
15 time (in seconds) ACME Data File 
records data after the 
postFlameImagingTimeSec has 
elapsed which occurs after 
command sent to close manifolds 
(i.e., stop gas flow)
useIPSUs true true true or false indicates if IPSUs will be used 
(images archived) for the test point
ipsuTimeoutS
ec
40 40 useIPSUs must be true time (in seconds) to wait for 
command responses from IPSUs 
and IPSUG when opening and 
starting test points
useAcmeCam
era
true true true or false useIPSUs & 
useAcmeCamera must 
both be true to use the 
ACME Camera
indicates if the ACME Camera will 
be used for the test point
useIntensified
Camera
true true true or false useIPSUs & 
useIntensifiedCamera 
must both be true to use 
indicates if the CIR Intensified 
Camera will be used for the test 
point
~~~~

### Pagina 156

Cita: [pdf_2ada277f4accf3ff7dca, p. 156]. Metodo: native.

~~~~text
153
the CIR Intensified 
Camera
ipsu1Archive
Rate
2 cannot be 0, 
must be a 
whole 
number
useIPSUs must be true indicates that every nth HiBMS 
Camera (IPSU1) image is saved 
(archived) (e.g., 10 indicates every 
10th image)
dataCameraP
reIgnitionExp
osureUs
10000
0
10-
60,000,000
useIPSUs & 
useAcmeCamera must 
both be true
exposure (in microseconds) of the 
ACME Camera prior to ignition and 
igniter retraction (set for imaging 
the igniter and ignition event)
dataCameraT
estExposureU
s
65000
0
10-
60,000,000
useIPSUs & 
useAcmeCamera must 
both be true
exposure (in microseconds) of the 
ACME Camera after igniter 
retraction (set for imaging the 
flame)
analogCamer
aPreIgnitionS
hutter
2 see Notes for 
acceptable 
values
shutter speed of the ACME 
Chamber Insert Camera (ops 
camera - no IPSU data recorded for 
this camera) prior to ignition and 
igniter retraction (set for imaging 
the igniter and ignition event)
analogCamer
aTestShutter
2 see Notes for 
acceptable 
values
shutter speed of the ACME 
Chamber Insert Camera (ops 
camera - no IPSU data recorded for 
this camera) after igniter retraction 
(set for imaging the flame)
intensifierGai
nAmplitude
50000 between 2500 
- 80000
CIR Intensified Camera intensifier 
gain setting; commanded to this 
value after turning off chamber LED 
lights;
this is the actual gain value; the 
script will convert to counts when 
sending the command
~~~~

### Pagina 157

Cita: [pdf_2ada277f4accf3ff7dca, p. 157]. Metodo: native.

~~~~text
154
preIgnitionIm
ageTimeSec
0 0 useIPSUs must be true time (in seconds) IPSUs record 
images before the CIR fuel manifold 
is commanded open
postFlameIm
agingTimeSec
3 useIPSUs must be true time (in seconds) IPSUs record 
images after flow stops
useBracketed
Exposures
false true or false indicates if bracketed exposures on 
the ACME Camera will be used for 
the test point; if true, replaces 
dataCameraTestExposureUs
bracketingIm
agesPerExpos
ure
1 useBracketedExposures 
must be true; when 
useBracketedExposures is 
false, parameter should 
be default value
number of images at each exposure 
before moving on to the next 
exposure when using bracketed 
exposure
bracketingNu
mberOfExpos
ures
4 useBracketedExposures 
must be true; when 
useBracketedExposures is 
false, parameter should 
be default value
number of exposures when using 
bracketed exposure
bracketingExp
osureStartUs
ec
5000 useBracketedExposures 
must be true; when 
useBracketedExposures is 
false, parameter should 
be default value
initial exposure (in microseconds) 
for the ACME Camera when using 
bracketed exposure
bracketingExp
osureMultipli
erTimes100
1000 useBracketedExposures 
must be true; when 
useBracketedExposures is 
false, parameter should 
be default value
value, divided by 100, that will get 
multiplied to the current exposure 
to determine the next exposure, 
when using bracketed exposure 
igniterIgnition
Position
0 0 - 2400 for 
25mm burner
0 - 2325 for 
50mm burner 
(Igniter Arm 
1)
position (in counts) of the igniter for 
preheat and ignition
igniterPrehea
tPowerV
0 0.46 - 4.5 V igniter power (in volts) during 
preheat (igniterPreheatDurationMs)
igniterPrehea
tTimeMs
0 time is before 
igniterIgnitionDurationMs
time (in milliseconds) the igniter is 
powered during the preheat
igniterIgnition
PowerV
3.75 0.46 - 4.5 V igniter power (in volts) during 
ignition (igniterIgnitionDurationMs)
igniterIgnition
DurationMs
2000 starts relative to 
fuelFlowIgnitionDeltaMs; 
if fuelFlowIgnitionDeltaMs 
is positive, time starts 
after fuel flow starts, if 
fuelFlowIgnitionDeltaMs 
is negative, time starts 
before fuel flow starts
time (in milliseconds) the igniter is 
powered for ignition; 
ends early if ignition is detected
igniterDelayB
eforeRetract
Ms
1500 time starts at the start of 
igniterIgnitionDurationMs
time (in milliseconds) the igniter 
stays in igniterIgnitionPosition 
before retracting
~~~~

### Pagina 158

Cita: [pdf_2ada277f4accf3ff7dca, p. 158]. Metodo: native.

~~~~text
155
igniterRetract
VelocityCount
sPerSec
2000 velocity (in counts/second) used 
when the igniter retracts if ignition 
is not detected
useIgnitionDe
tection
true true true or false indicates if Ignition Detection will be 
used; when ignition is detected (per 
the specified values), the igniter 
turns off and retracts
extinctionDet
ectionStopsTe
st
true true true or false indicates if Extinction Detection will 
be used to detect flame extinction; 
when extinction is detected (per the 
specified values or when 
commanded by operators), the 
script ends the gas flow and IPSUs 
recording of images and continues 
to the end of the script
pmt1Gain 6.25 0 - 10 V PMT1 gain during the script; set to 0 
at end of script;
PMT1 = 310nm, OH*
pmt2Gain 6.5 0 - 10 V PMT2 gain during the script; set to 0 
at end of script;
PMT2 = Broadband
pmt3Gain 6.5 0 - 10 V PMT3 gain during the script; set to 0 
at end of script;
PMT3 = 430nm, CH*
fiberIgnitionP
osition
0 0 - 10000 
(recommende
d limit)
will go to this position 
even if 
fiberMoveDuringTest is 
false
position (in counts) the fiber moves 
to prior to ignition (pre-positions 
the fiber so it can reach 
fiberTestPosition more quickly)
fiberTestPosit
ion
0 0 - 17700 (for 
25mm 
burner)
0 - 17500 (for 
50mm 
burner)
will go to this position 
even if 
fiberMoveDuringTest is 
false
position (in counts) the fiber moves 
to during test point (after 
stabalizationTime2Sec), starting 
position for fiber movement
fiberMoveDur
ingTest
false true or false indicates if fiber will move back and 
forth during test;
if true, fiber will move back and 
forth during the test; starts after 
fiberTestPosition is reached;
if false, fiber will still go into test 
position (fiberTestPosition) but not 
move back and forth
fiberSegment
Distance
100 maximum 
value is 17700 
(for 25mm 
burner) or 
17500 (for 
50mm 
burner) minus 
fiberTestPositi
on
fiberMoveDuringTest 
must be true for this value 
to be used
distance (in counts) the fiber moves 
towards the burner from the 
fiberTestPosition and back
~~~~

### Pagina 159

Cita: [pdf_2ada277f4accf3ff7dca, p. 159]. Metodo: native.

~~~~text
156
fiberVelocity 3000 3000 0-3000 
(recommende
d limit)
fiberMoveDuringTest 
must be true for this value 
to be used
velocity (in counts/second) of fiber 
when moving during test
fiberAccelerat
ion
1000 fiberMoveDuringTest 
must be true for this value 
to be used
acceleration (in counts/second 
squared) of fiber when moving 
during test
fiberDecelera
tion
0 0 fiberMoveDuringTest 
must be true for this value 
to be used
deceleration (in counts/second 
squared) of fiber when moving 
during test
fiberHoldDur
ationSec
1 fiberMoveDuringTest 
must be true for this value 
to be used
time (in seconds) to hold at the 
innermost and outermost positions 
of the fiber movement
fiberCycles 100 100 fiberMoveDuringTest 
must be true for this value 
to be used
number of cycles the fiber moves; 
one cycle is towards the burner 
(number of counts in 
fiberSegmentDistance) and back (to 
fiberTestPosition)
useFoma true true true or false indicates if gas flow will be used for 
test points
flowTimeoutS
ec
120 starts when fuel flow 
starts 
(fuelFlowIgnitionDeltaMS)
total time (in seconds) gas flows 
during script, starting when the fuel 
flow starts; gas flow stops after this 
time if not at end of script
nitrogenPrimi
ng1DurationS
ec
0 if using this 
N2 priming, 
minimum 
value is 1; 
whole second 
resolution;
if not using 
this N2 
priming, value 
is 0
flows at rate specified in 
nitrogenIgnitionFlowRate
N2Slpm; if no rate 
specified, this time is not 
included in the script
time (in seconds) for nitrogen to 
flow prior to the start of fuel flow; 
time is before IPSUs start archiving, 
before opening CIR fuel manifold, 
and before 
nitrogenPriming2DurationSec
nitrogenPrimi
ng2DurationS
ec
0 if using this 
N2 priming, 
minimum 
value is 0.1; 
tenth of a 
second 
resolution;
if not using 
this N2 
priming, value 
is 0
flows at rate specified in 
nitrogenIgnitionFlowRate
N2Slpm; if no rate 
specified, time is included 
in the script
time (in seconds) for nitrogen to 
flow prior to the start of fuel flow; 
time starts after CIR fuel manifold 
has been opened
fuelFlowIgniti
onDeltaMs
1000 positive or 
negative 
value, 
increments of 
100 ms
time (in milliseconds) fuel (and 
nitrogen) flows before or after start 
of igniterIgnitionDurationMs
~~~~

### Pagina 160

Cita: [pdf_2ada277f4accf3ff7dca, p. 160]. Metodo: native.

~~~~text
157
stabilizationTi
me1Sec
4 time (in seconds) to wait after 
igniter starts retracting, before 
increasing fuel (and nitrogen) to test 
flow rates
stabilizationTi
me2Sec
4 time (in seconds) to wait after 
ignitionToTestRampTimeSec, before 
the fiber moves into test position 
(fiberTestPosition) 
fuelBottleIgni
tionFlowRate
N2Slpm
1.2 must be less 
than or equal 
to the fuel 
mass flow 
controller 
installed
initial fuel bottle flow rate (SLPM N2 
basis) through 
stabilizationTime1Sec
nitrogenIgniti
onFlowRateN
2Slpm
0 must be less 
than or equal 
to the bypass 
mass flow 
controller 
installed
initial nitrogen flow rate (SLPM N2 
basis) through 
stabilizationTime1Sec
fuelBottleTest
FlowRateN2Sl
pm
1.2 must be less 
than or equal 
to the fuel 
mass flow 
controller 
installed
fuel bottle flow rate (SLPM N2 basis) 
after ignitionToTestRampTimeSec 
through the end of 
constantFlowTimeSec
nitrogenTestF
lowRateN2Slp
m
0 must be less 
than or equal 
to the bypass 
mass flow 
controller 
installed
nitrogen flow rate (SLPM N2 basis) 
after ignitionToTestRampTimeSec 
through the end of 
constantFlowTimeSec
ignitionToTes
tRampTimeSe
c
5 if ramping 
from 
IgnitionFlowR
ate to 
TestFlowRate, 
minimum 
value is 1; if 
flow rates are 
the same, 
value is 0
if 
fuelBottleIgnitionFlowRat
eN2Slpm and 
fuelBottleTestFlowRateN2
Slpm are the same AND 
nitrogenIgnitionFlowRate
N2Slpm and 
nitrogenTestFlowRateN2S
lpm are the same, then 
this time is skipped
time (in seconds) it takes to ramp 
from 
fuelBottleIgnitionFlowRateN2Slpm 
to fuelBottleTestFlowRateN2Slpm 
and 
nitrogenIgnitionFlowRateN2Slpm to 
nitrogenTestFlowRateN2Slpm after 
stabilizationTime1Sec
constantFlow
TimeSec
30 effectively 
whole second 
resolution 
(parameter 
can be 
decimal but 
script only 
checks timing 
once per 
second)
if using fiber and fiber 
movement, this time 
starts after fiber 
movement start;
if using fiber but not fiber 
movement, this time 
starts after fiber starts 
moving into position;
if not using fiber, this time 
starts after 
stabilizationTime2Sec
time (in seconds) to wait at a 
constant flow before continuing 
script
~~~~

### Pagina 161

Cita: [pdf_2ada277f4accf3ff7dca, p. 161]. Metodo: native.

~~~~text
158
numberOfRa
mpHolds
0 number of times gas flow will ramp 
and hold following 
constantFlowTimeSec
rampSizePerc
ent
-20 positive or 
negative 
value
numberOfRampHolds 
must be greater than 0 for 
this value to be used, use 
default when 
numberOfRampHolds is 0
percentage amount the flow rate 
changes the per ramp, based on 
fuelBottleTestFlowRateN2Slpm and 
nitrogenTestFlowRateN2Slpm
rampDuration
Sec
2 tenth of a 
second 
resolution; 
minimum 
value is 1 
numberOfRampHolds 
must be greater than 0 for 
this value to be used, use 
default when 
numberOfRampHolds is 0
time (in seconds) to ramp to next 
flow rate
holdDuration
Sec
10 numberOfRampHolds 
must be greater than 0 for 
this value to be used, use 
default when 
numberOfRampHolds is 0
time (in seconds) to hold at the flow 
rate after each ramp
temperatureL
imitCriticalC
300 if any 
(useCenterThermocouple, 
useOffsetThermocuople, 
useCenterFluxThermocou
ple, 
useOffsetFluxThermocoup
le) parameter marked 
true is over the limit, 
takes action
temperature limit (in degrees C) 
that ends the test point (stops all 
flows; script still performs post￾flame data and imaging collection, 
and then closes the test point 
nicely)
temperatureL
imitC
250 if any 
(useCenterThermocouple, 
useOffsetThermocuople, 
useCenterFluxThermocou
ple, 
useOffsetFluxThermocoup
le) parameter marked 
true is over the limit, 
takes action
temperature limit (in degrees C) 
that ends the constantFlowTimeSec 
and causes the script to moves on 
to ramping
useCenterThe
rmocouple
true true or false indicates if Center Thermocouple 
will be used in temperature limit 
checks
useOffsetTher
mocouple
true true or false indicates if Offset Thermocouple 
will be used in temperature limit 
checks
useCenterFlu
xThermocoup
le
true true or false indicates if Center Flux 
Thermocouple will be used in 
temperature limit checks
useOffsetFlux
Thermocoupl
e
true true or false indicates if Offset Flux 
Thermocouple will be used in 
temperature limit checks
preflowFlowD
urationSecs
0 if using 
preflow, must 
be greater 
than 5; if not 
using preflow, 
value is 0
time in seconds to flow from fuel 
bottle and/or nitrogen prior to 
starting gas flow for ignition
~~~~

### Pagina 162

Cita: [pdf_2ada277f4accf3ff7dca, p. 162]. Metodo: native.

~~~~text
159
preflowFuelR
ateSlpm
0 must be less 
than or equal 
to the fuel 
mass flow 
controller 
installed
preflowFlowDurationSecs 
must be greater than 0 for 
this value to be used, use 
default when 
preflowFlowDurationSecs 
is 0
fuel bottle flow rate (SLPM N2 basis) 
during preflowDurationSecs
preflowNitrog
enSlpm
0 must be less 
than or equal 
to the bypass 
mass flow 
controller 
installed
preflowFlowDurationSecs 
must be greater than 0 for 
this value to be used, use 
default when 
preflowFlowDurationSecs 
is 0
nitrogen flow rate (SLPM N2 basis) 
during preflowDurationSecs
preflowWaitD
urationSecs
300 if using 
preflow, must 
be greater 
than 50
preflowFlowDurationSecs 
must be greater than 0 for 
this value to be used, use 
default when 
preflowFlowDurationSecs 
is 0
time in seconds to wait after 
preflowFlowDurationSecs is 
complete before starting gas flow 
for ignition
~~~~

### Pagina 163

Cita: [pdf_2ada277f4accf3ff7dca, p. 163]. Metodo: native.

Calidad: table_structure_not_manually_validated.

~~~~text
160
Appendix E: Results obtained from Methane-Nitrogen 
Methane was used for some of the tests aboard the ISS and with the 25 mm burner. All flames 
self-extinguished within 45 seconds. 
Table E.1. Test results obtained from Methane-Nitrogen mixture and 25 mm burner
∆ℎ!
𝑋"#
Bef 
test
𝑋"#
After 
test
p 𝑚̇
$$ Osc 
Time
Ext 
Time
End 
cond 𝑞̇
%&'
$$ 𝑞̇
())
$$ 𝑇* Calorimeter Xr hf
test 
ID
kJ/
g
bar g/m2
-s s s
kW
/m2
kW
/m2 0
C kW/m2 mm
20279B7 50 0.36 0.35 1.06 5.98 7.70 14.93 SE 5.00 3.90 47.90 9.60 x 30.40
20279B5 50 0.37 0.37 1.06 4.98 7.80 42.30 SE 6.00 4.40 59.00 6.30 x 25.53
20279B8 50 0.35 0.35 1.06 4.49 9.43 42.70 SE 5.80 4.40 60.00 6.70 x 29.76
20279B6 50 0.37 0.36 1.05 3.98 7.83 18.43 SE 7.70 5.10 53.50 10.00 x 22.83
20279A2 50 0.39 0.39 1.05 2.97 15.13 23.43 SE 8.25 6.36 0.53 20.98
20279B4 50 0.38 0.37 1.05 2.46 17.17 24.10 SE 9.00 6.00 61.00 10.80 0.52 19.17
20279B1 50 0.39 0.38 1.05 1.97 22.47 25.60 SE 10.80 8.40 63.00 10.50 0.50 14.81
20279B2 50 0.38 0.38 1.05 1.76 27.23 30.60 SE 10.60 8.22 64.00 9.80 - 14.39
20339L3 35 0.37 0.36 1.06 7.92 6.76 8.13 SE 3.99 3.44 45.00 10.30 x 26.47
20339L2 35 0.37 0.37 1.06 5.22 8.73 13.23 SE 6.34 4.77 52.00 10.90 x 21.35
20339A0 35 0.38 0.37 1.06 4.24 13.28 13.51 SE 8.40 6.47 56.40 11.06 0.41 18.37
20339L1 35 0.37 0.37 1.06 3.49 14.50 17.27 SE 8.38 6.44 56.90 10.60 0.55 19.80
20339A3 25 0.39 0.39 1.05 11.90 7.20 10.87 SE 4.20 3.01 46.00 9.10 x 28.16
20339A7 25 0.38 0.38 1.06 10.41 6.71 11.48 SE 4.30 3.50 46.20 9.80 x
20339A4 25 0.39 0.39 1.06 8.94 7.50 15.00 SE 3.63 3.30 51.00 9.80 x 22.33
20339A6 25 0.39 0.38 1.06 7.46 9.23 23.10 SE 5.23 4.70 56.10 9.50 x 21.35
20339A8 25 0.38 0.38 1.06 6.42 10.87 24.27 SE 6.30 5.00 53.00 10.40 0.51 18.26
20339A9 25 0.38 0.38 1.06 6.40 18.53 25.30 SE 4.40 4.30 60.00 9.83 0.47 20.37
20339A2 25 0.40 0.39 1.05 5.96 16.33 19.20 SE 6.75 5.80 54.70 9.90 0.35 17.63
20279D4 50 0.34 0.33 1.04 5.97 6.23 7.30 SE 4.40 3.50 41.00 10.90 x 27.41
20279D3 50 0.34 0.34 1.04 5.00 7.70 9.73 SE 5.30 3.60 43.70 9.80 x 28.39
20279D7 50 0.33 0.25 1.04 4.49 6.53 9.10 SE 5.95 4.00 44.00 9.80 x 25.90
20279D2 50 0.34 0.34 1.04 3.98 6.93 10.63 SE 6.40 4.00 46.65 10.00 x 24.56
20279D1 50 0.35 0.34 1.04 2.97 8.43 11.37 SE 7.60 5.00 48.50 11.70 x 21.15
20279D6 50 0.33 0.33 1.04 2.46 11.10 13.37 SE 8.25 5.75 49.25 12.00 0.51 18.33
20279D5 50 0.33 0.33 1.04 1.97 14.93 16.47 SE 9.47 6.00 53.00 10.80 x 16.01
20279J6 50 0.24 0.40 1.04 3.98 6.97 21.43 SE 2.50 2.40 41.80 4.30 x
20279J1 50 0.25 0.25 1.03 1.99 6.10 6.67 SE 6.61 4.50 36.00 10.00 0.37 17.36
20279J2 50 0.25 0.25 1.03 1.76 5.87 5.87 SE 7.00 4.50 36.00 9.98 0.35 14.92
20339J3 25 0.25 0.25 1.04 5.86 5.44 5.50 SE 3.40 3.20 36.00 8.15 0.25 20.93
~~~~

### Pagina 164

Cita: [pdf_2ada277f4accf3ff7dca, p. 164]. Metodo: native.

Calidad: table_structure_not_manually_validated.

~~~~text
161
Appendix F: Results obtained by the 50 mm burner and Ethylene￾Nitrogen mixture
Part of the BRE experiments aboard the ISS was performed by using the 50 mm burner and 
Ethylene Nitrogen mixture. There were several tests that burned for the entire duration of the test 
but with oscillations started before fuel termination.
Table F.1. Test results obtained by the 50 mm burner and ethylene-nitrogen mixture. 
∆ℎ1
𝑋23
Bef. 
test
𝑋23
After 
test p 𝑚̇
..
Osc 
Time
Ext 
Time
End 
cond 𝑞̇
+,-
.. 𝑞̇
/00
.. 𝑇4
Calorim
eter Xr hf
test ID kJ/g bar g/m2
-s s s kW/m2 kW/m2 0
C kW/m2 mm
20247A1 47.20 0.40 0.38 1.07 1.51 24.90 150.93 FTO 79.04 10.60 - 39.73
20247C1 47.20 0.37 0.35 1.08 1.49 24.07 77.60 FTO 73.80 11.35 - 37.35
20247B1 47.20 0.38 0.37 1.07 1.07 36.83 95.47 FTO 81.00 12.70 - 30.53
21028B1 23.60 0.38 0.36 1.07 3.00 20.93 76.83 FTO 2.90 1.10 67.50 9.20 -
21028C1 23.70 0.39 0.38 1.07 2.98 32.30 91.30 FTO 2.70 1.50 71.30 10.50 -
21028B2 15.60 0.36 0.35 1.07 2.98 26.67 74.93 FTO 2.80 1.30 67.00 9.30 -
20247D1 47.20 0.35 0.34 1.06 1.50 36.80 74.97 FTO 5.20 3.00 71.50 10.30 - 37.69
20247G1 47.20 0.32 0.31 1.07 1.49 25.37 63.67 SE 4.90 2.90 65.30 8.62 - 41.88
20247P1 47.20 0.31 0.30 1.07 1.49 23.50 60.50 SE 4.72 2.52 64.04 8.60 - 42.19
20247F1 47.20 0.33 0.32 1.08 1.48 28.30 124.13 FTO 5.20 2.90 71.63 7.70 - 35.57
20247L2 47.20 0.35 0.34 1.08 1.48 38.60 136.97 FTO 5.50 3.25 72.70 11.07 - 34.46
21028D5 47.20 0.31 0.30 1.07 1.24 24.97 52.67 SE 3.30 1.70 63.00 9.10 - 35.08
21028D4 36.00 0.32 0.31 1.06 1.73 25.50 49.53 SE 2.90 1.70 59.70 9.30 - 30.61
21028D3 31.30 0.33 0.32 1.06 1.98 25.37 48.40 SE 2.70 1.60 60.00 9.10 - 33.73
21028D2 23.60 0.34 0.33 1.06 2.48 22.43 49.40 SE 3.30 1.70 59.00 8.50 - 37.86
20247N1 23.00 0.34 0.33 1.08 2.05 15.37 62.77 SE 5.60 3.30 64.55 10.40 - 28.81
20247M1 23.00 0.34 0.33 1.06 2.05 33.60 132.40 FTO 4.80 3.10 75.20 8.45 - 28.40
21028D1 15.60 0.35 0.34 1.05 2.98 25.37 65.33 SE 4.00 2.10 60.00 9.60 - 31.20
20247H2 47.20 0.27 0.26 1.07 1.50 17.23 40.53 SE 3.90 2.03 51.66 8.49 - 41.06
20247J1 47.20 0.26 0.26 1.05 1.49 11.57 20.80 SE 4.20 2.30 48.40 8.00 - 35.86
20247K1 47.20 0.26 0.25 1.05 1.49 12.13 21.53 SE 3.90 2.26 48.20 8.30 - 34.33
21028G4 47.20 0.24 0.24 1.05 1.24 12.63 18.60 SE 4.30 2.50 41.60 9.00 - 28.33
21028G1 15.60 0.24 0.24 1.04 2.98 9.63 18.07 SE 2.83 1.43 39.20 7.20 - 32.04
21028G5 15.40 0.24 0.23 1.05 1.97 10.13 17.30 SE 3.90 2.10 38.30 8.30 0.48 21.42
The radiative loss fraction was calculated using the correlation introduced in [52,60]. It was used 
along with the Eq. (6.17) to estimate the flame temperature and determine if these flames could 
reach steady state. It was shown that all flame temperatures were below the critical temperature 
range of 1100 K to 1200 K.
~~~~

### Pagina 165

Cita: [pdf_2ada277f4accf3ff7dca, p. 165]. Metodo: native.

~~~~text
162
Figure F.1. Preliminary examination of calculated flame temperatures obtained by the 50 mm 
burner
500
600
700
800
900
1000
1100
1200
0 1 2 3 4
calculated	flame	temperature	(K)
fuel	mixture	mass	flux	(g/m2s)
O40-P1-F20-FT
O40-p1-F50-50mm-FT
O40-p1-F100-50mm-FT
O40-p1-F33-50mm-FT
O34-p1-F100-50mm-FT
O34-P56-F25-FT
O40-p1-F100-50mm-SE
O34-p1-F100-50mm-SE
O34-p1-F76-50mm-SE
O34-p1-F66-50mm-SE
O34-p1-F50-50mm-SE
O34-p1-F33-50mm-SE
O27-p1-F100-50mm-SE
O27-p1-F50-50mm-SE
O27-p1-F33-50mm-SE
~~~~

### Pagina 166

Cita: [pdf_2ada277f4accf3ff7dca, p. 166]. Metodo: native.

~~~~text
163
Bibliography
[1] Ross HD Editor and Gollahalli SR Reviewer, Microgravity Combustion: Fire in Free Fall, 
Applied Mechanics Reviews, 55(6), 2002, pp. B116–B117.
[2] B. Burrough, Dragonfly: NASA and the Crisis Aboard the MIR. Harper Collins.
[3] J.M. Linenger, Off the Planet: Surviving Five Perilous Months Aboard the Space Station Mir. 
McGraw-Hill, 2000.
[4] Markan, A., Development and Analysis of a Burning Rate Emulator (BRE) for Study in 
Microgravity, PhD Thesis, UMCP.
[5] Sacksteder, K. R., Greenberg, P. S., Pettegrew, R. D., Tien, J. S., Ferkul, P. V., and Shih, H.-
Y., Forced Flow Flame Spreading Test: Preliminary Findings From the USMP-3 Shuttle 
Mission, Third United States Microgravity Payload: One Year Report"; p. 83-96; NASA/CP￾1998-207891, Washington D.C.
[6] P.V. Ferkul, S.L. Olson, M.C. Johnston, and J.S. T’ien., Flammability Aspects of Fabric in 
Opposed and Concurrent Air Flow in Microgravity. In 8th US National Combustion Meeting, 
8 Th U. S. National Combustion Meeting Organized by the Western States Section of the 
Combustion Institute, pp. 19–22.
[7] J.H. Kimzey, Skylab Results: Proceedings of the 3rd Space Processing Symposium, Vol. 1. 
Technical Report, NASA TM-X-70752: Marshall Space Flight Center.
[8] Ivanov, A. V., Balashov, Y. V., Andreeva, T. V., and Melikhov, A. S., Experimental 
Verification of Material Flammability in Space.
[9] Bhattacharjee, S., and Altenkirch, R. A., Radiation-Controlled, Opposed-Flow Flame Spread 
in a Microgravity Environment, Symposium (International) on Combustion, 23(1), 1991, pp. 
1627–1633.
[10] Markan, A., Sunderland, P. B., Quintiere, J. G., de Ris, J. L., Stocker, D. P., and Baum, H. 
R., A Burning Rate Emulator (BRE) for Study of Condensed Fuel Burning in Microgravity, 
Combustion and Flame, 192, 2018, pp. 272–282.
[11] Sacksteder, K. R., Greenberg, P. S., Pettegrew, R. D., Tien, J. S., Ferkul, P. V., and Shih, H.-
Y., Forced Flow Flame Spreading Test: Preliminary Findings From the USMP-3 Shuttle 
Mission, Washington D.C.
[12] Jomaas, G., Torero, J. L., Eigenbrod, C., Niehaus, J., Olson, S. L., Ferkul, P. V., Legros, G., 
Fernandez-Pello, A. C., Cowlard, A. J., Rouvreau, S., Smirnov, N., Fujita, O., T׳ien, J. S., 
Ruff, G. A., and Urban, D. L., Fire Safety in Space – beyond Flammability Testing of Small 
Samples, Acta Astronautica, 109, 2015, pp. 208–216.
[13] T’ien, J. S., The Possibility of a Reversal of Material Flammability Ranking from Normal 
Gravity to Microgravity, Combustion and Flame, 80(3), 1990, pp. 355–357.
[14] Matalon, M., and Law, C. K., Gas-Phase Transient Diffusion in Droplet Vaporization and 
Combustion, Combustion and Flame, 59(2), 1985, pp. 213–215.
[15] FERNANDEZ-PELLO, A. C., and HIRANO, T., Controlling Mechanisms of Flame Spread, 
Combustion Science and Technology, 32(1–4), 1983, pp. 1–31.
[16] Ferkul, P., Urban, D. L., Olson, S., Ruff, G. A., Easton, J., T’ien, J. S., Liao, Y.-T. T., 
Fernandez-Pello, A. C., Torero, J. L., and Legros, G., The Saffire Experiment: Large-Scale
~~~~

### Pagina 167

Cita: [pdf_2ada277f4accf3ff7dca, p. 167]. Metodo: native.

~~~~text
164
Combustion Aboard Spacecraft, 10th US National Combustion Meeting, Combustion 
Institute.
[17] Link, S., Huang, X., Olson, S., Ferkul, P., and Fernandez-Pello, C., The Effect of Gravity on 
Flame Spread over PMMA Cylinders in Opposed Flow with Variable Oxygen 
Concentration., 46th International Conference on Environmental Systems.
[18] Osorio, A. F., Mizutani, K., Fernandez-Pello, C., and Fujita, O., Microgravity Flammability 
Limits of ETFE Insulated Wires Exposed to External Radiation, Proceedings of the 
Combustion Institute, 35(3), 2015, pp. 2683–2689.
[19] Fernandez-Pello, A. C., Ray, S. R., and Glassman, I., Flame Spread in an Opposed Forced 
Flow: The Effect of Ambient Oxygen Concentration, Symposium (International) on 
Combustion, 18(1), 1981, pp. 579–589.
[20] Torero, J. L., and Fernandez-Pello, A. C., Forward Smolder of Polyurethane Foam in a Forced 
Air Flow, Combustion and Flame, 106(1), 1996, pp. 89–109.
[21] Fernandez-Pello, A., and Williams, F. A., Laminar Flame Spread over PMMA Surfaces, 
Symposium (International) on Combustion, 15(1), 1975, pp. 217–231.
[22] Dosanjh, S. S., Pagni, P. J., and Fernandez-Pello, A. C., Forced Cocurrent Smoldering 
Combustion, Combustion and Flame, 68(2), 1987, pp. 131–142.
[23] Fernandez—Pello, A. C., Flame Spread Modeling, Combustion Science and Technology, 
39(1–6), 1984, pp. 119–134.
[24] Thomsen, M., Carmignani, L., Rodriguez, A., Scudiere, C., Liveretou, C., Fernandez-Pello, 
C., Gollner, M., Olson, S., and Ferkul, P., Downward Flame Spread Rate Over PMMA Rods 
Under External Radiant Heating, Fire Technology, 2022.
[25] Xiong, C., Fan, H., Huang, X., and Fernandez-Pello, C., Evaluation of Burning Rate in 
Microgravity Based on the Fuel Regression, Flame Area, and Spread Rate, Combustion and 
Flame, 237, 2022, p. 111846.
[26] Thomsen, M., Fernandez-Pello, C., Olson, S. L., and Ferkul, P. V., Downward Burning of 
PMMA Cylinders: The Effect of Pressure and Oxygen, Proceedings of the Combustion 
Institute, 38(3), 2021, pp. 4837–4844.
[27] Thomsen, M., Fernandez-Pello, C., Huang, X., Olson, S., and Ferkul, P., Buoyancy Effect on 
Downward Flame Spread Over PMMA Cylinders, Fire Technology, 56(1), 2020, pp. 247–
269.
[28] Urban, D. L., Ferkul, P., Olson, S., Ruff, G. A., Easton, J., T’ien, J. S., Liao, Y.-T. T., Li, C., 
Fernandez-Pello, C., Torero, J. L., Legros, G., Eigenbrod, C., Smirnov, N., Fujita, O., 
Rouvreau, S., Toth, B., and Jomaas, G., Flame Spread: Effects of Microgravity and Scale, 
Combustion and Flame, 199, 2019, pp. 168–182.
[29] Thomsen, M., Fernandez-Pello, C., Urban, D., Ruff, G., and Olson, S., Upward Flame Spread 
over a Thin Composite Fabric: The Effect of Pressure and Microgravity, 48th International 
Conference on Environmental Systems.
[30] Link, S., Huang, X., Fernandez-Pello, C., Olson, S., and Ferkul, P., The Effect of Gravity on 
Flame Spread over PMMA Cylinders, Scientific Reports, 8(1), 2018, p. 120.
[31] Olson, S. L., Ferkul, P. V., and T’ien, J. S., Near-Limit Flame Spread over a Thin Solid Fuel 
in Microgravity, Symposium (International) on Combustion, 22(1), 1989, pp. 1213–1222.
~~~~

### Pagina 168

Cita: [pdf_2ada277f4accf3ff7dca, p. 168]. Metodo: native.

~~~~text
165
[32] Olson, S. L., Kashiwagi, T., Fujita, O., Kikuchi, M., and Ito, K., Experimental Observations 
of Spot Radiative Ignition and Subsequent Three-Dimensional Flame Spread over Thin 
Cellulose Fuels, Combustion and Flame, 125(1–2), 2001, pp. 852–864.
[33] Thomsen, M., Fernandez-Pello, C., Urban, D. L., Ruff, G. A., and Olson, S. L., On Simulating 
Concurrent Flame Spread in Reduced Gravity by Reducing Ambient Pressure, Proceedings 
of the Combustion Institute, 37(3), 2019, pp. 3793–3800.
[34] Dietrich, D., Ross, H., and T’ien, J., Candle Flames in Non-Buoyant and Weakly Buoyant 
Atmospheres, 32nd Aerospace Sciences Meeting and Exhibit, American Institute of 
Aeronautics and Astronautics.
[35] DIETRICH, D. L., ROSS, H. D., SHU, Y., CHANG, P., and T’IEN, J. S., Candle Flames in 
Non-Buoyant Atmospheres, Combustion Science and Technology, 156(1), 2000, pp. 1–24.
[36] Matalon, M., and Law, C. K., Gas-Phase Transient Diffusion in Droplet Vaporization and 
Combustion, Combustion and Flame, 59(2), 1985, pp. 213–215.
[37] Nayagam V, Microgravity N-Heptane Droplet Combustion in Oxygen-Helium Mixtures at 
Atmospheric Pressure, AIAA Journal, 36(8), 1998, p. 1369.
[38] Nayagam, V., Dietrich, D. L., Ferkul, P. V, Hicks, M. C., and Williams, F. A., Can Cool 
Flames Support Quasi-Steady Alkane Droplet Burning?, Combustion and Flame, 159(12), 
2012, pp. 3583–3588.
[39] Nayagam, V., Dietrich, D. L., Hicks, M. C., and Williams, F. A., Cool-Flame Extinction 
during n-Alkane Droplet Combustion in Microgravity, Combustion and Flame, 162(5), 2015, 
pp. 2140–2147.
[40] Nayagam, V., Dietrich, D. L., Hicks, M. C., and Williams, F. A., Radiative Extinction of
Large N-Alkane Droplets in Oxygen-Inert Mixtures in Microgravity, Combustion and Flame, 
194, 2018, pp. 107–114.
[41] Kumagai, S., Sakai, T., and Okajima, S., Combustion of Free Fuel Droplets in a Freely Falling 
Chamber, Symposium (International) on Combustion, 13(1), 1971, pp. 779–785.
[42] Hajilou, M., Brown, M. Q., Brown, M. C., and Belmont, E., Investigation of the Structure 
and Propagation Speeds of N-Heptane Cool Flames, Combustion and Flame, 208, 2019, pp. 
99–109.
[43] Hajilou, M., and Belmont, E., Characterization of Ozone-Enhanced Propane Cool Flames at 
Sub-Atmospheric Pressures, Combustion and Flame, 196, 2018, pp. 416–423.
[44] NASA-STD-6001B. Flammability, Offgassing, and Compatibility Requirements and Test 
Procedures.
[45] ISO, I. S. O., 5660-1:” Reaction-to-Fire Tests-Heat Release, Smoke Production and Mass 
Loss Rate-Part 1:(Cone Calorimeter Method)”, International Organization for 
Standardization, International Standard Organization, 2002.
[46] Zhang, Y., Kim, M., Guo, H., Sunderland, P. B., Quintiere, J. G., deRis, J., and Stocker, D. 
P., Emulation of Condensed Fuel Flames with Gases in Microgravity, Combustion and 
Flame, 162(10), 2015, pp. 3449–3455.
[47] Zhang, Y., Kim, M., Sunderland, P. B., Quintiere, J. G., and de Ris, J., A Burner to Emulate 
Condensed Phase Fuels, Experimental Thermal and Fluid Science, 73, 2016, pp. 87–93.
[48] Markan, A., Sunderland, P. B., Quintiere, J. G., de Ris, J. L., and Baum, H. R., Measuring 
Heat Flux to a Porous Burner in Microgravity, Proceedings of the Combustion Institute, 
37(3), 2019, pp. 4137–4144.
~~~~

### Pagina 169

Cita: [pdf_2ada277f4accf3ff7dca, p. 169]. Metodo: native.

~~~~text
166
[49] Markan, A., Baum, H. R., Sunderland, P. B., Quintiere, J. G., and de Ris, J. L., Transient 
Ellipsoidal Combustion Model for a Porous Burner in Microgravity, Combustion and Flame, 
212, 2020, pp. 93–106.
[50] Snegirev, A., Kuznetsov, E., Markus, E., Dehghani, P., and Sunderland, P., Transient 
Dynamics of Radiative Extinction in Low-Momentum Microgravity Diffusion Flames, 
Proceedings of the Combustion Institute, 38(3), 2021, pp. 4815–4823.
[51] Dehghani, P., Sunderland, P. B., Quintiere, J. G., and deRis, J. L., Burning in Microgravity: 
Experimental Results and Analysis, Combustion and Flame, 228, 2021, pp. 315–330.
[52] Dehghani, P., and Quintiere, J. G., Theoretical Analysis and Predictions of Burning in 
Microgravity Using a Burning Emulator, Combustion and Flame, 233, 2021, p. 111572.
[53] Dehghani, P. and Peter B. Sunderland, Burning Emulation in Microgravity: Experimental 
Results and Analysis, ASGSR.
[54] Dehghani, P., Auth, E., Cui, C., Stocker, D. P., de Ris, J. L., Sunderland, P. B., and Quintiere, 
J. G., Microgravity Observations of a Burnig Emulator to Investigate Material Flammability, 
ESSCI, Columbia.
[55] Auth, E., Using a Burning Rate Emulator (BRE) to Emulate Condensed Fuels and Study Pool 
Fire Behaviour in 1g, M. Sc. Thesis, University of Maryland.
[56] Auth, E., Quintiere, J. G., and Sunderland, P. B., Emulation of Condensed Fuel Flames with 
Gaseous Fuels Supplied through a Porous Copper Calorimeter, Fire and Materials, 44(7), 
2020, pp. 935–942.
[57] Kuznetsov, E. A., Snegirev, A. Yu., and Markus, E. S., Radiative Extinction of Laminar 
Diffusion Flame above the Flat Porous Burner in Microgravity: A Computational Study, 
Combustion, Explosion, and Shock Waves, 56(4), 2020, pp. 394–411.
[58] Grosshandler, W., RadCal: A Narrow Band Model for Radiation Calculations in a 
Combustion Environment, NIST Technical Note 1402, National Institute of Standards and 
Technology136, Gaithersburg, Maryland.
[59] Vivien R. Lecoustre, RadCal Improvements to the Narrow-Band Model for Radiation 
Calculations in a Combustion Environment, NIST Special Publication 1402, 2nd ed., 
Gaithersburg, Maryland.
[60] Dehghani, P., Quintiere, J. G., and de Ris, J., Burning Emulation of Solids and Liquids in 
Microgravity, Proc. Combust. Inst., 2022.
[61] Kim, H., Procedures to Obtain Accurate Measurement from a Gas Fueled Burner.
[62] Stephen J. Lawn, ACME-RPT-012: Advanced Combustion via Microgravity Experiments 
(ACME) BRE Radiometer Characterization Report.
[63] Michael W. Medved, ACME-DOC-010 Rev D: Advanced Combustion via Microgravity 
Experiments (ACME) Software Interface Design Description Contract NNC09BA02B, DO￾110.
[64] TELEDYNE HASTINGS INSTRUMENTS INSTRUCTION MANUAL HFM-300 FLOW 
METER, HFC-302 FLOW CONTROLLER Document Number 151-032015.
[65] McPherson, K., Hrovat, K., Kelly, E., and Keller, J., A Researcher’s Guide To International 
Space Station Acceleration Environment.
[66] DiNenno, P. J., Association, N. F. P., and Engineers, S. of F. P., SFPE Handbook of Fire 
Protection Engineering, National Fire Protection Association.
[67] Quintiere, J. G., Fundamentals of Fire Phenomena, John Wiley.
~~~~

### Pagina 170

Cita: [pdf_2ada277f4accf3ff7dca, p. 170]. Metodo: native.

~~~~text
167
[68] Quintiere, J. G., Principles of Fire Behavior, CRC Press.
[69] Advanced Combustion via Microgravity Experiments Integrated Science Requirements.
[70] Ban, H., Venkatesh, S., and Saito, K., Convection-Diffusion Controlled Laminar Micro 
Flames, 1994.
[71] ACME-RPT-0013- PMT Characterization Report Rev. - October 2016.
[72] R. Siegel, and J. R. Howell, Thermal Radiation Heat Transfer, Hemisphere, New York.
[73] M. Q. Brewster, Thermal Radiative Transfer and Properties, Wiley, New York.
[74] Tewarson, A., Generation of Heat and Chemical Compounds in Fires,” The SFPE Handbook 
of Fire Protection Engineering (3rd Ed), National Fire Protection Association, Quincy, MA.
[75] Vermina Plathner, F., Quintiere, J. G., and van Hees, P., Analysis of Extinction and Sustained 
Ignition, Fire Safety Journal, 105, 2019, pp. 51–61.
[76] Lundström, F. V., Sunderland, P. B., Quintiere, J. G., van Hees, P., and de Ris, J. L., Study 
of Ignition and Extinction of Small-Scale Fires in Experiments with an Emulating Gas 
Burner, Fire Safety Journal, 87, 2017, pp. 18–24.
[77] ISO 5660-1:2015 Reaction-to-Fire Tests — Heat Release, Smoke Production and Mass Loss 
Rate — Part 1: Heat Release Rate (Cone Calorimeter Method) and Smoke Production Rate 
(Dynamic Measurement).
[78] ISO 5660-1:2015/AMD 1:2019 Reaction-to-Fire Tests — Heat Release, Smoke Production 
and Mass Loss Rate — Part 1: Heat Release Rate (Cone Calorimeter Method) and Smoke 
Production Rate (Dynamic Measurement) — Amendment 1.
[79] Jiang, F., Qi, H., de Ris, J. L., and Khan, M. M., Radiation Enhanced B-Number, Combustion 
and Flame, 160(8), 2013, pp. 1510–1518.
[80] Perry, R. H., Green, D. W., and Maloney, J. O., Perry’s Chemical Engineers’ Handbook, 
McGraw-Hill, New York.
[81] Lide, D. R., Handbook of Chemistry and Physics, CRC Press, Boca Raton.
[82] Howell, J. R., Menguc, M. P., and Siegel, R., Thermal Radiation Heat Transfer, CRC press.
[83] Modest, M., Radiative Heat Transfer.
[84] de Ris, J., Fire Radiation—A Review, Symposium (International) on Combustion, 17(1), 
1979, pp. 1003–1016.
[85] Yu. Snegirev, A., Perfectly Stirred Reactor Model to Evaluate Extinction of Diffusion Flame, 
Combustion and Flame, 162(10), 2015, pp. 3622–3631.
[86] Irace, P. H., Lee, H. J., Waddell, K., Tan, L., Stocker, D. P., Sunderland, P. B., and Axelbaum, 
R. L., Observations of Long Duration Microgravity Spherical Diffusion Flames Aboard the 
International Space Station, Combustion and Flame, 229, 2021, p. 111373.
[87] Tang, S., Im, H. G., and Atreya, A., A Computational Study of Spherical Diffusion Flames 
in Microgravity with Gas Radiation. Part II: Parametric Studies of the Diluent Effects on 
Flame Extinction, Combustion and Flame, 157(1), 2010, pp. 127–136.
[88] Santa, K. J., Chao, B. H., Sunderland, P. B., Urban, D. L., Stocker, D. P., and Axelbaum, R. 
L., Radiative Extinction of Gaseous Spherical Diffusion Flames in Microgravity, Combustion 
and Flame, 151(4), 2007, pp. 665–675.
[89] Lecoustre, V. R., Sunderland, P. B., Chao, B. H., and Axelbaum, R. L., Numerical 
Investigation of Spherical Diffusion Flames at Their Sooting Limits, Combustion and Flame, 
159(1), 2012, pp. 194–199.
~~~~

### Pagina 171

Cita: [pdf_2ada277f4accf3ff7dca, p. 171]. Metodo: native.

~~~~text
168
[90] Lecoustre, V., Narayanan, P., Baum, H., and Trouve, A., Local Extinction of Diffusion 
Flames in Fires, Fire Safety Science, 10, 2011, pp. 583–595.
[91] Narayanan, P., Baum, H. R., and Trouvé, A., Effect of Soot Addition on Extinction Limits of 
Luminous Laminar Counterflow Diffusion Flames, Proceedings of the Combustion Institute, 
33(2), 2011, pp. 2539–2546.
[92] Science Requirements Document for Burning Rate Emulator (BRE): Material Burning and 
Extinction in Microgravity Version 2.11.
[93] Kline, S. J., Describing Uncertainty in Single Sample Experiments, Mech. Engineering, 75, 
1953, pp. 3–8.
[94] Moffat, R. J., Using Uncertainty Analysis in the Planning of an Experiment, 1985.
[95] Lyon, R. E., and Quintiere, J. G., Criteria for Piloted Ignition of Combustible Solids, 
Combustion and Flame, 151(4), 2007, pp. 551–559.
~~~~
