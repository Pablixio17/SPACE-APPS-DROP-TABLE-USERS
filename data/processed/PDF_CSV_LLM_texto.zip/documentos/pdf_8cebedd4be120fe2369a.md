# PS-03403_ACME_on_the_ISS

- Identificador: pdf_8cebedd4be120fe2369a
- Investigaciones: PSI-20, PSI-22, PSI-23
- Tipo de documento: Presentations, Science Documents
- Estado: processed
- Temas detectados automaticamente: oxygen, pressure, ignition, extinction, soot, cool_flames, microgravity, electric_fields, hardware, operations

## Fuentes

- [PSI-20_Science Documents_PS-03403_ACME_on_the_ISS.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-20/Science%20Documents/PSI-20_Science%20Documents_PS-03403_ACME_on_the_ISS.pdf)
- [PSI-22_Presentations_PS-03403 ACME on the ISS.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-22/Presentations/PSI-22_Presentations_PS-03403%20ACME%20on%20the%20ISS.pdf)
- [PSI-23_Presentations_PS-03403 ACME on the ISS.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-23/Presentations/PSI-23_Presentations_PS-03403%20ACME%20on%20the%20ISS.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_8cebedd4be120fe2369a, p. 1]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_8cebedd4be120fe2369a/p0001.jpg)

~~~~text
National Aeronautics and
Space Administration
Advanced Combustion via Microgravity Experiments (ACME)
/U/ML
on the International Space Station (ISS)
Laminar spherical and axisymmetric nonpremixed | Coflow Laminar Diffusion Flame (CLD Flame)
flames of gaseous fuels. | • Key researchers: Marshall Long, Mitch Smooke, and Jesse Tinajero (Yale)
• Goal: Improve computational flame models with benchmark quantitative data for sooty
Fundamental research focused primarily on practical | and extremely diluted microgravity flames.
terrestrial combustion, but also spacecraft fire safety. | • Selected findings
- Microgravity flames contain five to eight times more soot than the equivalent
Six independent experiments using one set of modular | normal-gravity flames.
hardware. | - Microgravity flames are taller and wider.
- Microgravity increases the limits of fuel dilution for both methane and ethylene
Five studies selected by NASA. One study selected | flames. Near limits, microgravity flames are more stable, allowing for lifted flames at
by NSF (National Science Foundation) and CASIS | lower fuel concentrations.
(Center for the Advancement of Science in Space).
U.S.-led research in collaboration with Russian | Electric-Field Effects on Laminar Diffusion Flames (E-FIELD Flames)
universities | • Key researchers: Derek Dunn-Rankin and Yu-Chien Chien (UC Irvine)
- Far Eastern Federal University | • Goal: Understand chemi-ionization in flames and the interplay between ion generation and ion-driven flows.
- Peter the Great St. Petersburg Polytechnic | • Selected findings
University | - In microgravity, flames exhibit a distinct peak ion current that corresponds to the most
and institutes of the Russian Academy of Sciences | compact flame.
- N.N. Semenov Institute of Chemical Physics | - There are clear correlations between flame luminosity, combustion intensity, and ion
- P.N. Lebedev Physical Institute | current.
- When soot is present in a flame, electric fields create a wide range of behaviors.
- Highly diluted flames can be stabilized with very weak electric fields.
- Jet flames, under the influence of the electric field, were unstable at high
Tests carried out within the
field strengths and exhibited corona and then arc discharges.
Combustion Integrated Rack (CIR).
Hardware set up by ISS crew members
from Canada, Germany, Italy, Japan,
Russia, and the United States.
Tests remotely commanded from
NASA's Glenn ISS Payload Operations | Burning Rate Emulator (BRE)
Center. | • Key researchers: Jim Quintiere and Peter Sunderland (U. Maryland), and John de Ris (FM Global, retired)
Four CIR | consoles staffed | • Goal: Determine burning conditions in still atmospheres as a function of material properties.
ground
test | • Selected findings
during | operations.
- Low-momentum microgravity flames can burn for minutes in the
absence of an airflow or flame spread.
- While the flames can burn for minutes in elevated oxygen concentrations,
like those being considered for future spacecraft, they were found to
self-extinguish in concentrations below -25 percent (by volume).
- While smaller flames can burn for minutes at elevated oxygen concentrations,
larger flames were generally seen to self-extinguish within 1.5 minutes.
- While ethylene flames at elevated oxygen concentrations can burn for
minutes, methane flames were seen to self-extinguish within a minute.
Flame Design
• Key researchers: Rich Axelbaum (Washington U. in St. Louis) and Peter Sunderland (U. Maryland)
• Goal: Improve understanding of soot inception and control to enable the optimization of oxygen-enriched
combustion and the "design" of nonpremixed flames that are both robust and soot free.
• Selected findings
- Flame size increases with reactant flow rate and decreases with ambient oxygen concentration.
- Very small flames have low radiative loss and asymptotically approach
On-orbit operations underway since September 2017.
steady-state behavior.
Over 1 ,000 flames ignited during 3.5 years of ISS testing.
- Large flames increase in size over time until the flame extinguishes due
Space station tests for four of six ACME experiments completed. | to radiative heat loss.
- Before total extinction, these flames experience an unstable, oscillatory
mode, in which they partially extinguish and reform. The oscillations grow
in magnitude until total extinction.
Structure and Response of Spherical Diffusion Flames (s-FIame)
• Key researchers: C.K. Law (Princeton) and Stephen Tse (Rutgers)
• Goal: Characterize and gain predictive capability of spherical diffusion flames; interrogate and possibly modify
chemical kinetic mechanisms and transport submodels.
• Selected findings
- Both radiative and kinetic (i.e., convective) extinction of the spherical flames appear to have been observed.
- Radiative extinction seems to occur at high flow rates and kinetic extinction at low flow rates. The latter may
Open-source data gradually shared via | seem counterintuitive, but at low flow rates, the flames are close to the burner where the velocities are highest.
www.nasa.gov/PSI. NASA periodically offers | - With helium, rather than nitrogen, dilution of both the fuel and oxygen, the extinction limits are shifted and kinetic
funding opportunities for its analysis. | extinction is generally difficult to discern.
Engineering and operations by
ZIN | OCCO
Technologies, Inc.
Cool Flames Investigation with Gases (CFI-G)
Managed by NASA's Glenn Research Center | • Key researchers: Peter Sunderland (U. Maryland), Rich Axelbaum (Washington U. in St. Louis), and Forman Williams
in Cleveland, Ohio. | (UC San Diego)
• Goal: Observe quasi-steady nonpremixed spherical cool flames.
WEBSITE: wwwl.grc.nasa.gov/go/acme I PHOTOS: www.flickr.com/photos/space-flames I UPDATES: www.facebook.com/space.flames | www.nasa.gov
PS--03403-0521
CONTACT: Dennis Stocker, NASA Glenn, dennis.p.stocker@nasa.gov
~~~~
