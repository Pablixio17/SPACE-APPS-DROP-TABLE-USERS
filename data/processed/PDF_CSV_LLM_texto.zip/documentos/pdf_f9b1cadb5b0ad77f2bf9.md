# Lopez-Camara et al 2017 Numerical Simulations of a Co-Flow Methane-Air Flame

- Identificador: pdf_f9b1cadb5b0ad77f2bf9
- Investigaciones: PSI-22
- Tipo de documento: Presentations
- Estado: processed
- Temas detectados automaticamente: computational_models, electric_fields, hardware, microgravity

## Fuentes

- [PSI-22_Presentations_Lopez-Camara et al 2017 Numerical Simulations of a Co-Flow Methane-Air Flame.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-22/Presentations/PSI-22_Presentations_Lopez-Camara%20et%20al%202017%20Numerical%20Simulations%20of%20a%20Co-Flow%20Methane-Air%20Flame.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_f9b1cadb5b0ad77f2bf9, p. 1]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_f9b1cadb5b0ad77f2bf9/p0001.jpg)

~~~~text
Drop-Tower experiment at NASA Glenn Research Center (Cleveland, OH). March 5th 2010.
Methane/air flame without external electric applied. Simulating zero-gravity
Pic by Sunny V. Karnani, LFA laboratory (UC Irvine, CA)
2mm
μg

[Texto OCR de la imagen]
Drop-Tower experiment at NASA Glenn Research Center (Cleveland, OH). March 5th 2010.
Methane/air flame without external electric applied. Simulating zero-gravity
Pic by Sunny u Karnani, LFA laboratory (UC Irvine, CA)
2mm
~~~~

### Pagina 2

Cita: [pdf_f9b1cadb5b0ad77f2bf9, p. 2]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_f9b1cadb5b0ad77f2bf9/p0002.jpg)

~~~~text
Drop-Tower experiment at NASA Glenn Research Center (Cleveland, OH). March 5th 2010.
Methane/air flame with external electric field applied (-6kV/cm ). Simulating zero-gravity
Pic by Sunny V. Karnani, LFA laboratory (UC Irvine, CA)
2mm
Methane/air flame with no applied electric field in 1g
Pic by Sunny V.Karnani. LFA laboratory (UC Irvine, CA)
μg

[Texto OCR de la imagen]
Drop-Tower experiment at NASA Glenn Research Center (Cleveland, OH). March 5th 2010.
Methane/air flame with external electric field applied (-6kV/cm ). Simulating zero-gravity
ptg | Pic | LFA
by Sunny u Karnani, | laboratory (UC Irvine, CA)
lg
Methane/air flame with no applie electric fi d in lg
Pic by Sunny V.Karnani. LFA laboratory (UC Irvine, CA)
~~~~

### Pagina 3

Cita: [pdf_f9b1cadb5b0ad77f2bf9, p. 3]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Numerical Simulations of a Co-Flow 
Methane/Air Flame under Different 
Gravity Conditions
Claudia-F. Lopez-Camara Jesse Tinajero Derek Dunn-Rankin
University of California at Irvine (CA, USA)
33rd Annual Meeting of the American Society for Gravitational and Space Research
Hyatt Regency, Seattle’s Southport on Lake Washington, WA, USA
October 25-28 2017
33rd ASGSR Annual meeting. Oct. 25-28, 2017. clopezca@uci.edu 3
~~~~

### Pagina 4

Cita: [pdf_f9b1cadb5b0ad77f2bf9, p. 4]. Metodo: native.

~~~~text
Simulate a methane/air flame with the 
application of an electric field
Goals
1) Understand e-field force action in the flame 
by simplifying the study case (microgravity)
2) Understand how buoyancy force contributes 
to flame behavior and see if there is any 
correlation with the e-field force contribution 
(partial gravity, gravity and hypergravity)
33rd ASGSR Annual meeting. Oct. 25-28, 2017. clopezca@uci.edu 4
~~~~

### Pagina 5

Cita: [pdf_f9b1cadb5b0ad77f2bf9, p. 5]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Burner Geometry
Fig.1. Co-Flow Extruded burner Fig.2. Axial-symmetric Mesh [mm].
Final mesh used after mesh independence test:
144234 squared cells
33rd ASGSR Annual meeting. Oct. 25-28, 2017. clopezca@uci.edu 5
~~~~

### Pagina 6

Cita: [pdf_f9b1cadb5b0ad77f2bf9, p. 6]. Metodo: native.

~~~~text
Mechanism #R Neutrals Chemi-ions
(HCO+
, H3O+)
Excited 
Species
(OH*, CH*)
Non￾Premixed
T. Pedersen
and R.C. 
Brown 
(1993)
86 Yes Yes Yes No
Prager et al. 
(1997) 208 Yes Yes No Yes
GRI-Mech
3.0 (2000) 325 Yes No No Yes
J. Hu et al. 
(2000) 31 Yes Yes No Yes
K. T. Walsh 
(2000) 19 No No Yes Yes
Main published chemical kinetic models for methane/air flames
Chemical-Kinetic Model
33rd ASGSR Annual meeting. Oct. 25-28, 2017. clopezca@uci.edu 6
~~~~

### Pagina 7

Cita: [pdf_f9b1cadb5b0ad77f2bf9, p. 7]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_f9b1cadb5b0ad77f2bf9/p0007.jpg)

~~~~text
Results
Temperature | profiles
0.02
0.015
0.01
1900
1800
0.005
1700
1600
1500
1400
1300
-0.01 | -o. 005 | o. 005 | 0.01 | -0.01 | -0.005 | 0.005 | 0.01 | -0.01 | -0.005 | o. 005 | 0.01 | 1200
x | x | x | 1100
1000
1. 5G | 2G | 3G | 900
0.02
800
700
600
0.015 | 500
400
0.01
UUU
0.005
-0.01 | -o. 005 | 0.005 | 0.01 | -0.01 | -0.005 | o. 005 | 0.01 | -0.01 | -o. 005 | o. 005 | 0.01
x | x | x
33rd ASGSR Annual meeting. Oct. 25-28, 2017. clopezca@uci.edu
~~~~

### Pagina 8

Cita: [pdf_f9b1cadb5b0ad77f2bf9, p. 8]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_f9b1cadb5b0ad77f2bf9/p0008.jpg)

~~~~text
Results
profiles
0.5G | IG
0.00B
0.006
0.004
0.002
1 1811
1811
9812
8812
-0.002 | 7812
6812
-0.004 -o. 002 | 0.002 o. 004 | -0.004 -0.002 | 0.002 0.004 | -o. 004 -0.002 | 0.002 0.004
x | x | x | 5812
4812
3812
1.5G | 2G | 3G
2E-12
IE-12
0.008
0.006
0.004
0.002
0.002
-0.004 -0.002 | o. 002 | 0.004 -o. 002 | o | a. 002 0.004 | -o. 004 -0.002 | o | 0.002 o. 004
x | x | x
33rd ASGSR Annual meeting. Oct. 25-28, 2017. clopezca@uci.edu
~~~~

### Pagina 9

Cita: [pdf_f9b1cadb5b0ad77f2bf9, p. 9]. Metodo: native.

~~~~text
Distance travelled by the jet at the exit speed w0 during the 
period of fuel diffusion tdif, from yF=1 at the jet centre, to the 
stoichiometric value yF = yF,stq at the flame front
9
33rd ASGSR Annual meeting. Oct. 25-28, 2017. clopezca@uci.edu 9
Lfl=tdifw0
tdif=(1−yF,stq)(R)2
/Di
Lfl=flame length
tdif=period fuel diffusion
w0= exit flame speed 
yF,stq= stoich. value (fuel, flame front)
R = radius of the flame
Di = diffusion coefficient
Lfl = w0 · (1−yF,stq) ·(R)2
/Di
ct ct
1G 2G 3G
Lfl [m] 0.051 0.051 0.051
R [m] 0.0025 0.0023 0.0020
w0
[m/s]
1.046 1.489 1.791
~~~~

### Pagina 10

Cita: [pdf_f9b1cadb5b0ad77f2bf9, p. 10]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_f9b1cadb5b0ad77f2bf9/p0010.jpg)

~~~~text
Results
profiles
0.5G | IG
o. 008
o. 004
H20+
o. 002 | 1. 2E-08
1. IE-08
IE-08
9E-09
8E-09
-o. 002
7E-09
-0.004 -0.002 | o | o. 002 0.004 | -0.004 -0.002 | o | 0.002 0.004 | -O. 004 -o. 002 | O. 002 0.004 | 6E-09
x | x | x
5E-09
4E-09
1.5G | 2G | 3G | 3E-09
2E-09
IE-09
0.008
0.006
0.004
0.002
-0.002
-0.004 -0.002 | o. 002 0.004 | -0.004 -0.002 | o | 0.002 0.004 | 0.004 -0.002 | 0.002 0.004
x | x | x
33rd ASGSR Annual meeting. Oct. 25-28, 2017. clopezca@uci.edu | 10
~~~~

### Pagina 11

Cita: [pdf_f9b1cadb5b0ad77f2bf9, p. 11]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_f9b1cadb5b0ad77f2bf9/p0011.jpg)

~~~~text
Results
HCO+ | orofiles
IG
0.008
0.006
0.004
HCO+
0.002 | 1 IE-II
IE-II
9812
8812
-0.002 | 7E-12
6E-12
-o. 004 -o. 002 | 0.002 0.004 | 0.004 | 0.002 | o | 0.002 0.004 | -0.004 -0.002 | 0.002 0.004
x | x | x
5812
4E-12
1.5G | 2G | 3G
3812
2E-12
0.008 | 1812
0.006
0.004
0.002
.0.002
-o. 002 | o | 0.002 0.004 | 0.004 | 0.002 | o | 0.002 o. 004 | -0.004 -0.002 | 0.002 0.004
x | x | x
33rd ASGSR Annual meeting. Oct. 25-28, 2017. clopezca@uci.edu | 11
~~~~

### Pagina 12

Cita: [pdf_f9b1cadb5b0ad77f2bf9, p. 12]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_f9b1cadb5b0ad77f2bf9/p0012.jpg)

~~~~text
Effect of body forces on CH* flame characteristics. [J. Tinajero, PhD dissertation, 2017]
OpenFOAM® Simulation
Buoyancy and E-field forces
33rd ASGSR Annual meeting. Oct. 25-28, 2017. clopezca@uci.edu 12

[Texto OCR de la imagen]
OpenFOAM@ Simulation
Buoyancy and E-field forces
30 | 1.5
20 | $10
10 | $ 05
0.0
1.0 | 1.5 | 2.0 | 1.0 | 1.5 | 2.0
(a) peak mole fraction | (b) base height.
—200
•27mL/min—2.5cm | •27 mlJmin—2.5cm
047mL/min—2.5cm | 0.8 047mL/min--2.5cm
150 +27mL/nun • —3.5cm | +27mL/min--3.5cm
047mL/min—3.5cm | -047 mL/min—3.5cm
0.6
100
0.4
= 50
0.2
Field Strength [kV/cm] | Field Strength [kV/cm]
(c) Fig. 4.6c | (d) Fig. 4.6a
Effect of body forces on CH* flame characteristics. [J. Tinajero, PhD dissertation, 2017]
33rd ASGSR Annual meeting. Oct. 25-28, 2017. clopezca@uci.edu | 12
~~~~

### Pagina 13

Cita: [pdf_f9b1cadb5b0ad77f2bf9, p. 13]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Effect of body forces on CH* flame characteristics. [J. Tinajero, PhD dissertation, 2017]
OpenFOAM® Simulation
Buoyancy and E-field forces
0
10
20
30
40
50
1 1.2 1.4 1.6 1.8 2
% change
G
Latest results 
(Sept 30th 2017, C-F. Lopez-Camara)
33rd ASGSR Annual meeting. Oct. 25-28, 2017. clopezca@uci.edu 13
~~~~

### Pagina 14

Cita: [pdf_f9b1cadb5b0ad77f2bf9, p. 14]. Metodo: native.

~~~~text
Main Flame characteristics
• Flame height was shown to not be affected by a change in gravity field.
• Flame width was affected by producing a thinner plume as it was expected. 
• Detachment with the burner tip was observed numerically and it might be 
attributed to the numerical challenge of these boundary conditions.
• The new combination of chemical kinetic model proposed containing excited 
species and ions has shown to predict important characteristics of the non￾premixed methane laminar jet flame.
CH* chemiluminescence
• CH* profiles showed a brighter flame while going to higher gravity 
environments (hypergravity conditions).
Ions
• High concentration of H3O+ produced and transported far away from the 
flame.
• Higher concentration of naturally produced ions has been observed under 
hypergravity conditions. The electric field effect could be increased under 
strong gravity environments.
Summary
33rd ASGSR Annual meeting. Oct. 25-28, 2017. clopezca@uci.edu 14
~~~~

### Pagina 15

Cita: [pdf_f9b1cadb5b0ad77f2bf9, p. 15]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
OpenFOAM® Simulation
E-field study
Part in collaboration with KAUST
33rd ASGSR Annual meeting. Oct. 25-28, 2017. clopezca@uci.edu 15
~~~~

### Pagina 16

Cita: [pdf_f9b1cadb5b0ad77f2bf9, p. 16]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, sparse_text_or_visual_only, table_structure_not_manually_validated, tiled_ocr_not_manually_verified.

[Imagen de la pagina](../imagenes/pdf_f9b1cadb5b0ad77f2bf9/p0016.jpg)

~~~~text
Thank
you
33rd ASGSR Annual meeting. Oct. 25-28, 2017. clopezca@uci.edu | 16
~~~~

### Pagina 17

Cita: [pdf_f9b1cadb5b0ad77f2bf9, p. 17]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, sparse_text_or_visual_only, table_structure_not_manually_validated, tiled_ocr_not_manually_verified.

[Imagen de la pagina](../imagenes/pdf_f9b1cadb5b0ad77f2bf9/p0017.jpg)

~~~~text
Extra Slides
33rd ASGSR Annual meeting. Oct. 25-28, 2017. clopezca@uci.edu | 17
~~~~

### Pagina 18

Cita: [pdf_f9b1cadb5b0ad77f2bf9, p. 18]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Flame behavior changes with an applied electric field
Introduction
Fig.A1. Co-flow ethane flame with E-field applied. 
Pic by Sunny Karnani, LFA group (UC Irvine, CA, US)
FLAMES AND EXTERNAL E-FIELDS
33rd ASGSR Annual meeting. Oct. 25-28, 2017. clopezca@uci.edu 18
~~~~

### Pagina 19

Cita: [pdf_f9b1cadb5b0ad77f2bf9, p. 19]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Internal 
domain
Co
-flow
Wall
Fuel
Fig.A2. Mesh design (144234 squared cells)
Mesh
(Rough)
33rd ASGSR Annual meeting. Oct. 25-28, 2017. clopezca@uci.edu 19
~~~~

### Pagina 20

Cita: [pdf_f9b1cadb5b0ad77f2bf9, p. 20]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
OpenFOAM® Simulation
Le vs Sc
Le=1 Sc=0.7 
0G 
1G
Le = 1 vs Sc = 0.7
Apparently not big change 
in height. What it really 
makes the difference is 
the transport data 
(Sutherland model 
predicted for each specie) 
but mostly the non￾uniform velocity model.
33rd ASGSR Annual meeting. Oct. 25-28, 2017. clopezca@uci.edu 20
~~~~

### Pagina 21

Cita: [pdf_f9b1cadb5b0ad77f2bf9, p. 21]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
OpenFOAM® Simulation
Le vs Sc
Le=1 Sc=0.7 
0G 
1G
Le = 1 vs Sc = 0.7
Apparently not big change 
in height. What it really 
makes the difference is 
the transport data 
(Sutherland model 
predicted for each specie) 
but mostly the non￾uniform velocity model.
33rd ASGSR Annual meeting. Oct. 25-28, 2017. clopezca@uci.edu 21
~~~~
