# FLEX-1209_Summary

- Identificador: pdf_acec6862d0f07be5aba4
- Investigaciones: PSI-39
- Tipo de documento: Analyzed Data
- Estado: processed
- Temas detectados automaticamente: oxygen

## Fuentes

- [PSI-39_Analyzed Data_FLEX-1209_Summary.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-39/Analyzed%20Data/PSI-39_Analyzed%20Data_FLEX-1209_Summary.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_acec6862d0f07be5aba4, p. 1]. Metodo: native.

~~~~text
1.0
0.8
0.6
0.4
0.2
0.0
( D / D0 )2
0.0 0.5 1.0 1.5 2.0 2.5 3.0
t / D
0
2
 ( s / mm
2
 )
25
20
15
105
Df ( mm ) , Df / Dd
3456789
1
23456789
10
2
Flame Radiance ( W )
Thu, Mar 9, 2017
FLEX-1209
F068A09
P = 774.849 mmHg YO2 = 0.207 YN2 = 0.789 YCO2 = 0.002
Dodecane D0 = 4.190 mm Dext = 3.788 mm kavg = 0.359 mm2
/sec
kavg, cool = 0.391 mm
2
/sec
Dext, cool = nan mm
~~~~
