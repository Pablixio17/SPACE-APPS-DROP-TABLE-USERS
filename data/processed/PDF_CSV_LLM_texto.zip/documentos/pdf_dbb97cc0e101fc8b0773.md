# 22024 Daily Test Point Log

- Identificador: pdf_dbb97cc0e101fc8b0773
- Investigaciones: PSI-10
- Tipo de documento: Raw Data
- Estado: processed
- Temas detectados automaticamente: hardware

## Fuentes

- [PSI-10_Raw Data_22024 Daily Test Point Log.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-10/Raw%20Data/PSI-10_Raw%20Data_22024%20Daily%20Test%20Point%20Log.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_dbb97cc0e101fc8b0773, p. 1]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_dbb97cc0e101fc8b0773/p0001.jpg)

~~~~text
ACME Daily Test Point Log | 1/25/2022
Downlink Data Limit (MB) = 127,000 | Total = | 129,698
Test Point Name Script Aborts | IPSU1/HiBMS | IPSU2/LLL-UV | ACME Camera | Intensified Camera
Downlink
(enter all test | Before 'PSUs | Archived | Archived | Archived | Archived
Data (MB)
points) | Open | Images | D/L? | Images | D/L? | Images | Images | D/L?
22024A1 | 603 | 450 | E] | 1294 | 6,273
22024A2 | 451 | 1297 | 5,020
2202481 | 846 | 1180 | 5,783
22024C1 | 770 | 1449 | 6,351
22024D1 | 753 | 1432 | 6,255
2202482 | 1446 | 1737 | 9,074
2202483 | 788 | 1947 | 7,846
2202461 | 465 | 339 | 1145 | 5,242
22024H1 | 824 | 1183 | 5,731
22024J1 | 649 | 1338 | 5,692
22024K1 | 611 | 1238 | 5,296
2202411 | 616 | 1242 | 5,321
22024L2 | 616 | 1286 | 5,449
2202413 | 612 | 1217 | 5,237
22024H2 | 665 | 1042 | 4,878
22024M1 | 1446 | 1738 | 9,076
22024M2 | 788 | 1947 | 7,846
22024K2 | 821 | 2308 | 8,985
22024K3 | 1320 | 3676 | 14,345
c:]
Date:
~~~~
