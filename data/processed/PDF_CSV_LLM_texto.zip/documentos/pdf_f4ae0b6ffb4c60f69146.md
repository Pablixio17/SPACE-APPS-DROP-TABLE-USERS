# ACME s-Flame  DoD

- Identificador: pdf_f4ae0b6ffb4c60f69146
- Investigaciones: PSI-23
- Tipo de documento: Science Documents
- Estado: processed
- Temas detectados automaticamente: pressure, microgravity, oxygen

## Fuentes

- [PSI-23_Science Documents_ACME s-Flame  DoD.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-23/Science%20Documents/PSI-23_Science%20Documents_ACME%20s-Flame%20%20DoD.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_f4ae0b6ffb4c60f69146, p. 1]. Metodo: native.

Calidad: table_structure_not_manually_validated.

~~~~text
PSI Data Organization Document 
Advanced Combustion via Microgravity Experiments (ACME) Structure and Response of Spherical 
Diffusion Flames (s-Flame) 
1 
To gain an initial understanding of this experiment, refer to the documents “ACME non-imaging data file 
description.pdf” and “s-Flame_final_report_20210729.pdf” located in “Final Report” of the “Resulting Products” 
section on the “Pubs & Docs” tab. 
The s-Flame data is organized in PSI by diluent and fuel composition. Raw data, and video & image data are 
available on the “Scientific Data and Information Tab” of each of the eight “Experiment Data” records: 
 1 Nitrogen-diluted Hydrogen and Oxygen 
 2 Nitrogen-diluted Methane and Oxygen 
 3 Nitrogen-diluted Hydrogen-Methane mixtures and Oxygen 
 4 Nitrogen-diluted Ethylene and Oxygen 
 5 Helium-diluted Hydrogen and Oxygen 
 6 Helium-diluted Methane and Oxygen 
 7 Helium-diluted Hydrogen-Methane mixtures and Oxygen 
 8 Helium-diluted Ethylene and Oxygen 
Within each “Experiment Data” record, “Raw Data”, “Images” and “Audio/Video Files” are available on the 
“Scientific Data and Information” tab. Test names are formatted YYDDDX# where YY identifies year, DDD identifies 
day of year (GMT), X identifies a letter and # identifies a number – where the different numbers can be for repeats 
but are typically variants, e.g., with different flow rate(s) or instrumentation setting(s), e.g. 19308F1. Record 
naming and listings are based on the detailed information in the test conditions table below (page 2). 
Test specific raw data files are located on the “Raw Data and Information” tab of the “Raw & Analyzed Data” 
record. The first row of the .csv files provides information about the test configuration. The headers of the basic 
data in .csv files is explained in Section 10.1, beginning on page 126 of the “ACME-DOC-010 Rev D.pdf” located in 
the “Data Organization Document(s)” section of the “Scientific Data and Information” section on the “Data” tab of 
the ACME s-Flames “Investigations” record. Associated videos are located on the “General” tab and associated 
images are located on the “Image Data and Information” tab of the “Videos & Images” record. 
There are various other supporting engineering documents, videos, reports and publications available on the other 
tabs of the “Investigations” record.
~~~~

### Pagina 2

Cita: [pdf_f4ae0b6ffb4c60f69146, p. 2]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
PSI Data Organization Document 
Advanced Combustion via Microgravity Experiments (ACME) Structure and Response of Spherical 
Diffusion Flames (s-Flame) 
2
~~~~
