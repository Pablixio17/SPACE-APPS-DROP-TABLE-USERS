# 21196 test parameter notes

- Identificador: pdf_1b8b31244aebfef04b38
- Investigaciones: PSI-159
- Tipo de documento: Raw Data
- Estado: processed
- Temas detectados automaticamente: oxygen, ignition, extinction, hardware, operations

## Fuentes

- [PSI-159_Raw Data_21196 test parameter notes.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-159/Raw%20Data/PSI-159_Raw%20Data_21196%20test%20parameter%20notes.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_1b8b31244aebfef04b38, p. 1]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_1b8b31244aebfef04b38/p0001.jpg)

~~~~text
testpointName | 21196A1
dataCameraprelgnitionExposureUs | 1000000
dataCameraTestExposureUs | 100000
analogCameraShutter | 2
uselntensifiedCamera | TRUE
intensifierlgnitionGain | 20000
intensifierTestGain | 60000
prelgnitionlmageTimeSec
postFlamelmagingTimeSec | 5
useDataCameraAutoGain | FALSE
autoGainTolerancePercent | 5
autoGainMaxDb | 33
autoGainMinDb
autoGainOutliers
autoGainRatePercent | 100
autoGainTargetPercent | so
rampDataCameraGain | FALSE
dataCameraGain1dB
dataCameraGain2dB | 0
dataCameraGain3dB
dataCameraHoldTime1Sec
dataCameraHoldTime2Sec
dataCameraRamp1t02TimeSec | 5
dataCameraRamp2t03TimeSec | 5
dataCameraManualGain | 33
useBracketedExposures | FALSE
bracketinglmagesPerExposure | 1
bracketingNumberOfExposures | 4
bracketingExposureStartUsec | 5000
bracketingExposureMultiplierTimes100 | 1000
igniterStartPosition | 2170
igniterEndPosition | 2290
igniterVelocityCountsPerSec | 80
igniterPreheatPowerV | 3
igniterPreheatDurationMs | 1000
igniterlgnitionPowerV | 4
igniterlgnitionDurationMs | 3000
igniterDelayBeforeRetractMs | 1800
igniterRetractVelocityCountsPerSec | 500
pmt1Gain | 10
pmt2Gain | 10
pmt3Gain | 10
fiberignitionPosition
fiberTestPosition
fiberMoveDuringTest | FALSE
fiberSegmentDistance | 100
fiberVelocity | 3000
fiberHoldDurationSec
fiberCycles | 100
useFoma | TRUE
flowTimeoutSec | 70
oxidizerFlowlgnitionDeitaMs | 2000
nitrogenFlowlgnitionDeltaMs
stabilizationTime1Sec
stabilizationTime2Sec | 5
oxidizerlgnitionFlowSIpm | 0.307
nitrogenlgnitionFlowSlpm | 0.918
oxidizer TestFlow1Slpm | 0.307
nitrogenTestFlow1Slpm | 0.918 | c;
oxidizerTestFlow2Slpm | 0
nitrogenTestFlow2SIpm
oxidizer TestFlow3Slpm
nitrogenTestFJow3Slpm
constantFlowTime1Sec | 40
constantFlowTime2Sec
constantF10wTime3Sec
ignitionToTestRampTimeSec
testFlowRamp1T02TimeSec
testFlowRamp2T03TimeSec | 0
postExtinctionDelaySec | 3
postExtinctionFlowChangeOxidizerPercent
postExtinctionFIowChangeNitrogenPercent
postExtinctionFlowChangeRampTimeSec
postExtinctionFlowChangeHoldSec | 0
~~~~

### Pagina 2

Cita: [pdf_1b8b31244aebfef04b38, p. 2]. Metodo: windows_ocr_grid_removed.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_1b8b31244aebfef04b38/p0002.jpg)

~~~~text
testpointNamel | 2119681
dataCameraPrelgnitionExposureU5 1 | 1000000
dataCameraTestExposureUsl | 100000
analogCameraShutterl | 2
uselntensifiedCamera I | TRUE
intensifierlgnitionGainl | 20000
intensifierTestGainl | 60000
preignitionlmageTimeSecl
postFlamelmagingTimeSecl
useDataCameraAutoGain I | FALSE
a utoGa inT olerancePercent I | 5
autoGainMaxDbl | 33
autoGainMinDb
autoGainOutliers
autoGainRatePercent | 100
autoGainTargetPercent
rampDataCameraGain | FALSE
dataCameraGain1dB
dataCameraGain2dB | 0
dataCameraGain3d8
dataCameraHoldTime1Sec
dataCameraHoldTime2Sec
dataCameraRamp1t02TimeSec | 5
dataCameraRamp2t03TimeSec | 5
dataCameraManualGain
useBracketedExposures | TRUE
bracketinglmagesPerExposure | 1
bracketingNumberOfExposures | 4
bracketingExposureStaÄUsec | soooo
bracketingExposureMultiplierTimes100 | 200
igniterStartPosition | 2170
igniterEndPosition | 2290
igniterVelocityCountsPerSec | 80
igniterPreheatPowerV | 3
igniterPreheatDurationMs | 1000
igniterlgnitionPowerV | 4
igniterlgnitionDurationMs | 3000
igniterDelayBeforeRetractMs | 1800
igniterRetractVelocityCountsPerSec | 500
pmt1Gain | 10
pmt2Gain | 10
pmt3Gain | 10
fiberlgnitionPosition | 10000
fiberTestPosition | 17000
fiberMoveDuringTest | FALSE
fiberSegmentDistance | 100
fiberVelocity | 3000
fiberHoldDurationSec | 1
fiberCycles | 100
useFoma | TRUE
flowTimeoutSec | 70
oxidizerFlowlgnitionDeltaMs
nitrogenFlowlgnitionDeltaMs
stabilizationTime1SeC
stabilizationTime2Sec | 5
oxidizerlgnitionFlowSlpm | 0.307
nitrogenlgnitionFlowSlpm | 0.918
oxidizer TestFlow1SEpm | 0.307
nitrogenTestFlow1Slpm | 0.918
oxidizer TestFlow2Slpm
nitrogenTestFlow2Slpm
oxidizer TestFlow3Slpm
nitrogenTestFlOw3Slpm
constantFlowTime1SeC | 40
constantFlowTime2Sec
constantFlowTime3Sec
ignitionToTestRampTimeSec
testFlowRamp1T02TimeSec
testFlowRamp2T03TimeSec
postExtinctionDelaySec | 3
postExtinctionFlowChangeOxidizerPercent
postExtinctionFlowChangeNitrogenPercent
postExtinctionFlowChangeRampTimeSec
postExtinctionFlowChangeHoEdSec
~~~~

### Pagina 3

Cita: [pdf_1b8b31244aebfef04b38, p. 3]. Metodo: windows_ocr_grid_removed.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_1b8b31244aebfef04b38/p0003.jpg)

~~~~text
testpointNamel | 21196C1
dataCameraPrelgnitionExposureUsl | 1000000
dataCameraTestExposureUsl | 100000
analogCameraShutterl | 2
uselntensifiedCamera | TRUE
intensifierlgnitionGain | 20000
intensifierTestGain | 60000
preignitionlmageTimeSec
postFlamelmagingTimeSec | 5
useDataCameraAutoGain | FALSE
autoGainTolerancePercent | 5
autoGainMaxDb | 33
autoGainMinDb
autoGainOutliers
autoGainRatePercent | 100
autoGainTargetPercent | 50
rampDataCameraGain | FALSE
dataCameraGain1dB
dataCameraGain2dB
dataCameraGain3dB
dataCameraH01dTime1Sec
dataCameraH01dTime2Sec
dataCameraRamp1t02TimeSec | 5
dataCameraRamp2t03TimeSec
dataCameraManualGain | 33
useBracketedExposures | FALSE
bracketinglmagesPerExposure | 1
bracketingNumberOfExposures | 4
bracketingExposureStartUsec | sooo
bracketingExposureMultiplierTimes100 | 1000
igniterStartPosition | 2170
igniterEndPosition | 2290
igniterVelocityCountsPerSec | 80
igniterPreheatP0werV | 3
igniterPreheatDurationMS | 1000
igniterlgnitionPowerV | 4
igniterlgnitionDurationMs | 3000
igniterDelayBeforeRetractMs | 1800
igniterRetractVelocityCountsPerSec | 500
pmt1Gain | 10
pmt2Gain | 10
pmt3Gain | 10
fiberlgnitionPosition
fiberTestPosition
fiberMoveDuringTest | FALSE
fiberSegmentDistance | 100
fiberVelocity | 3000
fiberHoldDurationSec | 1
fiberCycles | 100
useFoma | TRUE
flowTimeoutSec | 130
oxidizerFiowlgnitionDeltaMs
nitrogenFlowlgnitionDeltaMs
sta bilizationTime ISec
stabilizationTime2Sec
oxidizer'gnitionFlowSlpm | 0.307
nitrogenlgnitionFlowSlpm | 0.339
oxidizerTestFlow1Slpm | 0.307
nitrogenTestFIow1Slpm | 0.339
oxidizerTestFlow2SIpm
nitrogenTestFlow2Slpm
oxidizer TestFlow3Slpm
nitrogenTestFlow3Slpm
constantFlowTime1Sec | 100
constantFlowTime2Sec
constantFlowTime3Sec
ignitionToTestRampTimeSec
testFlowRamp1T02TimeSec
testFlowRamp2T03TimeSec
postExtinctionDelaySec | 3
postExtinctionFlowChangeOxidizerPercent
postExtinctionFlowChangeNitrogenPercent
postExtinctionFlowChangeRampTimeSec
postExtinctionF10wChangeH oldsecl
~~~~

### Pagina 4

Cita: [pdf_1b8b31244aebfef04b38, p. 4]. Metodo: windows_ocr_grid_removed.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_1b8b31244aebfef04b38/p0004.jpg)

~~~~text
testpointNamel | 2119601
dataCameraP relgnitionExposure Us I | 1000000
dataCameraTestExposureUsl | 100000
analogCameraShutterl_ | 2
uselntensifiedCameral | TRUE
intensifierlgnitionGainl | 20000
intensifierTestGainl | 60000
preignitionlmageTimeSeCl
postFlamelmagingTimeSecl | 5
useDataCameraAutoGainl | FALSE
autoGainTolerancePercentl | 5
autoGainMaxDbl | 33
autoGainMinDbl
autoGainOutIiersl
autoGainRatePercent | 100
autoGainTargetPercent | 50
rampDataCameraGain | FALSE
dataCameraGain1dB
dataCameraGain2dB
dataCameraGain3dB
dataCameraHoldTime1Sec
dataCameraHoldTime2Sec
dataCameraRamp1t02TimeSec | 5
dataCameraRamp2t03TimeSec | 5
dataCameraManualGain
useBracketedExposures | TRUE
bracketing'magesPerExposure | 1
bracketingNumberOfExposures | 4
bracketingExposureStartUsec | soooo
bracketingExposureMultiplierTimes100i | 200
igniterStartPosition | 2170
igniterEndPosition | 2290
igniterVelocityCountsperSec | 80
igniterPreheatPowerV | 3
igniterPreheatDurationMs | 1000
igniterlgniti0nPowerV | 4
igniterIgnitionDurationMS | 3000
igniterDelayBeforeRetractMs | 1800
igniterRetractVelocityCountsPerSec | 500
pmt1Gain | 10
pmt2Gain | 10
pmt3Gain | 10
fiberIgnitionPosition | 10000
fiberTestPosition | 17000
fiberMoveDuringTest | FALSE
fiberSegmentDistance | 100
fiberVelocity | 3000
fiberHoldDurationSec | 1
fiberCycles | 100
useFoma | TRUE
flowTimeoutSec | 130
oxidizerFlowlgnitionDeltaMs
nitrogenFlowlgnitionDeltaMs
stabilizationTime1Sec
stabilizationTime2Sec | 5
oxidizerlgn itionFlOwSlpm | 0.307
nitrogenlgnitionFlowSlpm | 0.339
oxidizer TestFlow1Slpm | 0.307
nitrogenTestFlow1Slpm | 0.339
oxidizer TestFlow2Slpm
nitrogenTestFlow2Slpm
oxidizer TestFlow3Slpm
nitrogen TestFlow3Slpm
constantFlowTime1Sec | 100
constantFlowTime2Sec
constantFlowTime3Sec
ignitionToTestRampTimeSec
testFlowRamp1T02TimeSec
testFlowRamp2T03TimeSec
postExtinctionDelaySec | 3
postExtinctionFlowChangeOxidizerPercent
postExtinctionFlowChangeNitrogenPercent
postExtinctionFlowChangeRampTimeSec
postExtinctionFlowChangeHoldSec
~~~~

### Pagina 5

Cita: [pdf_1b8b31244aebfef04b38, p. 5]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_1b8b31244aebfef04b38/p0005.jpg)

~~~~text
testpointName | 21196F1
dataCameraPrelgnitionExposureUs | 1000000
dataCameraTestExposureUs | 100000
analogCameraShutter | 2
uselntensifiedCamera | TRUE
intensifierlgnitionGain | 20000
intensifierTestGain | 60000
prelgnitionlmageTimeSec
postFlamelmagingTimeSec | 5
useDataCameraAutoGain | FALSE
autoGainTolerancePercent
autoGainMaxDb | 33
autoGainMinDb
autoGainOutIiers
autOGainRatePercent | 100
autoGainTargetPercent | 50
rampDataCameraGain | FALSE
dataCameraGain1dB
dataCameraGain2dB | 0
dataCameraGain3dB
dataCameraHoldTime1Sec | 0
dataCameraHoldTime2Sec
dataCameraRamp1t02TimeSec | 5
dataCameraRamp2t03TimeSec | 5
dataCameraManualGain | 33
useBracketedExposures | FALSE
bracketinglmagesPerExposure | 1
bracketingNumberOfExposures | 4
bracketingExposureStartUsec | 5000
bracketingExposureMultiplierTimes100 | 1000
igniterStartPosition | 2170
igniterEndPosition | 2290
igniterVelocityCountsPerSec | 80
igniterPreheatPowerV | 3
igniterPreheatDurationMs | 1000
igniter'gnitionPowerV | 4
igniterlgnitionDurationMs | 3000
igniterDelayBeforeRetractMs | 1800
igniterRetractVelociWCountsPerSec | 500
pmt1Gain | 10
pmt2Gain | 10
pmt3Gain | 10
fiberignitionPosition
fiberTestPosition
fiberMoveDuringTest | FALSE
fiberSegmentDistance | 100
fiberVelocity | 3000
fiberHoldDurationSec | 1
fiberCycles | 100
useFoma | TRUE
flowTimeoutSec | 60
oxidizerFlowlgnitionDeltaMs
nitrogenFlowlgnitionDeltaMs
stabilizationTime1Sec
stabilizationTime2Sec | 5
oxidizer IgnitionFlOwSlpm | 0.307
nitrogenlgnitionFlowSlpm | 70 | 1.406
oxidizer TestFlow1S'pm | 0.307
nitrogenTestFlow1Slpm | 1.406
oxidizerTestFlow2Slpm
nitrogenTestFlow2Slpm
oxidizerTestFIow3Slpm
nitrogenTestFlow3Slpm
constantFlowTime1Sec | 30
constantFlowTime2Sec
constantFlowTime3Sec | 0
ignitionToTestRampTimeSec
testFlowRamp1T02TimeSec
testFlowRamp2T03TimeSec
postExtinctionDelaySec | 3
postExtinctionHowChangeOxidizerPercent
postExtinctionFlowChangeNitrogenPercent
postExtinctionF10wChangeRampTimeSec
postExtinctionFIowChangeHoldSec
~~~~

### Pagina 6

Cita: [pdf_1b8b31244aebfef04b38, p. 6]. Metodo: windows_ocr_grid_removed.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_1b8b31244aebfef04b38/p0006.jpg)

~~~~text
testpointName | 21196F1
dataCameraPrelgnitionExposureUs I | 1000000
dataCameraTestExposureUs | 100000
analogCameraShutter
uselntensifiedCamera | TRUE
intensifierlgnitionGain | 20000
intensifierTestGain | 60000
prelgnitionlmageTimeSec
postFlamelmagingTimeSec
useDataCameraAutoGain | FALSE
autoGainTolerancePercentl
autoGainMaxDbl | 33
autoGainMinDb[
autoGainOutliersl
autoGainRatePercentl | 100
autoGainTargetPercentl | 50
rampDataCameraGain | FALSE
dataCameraGain1dB
dataCameraGain2dB
dataCameraGain3dB
dataCameraHoldTime1Sec
dataCameraHoldTime2Sec
dataCameraRamp1t02TimeSec
dataCameraRamp2t03TimeSec
dataCameraManualGainl | 33
useBracketedExposuresl | FALSE
bracketinglmagesPerExposurel
bracketingNumberOfExposures
bracketingExposureStartUsec | 5000
bracketingExposureMultiplierTimes1001 | 1000
igniterStartposition | 2170
igniterEndPosition | 2290
igniterVelocityCountsPerSec | 80
igniterPreheatPowerV
igniterPreheatDurationMs | 1000
igniterlgnitionPowerV
igniterlgnitionDurationMs | 3000
igniterDelayBeforeRetractMsl | 1800
igniterRetractVelocityCou ntsPerSecl | 500
pmt1Gain | 10
pmt2Gain | 10
pmt3Gainl | 10
fiberlgnitionPosition
fiberTestPosition
fiberMoveDuringTest | FALSE
fiberSegmentDistance | 100
fiberVelocityl | 3000
fiberHoldDurationSecl
fiberCyclesl | 100
useFomal | TRUE
flowTimeoutSec | 60
oxidizerFlowlgnitionDeltaMs
nitrogenFlowlgnitionDeltaMs
stabilizationTime1Sec
stabilizationTime2Sec
oxidizerlgnitionFlowSIpm | 0.307
nitrogenlgnitionFlowSlpm | 1.406 | 1 2#2-+71
oxidizerTestFlow1Slpml | 0.307 | I D,495 1
nitrogenTestFlow1Slpml | 1.406 | I n 2211
oxidizer TestFlow2Slpml
nitrogen TestFlow2Slpm
oxidizerTestFlow3Slpm
nitrogenTestFlow3Slpm
constantFlowTime1Sec | 30
constantFlowTime2Secl_
constantFIowTime3Secl
ignitionToTestRampTimeSecl
testFlowRamp1T02TimeSecl
testFlowRamp2T03TimeSecl
postExtinctionDelaySecl
postExtinctionFlowChangeOxidizerPercentl
postExtinctionFlowChangeNitrogenPercentl
postExtinctionFlowChangeRampTimeSec
postExtinctionFlowChangeHoldSec
~~~~

### Pagina 7

Cita: [pdf_1b8b31244aebfef04b38, p. 7]. Metodo: windows_ocr_grid_removed.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_1b8b31244aebfef04b38/p0007.jpg)

~~~~text
testpointNamel | 2119661
dataCameraPrelgnitionExposureUs | 1000000
dataCameraTestExposureUs | 100000
analogCameraShutter | 2
uselntensifiedCamera | TRUE
intensifierlgnitionGain | 20000
intensifierTestGain | 60000
prelgnitionlmageTimeSec
postAamelmagingTimeSec | 5
useDataCameraAut0Gain | FALSE
autoGainT01era ncepercent | 5
autoGainMaxDb | 33
autoGainMinDb
autoGainOutliers
autoGainRatePercent | 100
autoGainTargetPercent | so
rampDataCameraGain | FALSE
dataCameraGain1dB
dataCameraGain2dB
dataCameraGain3dB
dataCameraHoldTime1Sec
dataCameraHoldTime2Sec
dataCameraRamp1t02TimeSec | 5
dataCameraRamp2t03TimeSec | 5
dataCameraManualGain
use3racketedExposures | TRUE
bracketinglmagesPerExposure | 1
bracketingNumberOfExPOSures | 4
bracketingExposureStartUsec | soooo
bracketingExposureMultiplierTimes100 | 200
igniterStartPosition | 2170
igniterEndPosition | 2290
igniterVelocityCountsPerSec | 80
igniterPreheatPowerV | 3
igniterPreheatDurationMs | 1000
igniterlgnitionPowerV | 4
igniterlgnitionDurationMs | 3000
igniterDelayBeforeRetractMs | 1800
igniterRetractVelocityCountsPerSec | 500
pmt1Gain | 10
pmt2Gain | 10
pmt3Gain | 10
fiberlgnitionPosition | 10000
fiberTestPosition | 17000
fiberMoveDuringTest | FALSE
fiberSegmentDistance | 100
fibervelocity | 3000
fiberH01dDurationSec | 1
fiberCycles | 100
useFoma | TRUE
flowTimeoutSec | 60
oxidizerFlowlgnitionDettaMs
nitrogenFlowlgnitionDeltaMs
stabilizationTime1Sec
stabilizationTime2Sec | 5
oxidizerlgnitionFlowSipm | 0.307
nitrogenlgnitionFlowSlpm | 1.406
oxidizer TestFlow1Slpm | 0.307
nitrogen TestFlow1Slpm | 1.406
oxidizerTestFlow2Slpm
nitrogenTestFlow2Slpm
oxidizerTestFlow3Slpm
nitrogenTestFlow3SIpm
constantFlowTime1Sec | 30
constantFlowTime2Sec
constantFlowTime3Sec
ignitionTOTestRampTimeSec
testFlowRamp1T02TimeSec
testFlowRamp2T03TimeSec
postExtinctionDelaySec | 3
postExtinctionFIowChangeOxidizerPercent
postExtinctionFlowChangeNitrogenPercent
postExtinctionFlowChangeRampTimeSeC
postExtinctionFlowChangeH01dSec | 0
~~~~
