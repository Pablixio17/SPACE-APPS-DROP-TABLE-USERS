# Drawing_Solid.Fuel.Sample_2cmSphere

- Identificador: pdf_51aaea3a2a31c4322f9a
- Investigaciones: PSI-26
- Tipo de documento: Engineering Documents
- Estado: processed
- Temas detectados automaticamente: solid_materials

## Fuentes

- [PSI-26_Engineering Documents_Drawing_Solid.Fuel.Sample_2cmSphere.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-26/Engineering%20Documents/PSI-26_Engineering%20Documents_Drawing_Solid.Fuel.Sample_2cmSphere.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_51aaea3a2a31c4322f9a, p. 1]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_51aaea3a2a31c4322f9a/p0001.jpg)

~~~~text
6 | 5 | 4 | 3 | 2
NOTES
CAST ACRYLIC CABOCHON
PURCHASE FROM. CURBELL PLASTICS INC
THEIR PART NUMBER. ACRBALL0150
OR | AN ENGINEER APPROVED EQUIVALENT
D | D
2 | CERTIFICATE OF CONFORMANCE REQUIRED FOR
ALL COMMERCIAL PARTS AND ALL PROCESSES
3 | C | ONLY BY IMMERSION IN MI D SOAP
SOLUTION IN DISTILLED WATER | RINSE
WITH DISTILLED WATER AND AIR DRY
4 | HANDLE WITH CLEAN LINT | GLOVES
5 | B FORE STORAGE | PROTECT WITH
CONTAMINATION BARRIER | USE CLEAN | NEW,
TRANSPARENT POLYETHYLENE BAG FOR
ITEMS OR 4 | THICK MINIMUM
POLYETHYLENE SHEET AND SEAL
IDENTIFY PART BY TAGGING WITH PART
(SR9 53) | NUMBER AND SERIAL/LOT NUMBER AS
c | SPECIFIED IN WORK ORDER PER SAE AS 418 | c
METHOD 35
WI 9 06)
750 INCH STOCK
SECTION
CHG | ZONE | DESCRIPTION | A pp/DATE
REVISIONS
UNLESS OTHERWISE SPECIFIED | ZIN TECHNOLOGIES
NATIONAL A RONAU lcs AND SPACE ADMINISTRA ION
6745 ENGLE ROAD
JOHN H. GLENN RES ARCH CENT R
ALL DIMENSIONING AND | AIRPORT EXECUTIVE PARK
LEWIS Fl LD
TO ERANCING PER | CLEVELAND, OHIO 44130
CLEVE AND, OHIO
ASME Y14.5M-1994 | ZIN Technologies 440 625-2200
2 ALL DIMENSIONS ARE | PROJECT
IN MILLIMETERS | LEAD | T LORIK | 2/8/10
3 BREAK EDGES. 0.2-0 5 | SPHER CA | SAMPLE ASSEMBLY | 2CM
QUALITY D LYDEN | 2/8/10
4. LINEAR TOLERANCES.
o, 5-6 | SA ETY c BODZIONEY 2/8/10 | S1183VlFA1040
OVER 6-30
OVER 30 | 3 | ENG | J BRIJ EWER | 2/8/10
OVER 120-315 | 5
OV R 315- 000 ± 0 8 | DESIGNER c DIXON | 2/8/10 | SOLID FUEL SAMPLE | 2CM SPHERE
THIS DRAWING I s UNDER CONFIGURATION | OVER 1000-2000 ±I.2
5 ANGULAR TOLERANCES 00 30 | REVIEWER | PREVITE | 2/8/10
CONTROL | DO NO | REV | THOU | APPROVED aco
CONTRACT NUMBER NNC09BA02B | SIZE | DRAWING NUMBER | REV | BLDG | AREA
THIRD ANGLE | DELIV | ORDER: SPAC 118 | ZIN | GRC
S1183MFD1041
DATE | PROJECT ION | MODEL NAME | N T S: mm
E. McCLOSKEY | 2/9/10 | 183M D1041 | SCALE | NIT IAL REL DATE | S | DISCIPLINE
PRIOR o USE CHECK FOR ANY OUTSTANDING ECO'S WITH CONF IGURATION MANAGEMENT OFFICE | 4/ | 2/8/10
p RO/ E VERS ION | re 2.0
6 | 5 | 4 | 3
~~~~
