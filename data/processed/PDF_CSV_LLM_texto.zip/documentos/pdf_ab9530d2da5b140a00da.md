# FLEX-1238_Summary

- Identificador: pdf_ab9530d2da5b140a00da
- Investigaciones: PSI-39
- Tipo de documento: Analyzed Data
- Estado: processed
- Temas detectados automaticamente: oxygen, cool_flames, droplets

## Fuentes

- [PSI-39_Analyzed Data_FLEX-1238_Summary.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-39/Analyzed%20Data/PSI-39_Analyzed%20Data_FLEX-1238_Summary.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_ab9530d2da5b140a00da, p. 1]. Metodo: native.

~~~~text
1.0
0.8
0.6
0.4
0.2
0.0
( D / D0 )2
0.0 0.5 1.0 1.5 2.0 2.5 3.0
t / D
0
2
 ( s / mm
2
 )
30
25
20
15
105
Df ( mm ) , Df / Dd
0.1
23456
1
23456
10
2
Flame Radiance ( W )
16
14
12
1086420
Df, cool ( mm )
400
300
200
100 0
Peak Cool Flame Grayscale
Mon, May 1, 2017
FLEX-1238
F121A05
P = 387.279 mmHg YO2 = 0.210 YN2 = 0.790 YCO2 = 0.000 YHe = 0.000
Dodecane D0 = 4.463 mm Dext = 4.015 mm kavg = 0.369 mm2
/sec
kavg, cool = 0.328 mm
2
/sec
Dext, cool ~ 1.780 mm
 Droplet History
 Hot-Flame Diameter
 Hot-Flame FSR
 Cool Flame Diameter (FWHM)
 Cool Flame Diameter (peak-peak) 
 Cool Flame Grayscale
~~~~
