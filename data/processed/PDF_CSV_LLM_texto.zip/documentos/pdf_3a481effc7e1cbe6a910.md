# 21088 daily test point log

- Identificador: pdf_3a481effc7e1cbe6a910
- Investigaciones: PSI-159
- Tipo de documento: Raw Data
- Estado: processed
- Temas detectados automaticamente: hardware

## Fuentes

- [PSI-159_Raw Data_21088 daily test point log.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-159/Raw%20Data/PSI-159_Raw%20Data_21088%20daily%20test%20point%20log.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_3a481effc7e1cbe6a910, p. 1]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_3a481effc7e1cbe6a910/p0001.jpg)

~~~~text
ACME Daily Test Point Log | 3/30/2021
Downlink Data Limit (MB) = 127,000 | Total = | 119,739
Test Point Name Script Aborts | IPSU1/HiBMS | ACME Camera | Intensified Camera
Downlink
(enter all test | Before IPSUs | Archived | Archived | Archived
Data (MB)
points) | Open | Images | D/L? | Images | Images
21088A1 | 1076 | 696 | 2017 | 10,048
2108881 | 974 | 342 | 1944 | 8,635
21088C1 | 944 | 333 | 1829 | 8,213
21088D1 | 389 | 2074 | 9,430
21088DF1 | 535 | 186 | 1262 | 5,301
2108861 | 990 | 621 | 2156 | 10,062
21088H1 | 1154 | 407 | 2413 | 10,554
21088J1 | 891 | 313 | 1968 | 8,449
21088K1 | 1683 | 596 | 3237 | 14,580
21088H2 | 2100 | 766 | 3966 | 18,043
21088M1
21088M2
21088M3
21088M4 | 179 | 1160 | 3,863
2108811 | 289 | 1154 | 4,153
21088N1 | 151 | 1239 | 4,014
21088P1 | 164 | 1357 | 4,393
Date:
~~~~
