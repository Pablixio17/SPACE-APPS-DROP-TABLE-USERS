# 19150 test sheets

- Identificador: pdf_b1b2b89f87c8249adbd7
- Investigaciones: PSI-10
- Tipo de documento: Raw Data
- Estado: processed
- Temas detectados automaticamente: pressure, ignition, hardware, oxygen

## Fuentes

- [PSI-10_Raw Data_19150 test sheets.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-10/Raw%20Data/PSI-10_Raw%20Data_19150%20test%20sheets.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_b1b2b89f87c8249adbd7, p. 1]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_b1b2b89f87c8249adbd7/p0001.jpg)

~~~~text
ACME / Flame Design (normal flame) - Science Test Sheet
est date: | 3D zoc | CME test #: 7150k/
Local time: | est of day#: | /
MT: | /9(0 | /4 | Flame of day#:
TEST CONDITIONS | ontrol? | Xfully automated o 'manual'
Test type? o ignition o no-flame standardø other
INSTRUMENTATION | FP? no o fixed moving o back-n-forth
DataCam: filter? Y-clear o BG7 0 CH* o CH20 | 01? full o reduced | fps
_
Xlntensified: filter? clear | D CH20 0 none | ROI? E full o reduced | Z3fps
HiBMs: backlight filter? no Vyes | CIR backlight? o noy yes fps? | 30
FLAME BEHAVIOR | sk.,+k-se | but ...*
Flame | hole/opening(s) | 00t V:none o ignition only o little o lots
o asymmetric o
Flame | unsteady o blew out | oot@end none ignition a little a lots
a oscillating a
POST-TEST CONDITIONS | Oxidizer bottle pressure: 4 | psia
conc. | 39.67 % (volume) | alve safety timer | sec
xygen
*GENERAL COMMENTS
9fsøQL | ++
D--z_
6 Feb. 2019
~~~~

### Pagina 2

Cita: [pdf_b1b2b89f87c8249adbd7, p. 2]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_b1b2b89f87c8249adbd7/p0002.jpg)

~~~~text
ACME / Flame Design (normal flame) - Science Test Sheet
est date: | 30 Zec | CME test#: I
Local time: | est of day | Z
MT: | Flame of day#:
TEST CONDITIONS | ontrol? | Kfully automated 'manual'
Test type? o ignition o no-flame o standard o other
xygen conc. | % (volume) | Burner type: | 1/4" sphere a jet
hamber | sia | Fuel Bottle: o CH4 | 0/0LC2H41— %
pressure: | Z..te
ent before? mo | to | psia | Burner fuel conc.: | % (volume)
o yes,
Air' added? | to | psia | Fuel flow rate: | slpm (N2 basis)
pho o yes,
Iso just before? <fan GC o scrub | N2 flow rate: | slpm
INSTRUMENTATION | FP? o no o fixedß moving o back-n-forth
DataCam: filter? Ä_clear BG7 | CH20 | ROI? E full o reduced | fps
Intensified: filter? o clear CH* o CH20 0 none | ROI? z full o reduced | fps
HiBMs: backlight filter? no Ayes | CIR backlight? no eyes fps? e 15 30
FLAME BEHAVIOR | Ignited? o yes o no o yes, but ...*
Flame | o hole/opening(s) | 00t a none o ignition only o little o lots
o asymmetric
Flame oscillating o unsteady o blew out | oot@end o none o ignition o little a lots
o
POST-TEST CONDITIONS | xidizer bottle pressure: | psia
conc. | % (volume) | alve safety timer | sec
xygen
*GENERAL COMMENTS
6 Feb. 2019
~~~~

### Pagina 3

Cita: [pdf_b1b2b89f87c8249adbd7, p. 3]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_b1b2b89f87c8249adbd7/p0003.jpg)

~~~~text
ACME / Flame Design (normal flame) - Science Test Sheet
est date: | 3 | CME test#•. | D
Local time: | est of day #:
MT: / | c | Flame of day#:
TEST CONDITIONS | ontrol? | R fully automated o 'manual'
Test type? o ignition o no-flame o standard Bother
conc. | % (volume) | Burner type: | sphere jet
xygen
hamber | psia | Fuel Bottle: o CH4 | 0/6 R C2H4 LAO/O
pressure:
ent before? | to | psia | Burner fuel conc.: | % (volume)
o no o yes,
Air' added? | to | psia | Fuel flow rate: | slpm (N2 basis)
D no o yes,
Iso just before? | fan GC scrub | N2 flow rate: | slpm
INSTRUMENTATION | FP? o no o fixed Lmoving o back-n-forth
UDataCam: filter? E clear a BG7 0 | a CH20 | ROI? efull a reduced | fps
Intensified: filter? o clear (CH* o CH20 a none | ROI? g-full o reduced | z fps
O
HiBMs: backlight filter? ono | CIR backlight? o no *yes | a 30
o | yes
FLAME BEHAVIOR | +4 | Ignited? yes o no D yes, but ..
Flame | hole/o ening(s) | 00t (none ignition only o little o lots
o asymmetric o
Flame | unsteady o blew out | oot@end cnone ignition a little lots
o oscillating o
POST-TEST CONDITIONS | Oxidizer bottle pressure: | psia
conc. | % (volume) | alve safety timer | II | sec
xygen
*GENERAL COMMENTS
6 Feb. 2019
~~~~

### Pagina 4

Cita: [pdf_b1b2b89f87c8249adbd7, p. 4]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_b1b2b89f87c8249adbd7/p0004.jpg)

~~~~text
ACME / Flame Design (normal flame) - Science Test Sheet
est date: | 2-01 | CME test#: 1 15b
Local time: | est of day | 4
MT: | Flame of day #:
TEST CONDITIONS | ontrol? | automated o 'manual'
Test type? o ignition Cl no-flame o standard(other
conc. | —40 % (volume) | Burner type: | {1/4" sphere o jet
xygen
hamber | 14-6 psia | Fuel Bottle: | CH4 | C2H4 | %
pressure:
ent before? uno o | to | psia | Burner fuel conc.: | % (volume)
yes,
Air' added? | o | to | psia | Fuel flow rate: | slpm (N2 basis)
eno yes,
Iso just before? | an a GC a scrub | N2 flow rate: | slpm
INSTRUMENTATION | FP? Xoo o fixed o moving back-n-forth
DataCam: filter? clear BG7 a | CH20 | ROI? o full o reduced | fps
_
o Intensified: filter? D clear o CH* o CH20 0 none | ROI? o full o reduced | fps
HiBMs: backlight filter? no o yes | CIR backlight? o no yes fps? 0 15 30
a
Ignited? Eyes a no o yes, but *
FLAME BEHAVIOR | ...
Flame | hole/o ening(s) | 00tßnone o ignition only o little o lots
o asymmetric o
Flame oscillating unsteady a blew out | oot@end wnone o ignition a little a lots
o
POST-TEST CONDITIONS | Oxidizer bottle pressure: | psia
conc. | % (volume) | alve safety timer | sec
xygen
*GENERAL COMMENTS
Öz_ be-ß-e- -Esot———
6 Feb. 2019
~~~~

### Pagina 5

Cita: [pdf_b1b2b89f87c8249adbd7, p. 5]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_b1b2b89f87c8249adbd7/p0005.jpg)

~~~~text
ACME / Flame Design (normal flame) - Science Test Sheet
est date: | 30 Zb I | CME test
Local time: | est of day #:
Flame of day
TEST CONDITIONS | Control? | Cfully automated o 'manual'
Test type? o ignition o no-flame o standard Bother
xygen conc. | % (volume) | Burner type: | *4/4" sphere jet
hamber | psia | Fuel Bottle: o CH4 | % EC2H4k>b %
pressure:
ent before? no o | to | psia | Burner fuel conc.: | % (volume)
o | yes,
Air' added? | to | psia | Fuel flow rate: | slpm (N2 basis)
o no yes,
Iso just before? o fan o GC o scrub | N2 flow rate: | slpm
INSTRUMENTATION | FP? o no o fixed Ünoving back-n-forth
a-Datacam: filter? Gear o BG7 CH* CH20 | ROI? (full o reduced | fps
filter? clear | o CH20 0 none | ROI? full o reduced | fps
HiBMs: backlight filter? o no wyes | CIR backlight? no cyes fps? U15 0 30
FLAME BEHAVIOR | Ignited? (yes a no o yes, but ...*
Flame | o hole/opening(s) | 00t o none o ignition only o little o lots
o asymmetric
Flame | unsteady a blew out | oot@end o none o ignition little o lots
xoscillating a
POST-TEST CONDITIONS | Oxidizer bottle pressure: | psia
conc. | % (volume) | alve safety timer | 7 | sec
xygen
*GENERAL COMMENTS
cJ2Ja—
öz_
6 Feb. 2019
~~~~

### Pagina 6

Cita: [pdf_b1b2b89f87c8249adbd7, p. 6]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_b1b2b89f87c8249adbd7/p0006.jpg)

~~~~text
ACME / Flame Design (normal flame) - Science Test Sheet
est date: | CME test
Local time: | est of day
MT: | r50 | Flame of day#:
TEST CONDITIONS | ontrol? | Afully automated 'manual'
Test type? o ignition no-flame o standard *other
xygen conc. | '1-40 % (volume) | Burner type: | L_1/4" sphere o jet
Chamber pressure: | psia | Fuel Bottle: o CH4
ent before? | to | psia | Burner fuel conc.: | % (volume)
gno yes,
Air' added? | o o | to | psia | Fuel flow rate: D | slpm (N2 basis)
yes,
Iso just before? Afan o GCo scrub | N2 flow rate: | slpm
INSTRUMENTATION | FP? o no o fixed moving o back-n-forth
DataCam: filter? It-lear o BG7 0 | o CH20 | ROI? Efull o reduced | fps
g
• filter? o clear CH* a CH20 0 none | ROI? o full a reduced | fps
: backlight filter? no o yes | CIR backlight? no o yes fps? 0 15 D 30
FLAME BEHAVIOR | Ignited? o yes Kno o yes, but ...*
Flame | o hole/opening(s) | 00t o none ignition only o little a lots
o asymmetric
Flame | unsteady o blew out | oot@end none o ignition little o lots
o oscillating o
POST-TEST CONDITIONS | xidizer bottle pressure: | psia
conc. 30b I % (volume) | alve safety timer
xygen
*GENERAL COMMENTS
6 Feb. 2019
~~~~

### Pagina 7

Cita: [pdf_b1b2b89f87c8249adbd7, p. 7]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_b1b2b89f87c8249adbd7/p0007.jpg)

~~~~text
ACME / Flame Design (normal flame) - Science Test Sheet
est date: | CME test #: | 5032-—
Local time: | est of day #:
MT: | 150 | Flame of day #:
TEST CONDITIONS | ontrol? | g-fully automated o 'manual'
Test type? o ignition o no-flamaX standard bother
Oxygen conc. | % (volume) + Burner type: | Y-1/4" sphere o jet
Chamber | 4, | psia | OR Fuel Bottle: o CH4 | % e-C2H4/æQ0/0
pressure:
ent before? | to | psia | Burner fuel conc.: | % (volume)
zno o yes,
Air' added? | to | psia | Fuel flow rate: Obl slpm (N2 basis)
pno o yes,
Iso | before? | an o GC scrub | N2 flow rate: 0.4" slpm
just
INSTRUMENTATION | FP? o no fixed &wving o back-n-forth
DataCam: filter? | o BG7 c] CH* CH20 | ROI? Q full o reduced | fps
u-lntensifiedzfilter? clear o CH* a CH20 none | ROI? o full o reduced | fps
o
filter? no | CIR backlight. no yes fps? 0 15 30
yes
Ignited? Gs o no o | but *
FLAME BEHAVIOR | yes, | ...
Flame | hole/o ening(s) | 00t none ignition only o little o lots
o asymmetric o
Flame | blew out | oot@end a none ignition a little o lots
o oscillating o unsteady
POST-TEST CONDITIONS | Oxidizer bottle pressure: | psia
Oxygen conc. | % (volume) | alve safety timer | Zsec
*GENERAL COMMENTS
6 Feb. 2019
~~~~

### Pagina 8

Cita: [pdf_b1b2b89f87c8249adbd7, p. 8]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_b1b2b89f87c8249adbd7/p0008.jpg)

~~~~text
ACME / Flame Design (normal flame) - Science Test Sheet
est date: | o Zot | CME test | 1 OCI
Local time: | est of day #:
MT: | Flame of day #:
TEST CONDITIONS | ontrol? | & fully automated 'manual'
Test type? o ignition o no-flame | a other
INSTRUMENTATION | FP? o no o fixe | moving o back-n-forth
DataCam: filter? Aclear o BG7 0 | CH20 | ROI? Mull o reduced | fps
s4Rtensifieek-fi4ter? o clear o CH* o CH20 a none | ROI? o full o reduced | fps
_
cklight filter? no o | CIR backlight? no yes fps? 15 0 30
yes
FLAME BEHAVIOR | Ignited? yes o no o yes, but ...*
Flame | hole/opening(s) | 00t o none | only o little o lots
o asymmetric o
Flame | unsteady o blew out | oot@end none o ignition o little lots
o oscillating o
POST-TEST CONDITIONS | Oxidizer bottle pressure: | psia
conc. | % (volume) | alve safety timer | sec
xygen
*GENERAL COMMENTS
6 Feb. 2019
~~~~

### Pagina 9

Cita: [pdf_b1b2b89f87c8249adbd7, p. 9]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_b1b2b89f87c8249adbd7/p0009.jpg)

~~~~text
ACME / Flame Design (normal flame) - Science Test Sheet
date: | Ze | CME test | 7150 | 3
est | t
Local time: | est of day #:
MT: | Flame of day #:
150
TEST CONDITIONS | ontrol? | automated o 'manual'
Test type? o ignition o no-flamdstandard o other
INSTRUMENTATION | FP? o no o fixed moving o back-n-forth
DataCam: filter? | BG7 0 CH* a CH20 | ROI? Afull o reduced | fps
o
ter? clear o CH* CH20 0 none | ROI? o full o reduced | fps
o
-e-HiBMs•. backlight filter? no | CIR backlight? no o yes fps? 0 15 30
yes
FLAME BEHAVIOR | Ignited? *yes o no yes, but
Flame | hole/opening(s | 00t Znone ü ignition only little o lots
o asymmetric o
Flame | blew out | oot@end $none o ignition o little D lots
oscillating c] unsteady o
POST-TEST CONDITIONS | xidizer bottle pressure: | psia
conc. | 4 | % (volume) | alve safety timer | sec
xygen | _
*GENERAL COMMENTS
6 Feb. 2019
~~~~

### Pagina 10

Cita: [pdf_b1b2b89f87c8249adbd7, p. 10]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_b1b2b89f87c8249adbd7/p0010.jpg)

~~~~text
ACME / Flame Design (normal flame) - Science Test Sheet
est date: | / | CME test #: | )
Local time: | est of day#: /O
MT: | So | Flame of day #:
I
TEST CONDITIONS | ontrol? | <ully automated o 'manual'
Test type? o ignition no-flame | o other
conc. | % (volume) | Burner type: | ÅA/4" sphere a jet
xygen
hamber | psia 4k Fuel Bottle: o CH4
pressure:
ent before? | to | psia | Burner fuel conc.: | % (volume)
no o yes,
Air' added? •no | to | psia | Fuel flow rate: DSslpm (N2 basis)
o yes,
Iso just before? ufan o GC scrub | N2 flow rate: D, | slpm
INSTRUMENTATION | FP? o no o fixed Åmoving a back-n-forth
DataCam: filter? kclear BG7 a CH* CH20 | ROI? Åfull a reduced | fps
g-tm¯tftect•. filter? a clear a CH* o CH20 a none | ROI? o full o reduced | fps
Ü+åiBMs4acklight filter? no | CIR backlight? no o yes fps? 0 15 0 30
yes
Ignited? o | no o | but *
FLAME BEHAVIOR | ye | yes, | ...
Flame | hole/opening(s) | 00t o none a ignition only o little lots
o asymmetric o
Flame | unsteady o blew out | oot@end a none a ignition a little a lots
o oscillating o
POST-TEST CONDITIONS | Oxidizer bottle pressure: | psia
37.42— % (volume) | alve safety timer | S' | sec
xygen conc.
*GENERAL COMMENTS
*37-43 To D-z—
6 Feb. 2019
~~~~

### Pagina 11

Cita: [pdf_b1b2b89f87c8249adbd7, p. 11]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_b1b2b89f87c8249adbd7/p0011.jpg)

~~~~text
ACME / Flame Design (normal flame) - Science Test Sheet
date: | CME test | 7150b Z.—
est | 30
Local time: | est of day #:
MT: | Flame of day#: g
CONDITIONS | ontrol? | fully automated o 'manual'
TEST
Test type? o ignition o no-flame øtandard D other
INSTRUMENTATION | FP? o no o fixed Wrw/ing a back-n-forth
Datacam: filter? | BG7 a | CH20 | ROI? æfull o reduced | fps
o
filter? clear CH* o CH20 0 none | ROI? d full o reduced | fps
e-httensified: | o | a | _
filter? | CIR backlight? | ooyes fps? 15 0 30
o Hi8MS?bäcklight | no yes
Ignited? | o no o | but *
FLAME BEHAVIOR | yes, | ...
hole/opening(s) | 00t o none ignition only o little o lots
Flame asymmetric o
blew out | oot@end a none ignition o little D lots
Flame o oscillating o unsteady o
POST-TEST CONDITIONS | Oxidizer bottle pressure: | psia
Z IS % (volume) | alve safety timer | sec
xygen conc.
*GENERAL COMMENTS
6 Feb. 2019
~~~~

### Pagina 12

Cita: [pdf_b1b2b89f87c8249adbd7, p. 12]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_b1b2b89f87c8249adbd7/p0012.jpg)

~~~~text
ACME / Flame Design (normal flame) - Science Test Sheet
est date: | CME test | 5
Local time: | est of day | (2—
MT: | Flame of day #:
TEST CONDITIONS | ontrol? | *fully automated o 'manual'
Test type? o ignition o no-flame standard o other
conc. | % (volume) | Burner type: | (1/4" sphere a jet
xygen
hamber | psia | Fuel Bottle: o CH4 | % QC2H4 | %
pressure:
ent before? | o | to | psia | Burner fuel conc.: | % (volume)
o no yes,
Air' added? | to | psia | Fuel flow rate: öz slpm (N2 basis)
o no o yes,
Iso just before? dfan a GC scrub | N2 flow rate: 0.46 slpm
INSTRUMENTATION | FP? o no fixed moving a back-n-forth
LDataCam: filter? | BG7 0 CH* o CH20 | ROI? e full o reduced | fps
Intensified: filter? o cleare CH* CH20 0 none | ROI? V full D reduced | fps
filter? no o | CIR backlight? ko yes fps? 15 30
yes
FLAME BEHAVIOR | Ignited? yes o no o yes, but ...*
Flame | hole/opening(s) | 00t o none o ignition only o little o lots
o asymmetric o
Flame | unsteady blew out | oot@end o none o ignition o little a lots
POST-TEST CONDITIONS | xidizer bottle pressure: | psia
conc. | -7 Z % (volume) | alve safety timer | sec
xygen
*GENERAL COMMENTS
6 Feb. 2019
~~~~

### Pagina 13

Cita: [pdf_b1b2b89f87c8249adbd7, p. 13]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_b1b2b89f87c8249adbd7/p0013.jpg)

~~~~text
ACME / Flame Design (normal flame) - Science Test Sheet
est date: | CME test
Local time: | est of day #:
MT: | Flame of day #:
TEST CONDITIONS | ontrol? | <ully automated o frnanual'
Test type? o ignition D no-flame 'standard D other
INSTRUMENTATION | FP? o no fixed Goving o back-n-forth
K DataCam: filter? | o BG7 0 CH* o CH20 | ROI? full a reduced | fps
a-tntéfiSifiéd•. filter? clear D CH* o CH20 0 none | ROI? o full o reduced | fps
o
z-HiBMs±ackIight filter? o no | CIR | yes fps? 0 15 30
yes
Ignited? | o no o | but *
FLAME BEHAVIOR | yes | yes, | ...
Flame | hole/opening(s) | 00t a none a ignition only o little lots
asymmetric o
Flame | unsteady blew out | oot@end a none o ignition little o lots
o oscillating o | o
POST-TEST CONDITIONS | Oxidizer bottle pressure: | psia
conc. | % (volume) | alve safety timer | sec
xygen
*GENERAL COMMENTS
{leu..)
e.. | 'Jte.rr
Q
Z—bS
6 Feb. 2019
~~~~

### Pagina 14

Cita: [pdf_b1b2b89f87c8249adbd7, p. 14]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_b1b2b89f87c8249adbd7/p0014.jpg)

~~~~text
ACME / Flame Design (normal flame) - Science Test Sheet
est date: | 2-DI | CME test #: | (5bC--æ
Local time: | est of day #:
GMT: | 5 | Flame of day #:
TEST CONDITIONS | ontrol? | fully automated o 'manual'
Test type? o ignition no-flame Vs.tandard a other
conc. | (volume) | Burner type: | 81/4" sphere o jet
xygen
hamber | psia | Fuel Bottle: | CH4 | 0/6LC2H4 | %
pressure: | Clf
before? | to | psia | Burner fuel conc.: | % (volume)
ent | uno o yes,
Air' added? | to | psia | Fuel flow rate: | a Zslpm (N2 basis)
Eno o yes,
Iso just before? | fan o GC o scrub | N2 flow rate: | slpm
INSTRUMENTATION | FP? o no D fixed Xmoving o back-n-forth
filter? uclear o BG7 0 CH* o CH20 | ROI? éfull a reduced | fps
a-tT1terts#id: filter? clear o CH* o CH20 0 none | ROI? o full o reduced | fps
o
filter? D no | CIR backlight? uno yes fps? a 15 0 30
yes
FLAME BEHAVIOR | Ignited? Q yes o no yes, but ...*
Flame | hole/opening(s) | 00t o none d-ignition only o little Clots
o asymmetric o
Flame | A-blew out | oot@end gnone ignition little o lots
ø-unsteady
POST-TEST CONDITIONS | Oxidizer bottle pressure: | psia
% (volume) | alve safety timer | 2-7 ( sec
xygen conc.
*GENERAL COMMENTS
6 Feb. 2019
~~~~

### Pagina 15

Cita: [pdf_b1b2b89f87c8249adbd7, p. 15]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_b1b2b89f87c8249adbd7/p0015.jpg)

~~~~text
ACME / Flame Design (normal flame) - Science Test Sheet
est date: | CME test#: 1 5
Local time: | est of day #:
MT: | Flame of day#:
TEST CONDITIONS | ontrol? | fully automated o 'manual'
Test type? o ignition o no-flame•Åstandard o other
conc. | h-- o % (volume) -E Burner type: | QI/4" sphere o jet
xygen
hamber | psia | Fuel Bottle: o CH4 | % C2H4 tDö0/0
pressure:
before? | to | psia | Burner fuel conc.: | % (volume)
ent | o no o yes,
Air' added? | to | psia | Fuel flow rate: 02- slpm (N2 basis)
o no D yes,
Iso just before? | fan a GC scrub | N2 flow rate: | slpm
INSTRUMENTATION | FP? o no o fixed g.rnoving a back-n-forth
DataCam: filter? | o BG7 0 CH* o CH20 | full o reduced | fps
O | (clear
caJRtertsifie+filter? o clear o CH* o CH20 0 none | ROI? o full o reduced | fps
oNBMs:-batklight filter? D no | CIR backlight? *no o yes fps? 15 0 30
yes
FLAME BEHAVIOR | Ignited? (yes o no yes, but .
Flame | hole/opening(s) | 00t o none e-ignition only o little clots
o asymmetric o
Flame | Qblew out | oot@end g none ignition little lots
oscillating unsteady
POST-TEST CONDITIONS | xidizer bottle pressure:' | psia
conc. | -7S % (volume) | alve safety timer | sec
xygen
*GENERAL COMMENTS
beæe_ 4-z-s+—
354% O.z_
6 Feb. 2019
~~~~

### Pagina 16

Cita: [pdf_b1b2b89f87c8249adbd7, p. 16]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_b1b2b89f87c8249adbd7/p0016.jpg)

~~~~text
ACME / Flame Design (normal flame) - Science Test Sheet
est date: | 201 | test#: 19/50
Local time: | 332- | est of day #:
MT: | / | 5 | ODS3Z- | Flame of day | 2—
TEST CONDITIONS | Control? | < fully automated o 'manual'
Test type? ü ignition o no-flame | o other
INSTRUMENTATION | FP? o no fixed moving o back-n-forth
DataCam: | o BG7 0 CH* o CH20 | ROI? < full a reduced | fps
Q4n-tertsifieå•. filter? o clear a CH* o CH20 0 none | ROI? wfull o reduced | fps
filter? o no | CIR backlight? Go o yes fps? 15 0 30
yes
FLAME BEHAVIOR | Ignited? Ryes a no a yes, but ...*
Flame | o hole/opening(s) | 00t o none< ignition only o little Xlots
o asymmetric
Flame | unsteady B-blew out | oot@end o none ignitionnlittle o lots
%scillating
POST-TEST CONDITIONS | xidizer bottle pressure: | b psia
conc. | "16 % (volume) | alve safety timer | sec
xygen
*GENERAL COMMENTS
•-}-esf—
t-b-
6 Feb. 2019
~~~~

### Pagina 17

Cita: [pdf_b1b2b89f87c8249adbd7, p. 17]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_b1b2b89f87c8249adbd7/p0017.jpg)

~~~~text
ACME / Flame Design (normal flame) - Science Test Sheet
est date: | CME test #: | 15063
Local time: | est of day #:
7
MT: | Flame of day #:
Rack Officer (RO): | PD (ACME):
DMO (CIR): | Researcher:
TEST CONDITIONS | ontrol? | g-fully automated o 'manual'
Test type? ignition o no-flameastandard o other
conc. | M40 % (volume) | Burner type: | 1/4" sphere c] jet
xygen
Chamber | psia | Fuel Bottle: | CH4 | tee 0/0
pressure: | CAR
ent before? | to | psia | Burner fuel conc.: | % (volume)
kno o yes,
Air' added? | to | psia | Fuel flow rate: 02-slpm (N2 basis)
o yes,
Iso just before? Xfan o GC o scrub | N2 flow rate: | slpm
INSTRUMENTATION | FP? no o fixed moving a back-n-forth
filter? clear o BG7 0 CH* CH20 | ROI? < full o reduced | fps
p
z4Rtensified: filter? clear a CH* CH20 0 none | ROI? o full a reduced | fps
HiBMs: backlight filter? D no Eyes | CIR backlight? no Åyes fps? 15 30
FLAME BEHAVIOR | Ignited? dyes o no yes, but .
Flame | hole/opening(s) | 00t o noneAignltion only o little Alots
o asymmetric o
Flame | zunsteady zblew out | oot@end o none o ignition R little lots
g-oscillating
POST-TEST CONDITIONS | xidizer bottle pressure: | psia
conc. 33 Sb % (volume) | alve safety timer | sec
xygen
*GENERAL COMMENTS
3+14% Dz-
6 Feb. 2019
~~~~

### Pagina 18

Cita: [pdf_b1b2b89f87c8249adbd7, p. 18]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_b1b2b89f87c8249adbd7/p0018.jpg)

~~~~text
ACME / Flame Design (normal flame) - Science Test Sheet
date: | CME test | Dhjl
est | 30
Local time: | est of day#: 13
GMT: | Flame of day #:
Rack Officer (RO): | PD (ACME):
DMO (CIR): | Researcher:
TEST CONDITIONS | ontrol? | automated o 'manual'
Test type? D ignition | o other
conc. | % (volume) | Burner type: | Y-4/4" sphere c] jet
xygen
hamber | 14. | psia | Fuel Bottle: | CH4
pressure:
ent before? | to | psia | Burner fuel conc.: | % (volume)
o no •yes,
Air' added? | "es, to | psia | Fuel flow rate•o.07 | slpm (N2 basis)
o no
Iso just before? (fan o GC<scrub | N2 flow rate: 0.234 slpm
INSTRUMENTATION | FP? o no o fixed g-moving o back-n-forth
g-DataCam: filter? *clear BG7 | CH20 | ROI? <ull o reduced | fps
a-ln-tensified•; filter? o clear o CH* o CH20 0 none | ROI? o full o reduced | fps
backlight filter? o no o yes | CIR backlight? | o yes fps? a 15 30
p-HBMs:
FLAME BEHAVIOR | Ignited? Zyes no o yes, but .
Flame | hole/opening(s) | oot&none ignition only o little o lots
o asymmetric o
Flame | blew out | oot@end gnone o ignition a little o lots
Aoscillating Aunsteady
POST-TEST CONDITIONS | Oxidizer bottle pressure: | psia
conc. 2 | Z % (volume) | alve safety timer | sec
xygen
*GENERAL COMMENTS
c-)2_ be-.ß-e—
*
6 Feb. 2019
~~~~

### Pagina 19

Cita: [pdf_b1b2b89f87c8249adbd7, p. 19]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_b1b2b89f87c8249adbd7/p0019.jpg)

~~~~text
ACME / Flame Design (normal flame) - Science Test Sheet
est date: | zol | CME test #: | DS
b
Local time: | est of day #:
MT: | 035/1 | Flame of day #:
TEST CONDITIONS | ontrol? | 4 fully automated o 'manual'
Test type? o ignition no-flameßstandard o other
conc. | % (volume) | Burner type: | sphere jet
xygen
hamber | OR Fuel Bottle: CH4 | 0/0 a-C2H4
pressure:
ent before? | to | psia | Burner fuel conc.: lc.2> % (volume)
no o yes,
Air' added?øno | to | psia | Fuel flow rate•+'O.o, slpm (N2 basis)
o yes,
Iso just before? afan o GC scrub | slpm
INSTRUMENTATION | FP? o no o fixed R moving a back-n-forth
DataCam: filter? | BG7 CH* CH20 | ROI? (-full o reduced | fps
ofitensified*-$.iker? clear o CH* CH20 none | ROI? E full o reduced | fps
HiBMs: backlight filter? | CIR backlight? o no z yes fps? | 30
yes
FLAME BEHAVIOR | Ignited? Ayes o no o yes, but .
Flame | hole/opening(s) | 00t none ddgnition only o little o lots
o asymmetric o
Flame | unsteady o blew out | oot@end Rnone o ignition little D lots
oscillating o
POST-TEST CONDITIONS | Oxidizer bottle pressure: | psia
conc. | 4 % (volume) | alve safety timer | sec
xygen
*GENERAL COMMENTS
6 Feb. 2019
~~~~
