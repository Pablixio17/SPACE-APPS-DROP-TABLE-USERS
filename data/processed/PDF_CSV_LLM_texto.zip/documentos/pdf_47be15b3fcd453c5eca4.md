# 21265 test parameter notes

- Identificador: pdf_47be15b3fcd453c5eca4
- Investigaciones: PSI-159
- Tipo de documento: Raw Data
- Estado: processed
- Temas detectados automaticamente: oxygen, ignition, extinction, hardware, operations

## Fuentes

- [PSI-159_Raw Data_21265 test parameter notes.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-159/Raw%20Data/PSI-159_Raw%20Data_21265%20test%20parameter%20notes.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_47be15b3fcd453c5eca4, p. 1]. Metodo: windows_ocr_grid_removed.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_47be15b3fcd453c5eca4/p0001.jpg)

~~~~text
testpointName | 21265A1
dataCameraPrelgnitionExposureUs | 1000000
dataCameraTestExposureUs | 100000 | CCS
analogCameraShutter | 2 | 1
uselntensifiedCamera | 1
intensifierlgnitionGain | 20000
intensifierTestGain | 60000
prelgnitionlmageTimeSec
postFlamelmagingTimeSec | 5
useDataCameraAutoGain
autoGainTolerancePercent | 5
autoGainMaxDb | 33
autoGainMinDb
autoGainOutliers
autoGainRatePercent | 100
autoGainTargetPercent | 50
rampDataCameraGain
dataCameraGain1dB
dataCameraGain2dB
dataCameraGain3dB
dataCameraHoldTime1Sec
dataCameraHoldTime2Sec
dataCameraRamp1t02TimeSec | 5
dataCameraRamp2t03TimeSec
dataCameraManualGain | 33
useBracketedExposures
bracketinglmagesPerExposure | 1
bracketingNumberOfExposures | 4
bracketingExposureStartUsec | 50000
bracketingExposureMulti plierTimes100 | 200
igniterStartPosition | 2170
igniterEndPosition | 2290
igniterVelocityCountsPerSec | 80
igniterPreheatPowerV | 3
igniterPreheatDurationMs | 1000
igniterlgnitionPowerV | 4
igniterlgnitionDurationMs | 3000
igniterDelayBeforeRetractMs | 1800
igniterRetractVelocityCountsPerSec | 500
pmt1Gain | 10
pmt2Gain | 8
pmt3Gain | 10
fiberlgnitionPosifion
fiberTestPosition
fiberMoveDuringTest
fiberSegmentDistance | 100
fiberVelocity | 3000
fiberHoldDurationSec | 1
fiberCycles | 100
useFoma | 1
flowTimeoutSec | 90
oxidizerFlowlgnitionDeltaMs | 2000
nitrogenFlowlgnitionDeltaMs
stabilizationTime1Sec
stabilizationTime2Sec | 5
oxidizerlgnitionFlowSlprn | 0.295 | DDhß o,)
nitrogen IgnitionFlowSlpm
oxidizer TestFlow1Slpm | 0.295 | ,sui9 /
nitrogen TestFlow1Slpm
oxidizerTestFlow2Slpm
nitrogenTestFlow2Slpm
oxidizer TestFlow3Slpm
nitrogenTestFlow3Slpm
consta ntFlowTime1Sec | 60
constantFlowTime2Sec
consta ntFlowTime3Sec
ignitionToTestRampTmeSec
testFlowRamp1T02TimeSec
testFlowRa m p2 T03TimeSec
postExtinctionDelaySec | 3
postExtinctionFlowChangeOxidizerPercent
postExtinctionFlowChangeNitrogenPercent
postExtinctionFlowChangeRampTimeSec
postExtinctionFlowChangeHoldSec
~~~~

### Pagina 2

Cita: [pdf_47be15b3fcd453c5eca4, p. 2]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_47be15b3fcd453c5eca4/p0002.jpg)

~~~~text
testpointName | 2126581
dataCameraPrelgnitionExposureUs | 1000000
dataCameraTestExposureUs | 100000
analogCameraShutter | 2
uselntensifiedCamera | 1
intensifierlgnitionGain | 20000
intensifierTestGain | 60000
preignitionlmageTimeSe
postFlameEmagingTimeSec | 5
useDataCameraAutoGain
autoGainTolerancePercent | 5
autoGainMaxDb | 33
autoGainMinDb
autoGainOutliers
autoGainRatePercent | 100
autoGainTa etPercent | 50
rampDataCameraGain | 0
dataCameraGain1dB
dataCameraGain2dB
dataCameraGain3dB
dataCameraHoldTime1Sec
dataCameraHoldTime2Sec | 0
dataCameraRamp1t02TimeSec | 5
dataCameraRam 2t03TimeSe | 5
dataCameraManualGain
useBracketedExposures | 1
bracketinglmagesperExposure
bracketingNumberOfExposures | 4
bracketingExposureStartUsec | 50000
bracketingExposureMultiplierTimes100 | 200
igniterStartPosition | 2170
igniterEndPosition | 2290
igniterVelocityCountsPerSe | 80
igniterPreheatPowerV | 3
igniterPreheatDurationMs | 1000
igniterlgnitionPowerV | 4
igniterlgnitionDurationMs | 3000
igniterDelayBeforeRetractMs | 1800
i niterRetractVelocityCountsPerSe | 500
pmt1Gain | 10
pmt2Gain | 8
pmt3Gain | 10
fibertgnitionPosition | 10000
fiberTestPosition | 17000
fiberMoveDuringTest
fiberSegmentDistance | 100
fiberVeloci | 3000
fiberHoldDurationSec | 1
fiberCycles | 100
useFoma | 1
flowTimeoutSec | 90
oxidizerFlowignitionDeltaMs
nitrogenFlowlgnitionDeltaMs
stabilizationTime1Se
stabilizationTime2Sec | 5
oxidizerlgnitionFlowSlpm | o. 295
nitrogenlgnitionFlowSlpm
oxidizerTestFlow1Slpm | 0.295
nitrogen TestFlow1Slpm
oxidizer TestFlow2Slpm
nitrogenTestFlow2Slpm
oxidizerTestFlow3Slpm
nitrogenTestFlow3Slpm
constantFlowTime1Sec | 60
constantFlowTime2Sec
constantFlowTime3Sec
ignitionToTestRampTimeSe
testFlowRamp1T02 TmeSe
testFlowRam 2T03TimeSe
postExtinctionDelaySec | 3
postExtinctionFlowChangeOxidizerPercent
postExtnctionFlowChangeNitrogenPercent
postExtinctionFlowChangeRampTimeSec
postExtinctionFlowChangeHoldSec | 0
~~~~

### Pagina 3

Cita: [pdf_47be15b3fcd453c5eca4, p. 3]. Metodo: windows_ocr_grid_removed.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_47be15b3fcd453c5eca4/p0003.jpg)

~~~~text
testpointNamel | 21265C1
dataCameraPrelgnitionExposureUsl | 1000000
dataCameraTestExposuretJsl | 100000
analogCameraShutterl | 2
uselntensifiedCarneral | 1
intensifierignitionGainl | 20000
intensifierTestGain! | 60000
preignitionlmageTimeSec
postFlameImagingTimeSec | 5
useDataCameraAutoGain
autoGainTolerancePercent | 5
autoGainMaxDb | 33
autoGainMinDb
autoGainOutliers
autoGainRatePercent | 100
autoGainTargetPercent | 50
rampDataCameraGain
dataCameraGain1dB
dataCameraGain2dB
dataCameraGain3dB
dataCameraHoldTime1Sec
dataCameraHoldTime2Sec
dataCameraRamp1t02T1meSec | 5
dataCamera Ramp2t03TimeSec | 5
dataCameraManualGain | 33
useBracketedExposures
bracketinglmagesPerExposure | 1
bracketingNumberOfExposures | 4
bracketingExposureStartUsec | 50000
bracketingExposureMultiplierTimes100 | 200
igniterStartPosition | 2170
igniterEndPosition | 2290
igniterVelocityCountsPerSec | 80
igniterPreheatPowerV | 3
igniter PreheatDurationMS | 1000
igniterlgnitionPowerV | 4
igniterlgnitionDurationMs | 3000
igniterDelayBeforeRetractMs | 1800
igniterRetractVelocityCountsPerSec | 500
pmt1Gain | 10
pmt2Gain | 8
pmt3Gain | 10
fiberlgnitionposition
fiberTestPosition
fiberMoveDuringTest
fiberSegmentDistance | 100
fiberVelocity | 3000
fiberHoldDurationSec | 1
fiberCycles | 100
useFoma | 1
flowTimeoutSec | 90
oxidizerFlowlgnitionDeltaMs
nitrogen FlowlgnitionDeltaMS | 4500
stabilizationTime1Sec
stabilizationTime2Sec | 5
oxidizerlgnitionFlowStpm | 0.295 | OH-ty
nitrogenlgnitionFlOwSlpm | 0.203
oxidizerTestFlow1Slpm | 0.295 | 0097
nitrogenTestFlow1Slpm | 0.203
oxidizer TestFlow2Slpm
nitrogen TestFlow2Slpm
oxidizerTestFlow3Slpm
nitrogenTestFlow3Slpm
constantFlowTime1Sec | 60
constantFlowTime2Sec
constantFlowTime3Sec
ignitionToTestRampTimeSec
testFlowRamp1T02TimeSee
testFlowRamp2T03TimeSec!
postExtinctionDelaySecl, | 3
postExtinctionFlowChangeOxidizerPercentl | 0
postExtinction FlowCha ngeNitrogenPercentl
postExtinctionFlowChangeRampTimeSecl | 0
postExtnctionFlowChangeHoldSecl
~~~~

### Pagina 4

Cita: [pdf_47be15b3fcd453c5eca4, p. 4]. Metodo: windows_ocr_grid_removed.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_47be15b3fcd453c5eca4/p0004.jpg)

~~~~text
testpointName | 2126SD1
dataCameraPrelgnitionExposureUs | 1000000
dataCameraTestExposureUs | 100000
analogCameraShutter | 2
uselntensifiedCamera | 1
intensifiertgnitionGain | 20000
intensifierTestGain | 60000
preignitionlmageTimeSec
postFlamelmagingTimeSec | 5
useDataCameraAutoGain
autoGainTolerancePercent | 5
autoGainMaxDb | 33
autoGainMinDb
autoGainOutliers
autoGainRatePercent | 100
autoGainTargetPercent | 50
rampDataCameraGain
dataCameraGain1dB
dataCameraGain2dB
dataCameraGain3dB
dataCameraHoldTime1Sec
dataCameraHoldTime2Sec
dataCameraRamp1t02TimeSec | 5
dataCameraRamp2t03TimeSec | 5
dataCameraManualGain
useBracketedExposures | 1
bracketinglmagesPerExposure | 1
bracketingNumberOfExposures | 4
bracketingExposureStartUsec | 50000
bracketingExposureMultiplierTimes100 | 200
igniterStartPosition | 2170
igniterEndPosition | 2290
igniterVelocityCountsPerSec | 80
igniterPreheatPowerV | 3
igniterPreheatDurationMs | 1000
igniterlgnitionPowerV | 4
igniterlgnitionDurationMs | 3000
igniterDelayBeforeRetractMs | 1800
igniterRetractVelocityCountsPerSec | 500
pmt1Gain | 10
pmt2Gain | 8
pmt3Gain | 10
fiberlgnitionPosition | 10000
fiberTestPosition | 17000
fiberMoveDuringTest
fiberSegmentDistance | 100
fiberVelocity | 3000
fiberHoldDurationSec | 1
fiberCycles | 100
useFoma | 1
flow TimeoutSec | 90
oxidizerFlowlgnitionDeltaMs
nitrogen FlowlgnitionDeltaMS | 4500
stabilizationTime1Sec
stabilizationTime2Sec | 5
oxidizerlgnitionFlowSlpm | 0.295
nitrogenlgnitionFlowSlpm | 0.203
oxidizer TestFlow1Slpm | 0.295
nitrogen TestFlow1Slpm | 0.203
oxidizerTestFlow2Slpm
nitrogen TestFlow2Slpm
oxidizerTestFlow3Slpm
nitrogen TestFlow3Slpm
constantFlowTime1Sec | 60
constantFlowTime2Sec
constantFlowTime3Sec
ignitionToTestRampTimeSec
testFlowRamp1T02TimeSec
testFlowRamp2T03TimeSec
postExtinctionDelaySec | 3
postExtinctionFlowChangeOxidizerPercent | 0
postExtinctionFlowChangeNitrogenPercent
postExtinctionFlowChangeRampTimeSec
postExtinctionFlowChangeHoldSec
~~~~

### Pagina 5

Cita: [pdf_47be15b3fcd453c5eca4, p. 5]. Metodo: windows_ocr_grid_removed.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_47be15b3fcd453c5eca4/p0005.jpg)

~~~~text
testp0intNamel | 21265F1
dataCameraPrelgnitionExposureUsl | 1000000
data CameraTestExposureUsl | 100000
analogCameraShutterl | 2
uselntensifiedCameral | 1
intensifierlgnitionGainl | 20000
intensifierTestGain! | 60000
preignitionlmageTimeSec
postFlamelmagingTimeSec | 5
useDataCameraAut0Gain
autoGainTolerancePercent | 5
autoGainMaxDb | 33
autoGainMinDb
autoGainOuttiers
autoGainRatePercent | 100
autoGainTargetPercent | 50
rampDataCameraGain
dataCameraGain1dB
dataCameraGain2dB
dataCameraGain3dB | o
data Camera HoldTime ISec
dataCameraHoldTime2Seq
dataCameraRamp1t02TimeSec11 | 5
dataCameraRamp2t03TimeSecl | 5
dataCameraManuatGainl | 33
useBracketedExposuresl
bracketinglmagesPerExposurel | 1
bracketingNumberOfExposures | 4
bracketingExposureStartUsec | 50000
bracketingExposureMultiplierTimes100 | 200
igniterStartPosition | 2170
igniterEndPosition | 2290
igniterVelocityCountsPerSec | 80
igniterPreheatPowerV | 3
igniterPreheatDurationMs | 1000
igniterlgnitionPOwerV | 4
igniterlgnitionDurationMs | 3000
igniterDelayBeforeRetractMs | 1800
igniterRetractVelocityCountsPerSec | 500
pmt1Gain | 10
pmt2Gain | 8
pmt3Gain | 10
fibertgnitionPosition
fiberTestPosition
fiberMoveDuringTest
fiberSegmentDistance | 100
fiberVelocity | 3000
fiberHoldDurationSec | 1
fiberCycles | 100
useFoma | 1
flowTimeoutSec | 90
oxidizerFlowignitionDeltaMs
nitrogen FlowlgnitionDeltaMs | 4500
stabilizationTime1Sec
sta bilizatonTime2Sec | 5
oxidizerlgnitionFlowSlpm | 0/2-4>4 | 0.295
nitrogenlgnitionFlowSlpm, o-;543 | 0.882
oxidizerTestFlow1Slpml | onc-i7 | 0.295 | D..ffi7_-
nitrogenTestFlow1Slpm D 5-43 | 0.882 | /347/ I
oxidizer TestFlow2Slpm
nitrogenTestFlow2Slpm
oxidizer TestFlow3Slpm
nitrogenTestFlow3Slpm
constantFlowTime1Sec | 60
constantFlowTime2Sec
constantFlowTime3Sec
ignitionToTestRampTimeSec
testFlowRamp1T02TimeSec
testFlowRamp2T03TimeSec
postExtinctionDelaySec | 3
postExtinctionFlowChangeOxidizerpercent'
postExfinctionFtowChangeNitrogenPercen
postExtinctionFlowChangeRarnpTimeSecl
postExtinct10nFlowChangeHOldSecl
~~~~

### Pagina 6

Cita: [pdf_47be15b3fcd453c5eca4, p. 6]. Metodo: windows_ocr_grid_removed.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_47be15b3fcd453c5eca4/p0006.jpg)

~~~~text
testpointName | 21265F1
dataCameraPrelgnitionExposureUs | 1000000
dataCameraTestExposureUs | 100000
analogCameraShutter | 2
uselntensifiedCamera | 1
intensifierlgnitionGain | 20000
intensifierTestGain | 60000
preignitionlmageTimeSec
postFlamelmagingTimeSec | 5
useDataCameraAutoGain
autoGainTolerancePercent | 5
autoGainMaxDb | 33
autoGainMinDb
autoGainOutliers
autoGainRatePercent | 100
autoGainTargetPercent | 50
rampDataCameraGain
dataCameraGain1dB
dataCameraGain2dB
dataCameraGain3dB
dataCameraHoldTime1Sec
dataCameraHoldTime2Sec
dataCameraRamp1t02TimeSec | 5
dataCameraRamp2t03TimeSec | 5
dataCameraManualGain | 33
useBracketedExposures
bracketi nglmagesPerExposure | 1
bracketingNumberOfExposures | 4
bracketingExposureStartUsec | 50000
bracketingExposureMultiplierTimes100 | 200
igniterStartPosition | 2170
igniterEndPosition | 2290
igniterVelocityCountsPerSec | 80
igniterPreheatPowerV | 3
igniterPreheatDurationMs | 1000
igniterlgnitionPowerV | 4
igniterlgnitionDurationMs | 3000
igniterDelayBeforeRetractMs | 1800
igniterRetractVelocityCountsPerSec | 500
pmt1Gain | 10
pmt2Gain | 8
pmt3Gain | 10
fiberlgnitionPosition
fiberTestPosition
fiberMoveDuringTest
fiberSegmentDistance | 100
fiberVelocity | 3000
fiberHoldDurationSec | 1
fiberCycles | 100
useFoma | 1
flowTimeoutSec | 90
oxidizerFlowlgnitionDeltaMs
nitrogenFlowlgnitionDeltaMs | 4500
stabilizationTime1Sec
stabilizationTime2Sec | 5
oxidizerlgnitionFlowSlpm 02492 | 0.295
nitrogenlgnitionFEowSlpm | B, 429 | 0.882
oxidizerTestFlow1Slpm | 0.295
nitrogenTestFlow1Slpm | h 479 | 0.882
oxidizerTestFlow2Slpm
nitrogenTestFlow2Slpm
oxidizerTestFlow3Slpm
nitrogenTestFlow3Slpm
constantFlowTime1Sec | 60
constantFlowTime2Sec
constantFlowTime3Sec
ign ition TOTestRampTimeSec
testFlowRamp1T02TimeSec
testFlowRamp2T03TimeSec
postExtinctionDelaySec | 3
postExtinctionFlowChangeOxidizerPercent
postExtinctionFlowChangeNitrogenPercent
postExnncaonFlowChangeRampTimeSec
postExtinctionFlowChangeHoldSec
~~~~

### Pagina 7

Cita: [pdf_47be15b3fcd453c5eca4, p. 7]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_47be15b3fcd453c5eca4/p0007.jpg)

~~~~text
test ointName | 2126561
dataCameraPrelgnitionExposureUs | 1000000
data Camera TestExposureUs | 100000
analogCameraShutter | 2
uselntensifiedCamera
intensifierlgnitionGain | 20000
intensifierTestGain | 60000
prelgnitionlmageTimeSe
postFlamelma in TimeSe | 5
useDataCameraAutoGain
autoGainTolerancePercent
autoGainMaxDb | 33
autoGainMinDb
autoGainOutliers
autoGainRatePercent | 100
autoGainTargetPercent | 50
rampDataCameraGain
dataCameraGain1dB
dataCameraGain2dB
dataCameraGain3dB
dataCameraHoldTime1Se
dataCameraHoldTime2Se
dataCameraRamp1t02TimeSec | 5
dataCameraRam 2t03TimeSec | 5
dataCameraManualGain
useBracketedExposures | 1
bracketingl magesPerExposure
bracketingNumberOfExposures
bracketingExposureStartUsec | 50000
bracketingExposureMultiplierTimes100 | 200
igniterStartPosition | 2170
igniterEndPosition | 2290
igniterVelocityCountsPerSec | 80
igniterPreheatPowerV
igniterPreheatDurationMs | 1000
igniterlgnitionPower
igniterlgnitionDurationMs | 3000
igniterDelayBeforeRetractMs | 1800
i niterRetractVelocityCountsPerSec | 500
pmt1Gain | 10
pmt2Gain
pmt3Gain | 10
fiberEgnitionPosition | 10000
fiberTestPosition | 17000
fiberMoveDuringTest
fiberSegmentDistance | 100
fiberVeiocity | 3000
fiberHoldDurationSec | 1
fiberC cles | 100
useFoma | 1
flowTimeoutSe | 90
oxidizerFlowlgnitionDeltaMs
nitrogenFlowlgnitionDeltaMs | 4500
stabilizationTime1Sec
stabilizationTime2Sec | 5
oxidizerlgnitionFlowSlpm | 0.295
nitrogenlgnitionFlowSlpm | 0.882
oxidizerTestFlow1Slpm | 0.295
nitrogenTestFlow1Slpm | 0.882
oxidizer TestFlow2Slpm
nitrogenTestFlow2Sipm
oxidizerTestFlow3Slpm
nitrogen TestFlow3Slpm
constantFlowTime1Sec | 60
constantFlowTime2Sec
constantFlowTime3Se
ignitionToTestRampTimeSe
testFlowRamp1T02TimeSe
testFlowRamp2T03TimeSec
postExtinctionDelaySec
postExtinctionFlowChangeOxidizerPercent
postExtinctionFlowChangeNitrogen Percent
postExtinctionFlowChangeRampTimeSec
postExtinctionFiowChangeHoldSe
~~~~
