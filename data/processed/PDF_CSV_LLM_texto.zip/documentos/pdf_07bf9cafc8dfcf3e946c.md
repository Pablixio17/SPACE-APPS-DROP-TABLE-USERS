# 19115 test parameter notes

- Identificador: pdf_07bf9cafc8dfcf3e946c
- Investigaciones: PSI-10
- Tipo de documento: Raw Data
- Estado: processed
- Temas detectados automaticamente: ignition, extinction, hardware, operations

## Fuentes

- [PSI-10_Raw Data_19115 test parameter notes.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-10/Raw%20Data/PSI-10_Raw%20Data_19115%20test%20parameter%20notes.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_07bf9cafc8dfcf3e946c, p. 1]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_07bf9cafc8dfcf3e946c/p0001.jpg)

~~~~text
testpointName 19115A1
prelgnitionDataTimeSec
postFlameDataTimeSec | 15
uselPSUs TRUE
ipsuTimeoutSec | 40
useAcmeCamera TRUE
uselntensifiedCamera TRUE
ipsu1ArchiveRate | 2
dataCameraPrelgnitionExposureUs 100000
dataCameralgnitionExposureUs 100000
dataCameraTestExposureUs 1300000
dataCameraExtinctionExposureUs 650000
analogCameraPrelgnitionShutter | 2
analogCameralgnitionShutter | 2
analogCameraTestShutter | 1
analogCameraExtinctionShutter
intensifierGainAmplitude 60000
prelgnitionlmageTimeSec
postFlamelmagingTimeSec | 3
useBracketedExposures TRUE
bracketinglmagesperExposure | 1
bracketingNumberOfExposures | 4
bracketingExposureStartUsec 50000
bracketingExposureMultiplierTimes100 300
igniterlgnitionPosition 2330
igniterPreheatPowerV
igniterPreheatTimeMs
igniterlgnitionPowerV 3.75
igniterlgnitionDurationMs 2500
igniterDelayBeforeRetractMs 2000
igniterRetractVelocityCountsPerSec 1000
uselgnitionDetection TRUE
extinctionDetectionStopsTest TRUE
pmt1Gain 6.25
pmt2Gain | 6.5
pmt3Gain | 6.5
fiberlgnitionPosition 10000
fiberTestPosition -15500
fiberMoveDuringTest TRUE
fiberSegmentDistance 200
fiberVelocity 1
fiberAcceleration 1000
fiberDeceleration
fiberHoldDurationSec | 1
fiberCycles 150
useFoma TRUE
flowTimeoutSec 175
nitrogenPriming1DurationSec
nitrogenPriming2DurationSec
fuelFlowlgnitionDeltaMs
stabilizationTime1Sec
stabilizationTime2Sec | 5
fuelBottlelgnitionFlowRateN2Slpm | 078
nitrogenlgnitionFlowRateN2Slpm
fuelBottleTestFlowRateN2Slpm 0.078
nitrogenTestFlowRateN2Slpm
ignitionToTestRampTimeSec
constantFlowTimeSec
useRampFlowToZero TRUE
rampFlowToZeroSec | 30
constantPostExtinctionDelaySec
constantPostExtinctionFlowChangeFuelPercent -50.0
constantPostExtinctionFlowChangeN2Percent -50.0
constantPostExtinctionFlowChangeRampTimeSec | 3
constantPostExtinctionFlowChangeHoldSec | 5
rampPostExtinctionDelaySec
rampPostExtinctionFlowChangeFuelPercent 50.0
rampPostExtinctionFlowChangeN2Percent 50.0
rampPostExtinctionFlowChangeRampTimeSec | 3
rampPostExtinctionFlowChangeH01dSec | 5
~~~~

### Pagina 2

Cita: [pdf_07bf9cafc8dfcf3e946c, p. 2]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_07bf9cafc8dfcf3e946c/p0002.jpg)

~~~~text
testpointName | 1911581
prelgnitionDataTimeSec
postFlameDataTimeSec | 15
uselPSUs | TRUE
ipsuTimeoutSec | 40
useAcmeCamera | TRUE
uselntensifiedCamera | TRUE
ipsu1ArchiveRate | 2
dataCameraPrelgnitionExposureUs | 100000
dataCameralgnitionExposuretJs | 100000
dataCameraTestExposureUs | 1300000
dataCameraExtinctionExposureUs | 650000
analogCameraPrelgnitionShutter | 2
analogCameralgnitionShutter | 2
analogCameraTestShutter | 1
analogCameraExtinctionShutter
intensifierGainAmplitude | 60000
prelgnitionlmageTimeSec
postFlamelmagingTimeSec | 3
useBracketedExposures | TRUE
bracketinglmagesperExposure | 1
bracketingNumberOfExposures | 4
bracketingExposureStartUsec | 50000
bracketingExposureMultiplierTimes100 | 300
igniterlgnitionPosition | 2330
igniterPreheatPowerV
igniterPreheatTimeMs
igniterlgnitionPowerV | 3.75
igniterlgnitionDurationMs | 2500
igniterDelayBeforeRetractMs | 2000
igniterRetractVelocityCountsPerSec | 1000
uselgnitionDetection | TRUE
extinctionDetectionStopsTest | TRUE
pmt1Gain | 6.25
pmt2Gain | 6.5
pmt3Gain | 6.5
fiberlgnitionPosition | 10000
fiberTestPosition
fiberMoveDuringTest | TRUE
fiberSegmentDista nce
fiberVelocity
fiberAcceleration | 1000
fiberDeceleration
fiberHoldDurationSec | 1
fiberCycles | 150
useFoma | TRUE
flowTimeoutSec | 175
nitrogenPriming1DurationSec
nitrogenPriming2DurationSec
fuelFlowlgnitionDeltaMs
stabilizationTime1Sec
stabilizationTime2Sec | 5
fuelBottlelgnitionFlowRateN2Slpm | 0.052
nitrogenlgnitionFlowRateN2Slpm | 0
fuelBottleTestFlowRateN2Slpm | 0.052
nitrogenTestFlowRateN2SIpm
ignitionToTestRampTimeSec
constantFlowTimeSec
useRampFlowToZero | TRUE
rampFlowToZeroSec | 30
constantPostExtinctionDelaySec
constantPostExtinctionFlowChangeFuelPercent | -50.0
constantPostExtinctionFlowChangeN2Percent | -50.0
constantPostExtinctionFlowChangeRampTimeSec | 3
constantPostExtinctionFlowChangeHoldSec | 5
rampPostExtinctionDelaySec
rampPostExtinctionFlowChangeFuelPercent | 50.0
rampPostExtinctionFlowChangeN2Percent | 50.0
rampPostExtinctionFlowChangeRampTimeSec | 3
rampPostExtinctionFlowChangeHoldSec | 5
~~~~

### Pagina 3

Cita: [pdf_07bf9cafc8dfcf3e946c, p. 3]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_07bf9cafc8dfcf3e946c/p0003.jpg)

~~~~text
testpointName | 19115C1
preignitionDataTimeSec
postFlameDataümeSec | 15
uselPSUs | TRUE
ipsuTimeoutSec | 40
useAcmeCamera | TRUE
uselntensifiedCamera | TRUE
ipsu1ArchiveRate | 2
dataCameraPrelgnitionExposureUs | 100000
dataCameralgnitionExposurelJs | 100000
dataCameraTestExposureUs | 1300000
dataCameraExtinctionExposureUs | 650000
analogCameraPrelgnitionShutter | 2
analogCameralgnitionShutter | 2
analogCameraTestShutter | 1
analogCameraExtinctionShutter
intensifierGainAmplitude | 60000
prelgnitionlmageTimeSec
postFlamelmagingTimeSec | 3
useBracketedExposures | TRUE
bracketinglmagesPerExposure | 1
bracketingNumberOfExposures | 4
bracketingExposureStarWsec
bracketingExposureMultiplierTimes100
igniterlgnitionPosition | 2330
igniterPreheatPowerV
igniterPreheatTimeMs
igniterlgnitionPowerV | 3.75
igniterlgnitionDurationMs | 2500
igniterDelayBeforeRetractMs | 2000
igniterRetractVelocityCountsPerSec | 1000
uselgnitionDetection | TRUE
extinctionDetectionStopsTest | TRUE
pmt1Gain | 6.25
pmt2Gain | 6.5
pmt3Gain | 6.5
fiberlgnitionPosition | 10000
fiberTestPosition
fiberMoveDuringTest | TRUE
fiberSegmentDistance
fiberVelocity
fiberAcceleration | 1000
fiberDeceleration
fiberHoldDurationSec | 1
fiberCycles | 150
useFoma | TRUE
flowTimeoutSec
nitrogenPriming1DurationSec
nitrogenPriming2DurationSec
fuelFlowlgnitionDeltaMs
stabilizationTime1Sec
stabilizationTime2Sec | 5
fuelBottlelgnitionFlowRateN2Slpm | 0.026
nitrogenlgnitionFlowRateN2Slpm
fuelBottleTestFlowRateN2Slpm | 01026
nitrogenTestFlowRateN2Slpm
ignitionToTestRampTimeSec
constantFlowTimeSec
useRampFlowToZero | TRUE
rampFlowToZeroSec | 30
constantPostExtinctionDelaySec
constantPostExtinctionFlowChangeFuelPercent | -50.0
constantPostExtinctionFlowChangeN2Percent | -50.0
constantP05tExtinctionFlowChangeRampTimeSec | 3
constantPostExtinctionFlowChangeHoldSec | 5
rampPostExtinctionDelaySec
rampPostExtinctionFlowChangeFuelPercent | 50.0
rampPostExtinctionFlowChangeN2Percent | 50.0
rampPostExtinctionFlowChangeRampTimeSec | 3
rampPostExtinctionFlowChangeHoldSec | 5
~~~~

### Pagina 4

Cita: [pdf_07bf9cafc8dfcf3e946c, p. 4]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_07bf9cafc8dfcf3e946c/p0004.jpg)

~~~~text
testpointName | 19115D1
prelgnitionDataTimeSec
postFlameDataTimeSec | 15
uselPSUs | TRUE
ipsuTimeoutSec | 40
useAcmeCamera | TRUE
uselntensifiedCamera | TRUE
ipsu1ArchiveRate | 2
dataCameraPrelgnitionExposureUs | 100000
dataCameralgnitionExposureUs | 100000
dataCameraTestExposureUs | 1300000
dataCameraExtinctionExposureUs | 650000
analogCameraPrelgnitionShutter | 2
analogCameralgnitionShutter | 2
analogCameraTestShutter | 1
analogCameraExtinctionShutter
intensifierGainAmplitude | 60000
preignitionlmageTmeSec
postFlamelmagingTimeSec | 3
useBracketedExposures | TRUE
bracketing! magesperExposure | 1
bracketingNumberOfExposures | 4
bracketingExposureStartUsec | soooo
bracketingExposureMultiplierTimes100 | 300
igniterlgnitionPosition | 2330
igniterPreheatPowerV
igniterPreheatTimeMs
igniterlgnitionPowerV | 3.75
igniterlgnitionDurationMs | 2500
igniterDelayBeforeRetractMs | 2000
igniterRetractVelocityCountsPerSec | 1000
uselgnitionDetection | TRUE
extinctionDetectionStopsTest | TRUE
pmt1Gain | 6.25
pmt2Gain | 6.5
pmt3Gain | 6.5
fiberlgnitionPosition | 10000
fiberTestPosition | 715500
fiberMoveDuringTest | TRUE
fiberSegmentDistance | 200
fiberVelocity
fiberAcceleration | 1000
fiberDeceleration
fiberHoldDurationSec | 1
fiberCycles | 150
useFoma | TRUE
flowTimeoutSec
nitrogenPriming1DurationSec
nitrogenPriming2DurationSec
fuelFlowlgnitionDeltaMs
stabilizationTime1Sec
stabilizationTime2Sec | 5
fuelBottlelgnitionFlowRateN2Slpm | 0.078
nitrogenlgnitionFlowRateN2Slpm | 0.078
fuelBottleTestFlowRateN2Slpm | 0,07
nitrogenTestFlowRateN2Slpm
ignitionToTestRampTimeSec
constantFlowTimeSec
useRampFlowToZero | TRUE
rampFlowToZeroSec | 30
constantPostExtinctionDelaySec
constantPostExtinctionFlowChangeFuelPercent | -50.0
constantPostExtinctionFlowChangeN2Percent | -50.0
constantPostExtinctionFlowChangeRampTimeSec | 3
constantPostExtinctionFlowChangeHoldSec | 5
rampPostExtinctionDelaySec
rampPostExtinctionFlowChangeFuelPercent | 50.0
rampPostExtinctionFlowChangeN2Percent | 50.0
rampPostExtinctionFlowChangeRampTimeSec | 3
rampPostExtinctionFlowChangeHoldSec | 5
~~~~

### Pagina 5

Cita: [pdf_07bf9cafc8dfcf3e946c, p. 5]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_07bf9cafc8dfcf3e946c/p0005.jpg)

~~~~text
testpointName | 19115F1
prelgnitionDataTimeSec
postFlameDataTimeSec | 15
uselPSUs | TRUE
ipsuTimeoutSec | 40
useAcmeCamera | TRUE
uselntensifiedCamera | TRUE
ipsu1ArchiveRate | 2
dataCameraPrelgnitionExposureUs | 100000
dataCameralgnitionExposureUs | 100000
dataCameraTestExposureUs | 1300000
dataCameraExtinctionExposureUs | 650000
analogCameraPrelgnitionShutter | 2
analogCameralgnitionShutter | 2
analogCameraTestShutter | 1
analogCameraExtinctionShutter
intensifierGainAmplitude | 60000
prelgnitionlmageTimeSec
postFlamelmagingTimeSec | 3
useBracketedExposures | TRUE
bracketinglmagesPerExposure | 1
bracketingNumberOfExposures | 4
bracketingExposureStartUsec
bracketingExposureMultiplierTimes100
igniterlgnitionPosition | 2330
igniterPreheatPowerV
igniterPreheatTimeMs
igniterlgnitionPowerV | 3.75
igniterlgnitionDurationMs | 2500
igniterDelayBeforeRetractMs | 2000
igniterRetractVelocityCountsPerSec | 1000
uselgnitionDetection | TRUE
extinctionDetectionStopsTest | TRUE
pmt1Gain | 6.25
pmt2Gain | 6.5
pmt3Gain | 6.5
fiberlgnitionposition | 10000
fiberTestPosition | 15200
fiberMoveDuringTest | TRUE
fiberSegmentDistance
fiberVelocity | 150
fiberAcceleration | 1000
fiberDeceleration
fiberHoldDurationSec | 1
fiberCycles | 150
useFoma | TRUE
flowTimeoutSec | 17
nitrogenPriming1DurationSec
nitrogenPriming2DurationSec
fuelFlowlgnitionDeltaMs
stabilizationTime1Sec
stabilizationTime2Sec | 5
fuelBottlelgnitionFlowRateN2Slpm | 0,078
nitrogenlgnitionFlowRateN2Slpm | 0.117,
fuelBottleTestFlowRateN2Slpm | 0.078
nitrogenTestFlowRateN2Slpm | 0.117
ignitionToTestRampTimeSec
constantFlowTimeSec | 1
useRampFtowToZero | TRUE
rampFlowToZeroSec | 30
constantPostExtinctionDelaySec
constantPostExtinctionFlowChangeFuelPercent | -50.0
constantPostExtinctionFlowChangeN2Percent | -50.0
constantPostExtinctionFlowChangeRampTimeSec | 3
constantPostExtinctionFlowChangeHoldSec | 5
rampPostExtinctionDelaySec
ramppostExtinctionFlowChangeFuelPercent | 50.0
rampPostExtinctionFlowChangeN2Percent | 50.0
ramppostExtinctionFlowChangeRampTimeSec | 3
rampPostExtinctionFlowChangeHoldSec | 5
~~~~

### Pagina 6

Cita: [pdf_07bf9cafc8dfcf3e946c, p. 6]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_07bf9cafc8dfcf3e946c/p0006.jpg)

~~~~text
testpointName | 1911561
preignitionDataTlmeSec
postFlameDataTimeSec | 15
uselPSUs | TRUE
ipsuTimeoutSec | 40
useAcmeCa mera | TRUE
uselntensifiedCamera | TRUE
ipsu1ArchiveRate | 2
dataCameraprelgnitionExposureUs | 100000
dataCameralgnitionExposureUs | 100000
dataCameraTestExposureUs | 1300000
dataCameraExtinctionExposureUs | 650000
analogCameraPrelgnitionShutter | 2
analogCameralgnitionShutter | 2
analogCameraTestShutter | 1
analogCameraExtinctionShutter
intensifierGainAmplitude | 60000
prelgnitionlmageTimeSec
postFlamelmagingTimeSec | 3
useBracketedExposures | TRUE
bracketinglmagesperExposure | 1
bracketingNumberOfExposures | 4
bracketingExposureStartUsec | 5
bracketingExposureMultiplierTimes100
igniterlgnitionPosition | 2330
igniterPreheatPowerV
igniterPreheatTimeMs
igniterlgnitionPowerV | 3.75
igniterlgnitionDurationMs | 2500
igniterDelayBeforeRetractMs | 2000
igniterRetractVelocityCountsPerSec | 1000
uselgnitionDetection | TRUE
extinctionDetectionStopsTest | TRUE
pmt1Gain | 6.25
pmt2Gain | 6.5
pmt3Gain | 6.5
fiberlgnitionposition | 10000
fiberTestPosition
fiberMoveDuringTest | TRUE
fiberSegmentDistance | soo
fiberVelocity
fiberAcceleration | 1000
fiberDeceleration
fiberHoldDurationSec | 1
fiberCycles | 150
useFoma | TRUE
flowTimeoutSec | 95
nitrogenPriming1DurationSec
nitrogenPriming2DurationSec
fuelFlowlgnitionDeltaMs
stabilizationTime1Sec
stabilizationTime2Sec | 5
fuelBottlelgnitionFlowRateN2Slpm | 0.039
nitrogenlgnitionFlowRateN2Slpm | 0.059 o,
fuelBottleTestFlowRateN2Slpm | -0,078
nitrogenTestFlowRateN2Slpm | 0.117
ignitionToTestRampTimeSec
constantFlowTimeSec | 5
useRampFlowToZero | TRUE
rampFlowToZeroSec | 30
constantPostExtinctionDelaySec
constantPostExtinctionFlowChangeFuelPercent | -50.0
constantPostExtinctionFlowChangeN2Percent | -50.0
constantPostExtinctionFlowChangeRampTimeSec | 3
constantPostExtinctionFlowChangeHoldSec | 5
rampPostExtinctionDelaySec
rampPostExtinctionFlowChangeFuelPercent | 50.0
rampPostExtinctionFlowChangeN2Percent | 50.0
rampPostExtinctionFlowChangeRampTimeSec | 3
rampPostExtinctionFlowChangeHoldSec | 5
~~~~

### Pagina 7

Cita: [pdf_07bf9cafc8dfcf3e946c, p. 7]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_07bf9cafc8dfcf3e946c/p0007.jpg)

~~~~text
testpointName | 19115H1
prelgnitionDataTimeSec
postFlameDataTimeSec | 15
uselPSUs | TRUE
ipsuTimeoutSec | 40
useAcmeCamera | TRUE
uselntensifiedCamera | TRUE
ipsu1ArchiveRate | 2
dataCameraPrelgnitionExposureUs | 100000
dataCameralgnitionExposureUs | 100000
dataCameraTestExposurelJs | 1300000
dataCameraExtinctionExposureUs | 650000
analogCameraPrelgnitionShutter | 2
analogCameralgnitionShutter | 2
analogCameraTestShutter | 1
analogCameraExtinctionShutter
intensifierGainAmplitude | 60000
prelgnitionlmageTimeSec
postFlamelmagingTimeSec | 3
useBracketedExposures | TRUE
bracketinglmagesPerExposure | 1
bracketingNumberOfExposures | 4
bracketingExposureStarWsec
bracketingExposureMultiplierTimes100
igniterlgnitionPosition | 2330
igniterPreheatPowerV
igniterPreheatTimeMs
igniterlgnitionPowerV | 3.75
igniterIgnitionDurationMs | 2500
igniterDelayBeforeRetractMs | 2000
igniterRetractVelocityCountsPerSec | 1000
uselgnitionDetection | TRUE
extinctionDetectionStopsTest | TRUE
pmt1Gain | 6.25
pmt2Gain | 6.5
pmt3Gain | 6.5
fiberlgnitionPosition | 10000
fiberTestPosition | 14700
fiberMoveDuringTest | TRUE
fiberSegmentDistance | 1000
fiberVeIocity | 200
fiberAcceleration | 1000
fiberDeceleration
fiberHoldDurationSec | 1
fiberCycles | 150
useFoma | TRUE
flowTimeoutSec | A 75
nitrogenPriming1DurationSec
nitrogenPriming2DurationSec
fuelFlowlgnitionDeltaMs
stabilizationTime1Sec
stabilizationTime2Sec | 5
fuelBottlelgnitionFlowRateN2Slpm | 0078
nitrogenlgnitionFlowRateN2Slpm | 31
fuelBottleTestFlowRateN2Slpm | 0.078
nitrogenTestFlowRateN2Slpm
ignitionToTestRampTimeSec
constantFlowTimeSec
useRampFlowToZero | TRUE
rampFlowToZeroSec | 30
constantPostExtinctionDelaySec
constantPostExtinctionFlowChangeFuelPercent | -50.0
constantPostExtinctionFlowChangeN2Percent | -50.0
constantPostExtinctionFlowChangeRampTimeSec | 3
constantPostExtinctionFlowChangeHoldSec | 5
rampPostExtinctionDelaySec
rampPostExtinctionFlowChangeFuelPercent | 50.0
rampPostExtinctionFlowChangeN2Percent | 50.0
rampPostExtinctionFlowChangeRampTimeSec | 3
rampPostExtinctionFlowChangeH01dSec | 5
~~~~

### Pagina 8

Cita: [pdf_07bf9cafc8dfcf3e946c, p. 8]. Metodo: windows_ocr_tiled_upscaled.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, tiled_ocr_not_manually_verified.

[Imagen de la pagina](../imagenes/pdf_07bf9cafc8dfcf3e946c/p0008.jpg)

~~~~text
testpointName | 19115J1
prelgnitionDataTimeSec
postFIameDataTimeSec | 15
uselPSUs | TRUE
ipsuTimeoutSec | 40
useAcmeCamera | TRUE
uselntensifiedCamera | TRUE
ipsu1ArchiveRate | 2
dataCameraPrelgnitionExposureUs | 100000
dataCameralgnitionExposureUs | 100000
dataCameraTestExposureUs | 1300000
dataCameraExtinctionExposureUs | 650000
analogCameraPrelgnitionShutter | 2
analogCameralgnitionShutter | 2
analogCameraTestShutter | 1
analogCameraExtinctionShutter
intensifierGainAmplitude | 60000
prelgnitionlmageTimeSec
postFIamelmagingTimeSec | 3
useBracketedExposures | TRUE
bracketingtmagesPerExposure | 1
bracketingNumberOfExposures | 4
bracketingExposureStartUsec
bracketingExposureMultiplierTimes100
igniterlgnitionPosition | 2330
igniterPreheatPowerV
igniterPreheatTimeMs
igniterlgnitionPowerV | 3.75
igniterlgnitionDurationMs | 2500
igniterDelayBeforeRetractMs | 2000
igniterRetractVelocityCountsPerSec | 1000
uselgnitionDetection | TRUE
extinctionDetectionStopsTest | TRUE
pmt1Gain | 6.25
pmt2Gain | 6.5
pmt3Gain | 6.5
fiberlgnitionPosition | 10000
fiberTestPosition | 14700 $14700
fiberMoveDuringTest | TRUE
fiberSegmentDistance | E1000
fiberVelocity | ,200
fiberAcceleration | 1000
fiberDeceleration
fiberHoldDurationSec
fiberCycles | 150
useFoma | TRUE
flowTimeoutSec | 95
nitrogenPriming1DurationSec
nitrogenPriming2DurationSec
fuelFlowlgnitionDeltaMs
stabilizationTime1Sec
stabilizationTime2Sec
fuelBottlelgnitionFlowRateN2Slpm | 0.039
nitrogenlgnitionFlowRateN2Slpm | 0.156,
fuelBottleTestFIowRateN2Slpm | •0.078
nitrogenTestFlowRateN2Slpm
ignitionToTestRampTimeSec
constantFlowTimeSec
useRampFlowToZero | TRUE
rampFlowToZeroSec | 30
constantPostExtinctionDelaySec
constantPostExtinctionFlowChangeFuelPercent | -50.0
constantPostExtinctionFlowChangeN2Percent | -50.0
constantPostExtinctionFlowChangeRampTimeSec
constantPostExtinctionFlowChangeHoldSec
rampPostExtinctionDelaySec
rampPostExtinctionFlowChangeFuelPercent | 50.0
rampPostExtinctionFlowChangeN2Percent | 50.0
rampPostExtinctionFlowChangeRampTimeSec
rampPostExtinctionFlowChangeH01dSec | 5
~~~~

### Pagina 9

Cita: [pdf_07bf9cafc8dfcf3e946c, p. 9]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_07bf9cafc8dfcf3e946c/p0009.jpg)

~~~~text
testpointName | 19115K1
prelgnitionDataTimeSec
postFlameDataTimeSec | 15
usetPSlJs | TRUE
ipsuTimeoutSec | 40
useAcmeCamera | TRUE
uselntensifiedCamera | TRUE
ipsu1ArchiveRate | 2
dataCameraprelgnitionExposureUs | 100000
dataCameralgnitionExposureus | 100000
dataCameraTestExposureUs | 1300000
dataCameraExtinctionExposureUs | 650000
analogCameraPrelgnitionShutter | 2
analogCameralgnitionShutter | 2
analogCameraTestShutter | 1
analogCameraExtinctionShutter
intensifierGainAmplitude | 60000
prelgnitionlmageTimeSec
postFlamelmagingTimeSec | 3
useBracketedExposures | TRUE
bracketinglmagesPerExposure | 1
bracketingNumberOfExposures | 4
bracketingExposureStartUsec
bracketingExposureMultiplierTimes100
ignitertgnitionPosition | 2330
igniterPreheatPowerV
igniterPreheatTimeMs
igniterlgnitionPowerV | 3.75
igniterlgnitionDurationMs | 2500
igniterDelayBeforeRetractMs | 2000
igniterRetractVelocityCountsPerSec | 1000
uselgnitionDetection | TRUE
extinctionDetectionStopsTest | TRUE
pmt1Gain | 6.25
pmt2Gain | 6.5
pmt3Gain | 6.5
fiberlgnitionPosition | 10000
fiberTestPosition | a4700
fiberMoveDuringTest | TRUE
fiberSegmentDistance | -1000
fiberVelocity | 200
fiberAcceleration | 1000
fiberDeceleration
fiberHoldDurationSec | 1
fiberCycles | 150
useFoma | TRUE
flowTimeoutSec
nitrogenPriming1DurationSec
nitrogenPriming2DurationSec
fuelFlowlgnitionDeltaMs
stabilizationTime1Sec
stabilizationTime2Sec | 5
fuelBottlelgnitionFlowRateN2Slpm
nitrogenlgnitionFlowRateN2Slpm | 0.15
fuelBottleTestFlowRateN2Slpm
nitrogenTestFlowRateN2Slpm | 0.3
ignitionToTestRampTimeSec
constantFlowTimeSec
useRampFlowToZero | TRUE
rampFlowToZeroSec | 30
constantPostExtinctionDelaySec
constantPostExtinctionFlowChangeFuelPercent | -50.0
constantPostExtinctionFlowChangeN2Percent | -50.0
constantPostExtinctionFlowChangeRampTimeSec | 3
constantPostExtinctionFlowChangeHoldSec | 5
rampPostExtinctionDelaySec
rampPostExtinctionFlowChangeFuelPercent | 50.0
rampPostExtinctionFlowChangeN2Percent | 50.0
rampPostExtinctionFlowChangeRampTimeSec | 3
rampPostExtinctionFlowChangeHoldSec | 5
~~~~

### Pagina 10

Cita: [pdf_07bf9cafc8dfcf3e946c, p. 10]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_07bf9cafc8dfcf3e946c/p0010.jpg)

~~~~text
testpointName | 1911SL1
prelgnitionDataTimeSec
postFlameDataTimeSec | 15
uselPSUs | TRUE
ipsuTimeoutSec | 40
useAcmeCamera | TRUE
uselntensifiedCamera | TRUE
ipsu1ArchiveRate | 2
dataCameraPrelgnitionExposureUs | 100000
dataCameralgnitionExposureUs | 100000
dataCameraTestExposureUs | 1300000
dataCameraExtinctionExposureUs | 650000
analogCameraPrelgnitionShutter | 2
analogCameralgnitionShutter | 2
analogCameraTestShutter | 1
analogCameraExtinctionShutter
intensifierGainAmplitude | 60000
prelgnitionlmageTimeSec
postFlamelmagingTimeSec | 3
useBracketedExposures | TRUE
bracketinglmagesPerExposure | 1
bracketingNumberOfExposures | 4
bracketingExposureStarWsec | 10000
bracketingExposureMultiplierTimes100
igniterlgnitionPosition | 2330
igniterPreheatPowerV
igniterPreheatTimeMs
igniterlgnitionPowerV | 3.75
igniterlgnitionDurationMs | 2500
igniterDelayBeforeRetractMs | 2000
igniterRetractVelocityCountsPerSec | 1000
uselgnitionDetection | TRUE
extinctionDetectionStopsTest | TRUE
pmt1Gain | 6.25
pmt2Gain | 6.5
pmt3Gain | 6.5
fiberlgnitionposition | 10000
fiberTestPosition | 14700
fiberMoveDuringTest | TRUE
fiberSegmentDistance | 1000
fiberVelocity | 200
fiberAcceleration | 1000
fiberDeceleration
fiberHoldDurationSec | 1
fiberCycles | 150
useFoma | TRUE
flowTimeoutSec
nitrogenPriming1DurationSec
nitrogenPriming2DurationSec
fuelFlowlgnitionDeltaMs
stabilizationTime1Sec
stabilizationTime2Sec | 5
fuelBottlelgnitionFlowRateN2Slpm | 1
nitrogenlgnitionFlowRateN2Slpm | 0
fuelBottleTestFlowRateN2Slpm
nitrogenTestFlowRateN2Slpm
ignitionToTestRampTimeSec
constantFlowTimeSec
useRampFlowToZero | TRUE
rampFlowToZeroSec | 30
constantPostExtinctionDelaySec
constantPostExtinctionFlowChangeFuelPercent | -50.0
constantPostExtinctionFlowChangeN2Percent | -50.0
constantPostExtinctionFlowChangeRampTimeSec | 3
constantPostExtinctionFlowChangeHoldSec
rampPostExtinctionDelaySec
rampPostExtinctionFlowChangeFuelPercent | 50.0
rampPostExtinctionFlowChangeN2Percent | 50.0
rampPostExtinctionFlowChangeRampTimeSec | 3
rampPostExtinctionFtowChangeHoldSec | 5
~~~~

### Pagina 11

Cita: [pdf_07bf9cafc8dfcf3e946c, p. 11]. Metodo: windows_ocr_grid_removed.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_07bf9cafc8dfcf3e946c/p0011.jpg)

~~~~text
testpointName | PO_49115M1 Al
preignitionDataTimeSec
postFlameDataTimeSec | 15
uselPSUs | 05 | TRUE
ipsuTimeoutSec | 40
useAcmeCamera | fli | TRUE
uselntensifiedCamera | TRUE
ipsu1ArchiveRate | in 13 | 2
dataCameraPrelgnitionExposurelJs | 100000
dataCameralgnitionExposurelJs | 100000
dataCameraTestExposureUs | 1300000
dataCameraExtinctionExposureUs | 650000
analogCameraPrelgnitionShutter | 2
analogCameralgnitionShutter | 2
analogCameraTestShutter | 1
analogCameraExtinctionShutter
intensifierGainAmplitude | 60000
prelgnitionlmageTimeSec
postFlamelmagingTimeSec | 3
useBracketedExposures | TRUE
bracketinglmagesPerExposure | 1
bracketingNumberOfExposures | 4
bracketingExposureStartUsec
bracketingExposureMultiplierTimes100 | 060 •
igniterlgnitionPosition | 2330
igniterPreheatPowerV
igniterPreheatTimeMs
igniterlgnitionPowerV | 3.75
igniterlgnitionDurationMs | 2500
igniterDelayBeforeRetractMs | 2000
igniterRetractVelocityCountsPerSec | 1000
uselgnitionDetection | TRUE
extinctionDetectionStopsTest | TRUE
pmt1Gain | 6.25
pmt2Gain | 6.5
pmt3Gain | 6.5
fiberlgnitionPosition | 10000
fiberTestPosition
fiberMoveDuringTest | TRUE
fiberSegmentDistance
fiberVelocity
fiberAcceleration | 1000
fiberDeceleration
fiberHoldDurationSec | 1
fiberCycles | 150
useFoma | TRUE
flowTimeoutSec
nitrogenPriming1DurationSec
nitrogenPriming2DurationSec
fuelFlowlgnitionDeltaMs | 1760
stabilizationTime1Sec
stabilizationTime2Sec | 5
fuelBottlelgnitionFlowRateN2Slpm | 0.062
nitrogenlgnitionFlowRateN2Slpm | MO 052'
fuelBottleTestFlowRateN2Slpm | 5p.07E O o"
nitrogenTestFlowRateN2Slpm | Ö_b3S | D.055
ignitionToTestRampTimeSec
constantFlowTimeSec
useRampFlowToZero | TRUE
rampFlowToZeroSec | 30
constantPostExtinctionDelaySec | 0
constantPostExtinctionFlowChangeFuelPercent | -50.0
constantPostExtinctionFlowChangeN2Percent | -50.0
constantPostExtinctionFlowChangeRampTimeSec | 3
constantPostExtinctionFlowChangeHoldSec | 5
rampPostExtinctionDelaySec
rampPostExtinctionFlowChangeFuelPercent | 50.0
rampPostExtinctionFlowChangeN2Percent | 50.0
rampPostExtinctionFlowChangeRampTimeSec | 3
rampPostExtinctionFlowChangeHoldSec | 5
~~~~

### Pagina 12

Cita: [pdf_07bf9cafc8dfcf3e946c, p. 12]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_07bf9cafc8dfcf3e946c/p0012.jpg)

~~~~text
testpointName | 19115N1
preignitionDataTimeSec
postFlameDataTimeSec | 15
uselPSUs | TRUE
ipsuTimeoutSec | 40
useAcmeCamera | TRUE
uselntensifiedCamera | TRUE
ipsu1ArchiveRate | 2
dataCameraPrelgnitionExposurelJs | 100000
dataCameralgnitionExposureUs | 100000
dataCameraTestExposureUs | 1300000
dataCameraExtinctionExposureUs | 650000
analogCameraPrelgnitionShutter | 2
analogCameralgnitionShutter | 2
analogCameraTestShutter | 1
analogCameraExtinctionShutter
intensifierGainAmpIitude | 60000
prelgnitionlmageTimeSec
postFlamelmagingTimeSec | 3
useBracketedExposures | TRUE
bracketinglmagesPerExposure | 1
bracketingNumberOfExposures | 4
bracketingExposureStarWsec | 70000
bracketingExposureMultiplierTimes100 | 260
igniterlgnitionPosition | 2330
igniterPreheatPowerV
igniterPreheatTimeMs
igniterlgnitionPowerV | 3.75
igniterlgnitionDurationMs | 2500
igniterDelayBeforeRetractMs | 2000
igniterRetractVelocityCountsPerSec | 1000
uselgnitionDetection | TRUE
extinctionDetectionStopsTest | TRUE
pmt1Gain | 6.25
pmt2Gain | 6.5
pmt3Gain | 6.5
fiberlgnitionposition | O | 10000
fiberTestPosition | 14700
fiberMoveDuringTest | TRUE
fiberSegmentDistance | 1000
fiberVelocity | 200
fiberAcceleration | 1000
fiberDeceleration
fiberHoldDurationSec | 1
fiberCycles | 150
useFoma | TRUE
flowTimeoutSec
nitrogenPriming1DurationSec
nitrogenPriming2DurationSec
fuelFlowlgnitionDeltaMs
stabilizationTime1Sec
stabilizationTime2Sec | 5
fuelBottlelgnitionFlowRateN2Slpm
nitrogenlgnitionFlowRateN2Slpm
fuelBottleTestFlowRateN2Slpm
nitrogenTestFlowRateN2Slpm | 0.133
ignitionToTestRampTimeSec
constantFlowTimeSec | 1
useRampFlowToZero | TRUE
rampFlowToZeroSec | 30
constantPostExtinctionDelaySec
constantPostExtinctionFlowChangeFuelPercent | -50.0
constantPostExtinctionFlowChangeN2Percent | -50.0
constantPostExtinctionFlowChangeRampTimeSec | 3
constantPostExtinctionFlowChangeH01dSec | 5
rampPostExtinctionDelaySec
rampPostExtinctionFlowChangeFuelPercent | 50.0
rampPostExtinctionFlowChangeN2Percent | 50.0
rampPostExtinctionFlowChangeRampTimeSec | 3
rampPostExtinctionFlowChangeH01dSec | 5
D/
~~~~
