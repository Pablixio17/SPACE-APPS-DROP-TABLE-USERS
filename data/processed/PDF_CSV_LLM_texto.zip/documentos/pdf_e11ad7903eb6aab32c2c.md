# 21202 dail_y test point log

- Identificador: pdf_e11ad7903eb6aab32c2c
- Investigaciones: PSI-159
- Tipo de documento: Raw Data
- Estado: processed
- Temas detectados automaticamente: hardware

## Fuentes

- [PSI-159_Raw Data_21202 dail_y test point log.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-159/Raw%20Data/PSI-159_Raw%20Data_21202%20dail_y%20test%20point%20log.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_e11ad7903eb6aab32c2c, p. 1]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_e11ad7903eb6aab32c2c/p0001.jpg)

~~~~text
ACME Daily Test Point Log | 7/22/2021
Downlink Data Limit (MB) = 127,000 | Total = | 87,271
Test Point Name Script Aborts | IPSU1/HiBMS | ACME Camera | Intensified Camera
Downlink
(enter all test | Before IPSUs | Archived | Archived | Archived
Data (MB)
points) | Open | Images | D/L? | Images | D/L? | Images | D/L?
21202A1 | 318 | 1159 | 4,249
21202A2 | 329 | 1185 | 4,355
21202A3 | 400 | 1413 | 5,214
21202A4 | 579 | 1787 | 6, 798
21202H1 | 680 | 1978 | 7,634
21202H2 | 549 | 1695 | 6,448
21202H3 | 753 | 2232 | 8,574
21202H4 | 782 | 2300 | 8,853
21202J1 | 511 | 2626 | 9,041
212021<1 | 953 | 2697 | 10,481
21202K2 | 546 | 1688 | u | 6,419
21202L1 | 526 | 2668 | 9,205
Date: | lat
~~~~
