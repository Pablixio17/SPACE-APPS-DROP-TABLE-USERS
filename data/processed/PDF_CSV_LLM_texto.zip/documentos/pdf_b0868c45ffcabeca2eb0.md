# 19189 daily test point log

- Identificador: pdf_b0868c45ffcabeca2eb0
- Investigaciones: PSI-10
- Tipo de documento: Raw Data
- Estado: processed
- Temas detectados automaticamente: hardware

## Fuentes

- [PSI-10_Raw Data_19189 daily test point log.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-10/Raw%20Data/PSI-10_Raw%20Data_19189%20daily%20test%20point%20log.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_b0868c45ffcabeca2eb0, p. 1]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_b0868c45ffcabeca2eb0/p0001.jpg)

~~~~text
Point | 7/9/2019
ACME Daily Test | Log
Total = | 86,729
Downlink Data Limit (MB) = 127,000
Aborts | IPSU1/HiBMS | ACME camera | Intensified Camera
Test Point Name Script | Downlink
Before IPSUs | Archived | Archived | Archived
(enter all test | Data (MB)
Images | Images | D/L? | Images | D/L?
points) | Open
1159 | 212 | 1794 | 8,053
19189A1
114 | 1168 | 3,591
19189A2
115 | 1181 | 3,630
19189A3
15 | 397 | 1,152
19189D1
97 | 1029 | 3,154
19189A4
112 | 1192 | 3,652
19189D2
206 | 1841 | 5,737
19189D3
222 | 1960 | 6,115
19189H1
1224 | 465 | 1894 | 9,203
19189J1
1179 | 540 | 1828 | 9,141
19189J2
233 | 2079 | 6,479
19189J3
220 | 1981 | 6,168
19189K1
220 | 1987 | 6,185
191891<2
337 | 2843 | 8,914
19189K3
204 | 1778 | 5,555
19189P1
Date:
~~~~
