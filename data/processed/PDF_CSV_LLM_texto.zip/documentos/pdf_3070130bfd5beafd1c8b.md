# 21153 test sheets

- Identificador: pdf_3070130bfd5beafd1c8b
- Investigaciones: PSI-159
- Tipo de documento: Raw Data
- Estado: processed
- Temas detectados automaticamente: oxygen, pressure, ignition, hardware, soot

## Fuentes

- [PSI-159_Raw Data_21153 test sheets.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-159/Raw%20Data/PSI-159_Raw%20Data_21153%20test%20sheets.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_3070130bfd5beafd1c8b, p. 1]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_3070130bfd5beafd1c8b/p0001.jpg)

~~~~text
ACME / CFI-G (normal flame) - Science Test Sheet
est date: | CME test | 5
Local time: | est of day#:
GMT: | a | lame of day #:
Rack Officer (RO): | PD (ACME):
DMO (CIR): | Researcher: | evtR
TEST CONDITIONS | Control? | Ofully automated Imanual'
Test type? ignition o no-flame [standard other
Oxygen conc. | % (vol, nominal) | Fuel bottle (next row)
xygen conc. | .70 (vol, per calc) | C2H6 220/0 C3H8
hamber pressure: | sia (CIR avg) | Burner fuel conc.: | O % (volume)
ent before? o no yes, to 0-2— psia | Fuel flow rate: 444% > | slpm (N2 basis)
Air' added? no• yes, to | psia | ow rate: Ö | > | slpm
Iso just before? o fan GC scrub
no fixed moving back-n-forth
INSTRUMENTATION | Gain: | DataCam 3 Y ops camera
(Datacam: filter?bQclear BG7 | CH20 | ROI?Rfull reduced | fps
Qlntensified: filter? ü clear | E-CH20 none | ROI? kfull reduced | fps
Ndi-BMs: backlight filter? noeyes | CIR | yes fps?a-f5T30
FLAME BEHAVIOR
o cool maybe cool | Ignited? kyes no yes, but ...*
Flame hole/opening<' partially detached | Soot@ignition | none little lots
Flame Koscillatingeunsteady | Soot@middle | none o little lots
Out {ext. detect time out temp. limit | oot@end | little lots
POST-TEST CONDITIONS | hamber pressure: 7 | psia (CIR avg)
Oxygen conc. | (vol, per calc) | Oxidizer bottle pressure: ( | psia
alve safety timer | 07 sec | Fuel bottle pressure: | psia
20
*GENERAL COMMENTS
24 March 2021
~~~~

### Pagina 2

Cita: [pdf_3070130bfd5beafd1c8b, p. 2]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_3070130bfd5beafd1c8b/p0002.jpg)

~~~~text
ACME / CFI-G (normal flame) - Science Test Sheet
est date: | 2-ozl | CME test#: 2)15 A
Local time: | 271 | est of day#: •¯2—
MT: | 13 | lame of day#: 2—
TEST CONDITIONS | ontrol? | 'fully automated fmanual'
Test type? o ignition o no-flame gstandard other
Oxygen conc. | % (vol, nominal) | Fuel bottle (next row)
Oxygen conc. | % (vol, per calc) | 2H6 | 0/0—8 | 0/0 ü n-C4H10 | %
Chamber pressure: | 38 psia (CIR avg) | Burner fuel conc.: | 3D % (volume)
_
ent before? no o yes, to | psia | Fuel flow rate: | slpm (N2 basis)
Air' added? no o yes, to | psia | > | slpm
Iso just before? | fan GC scrub
FP?Wno o fixed moving o back-n-forth
INSTRUMENTATION | Gain: | DataCam | camera
ops
ÉDataCam: filter? V-clear o BG7 CH* c.) CH20 | ROI? (full reduced | fps
•Intensified: filter? clear o CH*st CH20 none | ROI? €-,full reduced | fps
backlight filter? no Kyes | CIR backlight?yno yes fps2-a-æs-ff-3€—
FLAME BEHAVIOR
Flame Khot cool maybe cool | no o | but
yes, | ..
Flame hole/opening gpartially detached | oot@ignition | none little d lots
Flame oscillatingV-unsteady | oot@middle | none c] little lots
Out next. detect time out temp. limit | Soot@end | none o little lots
k
POST-TEST CONDITIONS | hamber pressure: _4 psia (CIR avg)
xygen conc. 3 | % (vol, per calc) | Oxidizer bottle pressure: | psia
alve safety timer | 6 sec | Fuel bottle pressure: | psia
*GENERAL COMMENTS
24 March 2021
~~~~

### Pagina 3

Cita: [pdf_3070130bfd5beafd1c8b, p. 3]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_3070130bfd5beafd1c8b/p0003.jpg)

~~~~text
ACME / CFI-G (normal flame) - Science Test Sheet
est date: | Z | CME test#:
Local time: | est of day
GMT: | 2t | Flame of day #:
TEST CONDITIONS | Control? | ully automated 'manual'
Test type? ignition no-flame Xstandard other
Oxygen conc. æ-4D % (vol, nominal) | Fuel bottle (next row)
Oxygen conc. | c 0/0 (vol, | calc) | 2H6 | C3H8 | %
per | n-C4H10 | %
Chamber pressure: 4Z.psia (CIR avg) | Burner fuel conc.: | % (volume)
C)
ent before? no D yes, to | psia | Fuel flow rate: 0-211 > | slpm (N2 basis)
Air' added? •no yes, to | psia | slpm
Iso just before? | fan GC o scrub
FP? Qno fixed o moving back-n-forth
INSTRUMENTATION | Gain: | DataCam | camera
ops
Datacam: filter?dclear BG7 | CH20 | ROI? Rfull o reduced | fps
_
vlntensified: filter? clear | none | ROI?kfull o reduced
D-HiBMSÜbacklight filter? no•ß-yes | CIR backlight? szho yes fps?-trts-rr30
FLAME BEHAVIOR
Flame | ot o cool maybe cool | Ignited? Q | no c] | but
yes | yes, | ..
Flame hole/openingß partially detached | oot@ignition o none little Üts
Flame n oscillating ( unsteady o | oot@middle | none o little lots
Out ext. detect time out temp. limit | oot@end | none little o lots
POST-TEST CONDITIONS | Chamber pressure: | 5 psia (CIR avg)
Oxygen conc. 31' | % (vol, per calc) | Oxidizer bottle pressu re: | psia
alve safety timer | sec | Fuel bottle | 18 | psia
pressure:
*GENERAL COMMENTS
24 March 2021
~~~~

### Pagina 4

Cita: [pdf_3070130bfd5beafd1c8b, p. 4]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_3070130bfd5beafd1c8b/p0004.jpg)

~~~~text
ACME / CFI-G (normal flame) - Science Test Sheet
est date: | Z | CME test#:
Local time: | est of day #:
MT: | 3 | h/ Flame of day #:
Rack Officer (RO): | PD (ACME):
DMO (CIR): | Researcher:
TEST CONDITIONS | Control? | {fully automated 'manual'
Test type? ignition no-flame | tandard other
Oxygen conc. | % (vol, nominal) | Fuel bottle (next row)
Oxygen conc. | O % (vol, per calc) | % n-C4H10 | %
hamber pressure: | psia (CIR avg) | Burner fuel conc.: | % (volume)
ent before? no o yes, to | psia | Fuel flow rate:0 17 > | slpm (N2 basis)
Air' added? rno yes, to | psia | rate: | > | slpm
C)
Iso just before? | GC scrub
FP? no fixed moving back-n-forth
INSTRUMENTATION | Gain: —O— DataCam | ops camera
DataCam: filter?kclear BG7 c] CH* o CH20 | ROI? Afull reduced | fps
Y-Intensified: filter? o clear CH*S4CH20 none | ROI? Xfull Cl reduced | fps
g-HiBMs± backlight filter? no &yes | CIR backlight? p--no yes fps?-a+-tso
FLAME BEHAVIOR
Flame hot cool c] maybe cool | Ignited? (yes o no o yes, but
.
Flame hole/openin | partially detached | Soot@ignition | none little lots
Flame oscillatingwunsteady | oot@middle Knone little lots
ut%-ext. detect o time out temp. limit | oot@end | none little lots
POST-TEST CONDITIONS | Chamber pressure: 75 psia (CIR avg)
Oxygen conc. | 6 % (vol, per calc) | Oxidizer bottle pressure: | psia
alve safety timer | sec | Fuel bottle pressure: | / Z psia
*GENERAL COMMENTS
24 March 2021
~~~~

### Pagina 5

Cita: [pdf_3070130bfd5beafd1c8b, p. 5]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_3070130bfd5beafd1c8b/p0005.jpg)

~~~~text
ACME / CFI-G (normal flame) - Science Test Sheet
est date: | CME test
Local time: | est of day #:
GMT: | Flame of day #:
TEST CONDITIONS | Control? | ully automated 'manual'
Test type? o ignition no-flameq standard other
Oxygen conc. | D % (vol, nominal) | Fuel bottle (next row)
Oxygen conc. | % (vol, per calc) | 2H6 | b % o C3H8 | 0/0 n -C4H 10 | 0/0
Chamber pressure: | Epsia (CIR avg) | Burner fuel conc.: | % (volume)
O
ent before? & no o yes, to | psia | Fuel flow rate: | > | slpm (N2 basis)
Air' added? pno yes, to | psia | NULew-tate: ö | > | slpm
Iso just before? Efan GC scrub
FP?kno o fixed o moving back-n-forth
INSTRUMENTATION | ain: 33 DataCam _Ä_ ops camera
S' Datacam: filter?klear BG7 | CH20 | ROI? A full reduced | fps
_
g-lntensified: filter? clear | none | ROI? m full reduced | ZZ fps
a-HiBMS•. backlight filter? no | es | CIR | yes fps2-e-±-9-t-36—
FLAME BEHAVIOR
Flame Khot o cool maybe cool | Ignited? Oes no a yes, but
..
Flame hole/opening partially detached | Soot@ignition | none little Nots—
Flame a oscillating o unsteady | oot@middle | none o little lots
ut ext. detect o time out •temp. limit | oot@end | •none little lots
POST-TEST CONDITIONS | Chamber pressure: | 54 psia (CIR avg)
Oxygen conc. | % (vol, per calc) | Oxidizer bottle pressure: [547psia
alve safety timer | sec | Fuel bottle pressure: | psia
*GENERAL COMMENTS
24 March 2021
~~~~

### Pagina 6

Cita: [pdf_3070130bfd5beafd1c8b, p. 6]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_3070130bfd5beafd1c8b/p0006.jpg)

~~~~text
ACME / CFI-G (normal flame) - Science Test Sheet
est date: | CME test#: | 153
Local time: | est of day #:
MT: | lame of day#: 6
Rack Officer (RO): | PD (ACME):
DMO (CIR): | Researcher:
TEST CONDITIONS | Control? | u-fully automated c] 'manual'
Test type? ignition o no-flame gstandard other
xygen conc. | % (vol, nominal) | Fuel bottle (next row)
Oxygen conc. | % (vol, per calc) | C2H6 20/0 C3H8 | % n-C4H10
Chamber pressure: | psia (CIR avg) | Burner fuel conc.: | % (volume)
ent before? Ano o yes, to | psia | Fuel flow rate: | > | slpm (N2 basis)
Air' added? no yes, to | psia | slpm
ISO just before? cLfan o GC scrub
FP? Kno o fixed moving back-n-forth
INSTRUMENTATION | ain: | DataCam | ops camera
filter? | BG7 | CH20 | ROI? V full c] reduced | fps
_
Wlntensified: filter? o clear CHSåß2Q D none | ROI?efull reduced | 2-2 fps
n-HiBMs•. backlight filter? nonyes | CIR backlight?sa-no yes
/-Aywy
FLAME BEHAVIOR
Flame hot o cool maybe cool | Ignited? yes no | but
yes,
Flame hole/opening partially detached | oot@ignition o none little 3-lots
Flame oscillating o unsteady | oot@middle k none little lots
ut c] ext. detect time out temp. limit | Soot@end | Anone little lots
POST-TEST CONDITIONS | Chamber pressure: | 'C) psia (CIR avg)
Oxygen conc. 2 | ZYo(vol, per calc) | Oxidizer bottle pressure: 1 4 psia
alve safety timer | sec | Fuel bottle pressure: / | psia
*GENERAL COMMENTS
24 March 2021
~~~~

### Pagina 7

Cita: [pdf_3070130bfd5beafd1c8b, p. 7]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_3070130bfd5beafd1c8b/p0007.jpg)

~~~~text
ACME / CFI-G (normal flame) - Science Test Sheet
est date: | @ | CME test#:
Local time: | est of day#: 7
GMT: | lame of day #:
TEST CONDITIONS | Control? | fully automated 'manual'
Test type? ignition o nozflam*standard other
Oxygen conc | % (vol, nominal) | Fuel bottle (next row)
Oxygen | (vol, per calc) | % a C3H8 | % o n-C4H10 | %
hamber pressure: | 'bpsia (CIR avg) | Burner fuel conc.: | % (volume)
ent before? o no yes, to | psia | Fuel flow rate: | > | slpm (N2 basis)
Air' added? no o yes, to | psia | ate: C) > | slpm
Iso just before? a fan GC scrub
FP?Kno fixed moving back-n-forth
INSTRUMENTATION | Gain: _æ_ DataCam | ops camera
g DataCam: filter? *clear BG7 CH* o CH20 | ROI? {full reduced | fps
_
•élntensified: filter? o clear CH*CH20 none | ROI? <full ü reduced | 23 fps
Q_HiBM+backlight filter? no yes | CIR backlight?Æ no yes
FLAME BEHAVIOR
Flameb&hot cool maybe cool | Ignited? yes no yes, but ...*
Flameæ hole/opening Xpartially detached | oot@ignition | none o little Ots
Flame Aoscillating eunsteady | Soot@middle | none little lots
Out | detect time out temp. limit | oot@end | noneAlittle lots
POST-TEST CONDITIONS | Chamber pressure: ZZ4Z psia (CIR avg)
Oxygen conc. 3 | % (vol, per calc) | Oxidizer bottle pressure: Z | psia
alve safety timer | sec | Fuel bottle pressure: | psia
*GENERAL COMMENTS
YKs
24 March 2021
~~~~

### Pagina 8

Cita: [pdf_3070130bfd5beafd1c8b, p. 8]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_3070130bfd5beafd1c8b/p0008.jpg)

~~~~text
ACME / CFI-G (normal flame) - Science Test Sheet
est date: | CMEtest#: 2u5
Local time: | est of day #:
GMT: | O | Ilk Flame of day #: Z
TEST CONDITIONS | Control? | V fully automated 'manual'
Test type? ignition a no-flar*standard other
Oxygen conc. | % (vol, nominal) | Fuel bottle (next row)
Oxygen conc. 3 | % (vol, per calc) | 20/0 C3H8 | % n-C4H10 | %
Chamber pressure: | psia (CIR avg) | Burner fuel conc.: | % (volume)
ent | yes, to | psia | Fuel flow rate: D | > | slpm (N2 basis)
Air' added? | o yes, to | psia | ow rate: D | > | slpm
Iso just before? | fan GC scrub
fixed moving o back-n-forth
INSTRUMENTATION | Gain: | DataCam | ops camera
*DataCam: filter? | BG7 0 CH* CH20 | ROI? Afull reduced | fps
_
*Intensified: filter? clear CH*'4CH20 none | o reduced | fps
aBiBMsrbacklight filter? D no *yes | CIR backlightLno yes fps.2-*5-e-30
FLAME BEHAVIOR
Flame hot o cool maybe cool | Ignited? | es o no yes, but
..
Flame D hole/opening iQartially detached | oot@ignition | none little lots
Flamekoscillating Kunsteady | oot@middle | noneålittle lots | ResäO
Out ext. detect time out temp. limit | oot@end | none ü little o lots
POST-TEST CONDITIONS | Chamber pressure: 2% | psia (CIR avg)
Oxygen conc. 3 | % (vol, per calc) | Oxidizer bottle pressure: Z | psia
alve safety timer | sec | Fuel bottle pressure: | 6 Z— psia
*GENERAL COMMENTS
24 March 2021
~~~~

### Pagina 9

Cita: [pdf_3070130bfd5beafd1c8b, p. 9]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_3070130bfd5beafd1c8b/p0009.jpg)

~~~~text
ACME / CFI-G (normal flame) - Science Test Sheet
CME test
Local time: | est of day #:
MT: •t | lame of day #:
Rack Officer (RO): | PD (ACME):
DMO (CIR): | Researcher:
TEST CONDITIONS | ontrol? | Xåully automated 'manual'
Test type? o ignition no-flame Åstandard other
Oxygen conc. | % (vol, nominal) | Fuel bottle (next row)
Oxygen conc. | % (vol, per calc) | KC2H6 | C3H8 | 0/0 0 | H 10 | 0/0
Chamber pressure: Z | psia (CIR avg) | Burner fuel conc.. | % (volume)
ent before? k no yes, to | psia | Fuel flow rate: | > | slpm (N2 basis)
Air' added? ß-no yes, to | psia | > | slpm
Iso just before? | GC scrub
fixed o moving back-n-forth
INSTRUMENTATION | Gain: 33 DataCam | ops camera
DataCam: filter?kclear o BG7 CH* CH20 | ROI? *full reduced | fps
_
*Intensified: filter? clear ChßZCH20 none | a reduced | fps
æ44iBMssbacklight filter? noses | CIR backlight. no yes fps?
FLAME BEHAVIOR
Flame Qhot o cool maybe cool | Ignited? Kyes no | but *
yes, | ...
Flame hole/opening | artially detached | oot@ignition | none littleQts
nsteady o | oot@middle | none little lots
Out ext. detect o time out temp. limit | oot@end | Enone little ü lots
POST-TEST CONDITIONS | Chamber pressure: | psia (CIR avg)
z--
Oxygen conc. | 7 g % (vol, per calc) | xidizer bottle pressu re.•z | psia
alve safety timer | sec | Fuel bottle pressure: | /55 psia
*GENERAL COMMENTS
escnpe—
24 March 2021
~~~~

### Pagina 10

Cita: [pdf_3070130bfd5beafd1c8b, p. 10]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_3070130bfd5beafd1c8b/p0010.jpg)

~~~~text
ACME / CFI-G (normal flame) - Science Test Sheet
est date: | J | 2--02—1 | CME test #:
Local time: | est of day#: /D
MT: | 15 | log | lame of day #:
TEST CONDITIONS | ontrol? | fully automated 'manual'
Test type? ignition o no-flame*standard o other
Oxygen conc. | % (vol, nominal) | Fuel bottle (next row)
Oxygen conc. | g % (vol, per calc) | C2H6@0/0 C3H8 | % n-C4H10 | %
Chamber pressure: Zt47 psia (CIR avg) | Burner fuel conc.: | D % (volume)
ent before? Kno yes, to | psia | Fuel flow rate: | > | slpm (N2 basis)
Air' added? | yes, to | psia | w rate: | CD > | slpm
Iso just before? $z_fan GC scrub
FP? novefixed moving back-n-forth
INSTRUMENTATION | Gain: D DataCam | ops camera
ZDataCam: filter? #clear BG7 | CH20 | ROI? <full Cl reduced | fps
ntensified: filter? o clear o CH* | none | ROI? gefull reduced | 2-3 fps
QHiBMs: backlight filter? no yes | CIR backlight? zno yes fpsæ-±5-e-3.æ
FLAME BEHAVIOR
Flame hot o cool maybe cool | Ignited? | no o yes, but ...*
Flame hole/opening epartially detached | oot@ignition | none little lots
Flame. oscillating Q unsteady | oot@middle A none little lots
ut ext. detect time out temp. limit | Soot@end | —none little o lots
POST-TEST CONDITIONS | Chamber pressure: Zd54psia (CIR avg)
Oxygen conc. | % (vol, per calc) | Oxidizer bottle pressure: Zt5 psia
alve safety timer | sec | Fuel bottle pressure: | psia
*GENERAL COMMENTS
e-Sd-EY'9&
24 March 2021
~~~~

### Pagina 11

Cita: [pdf_3070130bfd5beafd1c8b, p. 11]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_3070130bfd5beafd1c8b/p0011.jpg)

~~~~text
ACME / CFI-G (normal flame) - Science Test Sheet
est date: | 2 20 | CME test #:
Local time: | est of day If
MT: | 15 | Flame of day #: II
Rack Officer (RO): | PD (ACME):
DMO (CIR): | Researcher:
TEST CONDITIONS | Control? | •fully automated 'manual'
Test type? ignition no-flame (standard other
Oxygen conc. | % (vol, nominal) | Fuel bottle (next row)
Oxygen conc. | % (vol, per calc)
Chamber pressure: | S2-psia (CIR avg) | Burner fuel conc.: | Bc) % (volume)
ent before? Kno o yes, to | psia | Fuel flow rate: | > | slpm (N 2 basis)
Air' | yes, to | psia | ate: | > | slpm
Iso just before? | GC scrub
FP?Vno c] fixed moving back-n-forth
INSTRUMENTATION | ain: -3 > DataCam | ops camera
g-DataCam: filter?+clear c] BG7 CH* CH20 | ROI? g-full reduced | fps
_
ylntensified: filter? c] clear CH*YÆH20 none | ROI? Cfull reduced | Z fps
a-H.i.BMs3 backlight filter? no #yes | CIR backlight?gno yes fps? 15 30
[-kYAs
FLAME BEHAVIOR
Flame hot cool maybe cool | Ignited? yes no yes, but
.
Flame hole/opening%partially detached | oot@ignition | none
Flame*oscillating | oot@middle Gone little o lots
Out ext. dete | time out temp. limit | oot@end | none little ü lots
POST-TEST CONDITIONS | Chamber pressure: Zt5tpsia (CIR avg)
Oxygen conc. | % (vol, per calc) | Oxidizer bottle pressure: 2 5 psia
alve safety timer | ZS | sec | Fuel bottle pressure: | MO | psia
*GENERAL COMMENTS
24 March 2021
~~~~

### Pagina 12

Cita: [pdf_3070130bfd5beafd1c8b, p. 12]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_3070130bfd5beafd1c8b/p0012.jpg)

~~~~text
ACME / CFI-G (normal flame) - Science Test Sheet
est date: | CME | S ZI 153C5
Local time: | est of day#: i Z
GMT: ZI 1 3 | he lame of day
TEST CONDITIONS | ontrol? | fully automated o 'manual'
Test type? c] ignition no-flame*tandard c] other
Oxygen conc. —40 % (vol, nominal) | Fuel bottle (next row)
Oxygen conc. | 73 % (vol, per calc) | 2H6 | o C3H8 | % n-C4H10 | %
Chamber pressure:ZZ5 psia (CIR avg) | Burner fuel conc.: | % (volume)
ent before. no yes, to | psia | Fuel flow rate:D /Öé > | slpm (N2 basis)
Air' added? L-no o yes, to | psia | te: O > | slpm
Iso just before? Afan GC scrub
fixed ü moving back-n-forth
INSTRUMENTATION | ain: 37 DataCam | ops camera
XDataCam: filter? Felear BG7 CH* CH20 | ROI?RfulI c] reduced | fps
_
Vlntensified: filter? clear | •SCH20 none | ROI? | Cl reduced | 23fps
æ-HiBMs: backlight filter? noVes | CIR backlight3éno o yes fps.?-a-B-ty-30-— | no
FLAME BEHAVIOR
Flame hot o cool maybe cool | Ignited? yes no yes, but ...*
Flame o hole/opening o partially detached | oot@ignition | none little Wots
Flame oscillating | Soot@middle (none little lots
Out ext. detect o time out temp. limit | oot@end | Xnone little o lots
POST-TEST CONDITIONS | hamber pressure: Z Lb psia (CIR avg)
Oxygen conc. 37 6 | % (vol, per calc) | Oxidizer bottle pressure: | psia
alve safety timer | sec | Fuel bottle pressure: | psia
*GENERAL COMMENTS
24 March 2021
~~~~

### Pagina 13

Cita: [pdf_3070130bfd5beafd1c8b, p. 13]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_3070130bfd5beafd1c8b/p0013.jpg)

~~~~text
ACME / CFI-G (normal flame) - Science Test Sheet
est date: | Z) | CME test#: | C
Local time: | est of day#: i
GMT: | 15 | lame of day #:
TEST CONDITIONS | Control? | g fully automated 'manual'
Test type? ignition no-flameKstandard other
Oxygen conc. | --4b % (vol, nominal) | Fuel bottle (next row)
Oxygen conc. | % (vol, per calc) | C2H6 3.2—0/0 0 C3H8 | % Cl n-C4H10 | %
Chamber pressure: | psia (CIR avg) | Burner fuel conc.: | % (volume)
ent before?x-no yes, to | psia | Fuel flow rate: 037> | slpm (N 2 basis)
Air' added? | yes, to | psia | low rate: | slpm
Iso just before? | fan GC scrub
F P | no fixed c] moving back-n-forth
INSTRUMENTATION | ain: 3 | DataCam 3_1_ ops camera
k Datacam: filter? | BG7 | CH20 | ROI? Rfull reduced | fps
filter? clear CH* KCH20 none | full c] reduced
E-HiBMs: backlight filter? a nonyes | CIR backlight?Eno yes
FLAME BEHAVIOR
Flame hot o cool maybe cool | Ignited? yes no o yes, but ...*
Flameß hole/opening epartially detached | oot@ignition | none little Ots
Flame | oot@middle | none little lots
Out | detect time out a temp. limit | Soot@end | g none little lots
POST-TEST CONDITIONS | Chamber pressure: | psia (CIR avg)
xygen conc. | % (vol, per calc) | Oxidizer bottle pressure: 2$$ psia
alve safety timer | sec | Fuel bottle pressure: / | psia
*GENERAL COMMENTS
5c•æ4-
24 March 2021
~~~~

### Pagina 14

Cita: [pdf_3070130bfd5beafd1c8b, p. 14]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_3070130bfd5beafd1c8b/p0014.jpg)

~~~~text
ACME / CFI-G (normal flame) - Science Test Sheet
est date: | v) | ZOZ | CME test #: | IS 30
Local time: | est of day #:
MT: ZI | Flame of day
Rack Officer (RO): | PD (ACME):
DMO (CIR): | Researcher:
TEST CONDITIONS | Control? | ully automated 'manual'
Test type? ü ignition no-flame standard other
Oxygen conc. | 44-0 % (vol, nominal) | Fuel bottle (next row)
Oxygen conc. | 7.. | % (vol, per calc) | % n-C4H10 | %
Chamber pressure: | psia (CIR avg) | Burner fuel conc.. | O % (volume)
ent before? (no yes, to | psia | Fuel flow rate: | > | slpm (N2 basis)
Air' added? Eno yes, to | psia | rate: | D > | slpm
Iso just before? kfan GC scrub
FP?k no o fixed moving back-n-forth
INSTRUMENTATION | Gain: 33 DataCam | ops camera
< DataCam: filter? *clear o BG7 CH* CH20 | ROI? Rfull o reduced | fps
ZJntensified: filter? a clear o CH*SCH20 ü none | ROI? Lfull o reduced | fps
crHtBMs=backlight filter? no yes | CIR backlight?Eno yes fp.s.?-g4.s-e-3e-
FLAME BEHAVIOR
Flame | ot cool maybe cool | Ignited? dyes no yes, but
.
Flame hole/opening partially detached | oot@ignition | none a little {lots
FlameQ-oscillating Sunsteady | oot@middle c] nonebd little lots
Out ext. dete | time out o temp. limit | oot@end | Qnone o little lots
POST-TEST CONDITIONS | Chamber pressure: 27." psia (CIR avg)
Oxygen conc. 372-1 % (vol, per calc) | Oxidizer bottle pressure: | psia
alve safety timer | sec | Fuel bottle pressure: | Z- psia
*GENERAL COMMENTS
24 March 2021
~~~~
