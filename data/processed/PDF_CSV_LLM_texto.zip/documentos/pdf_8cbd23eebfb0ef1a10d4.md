# 19182 test parameter notes

- Identificador: pdf_8cbd23eebfb0ef1a10d4
- Investigaciones: PSI-10
- Tipo de documento: Raw Data
- Estado: processed
- Temas detectados automaticamente: ignition, extinction, hardware, operations

## Fuentes

- [PSI-10_Raw Data_19182 test parameter notes.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-10/Raw%20Data/PSI-10_Raw%20Data_19182%20test%20parameter%20notes.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_8cbd23eebfb0ef1a10d4, p. 1]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_8cbd23eebfb0ef1a10d4/p0001.jpg)

~~~~text
testpointName 19182A1
prelgnitionDataTimeSec
postFlameDataTimeSec | 15
uselPSUs TRUE
ipsuTimeoutSec | 40
useAcmeCamera TRUE
uselntensifiedcamera TRUE
ipsu1ArchiveRate | 2
dataCameraprelgnitionExposureUs 1000000
dataCameralgnitionExposureUs | 50
dataCameraTestExposureUs 000000
dataCameraExtinctionExposureUs
analogCameraPrelgnitionShutter | 2
analogCameralgnitionShutter | 2
anatogCameraTestShutter | 2
anatogCameraExtinctionShutter
intensifierGainAmplitude 75000
prelgnitionlmageTimeSec
postFlamelmagingTimeSec | 5
useBracketedExposures
bracketinglmagesperExposure | 1
bracketingNumberOfExposures | 4
bracketingExposureStartUsec 50000
bracketingExposureMultiplierTlmes100 | 250
igniter Ignition Position
igniterPreheatPowerV | 2.25
igniterPreheatTimeMs | 1000
igniterlgnitionPOwerV | 3.75
igniterlgnitionDurationMs | 2500
igniterDelayBeforeRetractMs | 2000
igniterRetractVelocityCountsPerSec | 500
uselgnitionDetection TRUE
extinctionDetectionStopsTest TRUE
pmt1Gain | 5
pmt2Gain | 5.25
pmt3Gain | 5.25
fiberlgnitionPosition 11000
fiber TestPosition 15300
fiberMoveDuringTest TRUE
fiberSegmentDistance | 400
fiberVelocity | 500
fiberAcceteration | 1000
fiberDeceleration
fiber HoldDurationSec | 1
fiberCycles | 100
useFoma TRUE
flowTimeoutSec | 200
nitrogenPriming1DurationSec | 0
nitrogenPriming2DurationSec | 1
fuelFlowlgnitionDeltaMs
stabilization TimelSec | 3
stabilizationTime2Sec | 3
fuelB0ttlelgnitionFlowRateN2Slpm 0.052
nitrogenlgnitionFlowRateN2Slpm | ,468v
fuelB0ttleTestFlowRateN2Slpm 0.052
nitrogenTestFlowRateN2Slpm | 98m
ignitionToTestRampTimeSec
constantFIowTimeSec | 30
useRampF10wTOZero FALSE
rampFlowToZeroSec | 10
constantPostExtinctionDelaySec
constantPostExtinction FlowChangeFuelPercent -50.0
constantP0stExtinctionFlowChangeN2Percent -50.0
constantPostExtinctionFlowChangeRampTimeSec | 3
constantPostExtinctjonF10wChangeHoldSec | 0
rampP0stExtinctionDelaySec
rampPostExtinctionF10wChangeFuelPercent 100.0
rampPostExtinctionFlowChangeN2Percent 100.0
rampPostExtinctionF10wChangeRampTmeSec | 3
rampPostExtinctionFlowChangeHoldSec
burner TemperatureLimitC | 500
burner TemperatureLimitDurationSecs | 3
0-5 S 4
Yee;y
~~~~

### Pagina 2

Cita: [pdf_8cbd23eebfb0ef1a10d4, p. 2]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_8cbd23eebfb0ef1a10d4/p0002.jpg)

~~~~text
testpointName | 1918281
prelgnitionDataTimeSec
postFlameDataTimeSec | 15
uselPSUs | TRUE
ipsuTimeoutSec | 40
useAcmeCamera | TRUE
uselntensifiedCamera | TRUE
ipsu1ArchiveRate | 2
dataCameraPrelgnitionExposureUS | 1000000
dataCameralgnitionExposureUs | 00
dataCameraTestExposureUs | 000000
dataCameraExtinctionExposureUS
analogCameraPrelgnitionShutter | 2
analogCamera'gnitionShutter | 2
analogCameraTestShutter | 2
analogCameraExtinctionShutter
intensifierGainAmplitude | 75000
preignitionlmageT1meSec
postFlamelmagingTimeSec | 5
useBracketedExposures
bracketinglmagesPerExposure | 1
bracketingNumberOfExposures | 4
bracketingExposureStartUsec | soooo
bracketingExposureMultiplierTirnes100 | 250
ign iterignitionPosition | 3
igniterPreheatP0werV | 2.25
igniterPreheatTimeMs | 1000
igniterlgnitionPowerV | 3.75
igniterlgnitionDurationMs | 2500
ign iterDelayBeforeRetractMs | 2000
igniterRetractVelocityCountsperSec | 500
uselgnitionDetection | TRUE
extinctionDetectionStopsTest | TRUE
pmt1Gain | 5
pmt2Gain | 5.25
pmt3Gain | 5.25
fiberlgnitionposition
fiberTestPosition
fiberMoveDuringTest | FALSE
fiberSegmentDistance | 400
fiberVelocity | 500
fiberAcceleration | 1000
fiberDeceleration
fiber HoldDurationSec | 1
fiberCycles | 100
useFoma | TRUE
flow TimeoutSec | 200
nitrogenPriming1DurationSec
nitrogenPriming2DurationSec | 1
fuelF10wlgnitionDeltaMs
stabilizationTime1Sec | 3
stabilizationTlme2Sec
fuelB0ttlelgnitionFlowRateN2Slpm | 0.052
nitrogenlgnitionFlowRateN2Slpm | 46
fuel BottleTestF10wRateN2Slpm | 0.052
nitrogenTestFlowRateN2Slpm | 0.598
ignitionToTestRampTimeSec
constantF10wTimeSeC | 30
use Ram pFlowToZero | FALSE
rampFlowToZeroSec | 10
constantPostExtinctionDetaySec
constantPostExtinctionFlowChangeFuelPercent | -50.0
constantPostExtinctionF10wChangeN2Percent | -50.0
constantPostExtinctionF10wChangeRampTimeSec | 3
constantPostExtinctionFlowChangeH01dSec
rampPostExtinctionDelaySec
rampPostExtinctionFlowChangeFuelPercent | 100.0
rampPostExtinctionF10wChangeN2Percent | 100.0
rampPostExtinctionFlowChangeRampTimeSec | 3
rampPostExtinctionFlowChangeHOIdSec
burner Temperature LimitC | 500
burner TemperatureLimitDurationSecs | 3
~~~~

### Pagina 3

Cita: [pdf_8cbd23eebfb0ef1a10d4, p. 3]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_8cbd23eebfb0ef1a10d4/p0003.jpg)

~~~~text
testpointName | 19182c1
prelgnitionDataTimeSec
postFlameDataTimeSec | 15
uselPSUs | TRUE
ipsuTimeoutSec | 40
useAcmeCamera | TRUE
uselntensifiedcamera | TRUE
ipsu1ArchiveRate | 2
dataCameraPrelgnition ExposureUs | 1000000
dataCameralgnitionExposureUs
dataCameraTestExposureUs | 200000
dataCameraExtinctionExposureUS | 00000
analogCameraPrelgnitionShutter | 2
analogCameralgnitionShutter | 2
analogCameraTestShutter | 2
analogCameraExtinctionShutter
intensifierGainAmplitude | 75000
preignitionlmageTimeSec
postFlamelmagingTimeSec | 5
use BracketedExposures | RUE
bracketinglmagesPerExposure | 1
bracketingNumberOfExposures | 4
bracketingExposureStartUsec | 50000
bracketingExposureMultiplierTimes100 | 250
igniterlgnitionposition
igniterPreheatP0werV | 2.25
igniterPreheatTimeMs | 1000
igniterlgnitionPowerV | 3.75
igniterlgnitionDurationMs | 2500
igniterDelayBeforeRetractMs | 2000
igniterRetractVelocityC0untsPerSec | 500
uselgnitionDetection | TRUE
extinctionDetectionStopsTest | TRUE
pmt1Gain | 5
pmt2Gain | 5.25
pmt3Gain | 5.25
fiberlgnitionposition | 11000
fiberTestPosition | 15300
fiberMoveDuringTest | TRUE
fiberSegmentDistance
fiberVelocity | 500
fiberAcceleration | 1000
fiberDeceleration
fiberHoldDurationSec | 1
fiberCycles | 100
useFoma | TRUE
flowTimeoutSec | 200
nitrogenPriming1DurationSec
nitrogenPriming2DurationSec | 1
fuelF10wlgnitionDeltaMs
StabilizationTime1Sec
stabilizationTime2Sec
fuelB0ttlelgnitionFlowRateN2Slpm | 0.052
nitrogenlgnitionF10wRateN2Slpm | 0.526
fuelBottleTestFlowRateN2Slpm | 0.052
nitrogenTestFlowRateN2Slpm
ignitionTOTestRampTimeSec | 0
constantFlowTmeSec | 30
use Ram pF10wTOZer0 | FALSE
rampFlowToZeroSec | 10
constantPostExtinctionDelaySec
constantPostExtinctionFlowChangeFuelPercent | -50.0
constantPostExtinction FlowChangeN2Percent | -50.0
constantP0stExtincti0n FlowChangeRampTimeSec | 3
constantPostExtinctionFlowChangeHoldSec
rampPostExtinctionDelaySec
rampPostExtinctionFlowChangeFuelPercent | 100.0
rampPostExtinctionFlowChangeN2Percent | 100.0
rampPostExtinctionFlowChangeRampTimeSec | 3
rampPostExtinctionFlowChangeHOIdSec
burnerTemperatureLimitC | 500
burnerTemperatureLimitDurationSecs | 3
.ß.es+..s« /
V
~~~~

### Pagina 4

Cita: [pdf_8cbd23eebfb0ef1a10d4, p. 4]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_8cbd23eebfb0ef1a10d4/p0004.jpg)

~~~~text
testpointName | 19182D1
prelgnitionDataTimeSec
postFlameDataTlmeSec | 15
usepsus | TRUE
ipsuTimeoutSec | 40
useAcmeCamera | TRUE
uselntensifiedCamera | TRUE
ipsu1ArchiveRate | 2
dataCameraPrelgnitionExposureUs | 1000000
dataCameralgnitionExposureLJs
dataCameraTestExposureUs | 00
dataCameraExtinctionExposureUs
analogCameraPrelgnitionShutter | 2
analogCameralgnitionShutter | 2
analogCameraTestShutter | 2
analogCameraExtinctionShutter
intensifierGainAmplitude | 75000
preignitionlmageTimeSec
postFlamelmagingTimeSec | 5
useBracketedExposures | TRUE
bracketinglmagesPerExposure | 1
bracketingNumberOfExposures | 4
bracketingExposureStartUsec | 50000
bracketingExposureMultiplierTimes100 | 250
igniterlgnitionposition
igniterPreheatPowerV | 2.25
igniterPreheatümeMs | 1000
igniterlgnitionPowerV | 3.75
igniterlgnitionDurationMs | 2500
igniterDelayBeforeRetractMs | 2000
igniterRetractVelocityCountsPerSec | 500
uselgnitionDetection | TRUE
extinction DetectionStopsTest | TRUE
pmt1Gain | 5
pmt2Gain | 5.25
pmt3Gain | 5.25
fiberlgnitionPosition | 11000
fiberTestPosition | 15300
fiberMoveDuringTest | TRUE
fiberSegmentDistance | 400
fiberVelocity | 500
fiberAcceleration | 1000
fiberDeceleration
fiberHoldDurationSec | 1
fiberCycles | 100
useFoma | TRUE
flowTimeoutSec | 200
nitrogenPriming1DurationSec
nitrogenPriming2DurationSec | 1
fuelFlOwlgnitionDeltaMs
stabilizationTme1Sec | 0
stabilizationT1me2Sec | 5
fuelB0ttlelgnitionF10wRateN2Slpm | 0.065
nitrogenlgnitionF10wRateN2Slpm | 26
fuelBottleTestFlowRateN2Slpm | 0.065
nitrogenTestFlowRateN2Slpm
ignitionTOTestRampTimeSec
constantFlowTimeSec | 40
useRampFlowToZero | FALSE
rampF10wTOZeroSec | 10
constantPostExtinctionDelaySec
constantPostExtinctionFlowChangeFu e I Percent | -50.0
constantPostExtinctionFlowChangeN2Percent | -50.0
constantPostExtinction FlowChangeRampTimeSec | 3
constantPostExtinctionFlowChangeH01dSec
rampPostExtinctionDelaySec
rampPostExtinCtionF10wChangeFuelPercent | 100.0
rampPostExtinctionFlowChangeN2Percent | 100.0
rampPostExtinctionFlowChangeRampTimeSec | 3
rampPostExtinctionFlowChangeHoldSec | 0
burner TemperatureLimitC | 500
burner TemperatureLimitDurationSecs | 3
~~~~

### Pagina 5

Cita: [pdf_8cbd23eebfb0ef1a10d4, p. 5]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_8cbd23eebfb0ef1a10d4/p0005.jpg)

~~~~text
testpointName | 19182F1
preignitionDataTimeSec
postFlameDataTimeSec | 15
uselPSUs | TRUE
ipsuTimeoutSec | 40
useAcmeCamera | TRUE
uselntensifiedCamera | TRUE
ipsu1ArchiveRate | 2
dataCameraPrelgnitionExposureUs | 1000000
dataCameralgnitionExposureUs
dataCameraTestExposureUS | *200000
dataCameraExtinctionExpOSureUs
analogCameraPrelgnitionShutter | 2
analogCameralgnitionShutter | 2
analogCameraTestShutter | 2
analogCameraExtinctionShutter
intensifierGainAmplitude | 75000
prelgniti0nlmageTimeSec
postFiamelmagingTimeSec | 5
use3racketedExposures | TRUE
bracketinglmagesPerExposure | 1
bracketingNumberOfExposures | 4
bracketingExposureStartUsec | 50000
bracketingExposureMultiplierT1meSIOO | 250
igniterlgnitionPosition
igniterPreheatPowerV | 2.25
igniterPreheatTimeMs | 1000
igniterlgniti0nPowerV | 3.75
igniterlgnitionDuratiOnMs | 2500
igniterDelayBeforeRetractMs | 2000
igniter RetractVeIocityCountsPerSec | 500
uselgnitionDetection | TRUE
extinctionDetectionStopsTest | TRUE
pmt1Gain | 5
pmt2Gain | 5.25
pmt3Gain | 5.25
fiberlgnitionPosition | •11000
fiberTestPosition | 15300
fiberMoveDuringTest | TRUE
fiberSegmentDistance | 400
fiberVelocity | 500
fiberAcceleration | 1000
fiberDeceleration
fiberHoldDurationSec | 1
fiberCycles | 100
useFoma | TRUE
flowTimeoutSec | 200
nitrogenPriming1DurationSec
nitrogenPriming2DurationSec | 1
fuelF10wlgnitionDeltaMs | 12
stabilizationTime1Sec
stabilizationTime2Sec | 5
fuelB0ttlelgnitionF10wRateN2Slpm | 0.065
nitrogenlgnitionFlowRateN2Slpm | 0.435
fuelB0ttleTestFlowRateN2Slpm | 0,065
nitrogen TestF10wRateN2Slpm | 0.435
ignitionTOTestRampTimeSec
constantFlowTimeSec | 40
useRampFlowToZero | FALSE
rampF10wTOZeroSec | 10
constantPostExtinctionDelaySec
constantPostExtinctionFlowChangeFuelPercent | -50.0
constantPostExtinctionFIowChangeN2Percent | -50.0
constantPostExtinctionFlowChangeRampTimeSec | 3
constantPostExtinctionFlowChangeH01dSec | 0
rampPostExtinctionDelaySec
rampPostExtinctionFlowChangeFuelPercent | 100.0
rampPostExtinctionFlowChangeN2Percent | 100.0
rampPostExtinctionFlowChangeRampTimeSec | 3
rampPostExtinctionFlowChangeH01dSec | 0
burner Temperature LimitC | 500
burnerTemperatureLimitDurationSecs | 3
~~~~

### Pagina 6

Cita: [pdf_8cbd23eebfb0ef1a10d4, p. 6]. Metodo: windows_ocr_grid_removed.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_8cbd23eebfb0ef1a10d4/p0006.jpg)

~~~~text
testpointNamel | | 1918261
prelgnitionDataTimeSecl
postFlameDataTimeSec' | 15
uselPSUs | TRUE
ipsuTimeoutSec | 40
useAcmeCamera | TRUE
uselntensifiedCamera | TRUE
ipsu1ArchiveRate | 2
dataCameraPrelgnitionExposureUs | 1000ß00
dataCameralgnitionExposureUs | 150000
dataCameraTestExposureUs | 150000
dataCameraExtinctionExposureUs | 150000
analogCameraPrelgnitionShutter | 2
analogCameralgnitionShutter | 2
analogCameraTestShutter | 2
analogCameraExtinctionShutter
intensifierGainAmplitude | 75000
preignition ImageTimeSec
postFlameImagingTimeSec | 5
useBracketedExposures
bracketinglmagesPerExposure | 1
bracketingNumberOfExposures | 4
bracketingExposureStartUsec | 50000 | 4De•c
bracketingExposureMultiplierTimes100 | 250
igniterlgnitionPosition | 2280
igniterPreheatPowerV | 2.25
igniterPreheatTimeMs | 1000
igniterlgnitionP0werV | 3.75
igniterlgnitionDurationMs | 2500
igniterDelayBeforeRetractMs | 2000
igniter RetractVelocityCountsPerSec | 500
uselgnitionDetection | TRUE
extinctionDetectionStopsTest | TRUE
pmt1Gain | 5
pmt2Gain | 5.25
pmt3Gain | 5.25
fiberlgnitionPOSition | i Leo-o | -2
fiberTestPosition | 15 Cco
fiberMoveDuringTest
fiberSegmentDistance
fiberVelocity | 4vD | ADD
fiberAcceleration | 1000
fiberDeceleration
fiberHoldDurationSec | 1
fiberCycles | 100
useFoma | TRUE
flowTimeoutSec | 200
nitrogenPriming1DurationSec
nitrogenPriming2DurationSec | 1
fuelF10wlgnitionDeltaMs | 800
stabilizationTlme1Sec | 20
stabilizationTime2Sec
fuelB0ttlelgnitionAowRateN2Slpm | 0.078 | 5--67B s, off
nitrogenlgniti0nF10wRateN2Slpm | O.S12 o,tR2-
fuelBottleTestFlowRateN2Slpm | o.oq | 6.ct;- | 0.)b4- | 0.07g | .053
nitrogen TestFlowRateN2Slpm | 0.312 0.24= | 2.312
ignitionTOTestRampTimeSec | o | Vo | 2-0 | 40
constantFlowTimeSec | 1 95
useRampFlowToZero | FALSE
rampFlowTOZeroSec | 10
constantPostExtinction DelaySec
constantPostExtinctionF10wChangeFuelPercent | -50.0
constantPostExtinctionFlowChangeN2Percent | -50.0
constantPostExtinctionFiowChangeRampTimeSec | 3
constantPostExti nction FlowChangeH01dSec
rampPostExtinctionDelaySec
rampPostExtinctionFlowChangeFuelPercent | 100.0
rampPostExtinctionH0wChangeN2Percent | 100.0
rampPostExtinctionFlowChangeRampümeSec | 3
rampPostExtinCtionFlOWChangeH01dSec | 0
burner TemperatureLimitC | 500
b | 24
Aue | 242B
i gq 00 | D
45900
~~~~

### Pagina 7

Cita: [pdf_8cbd23eebfb0ef1a10d4, p. 7]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_8cbd23eebfb0ef1a10d4/p0007.jpg)

~~~~text
testpointName | 19182H1
prelgnitionDataTimeSec
postFlameDataTimeSec | 15
uselPSUs | TRUE
ipsuTimeoutSec | 40
useAcmeCamera | TRUE
uselntensifiedCamera | TRUE
ipsu1ArchiveRate | 2
dataCameraPrelgnitionExposurelJs | 1000000
dataCameralgnition | 150000
dataCameraTestExposureUs | 150000
dataCameraExtinctionExposureUs | 150000
analogCameraPrelgnitionShutter | 2
analogCameralgnitionShutter | 2
analogCameraTestShutter | 2
analogCameraExtinctionShutter
intensifierGainAmplitude | 75000
prelgnitionImageT1meSec
postFIamelmagingTimeSec | 5
useBracketedExposures | TRUE
bracketinglmagesPerExposure | 1
bracketingNumberOfExp0sures | 4
bracketingExposureStartUsec | 50000
bracketingExposureMultiplierTimes100 | 250
igniterlgnitionPosition | 2280
igniterPreheatPowerV | 2.25
igniterPreheatTimeMs | 1000
igniterlgnitionPowerV | 3.75
igniterlgnitionDurationMs | 2500
igniterDelayBeforeRetractMs | 2000
igniterRetractVelocityCountsPerSec | 500
use IgnitionDetection | TRUE
extinctionDetectionStopsTest | TRUE
pmt1Gain | 5
pmt2Gain | 5.25
pmt3Gain | 5.25
fiberIgnitionPosition | 11000
fiberTestPosition | 15300
fiberM0veDuringTest | TRUE
fiberSegmentDistance | 400
fiber Velocity | 500
fiberAcceleration | 1000
fiberDeceleration
fiberHoldDurationSec | 1
fiberCycIes | 100
useFoma | TRUE
flowTimeoutSec | 200
nitrogenPriming1DurationSec
nitrogenPriming2DurationSec | 1
fuelFlowlgnitionDeltaMs | 800
stabilizationTime1Sec
stabilizationTime2Sec | 5
fuel Bottle Ignition FlowRateN2Slpm | 0.078
nitrogenlgnitionFlowRateN2Slpm | 0.312
fuelB0ttleTestFtowRateN2Slpm | 0.078
nitrogenTestFlowRateN2Slpm | 0.312
ignitionToTestRampTimeSec | 0
constantF10wTimeSec | 25
useRampFlowTOZero | FALSE
rampFlowToZeroSec | 10
constantPostExtincti0nDelaySec
constantPostExtinctionFlowChangeFuelPercent | -50.0
constantPostExtinctionFlowChangeN2Percent | -50.0
constantPostExtinctionFtowChangeRampTimeSec | 3
constantPostExtinctionFlowChangeHoldSec
rampPostExtinctionDelaySec
rampPostExtinctionFlowChangeFuelPercent | 100.0
rampPostExtinctionFlowChangeN2Percent | 100.0
ramp PostExtinctionFlowChangeRampTimeSec | 3
rampPostExtinctionFlowChangeHoldSec
burner TemperatureLimitC | 500
burner TemperatureLimitDurationSecs | 3
~~~~

### Pagina 8

Cita: [pdf_8cbd23eebfb0ef1a10d4, p. 8]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_8cbd23eebfb0ef1a10d4/p0008.jpg)

~~~~text
testpointName | 19182J1
preignitionDataTimeSeC
postFlameDataümeSec | 15
usetPSus | TRUE
ipsuTimeoutSec | 40
useAcmeCamera | TRUE
uselntensifiedCamera | TRUE
ipsu1ArchiveRate | 2
dataCameraPrelgnitionExposureUs | 1000000
dataCameralgnitionExposureUs | 100000
dataCameraTestExposurelJs | 100000
dataCameraExtinctionExposureUs | 10
analogCameraprelgnitionShutter | 2
analogCameralgnitionShutter | 2
analogCameraTestShutter | 2
analogCameraExtinctionShutter
intensifierGainAmplitude | 75000
prelgnitionlmageTimeSec
postFlamelmagingTimeSec | 5
useBracketedExposures | TRUE
bracketinglmagesPerExposure | 1
bracketingNumberOfExposures | 4
bracketingExposureStartUsec | 50000
bracketingExposureMultiplierTimes100 | 250
igniterlgnitionPosition | 2280
igniterPreheatPowerV | 2.25
igniterPreheatTimeMs | 1000
igniterlgnitionPowerV | 3.75
igniterlgnitionDurationMs | 2500
igniterDelayBeforeRetractMs | 2000
igniterRetractVelocityC0untsPerSec | 500
useignitionDetection | TRUE
extinctionDetectionStopsTest | TRUE
pmt1Gain | 5
pmt2Gain | 5.25
pmt3Gain | 5.25
fibertgnitionPosition | 11000
fiberTestPosition | 15300
fiberMoveDuringTest | tRUE
fiberSegmentDistance | 400
fiberVeiocity | 500
fiberAcceleration | 1000
fiberDeceleration
fiberH01dDurationSec | 1
fiberCycIes | 100
useFoma | TRUE
flowTimeoutSec | 200
nitrogenPriming1DurationSec
nitrogenPriming2DurationSec | 1
fuelFlowlgnitionDeltaMs | 800
stabilizationTime1Sec
stabilizationTime2Sec
fuelBottlelgnitionFlowRateN2Slpm | 0.078
nitrogenlgnitionFlowRateN2Slpm | 0.117
fuelB0ttleTestFtowRateN2Slpm | .078
nitrogenTestFlowRateN2Slpm | 0.117
ignitlonTOTestRampTimeSec
constantFlowTimeSec | 35
useRampFlowToZero | FALSE
rampFlowTOZeroSec | 10
constantPostExti | Delays ec
constantPostExtinctionFlowChangeFuelPercent | -50.0
constantPostExtinctionF10wChangeN2Percent | -50.0
constantPostExtinctionF10wChangeRampTlmeSec | 3
constantPostExtinctionFlowChangeHoldSec
rampPostExtinctionDetaySec
rampPostExtinctionFlowChangeFuelPercent | 100.0
rampPostExtinctionFlowChangeN2Percent | 100.0
rampPostExtinctionF10wChangeRampTimeSec | 3
rampPostExtinctionFlowChangeH01dSec
burnerTemperatureLimitC | 500
burner TemperatureLimitDurationSecs | 3
~~~~

### Pagina 9

Cita: [pdf_8cbd23eebfb0ef1a10d4, p. 9]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_8cbd23eebfb0ef1a10d4/p0009.jpg)

~~~~text
testpointName | 19182<1
prelgnitionDataTimeSec
postFlameDataTimeSec | 15
uselPSUs | TRUE
ipsuTimeoutSec | 40
useAcmeCamera | TRUE
uselntensifiedCamera | TRUE
ipsu1ArchiveRate | 2
dataCameraPrelgnitionExposureus | 1000000
dataCameralgnitionExposureus | 100000
dataCameraTestExposureUs | 100000
dataCameraExtinctionExpOSurelJs | 00000
analogCameraPreEgnitionShutter | 2
analogCameralgnitionShutter | 2
analogCameraTestShutter | 2
analogCameraExtinctionShutter
intensifierGainAmplitude | 75000
preignitionlmageTimeSec
postFlamelmagingTimeSec | 5
useBracketedExposures | TRUE
bracketinglmagesperExposure | 1
bracketingNumberOfExposures | 4
bracketingExposureStartUsec | 50000
bracketingExposureMultiplierTimes100 | 250
igniterlgnitionPosition | 2260
ign iterPreheatP0werV | 2.25
igniterPreheatTimeMs | 1000
igniterlgnitionPowerV | 3.75
igniterIgnitionDurationMs | 2500
igniterDelayBeforeRetractMs | 2000
igniterRetractVelocityC0untsPerSec | 500
uselgnitionDetection | TRUE
extinctionDetectionStopsTest | TRUE
pmt1GaIn | 5
pmt2Gain | 5.25
pmt3Gain | 5.25
fiberignitionPosition | -11000
fiberTestPosition | 15100
fiberMoveDuringTest | TRUE
fiberSegmentDistance
fiberVetocity | 500
fiberAcceleration | 1000
fiberDeceleration
fiberH01dDurationSec | 1
fiberCycles | 100
useFoma | TRUE
flowTimeoutSec | 200
nitrogenPriming1DurationSec
nitrogenPriming2DurationSec | 1
fuelFlowlgnitionDeltaMs | 300
stabilizationTime1Sec
stabilizationTime2Sec | 5
fuelBotttelgnitionFlowRateN2Slpm
nitrogenlgnitionFlowRateN2Slpm | 0.133
fuelB0ttleTestFlowRateN2Slpm
nitrogenTeStFlOwRateN2Slpm | 0.133
ignitionToTestRampTimeSec
constantFtowTimeSec
useRampFlowToZero | FALSE
rampF10wToZeroSec | 10
constantPostExtinctionDelaySec
constantPostExtinctionFlowChangeFuelPercent | -50.0
constantPostExtinctionFlowChangeN2Percent | -50.0
constantPostExtinctionFIowChangeRampTimeSec | 3
constantPostExtinctionF10wChangeH01dSeC
rampPostExtinctionDelaySec
rampPostExtinctionFlowChangeFuelPercent | 100.0
rampPostExtinctionF10wChangeN2Percent | 100.0
rampPostExtinctionFlowChangeRampTimeSec | 3
rampPostExtinctionFlowChangeH01dSec
burner TemperatureLimitC | 500
burner TemperatureLimitDurationSecs | 3
~~~~

### Pagina 10

Cita: [pdf_8cbd23eebfb0ef1a10d4, p. 10]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_8cbd23eebfb0ef1a10d4/p0010.jpg)

~~~~text
testpointName | 19182L1
preignition DataTimeSec
postFlameDataTimeSec | 15
uselPSUs | TRUE
ipsuTimeoutSec | 40
useAcmeCamera | TRUE
uselntensifiedCamera | TRUE
ipsu1ArchiveRate | 2
dataCameraPrelgnitionExposureUs | 1000000
dataCameralgnitionExposureUS | 100000
dataCameraTestExposureUs | 100000
dataCameraExtinctionExposureUs | 100000
analogCameraPrelgnitionShutter | 2
analogCameralgnitionShutter | 2
analogCameraTestShutter | 2
analogCameraExtinctionShutter
intensifierGainAmplitude | 75000
prelgnitionlmageTimeSec
postFlamelmagingTimeSec | 5
useBracketedExposures | TRUE
bracketinglmagesPerExposure | 1
bracketingNumberOfExposures | 4
bracketingExposureStartUsec | 50000
bracketingExposureMuItiplierTimes100 | 250
igniterlgnitionPosition | 2260
igniterPreheatPowerV | 2.25
igniterPreheatTimeMs | 1000
igniterlgnitionPowerV | 3.75
igniterlgnitionDurationMs | 2500
igniterDelayBeforeRetractMs | 2000
igniterRetractVelocityCountsPerSec | 500
uselgnitionDetection | TRUE
extinctionDetectionStopsTest | TRUE
pmt1Gain | 5
pmt2Gain | 5.25
pmt3Gain | 5.25
fibertgnitionPosition
fiberTestPosition | 15100
fiberMoveDuringTest | TRUE
fiberSegmentDistance
fiberVelocity | 500
fiberAcceleration | 1000
fiberDeceleration
fiberHoldDurationSec | 1
fiberCycles | 100
useFoma | TRUE
flowTimeoutSec | 200
nitrogen Priming1DurationSec
nitrogenPriming2DurationSec | 1
fuelFlowlgnitionDeltaMs | 300
stabilizationTime1Sec
stabilizationTime2Sec | TAS
fuelBottlelgnitionFlowRateN2Slpm
nitrogenlgnitionFlowRateN2Slpm | 0.3
fuelBottleTestFlowRateN2Slpm
nitrogen TestFlowRateN2Slpm | 0.3
ignitionToTestRampTimeSec
constantFlowTimeSec | 120
useRampFlowToZero | FALSE
rampFlowToZeroSec | 10
constantPostExtinctionDelaySec
constantPostExtinctionFlowChangeFuelPercent | -50.0
constantPostExtinctionFlowChangeN2Percent | -50.0
constantPostExtinctionFlowChangeRampTimeSec | 3
constantPostExtinctionFlowChangeHoldSec
rampPostExtinctionDelaySec
rampPostExtinctionFlowChangeFuelPercent | 100.0
rampPostExtinctionFlowChangeN2Percent | 100.0
rampPostExtinctionFlowChangeRampTimeSec | 3
rampPostExtinctionFlowChangeHoldSec
burnerTemperatureLimitC | 500
burnerTemperatureLimitDurationSecs | 3
~~~~

### Pagina 11

Cita: [pdf_8cbd23eebfb0ef1a10d4, p. 11]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_8cbd23eebfb0ef1a10d4/p0011.jpg)

~~~~text
testpointName | 19182M1
preignitionDataTimeSec
postFIameDataTimeSec | 15
usepsus | TRUE
ipsuTimeoutSec | 40
useAcmeCamera | TRUE
uselntensifiedCamera | TRUE
ipsu1ArchiveRate | 2
dataCameraPrelgnitionExposureUS | 1000000
dataCameralgnitionExposureUs | 100000
dataCameraTestExposureUs | 100000
dataCameraExtinctionExposureUs | 100000
analogCameraPrelgnitionShutter | 2
analogCameralgnitiOnShutter | 2
analogCameraTestShutter | 2
analogCameraExtinctionShutter | 0
intensifierGainAmplitude | 75000
prelgnitionlmageTimeSec
postFlamelmagingTimeSec | 5
useBracketedExposures
bracketinglmagesPerExposure | 1
bracketingNumberOfExposures | 4
bracketingExposureStartUsec | 50000
bracketingExposureMultiplierT1mes100 | 250
igniterlgnitionPosition | 2260
igniterPreheatPowerV | 2.25
igniterPreheatTimeMs | 1000
igniterlgnitionPowerV | 3.75
igniter IgnitionDurationMs | 2500
igniterDelayBeforeRetractMs | 2000
igniterRetractVeIocityCountsPerSec | 500
uselgnitionDetection | TRUE
extinctionDetectionStopsTest | TRUE
pmt1Gain | 5
pmt2Gain | 5.25
pmt3Gain | 5.25
fiberlgnitionposition | 11000
fiber TestPosition | 15100
fiberMoveDuringTest | TRUE
fiberSegmentDistance
fiberVelocity | 500
fiberAcceleration | 1000
fiberDeceleration
fiberHoldDurationSec | 1
fiberCycles | 100
useFoma | TRUE
flowTimeoutSec | 200
nitrogenPriming1DurationSec | 0
nitrogenPriming2DurationSec | 1
fuelF10wlgnitionDeltaMs | 300
stabilizationTime1Sec
stabilizationTime2Sec
fuelB0ttlelgnitionFlowRateN2Slpm
nitrogenlgnitionF10wRateN2Slpm | 0.467
fuelBottleTestFlowRateN2Slpm
nitrogen TestFlowRateN2Slpm | 0.467
ignitionTOTestRampTimeSec
constantFiowTimeSec
useRampFlowToZero | FALSE
rampFlowTOZerOSeC | 10
constantP05tExtinctionDelaySec
constantPostExtinctionFtowChangeFuelPercent | -50.0
constantPostExtinctionFlowChangeN2Percent | -50.0
constantPostExtinctionFE0wChangeRampTimeSec | 3
constantPostExtinctionFlowChangeHoldSec
rampPostExtinctionDelaySec | 0
rampPostExtinctionFlowChangeFuelPercent | 100.0
rampPostExtinctionFlowChangeN2Percent | 100.0
rampPostExtinctionF10wChangeRampTlmeSec | 3
rampPostExtinctionFlowChangeHoldSec
burner TemperatureLimitC | 500
burner TemperatureLimitDurationSecs | 3
~~~~
