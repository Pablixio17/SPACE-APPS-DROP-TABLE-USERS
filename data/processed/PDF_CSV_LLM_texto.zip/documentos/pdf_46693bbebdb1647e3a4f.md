# ACME_CSSCI_20140317

- Identificador: pdf_46693bbebdb1647e3a4f
- Investigaciones: PSI-20, PSI-22, PSI-23
- Tipo de documento: Presentations
- Estado: processed
- Temas detectados automaticamente: hardware, soot, microgravity, electric_fields, oxygen, extinction, pressure, ignition, smoke_detection, computational_models, solid_materials, droplets, operations

## Fuentes

- [PSI-20_Presentations_ACME_CSSCI_20140317.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-20/Presentations/PSI-20_Presentations_ACME_CSSCI_20140317.pdf)
- [PSI-22_Presentations_ACME_CSSCI_20140317 - Gaseous Non-Premixed Flame Research Planned for the International Space Station.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-22/Presentations/PSI-22_Presentations_ACME_CSSCI_20140317%20-%20Gaseous%20Non-Premixed%20Flame%20Research%20Planned%20for%20the%20International%20Space%20Station.pdf)
- [PSI-23_Presentations_ACME_CSSCI_20140317.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-23/Presentations/PSI-23_Presentations_ACME_CSSCI_20140317.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_46693bbebdb1647e3a4f, p. 1]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
www.nasa.gov 1
Gaseous Non-Premixed Flame Research
Planned for the International Space Station
Spring Technical Meeting of the 
Central States Section of 
The Combustion Institute 
Mar 16–18, 2014
Dennis P. Stocker1
, Fumiaki Takahashi2
, J. Mark Hickman1
, and Andrew C. Suttles1
1NASA Glenn Research Center, Cleveland, Ohio 44135, USA
2Case Western Reserve University, Cleveland, Ohio 44106, USA
~~~~

### Pagina 2

Cita: [pdf_46693bbebdb1647e3a4f, p. 2]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_46693bbebdb1647e3a4f/p0002.jpg)

~~~~text
National Aeronautics and Space Administration
www.nasa.gov
Outline
• Background
– Why microgravity?
– Gaseous non-premixed 
flames in space
• ACME
– Science
– Hardware
– Status
• Questions
2

[Texto OCR de la imagen]
National Aeronautics and Space Administration
Outline
Background
Why microgravity?
Gaseous non-premixed
flames in space
, ACME
— Science
etional Space
— Hardware
— Status
Questions
Advanced Combustion via Microgravity Experiments
www.nasa.gov 2
~~~~

### Pagina 3

Cita: [pdf_46693bbebdb1647e3a4f, p. 3]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_46693bbebdb1647e3a4f/p0003.jpg)

~~~~text
National Aeronautics and Space Administration
www.nasa.gov
Why Microgravity?
• Effective 
elimination of 
buoyancy and 
buoyancy￾induced flicker
• Spherical flames
• Momentum￾dominated flames 
at low velocities
• Increased length 
scales
• Longer residence 
times - good for 
studies of soot
• Stronger flame 
sensitivity to 
atmosphere
• Studies of limit 
and stability 
behavior, where 
chemical kinetics 
dominate
• Spacecraft fire 
safety
Background > Science > Hardware > Status 3

[Texto OCR de la imagen]
National Aeronautics and Space Administration
Why Microgravity?
Effective
elimination of
buoyancy and
buoyancy-
induced flicker
Spherical flames
Momentum-
dominated flames
at Iow velocities
Increased length
scales
Longer residence
times - good for
studies of soot
Stronger flame
sensitivity to
atmosphere
Studies of limit
and stability
behavior, where
chemical kinetics
dominate
Spacecraft fire
safety
Background > Science > Hardware > Status | www.nasa.gov 3
~~~~

### Pagina 4

Cita: [pdf_46693bbebdb1647e3a4f, p. 4]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
www.nasa.gov
Gaseous Non-premixed Flames in Space
3 space shuttle and 2 ISS experiments thus far
• LSP: Laminar Soot Processes
– PI: G.M. Faeth (U. Michigan)
– Combustion Module
– STS-83 and STS-94 (1997), STS-107 (2003)
• TGDF: Turbulent Gas-jet Diffusion Flames
– PI: M.Y. Bahadori (SAIC)
– Get Away Special Canister (GAS can)
– STS-87 (1997)
• ELF: Enclosed Laminar Flames
– PI: L.-D. Chen (U. Iowa)
– Middeck Glovebox (MGBX)
– STS-87 (1997)
• SPICE: Smoke Point In Coflow Experiment
– PI: D.L. Urban (NASA Glenn) - initially G.M. Faeth
– Microgravity Science Glovebox (MSG)
– ISS Expeditions 18-19, 30 (2009, 2012)
• SLICE: Structure & Liftoff In Combustion Experiment
– PI: M.B. Long (Yale U.)
– Microgravity Science Glovebox (MSG)
– ISS Expedition 30 (2012)
Roger Crouch with CM 4
-1 on STS-83 (top), Michael Barratt with SPICE (bottom)
ISS Space Shuttle
~~~~

### Pagina 5

Cita: [pdf_46693bbebdb1647e3a4f, p. 5]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
www.nasa.gov 5
Advanced Combustion
via Microgravity Experiments
• Conduct 5+ distinct experiments using a single modular insert
for the Combustion Integrated Rack (CIR) on the ISS
– The only existing CIR insert, MDCA, is for the FLEX droplet combustion 
experiments, which have been collectively operating on ISS since 2009
Koichi Wakata with MDCA in CIR (left), ISS (right)
~~~~

### Pagina 6

Cita: [pdf_46693bbebdb1647e3a4f, p. 6]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
www.nasa.gov
5 Current ACME Experiments
11 Investigators and 7 Universities (+ NASA Glenn)
• BRE
– Burning Rate Emulator
– PIs: James G. Quintiere, Peter B. Sunderland (both U. Maryland) 
• CLD Flame
– Coflow Laminar Diffusion Flame
– PIs: Marshall Long, Mitchell Smooke (both Yale U.)
• E-FIELD Flames
– Electric-Field Effects on Laminar Diffusion Flames
– PI: Derek Dunn-Rankin (UC Irvine)
• Flame Design - a novel approach to clean, efficient diffusion flames
– PIs: Richard L. Axelbaum (Washington U. in St. Louis), Beei-Huan 
Chao (U. Hawaii), Peter B. Sunderland (U. Maryland), David L. 
Urban (NASA Glenn)
• s-Flame
– Structure and Response of Spherical Diffusion Flames
– PIs: C.K. Law (Princeton U.), Stephen D. Tse (Rutgers U.), Kurt R. 
Sacksteder (NASA Glenn)
Background > Science > Hardware > Status 6
~~~~

### Pagina 7

Cita: [pdf_46693bbebdb1647e3a4f, p. 7]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
www.nasa.gov 7
BRE
• Burning Rate Emulator
– Jim Quintiere & Peter Sunderland (both U. Maryland)
• Concept
– Flat-plate burner with gaseous fuel flow simulating the 
vaporization and combustion of condensed fuels
– Heat flux to the burner is measured, where the flux 
vaporizes condensed-phase fuels
– Fuels to be simulated include paper, plastic, alcohols
• Goals 
– Quantify the burning and extinction behavior of 
condensed fuels in microgravity
– Quantify the effects of increased O2 concentrations, 
e.g., for exploration atmospheres, on µg combustion.
• Why?
– Spacecraft fire prevention through improved 
assessment for materials selection (currently based on 
1g testing, where flames can exist in µg and not in 1g) 
Background > Science > Hardware > Status
50-mm diam. burner
C2H4 (various flows)
in air at 1 atm 
µg flame 
near end of 5.18 s drop
~~~~

### Pagina 8

Cita: [pdf_46693bbebdb1647e3a4f, p. 8]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
www.nasa.gov 8
CLD Flame
• Coflow Laminar Diffusion Flame
– Marshall B. Long & Mitchell D. Smooke (both Yale U.)
• Concept
– Lifted coflow (2D) flame, so little/no heat loss to burner
• enabling improved modeling of the flame
• Goals 
– Generation of modified kinetic mechanisms for 
hydrocarbon fuels that are able to model effectively 
diffusion flame structure under a larger parameter 
range than existing mechanisms.
– Development of submodels for soot formation that are 
capable of predicting both high and low soot loading 
levels in hydrocarbon flames of various fuels.
• Why?
– Improved design capability through validation of 
combustion models over wider parameter range
Background > Science > Hardware > Status
Attached
100% CH4 
flame on a 
1.6-mm ID 
burner tube, 
with soot 
temperature, 
soot volume 
fraction 
below.
~~~~

### Pagina 9

Cita: [pdf_46693bbebdb1647e3a4f, p. 9]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
www.nasa.gov 9
E-FIELD Flames
• Electric-Field Effects on Laminar Diffusion Flames
– Derek Dunn-Rankin (UC Irvine)
• Concept
– Gas-jet or coflow (2D) flame with high-voltage mesh (up 
to ±10 kV) electrode above (downstream of) burner
• Goal
– Understand chemi-ionization behavior and the resulting 
ion driven winds sufficiently well so that electrical 
properties of flames can be used to characterize (by 
monitoring ion current) and control them (via direct 
chemical or local convective influences).
• Why?
– Advanced control capability enabling improved 
combustion performance
1g, 0 kV, gas-jet
0g, -0.6 kV, gas-jet
0g, 0kv, 24 cm/s coflow
Background > Science > Hardware > Status
~~~~

### Pagina 10

Cita: [pdf_46693bbebdb1647e3a4f, p. 10]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
www.nasa.gov
Flame Design
• A novel approach to clean, efficient diffusion flames
– Rich Axelbaum (Washington U., St. Louis), Beei￾Huan Chao (U. Hawaii), Peter Sunderland (U. 
Maryland), David L. Urban (NASA Glenn)
• Concept
– Spherical (1D) flame, normal and inverse flow config.
• Goals 
– Evaluate the effects of flame structure on soot 
inception and flame extinction
– Obtain a correlation of sooting limits with 
stoichiometric mixture fraction, Zst, and adiabatic 
temperature, Tad
– Determine the importance of gas-phase oxidation on 
soot inception for high Zst flames
– Demonstrate the existence of steady spherical flames
– Identify pseudo-flammability limits for diffusion flames 
in terms of Zst and Tad
• Why?
– To reduce soot and NOx through nitrogen exchange
Background > Science > Hardware > Status
18% 
C2H4 
into
27%
O2
18%
C2H4 
Into
28%
O2
100% 
O2
into 
12%
C2H4 
100%
O2 
into
13% 
C2H4 
Inverse flames Normal flames
10
~~~~

### Pagina 11

Cita: [pdf_46693bbebdb1647e3a4f, p. 11]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
www.nasa.gov 11
s-Flame
• Structure and Response of Spherical Diffusion Flames
– C.K. Law (Princeton U.), Stephen D. Tse (Rutgers U.), Kurt R. 
Sacksteder (NASA Glenn)
• Concept
– Spherical (1D) flame stabilized on a porous burner
• Goals
– Use spherical diffusion flames in ISS environment to:
• obtain experimental data in simple, well-defined flow fields
• understand various key elemental diffusion flame processes
– Characterize transient structure, determine extinction limits, and 
check existence of theoretically predicted pulsating instabilities. 
– Validate and improve accuracy of computational simulation 
including detailed chemistry and transport
• Why?
– Improvements in the design of practical, high-efficiency, low￾emission combustion systems on Earth
flame 
evolution 
with time
Background > Science > Hardware > Status
~~~~

### Pagina 12

Cita: [pdf_46693bbebdb1647e3a4f, p. 12]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
www.nasa.gov
ACME Approach
• ACME is not a technology demonstration, but is 
seeking to improve life on Earth via the path below.
12
Improved understanding of 
combustion fundamentals
Improved numerical models 
of combustion processes
Improved design tools
Improved practical 
combustion devices
ACME
from
ACME
Background > Science > Hardware > Status
Numerical prediction of flame structure [Yale U.]
~~~~

### Pagina 13

Cita: [pdf_46693bbebdb1647e3a4f, p. 13]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
www.nasa.gov
Similarities of Current Experiments
• Gaseous flame
– fuel is a gas, e.g., methane and ethylene
• Non-premixed (i.e., diffusion), flame
– fuel and oxidizer (e.g., air) are on opposite sides of 
the reaction sheet 
– but premixed flames can be studied with ACME
• Laminar flame
– flow is smooth and not turbulent (i.e., w/o vortices)
– but turbulent flames can be studied with ACME
• 1D or 2D flame
– but 3D flames can be studied with ACME
13
F
O2
O2
O2 O2
O2
F
F F
F
Normal flame Inverse flame
Background > Science > Hardware > Status
~~~~

### Pagina 14

Cita: [pdf_46693bbebdb1647e3a4f, p. 14]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
www.nasa.gov 14
ACME Hardware
avionics package
digital 
color 
camera
Background > Science > Hardware > Status
modular insert
burners
gas bottles and filters
~~~~

### Pagina 15

Cita: [pdf_46693bbebdb1647e3a4f, p. 15]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_46693bbebdb1647e3a4f/p0015.jpg)

~~~~text
National Aeronautics and Space Administration
Photomultiplier Tube (PMT) array Ss
Thermocouple rakes
s
3 Mass Flow
Controllers
(MFCs)
Camera, color, analog
Radiometer array, linear
Electrode, mesh
Igniter, hot-wire, retracting
Burner
Background > Science > Hardware > Status | www.nasa.gov 15
~~~~

### Pagina 16

Cita: [pdf_46693bbebdb1647e3a4f, p. 16]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_46693bbebdb1647e3a4f/p0016.jpg)

~~~~text
National Aeronautics and Space Administration
www.nasa.gov
• Delivers 3 gases from CIR to 
the chamber or burner
• fuel (2 slpm max, N2 basis)
• oxygen/inert mix or diluent 
(e.g., He or CO2)
• nitrogen (from ISS)
• Mass flow controllers (crew 
swappable to vary flow ranges)
Gas Flow System
Background > Science > Hardware > Status 16

[Texto OCR de la imagen]
National Aeronautics and Space Administration
Oxygen Manifold 2 | Delivers 3 | from CIR to
gases
Static
Diluent Manifold 1 | the chamber | burner
Mixer | or
anifold #3 Gas Bottle Line Not Used
ISS Nafrom GIS
ypass Li | • | fuel | N2
(2 slpm max, | basis)
Fuel Manifold 4
CIR FOMA | • | oxygen/inert mix or diluent
QD13 | OD12 | QD11
(e.g., He or C02)
Interface R | rce Ring ORR)
• | nitrogen (from ISS)
QD A1 | QD A4
ACME
FLOW System | Mass flow controllers
(crew
QD A8
QD A9 | swappable to | flow ranges)
vary
MFC A1 | MFC A2 | MFC A3
SV Al | SV A2 | SV A3
to | to | to
Chamber | Chamber | Chamber
SV A4 | SV A5 | SV A6 | SV A7 | SV A8 | SV A9
To Outer Coflow
To Inner Coflow
To Gas-Jet Burner
To Spherical Burner
Background > Science > Hardware > Status | www.nasa.gov 16
~~~~

### Pagina 17

Cita: [pdf_46693bbebdb1647e3a4f, p. 17]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
www.nasa.gov
Burners & Igniter
• Four types of burners are planned for the first 5 experiments:
• gas-jet burners (7) 0.4, 0.8, 1.3, 1.6, 2.1, 2.7 and 3.2 mm ID
• spherical burners (3) 0.25, 0.375, 0.5 inch diameter, porous sintered metal
• coflow burner (1) 2.1-mm ID inner tube, 25-mm ID outer tube 
• BRE burners (2) 25, 50 mm diameter, porous (w/ 2 heat flux transducers each)
• Thermocouple for surface temperature on most burners
• Burners will generally be electrically isolated
• Hot-wire igniter, retracting, similar to that in use for MDCA
• Igniter tips are replaceable, e.g., to match the burner type/size
Background > Science > Hardware > Status
Gas-jet, spherical, coflow, and BRE burners (left to right)
Igniter, hot-wire
17
~~~~

### Pagina 18

Cita: [pdf_46693bbebdb1647e3a4f, p. 18]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
www.nasa.gov
Electric Field
• ±10kV at copper mesh above (i.e., 
downstream of) isolated burner
• Ion current through flame is 
determined from Ohm’s law (I=V/R) 
and measurement of the voltage 
difference across a shunt resistor 
(in series with the flame)
• copper mesh screen (removable)
• high-voltage source (removable)
• passive electronics (fixed)
H.V.
Chamber
Nozzle
Mesh 
electrode
Shunt for current 
measurement, Rs
Low voltage input, e.g., 0-24VDC
Gas supply 
tubes
Insulator
Coflow burner 
with flame
Electrode mesh
Background > Science > Hardware > Status 18
~~~~

### Pagina 19

Cita: [pdf_46693bbebdb1647e3a4f, p. 19]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
www.nasa.gov 19
Basic Imaging
• Color Imaging for Ops
– Analog color camera 
(removable) with 45-degree 
turning mirror
– LEDs for optional illumination
• Color Imaging for Data
– Digital GigE color camera, 1.4 
megapixel, 12 bit, 30 fps with 
motorized control of zoom, 
iris, and focus
– 3 optional filters including a 
blue-green BG-7 filter (to 
balance light intensity for 
pyrometry), 430 and 450-nm 
for CH* (incl. soot subtraction)
• Ultraviolet (UV) Imaging
– Existing LLL-UV camera 
equipped with a 310-nm filter 
for imaging OH*
– Field of view (FOV) options: 
50-mm and 80-mm diameter
Background > Science > Hardware > Status
Color 
Camera
Motorized
Zoom Lens
Electronics
Enclosure
45° Fold
Mirror
Filters
(swap via 
rotating 
barrel)
~~~~

### Pagina 20

Cita: [pdf_46693bbebdb1647e3a4f, p. 20]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
www.nasa.gov 20
Advanced Imaging
• Pyrometry for Hot Sooty and 
Soot-Free Regions
– Determine temperature distribution from 
broadband thermal radiation, where the 
spectrum is indicative of the temp. using 
(1) GigE camera and/or (2) HiBMs 
camera with a liquid-crystal tunable filter.
– Thin-Filament Pyrometry (TFP) to 
determine temperature profiles from the 
broadband thermal radiation. Array of 
15-micron oxidized SiC fibers stretched 
across the flame with motor to allow for 
scanning or removal of the fibers from 
the flame. Alternate array includes a Pt 
wire for absolute light calibration.
– HiBMs FOV options: 30 and 50-mm dia.
• Soot Volume Fraction
– Via (1) GigE camera or (2) CIR 
illumination package (using a 653-nm 
laser diode) and a second HiBMs camera
– HiBMs FOV options: 30, 50, and 90-mm 
diameter
TFP Soot vol. fraction HiBMs camera
Soot pyrometry
Background > Science > Hardware > Status
High Bit-depth Multi-spectral (HiBMs)
~~~~

### Pagina 21

Cita: [pdf_46693bbebdb1647e3a4f, p. 21]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
www.nasa.gov
Emission Measurements
• Photomultiplier Tubes (PMTs)
• Broadband, OH*, CH* (3 total)
• Radiometers (up to 6 total)
• Broadband thermal radiation via 
thermopile detectors
• Wide and/or narrow angle FOVs
• One fixed detector
• An exchangeable array with 2 
current options
• std. array with 5 sensors
• BRE array with 3 sensors
Background > Science > Hardware > Status
BRE Radiometer Array
-10 Offset
+30 Offset
+60 Offset ~27° = 70 mm FOV
~27° = 70 mm FOV
~27° = 70 mm FOV
Use knife-edge at the radiometer housing to 
block the burner from being “seen”
Center
120mm FOV
30 mm Offset
2mm Spot
-30 mm Offset
2mm Spot
60 mm Offset
2mm Spot
-60 mm Offset
2mm Spot
~47° = 120 mm FOV
ACME Radiometer Array
21
~~~~

### Pagina 22

Cita: [pdf_46693bbebdb1647e3a4f, p. 22]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
www.nasa.gov
Optical 
Layout
1
5
3 7
Radiometers
Color
Camera
Single
IPSU
LLL-UV
Stacked 
2 IPSUs
Illumination
HiBMs (1 & 2)
PMT
Analog
Background > Science > Hardware > Status
GigE Gigabit Ethernet (color camera)
HiBMs High Bit-depth Multi-spectral camera
IPSU Image Processing and Storage Unit
LLL-UV Low Light Level Ultraviolet camera
PMT Photomultiplier Tube module
R Radiometers
22
~~~~

### Pagina 23

Cita: [pdf_46693bbebdb1647e3a4f, p. 23]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
www.nasa.gov 23
Additional Diagnostics
• Heat flux (BRE burners, on & off axis)
• Temperature
– Burner surface (with 0-2 TCs)
– Far-field gas phase
• 2 fixed thermocouples (TCs)
• rake with 4 TCs is crew removable or 
swappable for different TC positions
• Ion current (electric field tests only)
• Pre- & post-test gas composition
– via gas chromatograph
– e.g., CO, CO2, CH4, C2H2, C2H4, 
N2, O2
MDCA and CIR
Thermocouple 
rake and 2 fixed 
thermocouples
~~~~

### Pagina 24

Cita: [pdf_46693bbebdb1647e3a4f, p. 24]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_46693bbebdb1647e3a4f/p0024.jpg)

~~~~text
National Aeronautics and Space Administration
www.nasa.gov 24
Monitoring Measurements
• Chamber pressure
• Gas flow rates
• Burner pressure differential
– for porous burners
• Electrical potential
– for tests with the electric field
• Acceleration
– i.e., effective gravity
These measurements are required to 
verify boundary & initial conditions and 
thus enable modeling and analysis.
Michael Barratt with MDCA in CIR

[Texto OCR de la imagen]
National Aeronautics and Space Administration
Monitoring Measurements
Chamber pressure
Gas flow rates
Burner pressure differential
for porous burners
Electrical potential
for tests with the electric field
Acceleration
i.e., effective gravity
These measurements are required to
verify boundary & initial conditions and
thus enable modeling and analysis.
Michael Barratt with MDCA in CIR | www.nasa.gov 24
~~~~

### Pagina 25

Cita: [pdf_46693bbebdb1647e3a4f, p. 25]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
www.nasa.gov 25
Nominal Operational Sequence
• Flow > Ignite > Measure > Extinguish 
– Initiate burner flows at ignition condition 
– Ignite flame
• Wait for flame to stabilize
– If needed, adjust flow(s) to initial test condition 
• Wait for flame to stabilize
– If desired:
• increase or decrease burner flow(s)
– to vary flow/velocity or concentration
• activate and adjust electric field
• translate TFP array
– Stop burner flows
• per extinction detection, test duration, etc.
• Ops control can be automated or “manual”
– Ground control, not astronaut operated
Nicole Stott with CIR
~~~~

### Pagina 26

Cita: [pdf_46693bbebdb1647e3a4f, p. 26]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
www.nasa.gov 26
ACME Status
• Schedule
• 2013 Critical Design Review (CDR)
• 2014 (now) completion of detailed design for spaceflight hardware
assembly of engineering models
fabrication of spaceflight hardware
• 2016-2019 ISS ops
Mike Fossum with CIR (left), Satoshi Furukawa with CIR (right)
~~~~

### Pagina 27

Cita: [pdf_46693bbebdb1647e3a4f, p. 27]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_46693bbebdb1647e3a4f/p0027.jpg)

~~~~text
National Aeronautics and Space Administration
Mike Fossum with MDCA in CIR | www.nasa.gov 27
~~~~

### Pagina 28

Cita: [pdf_46693bbebdb1647e3a4f, p. 28]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
www.nasa.gov 28
Acknowledgements
• Investigators (7 universities and NASA Glenn)
• Richard L. Axelbaum, Beei-Huan Chao, Derek Dunn-Rankin, C.K. 
Law, Marshall B. Long, James G. Quintiere, Kurt R. Sacksteder, 
Mitchell D. Smooke, Peter B. Sunderland, Stephen D. Tse, David L. 
Urban
• NASA Glenn
• ISS Research Program Manager Fred Kohl
• ISS Research Project Manager Tom St. Onge
• R&T: Microgravity Combustion David Urban
• Microgravity Facilities Manager Eric Neumann
• Universities Space Research Association
• Imaging Jay Owens
• ZIN Technologies, Inc.
• ACME Lead Brian Borowski
• Diagnostics Steve Lawn
• Electrical/Electronics Tim Gobeli
• Mechanical Adrian Drake
• Software Mike Medved
• Systems Chris Mroczka
~~~~

### Pagina 29

Cita: [pdf_46693bbebdb1647e3a4f, p. 29]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, sparse_text_or_visual_only, tiled_ocr_not_manually_verified.

[Imagen de la pagina](../imagenes/pdf_46693bbebdb1647e3a4f/p0029.jpg)

~~~~text
National Aeronautics and Space Administration
BACKUP
www.nasa.gov 29
~~~~

### Pagina 30

Cita: [pdf_46693bbebdb1647e3a4f, p. 30]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
www.nasa.gov
Why Study Combustion?
• Energy
– While we might associate fire with the Stone Age, we still make 
extensive use of combustion in our daily lives.
• Electricity – about 70% in the U.S. from combustion
• Heating of buildings, water, food, and in manufacturing processes
• Transportation
– Our reliance on imported fuel contributes to our national trade 
deficit and affects our national security.
• Environment
– Combustion is a source of greenhouse gases.
– Soot contributes to global warming and is a health problem.
• Fire Safety
Given its pervasive use with annual U.S. fuel costs on the order 
of a trillion dollars even small improvements in combustion 
technology can significantly reduce fuel needs and 
pollution production!
Background > Science > Hardware > Status 30
~~~~
