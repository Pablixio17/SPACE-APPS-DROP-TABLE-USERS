# FLEX-1213_Summary

- Identificador: pdf_f719bf08c3d3f75ca5c9
- Investigaciones: PSI-39
- Tipo de documento: Analyzed Data
- Estado: processed
- Temas detectados automaticamente: oxygen, cool_flames, droplets

## Fuentes

- [PSI-39_Analyzed Data_FLEX-1213_Summary.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-39/Analyzed%20Data/PSI-39_Analyzed%20Data_FLEX-1213_Summary.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_f719bf08c3d3f75ca5c9, p. 1]. Metodo: native.

~~~~text
1.0
0.8
0.6
0.4
0.2
0.0
( D / D0 )2
0.0 0.5 1.0 1.5 2.0 2.5 3.0
t / D
0
2
 ( s / mm
2
 )
20
15
1050
Df ( mm ) , Df / Dd
14
12
1086420
Df, cool ( mm )
450
400
350
300
250
Peak Cool Flame Grayscale
8
0.1
2468
1
2468
10
Flame Radiance ( W )
Mon, Mar 27, 2017
FLEX-1213
F086A04
P = 772.131 mmHg YO2 = 0.210 YN2 = 0.790 YCO2 = 0.000 YHe = 0.000
Dodecane D0 = 4.189 mm Dext = 4.113 mm kavg = 0.189 mm
2
/sec
 Droplet History
 Hot-Flame Diameter
 Hot-Flame FSR
 Cool Flame Diameter (FWHM)
 Cool Flame Diameter (peak-peak) 
 Cool Flame Grayscale
 Flame Radiance (wideband)
 Flame Radiance (narrowband)
~~~~
