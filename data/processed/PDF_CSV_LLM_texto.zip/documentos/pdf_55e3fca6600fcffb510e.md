# 19137 test parameter notes

- Identificador: pdf_55e3fca6600fcffb510e
- Investigaciones: PSI-10
- Tipo de documento: Raw Data
- Estado: processed
- Temas detectados automaticamente: ignition, extinction, hardware, operations

## Fuentes

- [PSI-10_Raw Data_19137 test parameter notes.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-10/Raw%20Data/PSI-10_Raw%20Data_19137%20test%20parameter%20notes.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_55e3fca6600fcffb510e, p. 1]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_55e3fca6600fcffb510e/p0001.jpg)

~~~~text
testpointName 9137A1
preignitionDataTimeSec
postFlameDataTimeSec 15
uselPSUs TRUE
ipsuTimeoutSec 40
useAcmeCamera TRUE
uselntensifiedCamera TRUE
ipsu1ArchiveRate | 2
dataCameraPrelgnitionExposureUs 100000
dataCameralgnitionExposureUs 100000
dataCameraTestExposureUs 1300000
dataCameraExtinctionExposureUs 650000
analogCameraPrelgnitionShutter | 2
analogCameralgnitionShutter | 2
analogCameraTestShutter | 2
analogCameraExtinctionShutter
intensifierGainAmplitude 50000
prelgnitionlmageTimeSec
postFlamelmagingTimeSec | 5
useBracketedExposures TRUE
bracketinglmagesPerExposure | 1
bracketingNumberOfExposures | 3
bracketingExposureStartUsec 80000
bracketingExposureMuItiplierTimes100 500
igniter'gnitionposition 2250
igniterPreheatPowerV 2.25
igniterPreheatTimeMs 1000
igniterlgnitionPowerV 3.75
igniterlgnitionDurationMs 2500
igniterDelayBeforeRetractMs 2000
igniterRetractVelocityCountsPerSec 500
uselgnitionDetection TRUE
extinctionDetectionStopsTest TRUE
pmt1Gain | 5
pmt2Gain 5.25
pmt3Gain 5.25
fiberIgnitionPosition 10000
fiberTestPosition 15300
fiberMoveDuringTest TRUE
fiberSegmentDistance 400
fiberVelocity 500
fiberAcceleration 1000
fiberDeceleration
fiberHoldDurationSec | 1
fiberCycles 100
useFoma TRUE
flowTimeoutSec
nitrogenPriming1DurationSec
nitrogenPriming2DurationSec
fuetFlowlgnitionDeltaMs
stabilizationTime1Sec
stabilizationTime2Sec | 3
fuelBottlelgnitionFlowRateN2Slpm
nitrogenlgnitionFlowRateN2Slpm
fuelBottleTestFlowRateN2Slpm
nitrogenTestFlowRateN2Slpm
ignitionToTestRampTimeSec
constantFlowTimeSec
useRampFlowToZero TRUE
rampFlowToZeroSec 30
constantPostExtinctionDelaySec
constantPostExtinctionFlowChangeFuelPercent -50.0
constantPostExtinctionFlowChangeN2Percent -50.0
constantPostExtinctionFlowChangeRampTimeSec | 3
constantPostExtinctionFlowChangeHoldSec | 2
rampPostExtinctionDeIaySec
rampPostExtinctionFlowChangeFuelPercent 50.0
rampPostExtinctionFlowChangeN2Percent 50.0
rampPostExtinctionFlowChangeRampTimeSec | 3
rampPostExtinctionFlowChangeHoldSec | 2
~~~~

### Pagina 2

Cita: [pdf_55e3fca6600fcffb510e, p. 2]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_55e3fca6600fcffb510e/p0002.jpg)

~~~~text
testpointName | 1913781
prelgnitionDataTimeSec
postFlameDataTimeSec | 15
uselPSUs | TRUE
ipsuTimeoutSec | 40
useAcmeCamera | TRUE
uselntensifiedCamera | TRUE
ipsu1ArchiveRate | 2
dataCameraprelgnitionExposureUs | 100000
dataCameralgnitionExposureUs | 100000
dataCameraTestExposureUs | 1300000
dataCameraExtinctionExposureUs | 650000
analogCameraPrelgnitionShutter | 2
analogCameralgnitionShutter | 2
analogCameraTestShutter | 2
analogCameraExtinctionShutter
intensifierGainAmplitude | 50000
preignitionlmageTimeSec
postFlamelmagingTimeSec | 5
useBracketedExposures | TRUE
bracketinglmagesPerExposure | 1
bracketingNumberOfExposures | 3
bracketingExposureStartUsec | 80000
bracketingExposureMultiplierTimes100 | 500
ignitertgnitionposition | 2250
igniterPreheatPowerV | 2.25
igniterPreheatTimeMs | 1000
igniterlgnitionPowerV | 3.75
igniterlgnitionDurationMs | 2500
igniterDelayBeforeRetractMs | 2000
igniterRetractVelocityCountsPerSec | 500
uselgnitionDetection | TRUE
extinctionDetectionStopsTest | TRUE
pmt1Gain | 5
pmt2Gain | 5.25
pmt3Gain | 5.25
fiberlgnitionPosition | 10000
fiberTestPosition | 15300
fiberMoveDuringTest | TRUE
fiberSegmentDistance | 400
fiberVelocity | 500
fiberAcceleration | 1000
fiberDeceleration
fiberHoldDurationSec | 1
fiberCycles | 100
useFoma | TRUE
flowTjmeoutSec
nitrogenPriming1DurationSec
nitrogenPriming2DurationSec
fuelFlowlgnitionDeltaMs
stabilizationTime1Sec
stabilizationTime2Sec | 3
fuelBottlelgnitionFlowRateN2Slpm
nitrogenlgnitionFlowRateN2Slpm | 0.103
fuelBottleTestFlowRateN2Slpm
nitrogenTestFlowRateN2Slpm | 0.1 3
ignitionToTestRampTimeSec
constantFlowTimeSec
useRampFlowToZero | TRUE
rampFlowToZeroSec | 30
constantPostExtinctionDelaySec
constantPostExtinctionFlowChangeFuelpercent | -50.0
constantPostExtinctionFlowChangeN2Percent | -50.0
constantPostExtinctionFlowChangeRampTimeSec | 3
constantPostExtinctionFlowChangeHoldSec | 2
rampPostExtinctionDelaySec
rampPostExtinctionFlowChangeFuelPercent | 50.0
rampPostExtinctionFlowChangeN2Percent | 50.0
rampPostExtinctionFlowChangeRampTimeSec | 3
rampPostExtinctionFlowChangeHoldSec | 2
~~~~

### Pagina 3

Cita: [pdf_55e3fca6600fcffb510e, p. 3]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_55e3fca6600fcffb510e/p0003.jpg)

~~~~text
testpointName | 19137C1
prelgnitionDataTimeSec
postFlameDataTimeSec | 15
uselPSUs | TRUE
ipsuTimeoutSec | 40
useAcmeCamera | TRUE
uselntensifiedCamera | TRUE
ipsu1ArchiveRate | 2
dataCameraPrelgnitionExposureus | 100000
dataCameralgnitionExposureUs | 100000
dataCameraTestExposureUs | 13tx»ooo
dataCameraExtinctionExposureUs | 650000
analogCameraPrelgnitionShutter | 2
analogCameralgnitionShutter | 2
analogCameraTestShutter | 2
analogCameraExtinctionShutter
intensifierGainAmplitude | 50000
prelgnitionlmageTimeSec
postFlamelmagingTimeSec | 5
useBracketedExposures | TRUE
bracketinglmagesperExposure | 1
bracketingNumberOfExposures | 3
bracketi ngExposureStartUsec | 80000
bracketingExposureMultiplierTimes100 | 500
igniterlgnitionPosition | 2250
igniterPreheatPowerV | 2.25
igniterPreheatTimeMs | 1000
igniterlgnitionPowerV | 3.75
igniterlgnitionDurationMs | 2500
igniterDelayBeforeRetractMs | 2000
igniterRetractVelocityCountsPerSec | 500
uselgnitionDetection | TRUE
extinctionDetectionStopsTest | TRUE
pmt1Gain | 5
pmt2Gain | 5.25
pmt3Gain | 5.25
fiberlgnitionposition | 10000
fiberTestPosition | 15300
fiberMoveDuringTest | *TRUE
fiberSegmentDistance | 400
fiberVelocity | 500
fiberAcceleration | 1000
fiberDeceleration
fiberHoldDurationSec | 1
fiberCycles | 100
useFoma | TRUE
flowTimeoutSec
nitrogenPriming1DurationSec
nitrogenPriming2DurationSec
fuelFlowlgnitionDeltaMs
stabilizationTime1Sec
stabilizationTime2Sec | 3
fuelBottlelgnitionFlowRateN2Slpm
nitrogenlgnitionFlowRateN2Slpm | 0.233
fuelBottleTestFlowRateN2Slpm
nitrogenTestFlowRateN2Slpm | 0.233
ignitionToTestRampTimeSec
constantFlowTimeSec
useRampFlowToZero | TRUE
rampFlowToZeroSec | 30
constantPostExtinctionDelaySec
constantPostExtinctionFlowChangeFuelPercent | -50.0
constantPostExtinctionFlowChangeN2Percent | -50.0
constantPostExtinctionFlowChangeRampTimeSec | 3
constantPostExtinctionFlowChangeHoldSec | 2
rampPostExtinctionDelaySec
rampPostExtinctionFlowChangeFuelPercent | 50.0
rampPostExtinctionFlowChangeN2Percent | 50.0
rampPostExtinctionFlowChangeRampTimeSec | 3
rampPostExtinctionFlowChangeHoldSec | 2
~~~~

### Pagina 4

Cita: [pdf_55e3fca6600fcffb510e, p. 4]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_55e3fca6600fcffb510e/p0004.jpg)

~~~~text
testpointName | 1913701
prelgnitionDataTimeSec
postFlameDataTimeSec | 15
uselPSUs | TRUE
ipsuTimeoutSec | 40
useAcmeCamera | TRUE
uselntensifiedCamera | TRUE
ipsu1ArchiveRate | 2
dataCameraPrelgnitionExposureUs | 100000
dataCameralgnitionExposureUs | 100000
dataCameraTestExposureUs
dataCameraExtinctionExposureUs | 650000
analogCameraPrelgnitionShutter | 2
analogCameralgnitionShutter | 2
analogCameraTestShutter | 2
analogCameraExtinctionShutter
intensifierGainAmplitude | 50000
prelgnitionlmageTimeSec
postFlamelmagingTimeSec | 5
useBracketedExposures | TRUE
bracketinglmagesperExposure | 1
bracketingNumberOfExposures | 3
bracketingExposureStartUsec | 80000
bracketingExposureMultiplierTimes100 | 500
igniterlgnitionPosition | 2250
igniterPreheatPowerV | 2.25
igniterPreheatTimeMs | 1000
igniterlgnitionPowerV | 3.75
igniterlgnitionDurationMs | 2500
igniterDelayBeforeRetractMs | 2000
igniterRetractVelocityCountsPerSec | 500
uselgnitionDetection | TRUE
extinctionDetectionStopsTest | TRUE
pmt1Gain | 5
pmt2Gain | 5.25
pmt3Gain | 5.25
fiberlgnitionposition | 10000
fiberTestPosition | 15300
fiberMoveDuringTest | TRUE
fiberSegmentDistance | 400
fiberVelocity | 500
fiberAcceleration | 1000
fiberDeceleration
fiberHoldDurationSec | 1
fiberCycles | 100
useFoma | TRUE
flowTimeoutSec
nitrogenPriming1DurationSec
nitrogenPriming2DurationSec
fuelFlowlgnitionDeltaMs
stabilizationTime1Sec
stabilizationTime2Sec
fuelBottlelgnitionFlowRateN2Slpm | 5
nitrogenlgnitionFlowRateN2Slpm | 0.362
fuelBottleTestFlowRateN2Slpm | o,
nitrogenTestFlowRateN2Slpm | 0.362
ignitionToTestRampTimeSec
constantFlowTimeSec
useRampFlowToZero | TRUE
rampFlowToZeroSec | 30
constantPostExtinctionDelaySec
constantPostExtinctionFlowChangeFuelPercent | -50.0
constantPostExtinctionFlowChangeN2Percent | -50.0
constantPostExtinctionFlowChangeRampTimeSec | 3
constantPostExtinctionFlowChangeHoldSec | 2
rampPostExtinctionDelaySec
rampPostExtinctionFlowChangeFuelPercent | 50.0
rampPostExtinctionFlowChangeN2Percent | 50.0
rampPostExtinctionFlowChangeRampTimeSec | 3
rampPostExtinctionFlowChangeHoldSec | 2
~~~~

### Pagina 5

Cita: [pdf_55e3fca6600fcffb510e, p. 5]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_55e3fca6600fcffb510e/p0005.jpg)

~~~~text
testpointName | 19137F1
prelgnitionDataTimeSec
postFlameDataTimeSec | 15
use] PSUs | TRUE
ipsuTimeoutSec | 40
useAcmeCamera | TRUE
uselntensifiedCamera | TRUE
ipsu1ArchiveRate | 2
dataCameraPrelgnitionExposureUs | 100000
dataCameralgnitionExposureUs | 100000
dataCameraTestExposureUs | 1300000
dataCameraExtinctionExposurelJs | 650000
analogCameraPrelgnitionShutter | 2
analogCameralgnitionShutter | 2
a nalogCameraTestSh utter | 2
analogCameraExtinctionShutter
intensifierGainAmplitude | 50000
prelgnitionlmageTimeSec
postFlamelmagingTimeSec | 5
useBracketedExposures | TRUE
bracketinglmagesPerExposure | 1
bracketingNumberOfExposures | 3
bracketi ngExposureSta rtUsec | 80000
bracketingExposureMultiplierTimes100 | 500
igniterlgnitionposition | 2250
igniterPreheatPowerV | 2.25
igniterPreheatTimeMs | 1000
igniterlgnitionPowerV | 3.75
igniterlgnitionDurationMs | 2500
igniterDelayBeforeRetractMs | 2000
igniterRetractVelocityCountsPerSec | 500
uselgnitionDetection | TRUE
extinctionDetectionStopsTest | TRUE
pmt1Gain | 5
pmt2Gain | 5.25
pmt3Gain | 5.25
fiberlgnitionposition
fiberTestPosition | 15300
fiberMoveDuringTest | TRUE
fiberSegmentDistance | 400
fiberVelocity | 500
fiberAcceleration | 1000
fiberDeceleration
fiberHoldDurationSec | 1
fiberCycles | 100
useFoma | TRUE
flowTimeoutSec
nitrogenPriming1DurationSec
nitrogenPriming2DurationSec
fuelFlowlgnitionDeltaMs
stabilizationTime1Sec
stabilizationTime2Sec
fuelBottlelgnitionFlowRateN2Slpm
nitrogenlgnitionFlowRateN2Slpm | 0.465
fuelBottleTestFlowRateN2Slpm
nitrogenTestFlowRateN2Slpm | 0455
ignitionToTestRampTi meSec
constantFlowTimeSec
useRampFlowToZero | TRUE
rampFlowToZeroSec | 30
constantPostExtinctionDelaySec
constantPostExtinctionFlowChangeFuelPercent | -50.0
constantPostExtinctionFlowChangeN2Percent | -50.0
constantPostExtinctionFlowChangeRampTimeSec | 3
constantPostExtinctionFlowChangeHoldSec | 2
rampPostExtinctionDelaySec
rampPostExtinctionFlowChangeFuelPercent | 50.0
rampPostExtinctionFlowChangeN2Percent | 50.0
rampPostExtinctionFIowChangeRampTimeSec | 3
rampPostExtinctionFlowChangeHoldSec | 2
~~~~

### Pagina 6

Cita: [pdf_55e3fca6600fcffb510e, p. 6]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_55e3fca6600fcffb510e/p0006.jpg)

~~~~text
testpointName | 1913761
prelgnitionDataTimeSec
postFlameDataTimeSec | 15
uselPSUs | TRUE
ipsuTimeoutSec | 40
useAcmeCamera | TRUE
uselntensifiedCamera | TRUE
ipsu1ArchiveRate | 2
dataCameraPrelgnitionExposureUs | 100000
dataCameralgnitionExposureUs | 100000
dataCameraTestExposureUs | 1300000
dataCameraExtinctionExposureUs | 650000
analogCameraPrelgnitionShutter | 2
analogCameralgnitionShutter | 2
analogCameraTestShutter | 2
analogCameraExtinctionShutter
intensifierGainAmplitude | 50000
preignitionlmageTimeSec
postFlamelmagingTimeSec | 5
useBracketedExposures | TRUE
bracketinglmagesPerExposure | 1
bracketingNumberOfExposures | 3
bracketingExposureStartUsec | 80000
bracketingExposureMuItiplierTimes100 | 500
igniterlgnitionPosition | 2250
igniterPreheatPowerV | 2.25
igniterPreheatTimeMs | 1000
igniterlgnitionPowerV | 3.75
igniterlgnitionDurationMs | 2500
igniterDelayBeforeRetractMs | 2000
igniterRetractVelocityCountsPerSec | 500
uselgnitionDetection | TRUE
extinctionDetectionStopsTest | TRUE
pmt1Gain | 5
pmt2Gain | 5.25
pmt3Gain | 5.25
fiberlgnitionposition
fiber Testposition
fiberMoveDuringTest
fiberSegmentDistance | 400
fiberVelocity | 500
fiberAcceleration | 1000
fiberDeceleration
fiberHoldDurationSec | 1
fiberCycles | 100
useFoma | TRUE
flowTimeoutSec | 80
nitrogenPriming1DurationSec
nitrogenPriming2DurationSec | 0
fuelFlowlgnitionDeltaMs
stabilizationTime1Sec
stabilizationTime2Sec
fuelBottlelgnitionFlowRateN2Slpm | 0.13
nitrogenlgnitionFlowRateN2Slpm
fuelBottleTestFlowRateN2Slpm | 0-13
nitrogenTestFlowRateN2Slpm
ignitionToTestRampTimeSec
constantFlowTimeSec
useRampFlowToZero | TRUE
rampFlowToZeroSec
constantPostExtinctionDelaySec
constantPostExtinctionFlowChangeFuelPercent | -50.0
constantPostExtinctionFlowChangeN2Percent | -50.0
constantPostExtinctionFlowChangeRampTimeSec | 3
constantPostExtinctionFlowChangeHoldSec | 2
rampPostExtinctionDelaySec
rampPostExtinctionFlowChangeFuelPercent | 50.0
rampPostExtinctionFlowChangeN2Percent | 50.0
rampPostExtinctionFlowChangeRampTimeSec | 3
rampPostExtinctionFlowChangeHoldSec | 2
ZI Ds
ops
~~~~

### Pagina 7

Cita: [pdf_55e3fca6600fcffb510e, p. 7]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_55e3fca6600fcffb510e/p0007.jpg)

~~~~text
testpointName | 19137H1
prelgnitionDataTimeSec
postFlameDataTimeSec | 15
uselPSUs | TRUE
ipsuTimeoutSec | 40
useAcmeCamera | TRUE
uselntensifiedCamera | TRUE
ipsu1ArchiveRate | 2
dataCameraPrelgnitionExposureUs | 100000
dataCameralgnitionExposureUs | 100000
dataCameraTestExposureUs | 1300000
dataCameraExtinctionExposureus | 650000
analogCameraPrelgnitionShutter | 2
analogCameraEgnitionShutter | 2
analogCameraTestShutter | 2
analogCameraExtinctionShutter
intensifierGainAmplitude | 50000
prelgnitionlmageTimeSec
postFlamelmagingTimeSec
useBracketedExposures | TRUE
bracketinglmagesPerExposure | 1
bracketingNumberOfExposures | 3
bracketingExposureStartUsec | 80000
bracketingExposureMultiplierTimes100 | 500
igniterlgnitionposition | 2250
igniterPreheatPowerV | 2.25
igniterPreheatTimeMs | 1000
igniterlgnitionPowerV | 3.75
igniterlgnitionDurationMs | 2500
igniterDelayBeforeRetractMs | 2000
igniterRetractVelocityCountsPerSec | 500
uselgnitionDetection | TRUE
extinctionDetectionStopsTest | TRUE
pmt1Gain | 5
pmt2Gain | 5.25
pmt3Gain | 5.25
fiberlgnitionposition
fiberTestPosition
fiberMoveDuringTest
fiberSegmentDistance | 400
fiberVelocity | 500
fiberAcceleration | 1000
fiberDeceleration
fiberHoldDurationSec | 1
fiberCycles | 100
useFoma | TRUE
flowTimeoutSec | 80
nitrogenPriming1DurationSec
nitrogenPriming2DurationSec
fuelFlowlgnitionDeltaMs
stabilizationTime1Sec
stabilizationTime2Sec
fuelBottlelgnitionFlowRateN2Slpm | 0.13
nitrogenlgnitionFlowRateN2Slpm | 0
fuelBottleTestFlowRateN2Slpm | 0.13
nitrogenTestFlowRateN2Slpm
ignitionToTestRampTimeSec
constantFlowTimeSec | 3
useRampFlowToZero | TRUE
rampFlowToZeroSec | 30
constantPostExtinctionDelaySec
constantPostExtinctionFlowChangeFuelPercent | -50.0
constantPostExtinctionFlowChangeN2Percent | -50.0
constantPostExtinctionFlowChangeRampTimeSec | 3
constantPostExtinctionFlowChangeHoldSec | 2
rampPostExtinctionDelaySec
rampPostExtinctionFlowChangeFuelPercent | 50.0
rampPostExtinctionFlowChangeN2Percent | 50.0
rampPostExtinctionFlowChangeRampTimeSec | 3
rampPostExtinctionFlowChangeHoldSec | 2
z 10
~~~~

### Pagina 8

Cita: [pdf_55e3fca6600fcffb510e, p. 8]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_55e3fca6600fcffb510e/p0008.jpg)

~~~~text
testpointName | 19137J1
prelgnitionDataTimeSec
postFlameDataTimeSec | 15
uselPSUs | TRUE
ipsuTimeoutSec | 40
useAcmeCamera | TRUE
uselntensifiedCamera | TRUE
ipsu1ArchiveRate | 2
dataCameraPrelgnitionExposureUs | 100000
dataCameralgnitionExposureUs | 100000
dataCameraTestExposureUs | 1300000
dataCameraExtinctionExposureUs | 650000
analogCameraPrelgnitionShutter | 2
analogCameralgnitionShutter | 2
analogCameraTestShutter | 2
analogCameraExtinctionShutter
intensifierGainAmplitude | 50000
prelgnitionlmageTimeSec
postFlamelmagingTimeSec | 5
useBracketedExposures | TRUE
bracketinglmagesPerExposure | 1
bracketingNumberOfExposures | 3
bracketingExposureStartUsec | 80000
bracketingExposureMultiplierTimes100 | 500
igniterlgnitionPosition | 2250
igniterPreheatPowerV | 2.25
igniterPreheatTimeMs | 1000
igniterlgnitionPowerV | 3.75
igniterlgnitionDurationMs | 2500
igniterDelayBeforeRetractMs | 2000
igniterRetractVelocityCountsperSec | 500
uselgnitionDetection | TRUE
extinctionDetectionStopsTest | TRUE
pmt1Gain | 5
pmt2Gain | 5.25
pmt3Gain | 5.25
fiberlgnitionPosition
fiber Testposition | o;
fiberMoveDuringTest
fiberSegmentDistance | 400
fiberVelocity | 500
fiberAcceleration | 1000
fiberDeceleration
fiberHoldDurationSec | 1
fiberCycles | 100
useFoma | TRUE
flowTimeoutSec | 80
nitrogenPriming1DurationSec
nitrogenPriming2DurationSec
fuelFlowlgnitionDeltaMs
stabilizationTime1Sec
stabilizationTime2Sec
fuelBottlelgnitionFlowRateN2Slpm | 0.13
nitrogenlgnitionFlowRateN2Slpm
fuelBottleTestFlowRateN2Slpm | 0.13
nitrogenTestFlowRateN2Slpm
ignitionToTestRampTimeSec
constantFlowTimeSec
useRampFlowToZero | TRUE
rampFlowToZeroSec | 20
constantPostExtinctionDetaySec
constantPostExtinctionFlowChangeFuelPercent | -50.0
constantPostExtinctionFlowChangeN2Percent | -50.0
constantPostExtinctionFlowChangeRampTimeSec | 3
constantPostExtinctionFlowChangeHoldSec | 2
rampPostExtinctionDetaySec
rampPostExtinctionFlowChangeFuelPercent | 50.0
rampPostExtinctionFlowChangeN2Percent | 50.0
rampPostExtinctionFlowChangeRampTimeSec | 3
rampPostExtinctionFlowChangeHoldSec | 2
~~~~

### Pagina 9

Cita: [pdf_55e3fca6600fcffb510e, p. 9]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_55e3fca6600fcffb510e/p0009.jpg)

~~~~text
testpointName | 19137<1
prelgnitionDataTimeSec
postFlameDataTimeSec | 15
uselPSUS | TRUE
ipsuTimeoutSec | 40
useAcmeCamera | TRUE
uselntensifiedCamera | TRUE
ipsu1ArchiveRate | 2
dataCameraPrelgnitionExposureUs | 100000
dataCameralgnitionExposureUs | 100000
dataCameraTestExposureUs | 1300000
dataCameraExtinctionExposureUs | 650000
analogCameraPrelgnitionShutter | 2
analogCameralgnitionShutter | 2
analogCameraTestShutter | 2
analogCameraExtinctionShutter
intensifierGainAmplitude | 50000
prelgnitionlmageTimeSec
postFlamelmagingTimeSec | 5
useBracketedExposures | TRUE
bracketinglmagesPerExposure | 1
bracketingNumberOfExposures | 3
bracketingExposureStartUsec | 80000
bracketingExposureMultiplierTimes100 | 500
igniterlgnitionPosition | 2250
igniterPreheatPowerV | 2.25
igniterPreheatTimeMs | 1000
igniterlgnitionPowerV | 3.75
igniterlgnitionDurationMs | 2500
igniterDelay8eforeRetractMs | 2000
igniterRetractVelocityCountsPerSec | 500
uselgnitionDetection | TRUE
extinctionDetectionStopsTest | TRUE
pmt1Gain | 5
pmt2Gain | 5.25
pmt3Gain | 5.25
fiberlgnitionPosition
fiberTestPosition
fiberMoveDuringTest
fiberSegmentDistance
fiberVelocity | 500
fiberAcceleration | 1000
fiberDeceleration
fiberHoldDurationSec | 1
fiberCycles | 100
useFoma | TRUE
flowTimeoutSec | 0
nitrogenPriming1DurationSec
nitrogenPriming2DurationSec
fuelFlowlgnitionDeltaMs
stabilizationTime1Sec
stabilizationTime2Sec
fuelBottlelgnitionFlowRateN2Slpm | 0.13
nitrogenlgnitionFlowRateN2Slpm
fuelBottleTestFlowRateN2Slpm | 0.1
nitrogenTestFlowRateN2Slpm
ignitionToTestRampTimeSec
constantFlowTimeSec | 3
useRampFlowToZero | TRUE
rampFlowToZeroSec | 10
constantPostExtinctionDelaySec
constantPostExtinctionFlowChangeFuelPercent | -50.0
consta ntPostExti nctionFlowChangeN2Percent | -50.0
constantPostExtinctionFlowChangeRampTimeSec | 3
constantPostExtinctionFlowChangeHoldSec | 2
rampPostExtinctionDelaySec
rampPostExtinctionFlowChangeFuelPercent | 50.0
rampPostExtinctionFlowChangeN2Percent | 50.0
rampPostExtinctionFlowChangeRampTimeSec | 3
rampPostExtinctionFlowChangeHoldSec | 2
~~~~

### Pagina 10

Cita: [pdf_55e3fca6600fcffb510e, p. 10]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_55e3fca6600fcffb510e/p0010.jpg)

~~~~text
testpointName | 913711
prelgnitionDataTimeSec
postFlameDataTimeSec | 15
uselPSUs | TRUE
ipsuTimeoutSec | 40
useAcmeCamera | TRUE
uselntensifiedCamera | TRUE
ipsu1ArchiveRate | 2
dataCameraprelgnitionExposureUs | 100000
dataCameralgnitionExposureUs | 100000
dataCameraTestExposureUs | 1300000
dataCameraExtinctionExposureUs | 650000
analogCameraPrelgnitionShutter | 2
analogCameralgnitionShutter | 2
analogCameraTestShutter | 2
analogCameraExtinctionShutter
intensifierGainAmplitude | 50000
prelgnitionlmageTimeSec
postFlame'magingTimeSec | 5
useBracketedExposures | TRUE
bracketinglmagesperExposure | 1
bracketingNumberOfExposures | 3
bracketingExposureStartUsec | 80000
bracketingExposureMultiplierTimes100 | 500
igniterlgnitionPosition | 2250
igniterPreheatPowerV | 2.25
igniterPreheatTimeMs | 1000
igniterlgnitionPowerV | 3.75
igniterlgnitionDurationMs | 2500
igniterDelayBeforeRetractMs | 2000
igniterRetractVelocityCountsperSec | 500
uselgnitionDetection | TRUE
extinctionDetectionStopsTest | TRUE
pmt1Gain | 5
pmt2Gain | 5.25
pmt3Gain | 5.25
fiberlgnitionPosition
fiber Testposition
fiberMoveDuringTest
fiberSegmentDistance | 400
fiberVelocity | 500
fiberAcceleration | 1000
fiberDeceleration
fiberHoldDurationSec | 1
fiberCycles | 100
useFoma | TRUE
flowTimeoutSec | 80
nitrogenPriming1DurationSec
nitrogenPriming2DurationSec
fuelFlowlgnitionDeltaMs
stabilizationTime1Sec | 0
stabilizationTime2Sec
fuelBottlelgnitionFlowRateN2Slpm | 0.13
nitrogenlgnitionFlowRateN2Slpm | 052 0.195
fuel BottleTestFlowRateN2Slpm | 0.13
nitrogenTestFlowRateN2Slpm | 0.195
ignitionToTestRampTimeSec | 0
constantFlowTimeSec | 3
useRampFlowToZero | TRUE
rampFlowToZeroSec
constantPostExtinctionDelaySec | 0
constantPostExtinctionFlowChangeFuelPercent | -50.0
constantPostExtinctionFlowChangeN2Percent | -50.0
constantPostExtinctionFlowChangeRampTimeSec | 3
constantPostExtinctionFlowChangeHoldSec | 2
rampPostExtinctionDelaySec
rampPostExtinctionFlowChangeFuetPercent | 50.0
rampPostExtinctionFlowChangeN2Percent | 50.0
rampPostExtinctionFlowChangeRampTimeSec
rampPostExtinctionFlowChangeHoldSec | 2
Cevu.zrc..
ops
~~~~

### Pagina 11

Cita: [pdf_55e3fca6600fcffb510e, p. 11]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_55e3fca6600fcffb510e/p0011.jpg)

~~~~text
testpointName | 19137M1
prelgnitionDataTimeSec
postFlameDataTimeSec | 15
uselPSUS | TRUE
ipsuTimeoutSec | 40
useAcmeCamera | TRUE
uselntensifiedCamera | TRUE
ipsu1ArchiveRate | 2
dataCameraprelgnitionExposureUs | 100000
dataCameralgnitionExposureIJs | 100000
dataCameraTestExposureUs | 1300000
dataCameraExtinctionExposureUs | 650000
analogCameraPrelgnitionShutter | 2
analogCameralgnitionShutter | 2
analogCameraTestShutter | 2
analogCameraExtinctionShutter
intensifierGainAmplitude | soooo
prelgnitionlmageTimeSec
postFlamelmagingTimeSec | 5
useBracketedExposures | TRUE
bracketinglmagesPerExposure | 1
bracketingNumberOfExposures | 3
bracketingExposureStartUsec | 80000
bracketingExposureMultiplierTimes100 | 500
igniterlgnitionposition | 2250
igniterPreheatPowerV | 2.25
igniterPreheatTimeMs | 1000
igniterlgnitionPowerV | 3.75
igniterlgnitionDurationMs | 2500
igniterDelayBeforeRetractMs | 2000
igniterRetractVelocityCountsPerSec | 500
usetgnitionDetection | TRUE
extinctionDetectionStopsTest | TRUE
pmt1Gain | 5
pmt2Gain | 5.25
pmt3Gain | 5.25
fiberlgnitionposition
fiberTestPosition
fiberMoveDuringTest
fiberSegmentDistance | 400
fiberVelocity | 500
fiberAcceleration | 1000
fiberDeceleration
fiberHoldDurationSec | 1
fiberCycles | 100
useFoma | TRUE
flowTimeoutSec | 80
nitrogenPriming1DurationSec
nitrogenPriming2DurationSec
fuelFlowlgnitionDettaMs
stabilizationTime1Sec
stabilizationTime2Sec
fuelBottlelgnitionFlowRateN2Slpm | 013
nitrogenlgnitionFlowRateN2Slpm | 0.195
fuelBottleTestFlowRateN2Slpm | 0.13
nitrogenTestFlowRateN2Slpm | 0.195
ignitionToTestRampTimeSec
constantFlowTimeSec | 3
useRampFlowToZero | TRUE
rampFlowToZeroSec | 30
constantPostExtinctionDelaySec
constantPostExtinctionFlowChangeFuelPercent | -50.0
constantPostExtinctionFlowChangeN2Percent | -50.0
constantPostExtinctionFlowChangeRampTimeSec | 3
constantPostExtinctionFlowChangeHoldSec | 2
rampPostExtinctionDelaySec
rampPostExtinctionFlowChangeFuelPercent | 50.0
rampPostExtinctionFlowChangeN2Percent | 50.0
rampPostExtinctionFlowChangeRampTimeSec | 3
rampPostExtinctionFlowChangeHoldSec | 2
~~~~

### Pagina 12

Cita: [pdf_55e3fca6600fcffb510e, p. 12]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_55e3fca6600fcffb510e/p0012.jpg)

~~~~text
testpointName | 19137N1
prelgnitionDataTimeSec
postFlameDataTimeSec | 15
uselPSUs | TRUE
ipsuTimeoutSec | 40
useAcmeCamera | TRUE
uselntensifiedCamera | TRUE
ipsu1ArchiveRate | 2
dataCameraPrelgnitionExposureUs | 100000
dataCameralgnitionExposurelJs | 100000
dataCameraTestExposureUs | 1300000
dataCameraExtinctionExposureus | 650000
analogCameraprelgnitionShutter | 2
analogCameralgnitionShutter | 2
analogCameraTestShutter | 2
analogCameraExtinctionShutter
intensifierGainAmplitude | 50000
preignitionlmageTimeSec
postFlamelmagingTimeSec | 5
useBracketedExposures | TRUE
bracketinglmagesPerExposure | 1
bracketingNumberOfExposures | 3
bracketingExposureStartUsec | 80000
bracketingExposureMultiplierTimes100 | 500
igniterlgnitionposition | 2250
igniterPreheatPowerV | 2.25
igniterPreheatTimeMs | 1000
igniterlgnitionPowerV | 3.75
igniterlgnitionDurationMs | 2500
igniterDelayBeforeRetractMs | 2000
igniterRetractVelocityCountsPerSec | 500
uselgnitionDetection | TRUE
extinctionDetectionStopsTest | TRUE
pmt1Gain | 5
pmt2Gain | 5.25
pmt3Gain | 5.25
fiberlgnitionPosition
fiberTestPosition
fiberMoveDuringTest
fiberSegmentDistance | 400
fiberVelocity | 500
fiberAcceleration | 1000
fiberDeceleration
fiberHoldDurationSec | 1
fiberCycles | 100
useFoma | TRUE
flowTimeoutSec
nitrogenPriming1DurationSec
nitrogenPriming2DurationSec
fuelFlowlgnitionDeltaMs
stabilizationTime1Sec
stabilizationTime2Sec
fuelBottlelgnitionFlowRateN2Slpm | 0.13
nitrogenlgnitionFlowRateN2Slpm | 0.195
fuelBottleTestFlowRateN2Slpm | 0.13
nitrogenTestFlowRateN2Slpm | 0.195
ignitionToTestRampTimeSec
constantFlowTimeSec | 3
useRampFlowToZero | TRUE
rampFlowToZeroSec
constantPostExtinctionDelaySec
constantPostExtinctionFlowChangeFuelPercent | -50.0
constantPostExtinctionFlowChangeN2Percent | -50.0
constantPostExtinctionFlowChangeRampTimeSec | 3
constantPostExtinctionFlowChangeHoldSec | 2
rampPostExtinctionDelaySec
rampPostExtinctionFlowChangeFuelPercent | 50.0
rampPostExtinctionFlowChangeN2Percent | 50.0
rampPostExtinctionFlowChangeRampTimeSec | 3
rampPostExtinctionFlowChangeHoldSec | 2
~~~~

### Pagina 13

Cita: [pdf_55e3fca6600fcffb510e, p. 13]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_55e3fca6600fcffb510e/p0013.jpg)

~~~~text
testpointName | 19137P1
prelgnitionDataTimeSec
postFlameDataTimeSec | 15
uselPSUs | TRUE
ipsuTimeoutSec | 40
useAcmeCamera | TRUE
uselntensifiedCamera | TRUE
ipsu1ArchiveRate | 2
dataCameraPrelgnitionExposureus | 1 ooooo
dataCameralgnitionExposureUs | 100000
dataCameraTestExposureUs | 1300000
dataCameraExtinctionExposureUs | 650000
analogCameraPrelgnitionShutter | 2
analogCameralgnitionShutter | 2
analogCameraTestShutter | 2
analogCameraExtinctionShutter
intensifierGainAmplitude | 50000
preignitionlmageTimeSec
postFlamelmagingTimeSec | 5
use3racketedExposures | TRUE
bracketinglmagesPerExposure | 1
bracketingNumberOfExposures | 3
bracketingExposureStartlJsec | 80000
bracketingExposureMultiplierTimes100 | 500
igniterlgnitionPosition | 2250
igniterPreheatPowerV | 2.25
igniterPreheatTimeMs | 1000
igniterlgnitionPowerV | 3.75
igniterlgnitionDurationMs | 2500
igniterDelayBeforeRetractMs | 2000
igniterRetractVelocityCountsPerSec | 500
uselgnitionDetection | TRUE
extinctionDetectionStopsTest | TRUE
pmt1Gain | 5
pmt2Gain | 5.25
pmt3Gain | 5.25
fiberlgnitionposition
fiberTestPosition
fiberMoveDuringTest
fiberSegmentDistance | 400
fiberVelocity | 500
fiberAcceleration | 1000
fiberDeceleration
fiberHoldDurationSec | 1
fiberCycles | 100
useFoma | TRUE
flowTimeoutSec | 80
nitrogenPriming1DurationSec
nitrogenPriming2DurationSec
fuelFlowlgnitionDeltaMs
stabilizationTime1Sec
stabilizationTime2Sec
fuelBottlelgnitionFlowRateN2Slpm | 0.13
nitrogenlgnitionFlowRateN2Slpm | 0.195
fuelBottleTestFlowRateN2Slpm | 0.136
nitrogenTestFlowRateN2Slpm | 0.195
ignitionToTestRampTimeSec
constantFlowTimeSec
useRampFlowToZero | TRUE
ra mpFlowToZeroSec
constantPostExtinctionDelaySec
constantPostExtinctionFlowChangeFuelPercent | -50.0
constantPostExtinctionFlowChangeN2Percent | -50.0
constantPostExtinctionFlowChangeRampTimeSec | 3
constantPostExtinctionFlowChangeHoldSec | 2
rampPostExtinctionDeIaySec
rampPostExtinctionFlowChangeFuelPercent | 50.0
rampPostExtinctionFlowChangeN2Percent | 50.0
rampPostExtinctionFlowChangeRampTimeSec | 3
rampPostExtinctionFlowChangeHoldSec | 2
~~~~
