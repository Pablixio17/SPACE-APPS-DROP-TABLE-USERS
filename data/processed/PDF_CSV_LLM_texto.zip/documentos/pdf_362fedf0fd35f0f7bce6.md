# 19063 daily test point log

- Identificador: pdf_362fedf0fd35f0f7bce6
- Investigaciones: PSI-20
- Tipo de documento: Raw Data
- Estado: processed
- Temas detectados automaticamente: hardware

## Fuentes

- [PSI-20_Raw Data_19063 daily test point log.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-20/Raw%20Data/PSI-20_Raw%20Data_19063%20daily%20test%20point%20log.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_362fedf0fd35f0f7bce6, p. 1]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_362fedf0fd35f0f7bce6/p0001.jpg)

~~~~text
ACME Daily Test Point Log | 3/4/2019
Downlink Data Limit (MB) = 127,000 | Total = | 87,026
Test Point Name Script Aborts | IPSU1/HiBMS | ACME Camera | Intensified Camera
Downlink
(enter all test | Before IPSUs | Archived | Archived | Archived
Data (MB)
points) | Open | Images | Images | D/L? | Images | D/L?
19063A1 | 4921 | 718 | 7625 | 33,688
1906381 | 2782 | 476 | 4328 | 19,296
19063C1 | 1873 | 369 | 2916 | 13,138
19063D1 | 1043 | 323 | 1626 | 7,663
19063F1 | 962 | 289 | 1495 | 7,029
19063G1 | 849 | 263 | 1314 | 6,211
PD: | Date:
~~~~
