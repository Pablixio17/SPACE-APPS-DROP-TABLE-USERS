# SPICE-front-window

- Identificador: pdf_0f5fc3df74b8da391f74
- Investigaciones: PSI-26
- Tipo de documento: Engineering Documents
- Estado: processed
- Temas detectados automaticamente: 

## Fuentes

- [PSI-26_Engineering Documents_SPICE-front-window.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-26/Engineering%20Documents/PSI-26_Engineering%20Documents_SPICE-front-window.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_0f5fc3df74b8da391f74, p. 1]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_0f5fc3df74b8da391f74/p0001.jpg)

~~~~text
tOOH-:antS009
s | 9NIMV8Q
00
I-LJ
I-LJ | z z
z | O
O cr | CD 00
O | z
0
_J
cr
>—
I—LI
cr
I—LI
>—
(40 | —J
z z
cr
LL_J | Lu_J
O | O O | LL_J
E:
LIJ
00 co
00
~~~~
