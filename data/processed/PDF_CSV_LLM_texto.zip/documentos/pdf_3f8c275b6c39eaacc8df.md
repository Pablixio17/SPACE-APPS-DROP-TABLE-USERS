# Swenson et al 2011 Electric field induced convection in microgravity combustion

- Identificador: pdf_3f8c275b6c39eaacc8df
- Investigaciones: PSI-22
- Tipo de documento: Presentations
- Estado: processed
- Temas detectados automaticamente: electric_fields, oxygen, extinction, microgravity, hardware, pressure, ignition, soot, droplets, computational_models

## Fuentes

- [PSI-22_Presentations_Swenson et al 2011 Electric field induced convection in microgravity combustion.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-22/Presentations/PSI-22_Presentations_Swenson%20et%20al%202011%20Electric%20field%20induced%20convection%20in%20microgravity%20combustion.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Pasajes de orientacion (extractivos, no resumen validado)

### conclusion - pagina 6

Conclusion 
The ion current response is nearly identical in μg and 1g environments, with the exception of the 
positive saturation plateau. This is expected considering that ion production is a global measure 
of flame behavior that is dependent on the flow field regardless of the driving mechanism. At 
electric field strengths greater than 1.8 kV/cm in μg, the flame begins to oscillate and the ion 
current jumps up significantly. At this point a faint corona glow is observed from the nozzle tip. 
At electric field strengths more negative than -1.6 kV/cm, the flame is unable to adjust to the 
abrupt change in flow conditions and extinguishes. Future research will include intermediate 
voltage steps or a ramp for testing at higher field strengths. Within the respective uncertainties, 
the surface area and flame base location of the images presented in Figure 4 are equal; where a 
-0.6 kV/cm electric field or a 24 cm/s coflow acting on a μg flame can produce a flame shape 
similar to that of a 1g flame without these influences. The flames at these conditions are shown 
in Figure 4. A deeper understanding of how electric fields effect flames may lead to future 
applications such as soot control and applications where efficiency and stability can be actively 
controlled with electric fields. 
Derivation of the Uncertainty of the Surface Area of a Flame 
The surface area of a flame is approximated the flame as a cylinder defined as: 
 A = πWH (A.1) 
Taylor expansion of A.1 yields: 
 ΔA = ∂A
∂W
ΔW +
∂A
∂H
ΔH + H.O.T (A.2) 
Neglecting higher order terms and substituting the partial derivatives of A.1 in equation A.2 
gives: 
 ΔA = πHΔW + πWΔH (A.3) 
Squaring both sides of A.3 and disregarding the cross terms of the right hand side, due to the fact 
that the uncertainty is very

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_3f8c275b6c39eaacc8df, p. 1]. Metodo: native.

~~~~text
Paper # OT11 Provided from CI Office Topic: Laminar Flames 
1 
2011 7th US National Combustion Meeting 
Organized by the Eastern States Section of the Combustion Institute 
and Hosted by the Georgia Institute of Technology, Atlanta, GA 
March 20-23, 2011 
Electric field induced convection in microgravity combustion 
K. Swenson1
, S. Karnani2
, D. Dunn-Rankin2
, F. Takahashi3
, D. Stocker1
, and 
Z-G. Guang3
1
NASA Glenn Research Center, Cleveland, Ohio 44135 
2
Department of Mechanical and Aerospace Engineering, University of California at Irvine, 
Irvine, California 92617, USA 
3
National Center for Space Exploration Research on Fluids and Combustion, Cleveland, Ohio 
92617, USA 
This paper describes measurements aimed at understanding the influence of electric fields on 
flames where buoyancy has been removed. Given that buoyancy and an electric field can have a 
similar influence on flames, buoyancy can obscure the contribution of an electric field in a normal 
gravity (1g) environment. Experiments were performed in the microgravity conditions of NASA’s 
2.2 Second Drop Tower on a simple jet diffusion flame to isolate the influence of an electric field. 
Results show similarities between the ion current response of a methane flame in an electric field 
in both 1g and microgravity (μg). Under some coflow velocities and electric fields strengths, it is 
possible to modify the flame shape so that it resembles a flame in 1g. 
1. Introduction 
 When oxidized, hydrocarbon fuels produce a number of intermediate species, a small 
subset of which are charged. Hence, an electrostatic field applied across the flame zone creates a 
charge separation; opposites attract and ions move toward their respective opposite electrode. 
Acceleration of the ions is limited as momentum is transferred through collisions with neutral 
molecules. These repeated collisions induce a wind of companion neutral gas, which can 
potentially affect flame stability [1, 2], induce convection [3], and simulate microgravity [4-6]. 
 In a 1g environment, the plume of hot gases from a flame naturally induces, through mass 
continuity, a convective flow to the neighboring cooler environment, giving rise to the flame’s 
characteristic teardrop shape. In a microgravity environment, buoyant convection, which in 1g is 
responsible for the transport of fresh oxidizer to a flame, is removed, leaving forced convection 
to dominate the flow field while species transport is a function of both that and molecular 
diffusion[7]. A number of experiments [8-10] have studied electric fields applied to flames in 
microgravity environments to measure mobility, its influence on burning rate constants, and the 
feasibility of inducing forced convection in a buoyancy free environment. 
 The comparable influence of buoyant convection makes studying ion wind effects on 
flames in a 1g environment difficult. By removing buoyancy, the ion wind becomes a dominant 
force capable of creating similar flame shapes in a non-buoyant environment. This paper’s 
objective is to explore the different ion current regimes of a small diffusion flame when affected 
by an electric field in 1g and μg using the NASA Glenn 2.2-s Drop Tower.
~~~~

### Pagina 2

Cita: [pdf_3f8c275b6c39eaacc8df, p. 2]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
7th US Combustion Meeting – Paper # OT11 Topic: Laminar Flames 
2 
2. Experimental 
The experimental drop rig (Figure 1) includes a cylindrical test chamber (24.6 cm i.d., 53.3 cm 
length), flow system, and data acquisition/control hardware. The burner is a stainless-steel fuel 
tube (2.1 mm i.d., 2.4 mm o.d.), coaxially positioned inside the cylindrical test chamber. For 
conditions requiring a coflowing annulus of gas, the stainless-steel fuel tube is coaxially 
positioned inside a Pyrex® converging nozzle (27.3 mm exit i.d.), through which air flows. Gas 
flow was controlled with a fixed orifice and upstream pressure. A hot-wire igniter (coiled 29-
gauge Kanthal, 11 cm length), which can be positioned over the burner by a rotary solenoid is 
used to ignite the fuel (CH4, 99.97%). Data signals from thermocouples, pressure transducers, 
radiometer (Dexter, ST150 Amplified), and a tri-axis accelerometer (Crossbow, CXL02TG3-S) 
are digitized and recorded at 20 Hz. The flame is observed by a CCD color camera (Hitachi HV￾D30), transmitted through a tethered optical fiber, and recorded using a digital video recorder 
placed atop the Drop Tower. 
To establish a steady flow through the flow orifice, fuel is introduced to the burner 8 seconds 
prior to the drop event (t = 0). Following ignition and igniter retraction, a selected high voltage is 
applied to the mesh electrode relative to the burner. The mesh screen was located 5 cm above the 
nozzle tip. The average strength of the electric field is approximated as: 
 E = V
d , (1) 
where V is the voltage applied by the high voltage power supply and d is the distance between 
the tip of the nozzle and the screen. Ion current is computed by measuring the voltage drop 
Figure 1. NASA Glenn 2.2-s Drop Tower rig
~~~~

### Pagina 3

Cita: [pdf_3f8c275b6c39eaacc8df, p. 3]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
7th US Combustion Meeting – Paper # OT11 Topic: Laminar Flames 
3 
across a 1 MΩ resistor in the high-voltage return. Upon impact at the bottom of the Drop Tower 
(t = 2.2 s), the gas flows and applied voltage are shut off. 
3. Results and Discussion 
Flame response is presented in the following graphs by plotting the measured ion current as a 
function of the applied field. It should be noted that the burner is always grounded and electrical 
potentials are applied at the electrode. The polarity of the field is considered positive when the 
mesh electrode has a positive potential with respect to the burner electrode. All data points, 
except where noted, are averaged between t = 1.6 s to t = 2.1 s of the drop to avoid measuring the 
flame’s transient response. Data points were only included in the data set if a flame was present. 
Error bars represent the standard deviation of the shunt voltage in this same time period. 
Figure 3 shows the relationship between ion current and electric field strength for a 24 cm/s 
methane velocity in μg and 1g. Both conditions, regardless of polarity, show a sub-saturation 
region characterized by a near quadratic increase in ion current with voltage and a saturation 
region where ion current remains constant with increasing voltage. The ion current response 
exhibits minor differences in magnitude when changing gravity levels with a negative potential 
mesh in the sub-saturation and early saturation regions. At larger field strengths, initial transients 
from the voltage step can extinguish the flame. Points that involve extinguishment are measured 
over different time periods and should not be considered accurate; however, the values are 
plotted for completeness and to show that extinguished flames have a clearly discernable 
behavior. For a positive potential mesh applied in μg, the ion driven wind forces the flame 
against the burner tube. The flames are partially quenched on the burner tube, reducing the 
Figure 3. Ion current response in 1g and μg for a 24 cm/s non-premixed methane flame
~~~~

### Pagina 4

Cita: [pdf_3f8c275b6c39eaacc8df, p. 4]. Metodo: native.

Calidad: figures_not_digitized, table_structure_not_manually_validated.

~~~~text
7th US Combustion Meeting – Paper # OT11 Topic: Laminar Flames 
4 
measured ion current. By removing the competition with buoyant convection, the ion wind in μg 
can induce corona breakdown at lower applied voltages, as shown by the abrupt jump in current 
at a 1.8 kV/cm applied field. 
Figure 4 compares the effect of different external influences on a jet flame: gravity or natural 
convection, electric field driven wind, and coflow sheath convection. Differences in ambient 
lighting are a result of the conditions in the laboratory versus the drop tower. Low initial 
momentum jet flames in microgravity without an externally applied body force approach a near 
spherical shape; however, both coflowing air and an electric field can alter the local flow field, 
supplying fresh oxidizer to the flame zone. Using the flame shape as a measure of similarity, it is 
possible, as a first order approximation to measure the flame’s surface area by idealizing the 
 A . 1g | 0 kV/cm B . 0g | -0.60 kV/cm C . 0g | 24 cm/s coflow 
Figure 4 Flame shape as a function of gravity and applied electric field. 
Figure 5. Variables for computing flame surface area
~~~~

### Pagina 5

Cita: [pdf_3f8c275b6c39eaacc8df, p. 5]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
7th US Combustion Meeting – Paper # OT11 Topic: Laminar Flames 
5 
flame as a cylinder and disregarding the top and bottom surface. 
Shown in Figure 5, W is defined as the diameter of the flame, measured as the flame’s maximum 
width, and H is defined as the flame’s centerline height. The location of the flame is defined as 
L, where L is negative when the base of the flame is below the nozzle tip. 
Based on these definitions, Figure 6 plots the approximate surface area of flames as a function of 
coflow velocity and electric field forcing in μg and 1g. The pink vertical line at 144 mm2
 marks 
Figure 6. Flame area as a function of electric field strength and coflow velocity. 
Figure 7. Flame base location as a function of electric field strength and coflow velocity.
~~~~

### Pagina 6

Cita: [pdf_3f8c275b6c39eaacc8df, p. 6]. Metodo: native.

~~~~text
7th US Combustion Meeting – Paper # OT11 Topic: Laminar Flames 
6 
the surface area of the flame in 1g without an electric field. The error in the surface area 
measurement is computed using equation A.4. Figure 7 compares the location of the flame base 
as a function of applied electric field strength and coflow velocity. The pink vertical line 
corresponds to the base location of a 1g flame without an applied field. The graphs show that a 
flame in μg with a -0.6 kV/cm average applied electric field or a coflow velocity of 24 cm/s will 
produce a flame with a similar area and flame base location as the unforced 1g flame. 
4. Conclusion 
The ion current response is nearly identical in μg and 1g environments, with the exception of the 
positive saturation plateau. This is expected considering that ion production is a global measure 
of flame behavior that is dependent on the flow field regardless of the driving mechanism. At 
electric field strengths greater than 1.8 kV/cm in μg, the flame begins to oscillate and the ion 
current jumps up significantly. At this point a faint corona glow is observed from the nozzle tip. 
At electric field strengths more negative than -1.6 kV/cm, the flame is unable to adjust to the 
abrupt change in flow conditions and extinguishes. Future research will include intermediate 
voltage steps or a ramp for testing at higher field strengths. Within the respective uncertainties, 
the surface area and flame base location of the images presented in Figure 4 are equal; where a 
-0.6 kV/cm electric field or a 24 cm/s coflow acting on a μg flame can produce a flame shape 
similar to that of a 1g flame without these influences. The flames at these conditions are shown 
in Figure 4. A deeper understanding of how electric fields effect flames may lead to future 
applications such as soot control and applications where efficiency and stability can be actively 
controlled with electric fields. 
Derivation of the Uncertainty of the Surface Area of a Flame 
The surface area of a flame is approximated the flame as a cylinder defined as: 
 A = πWH (A.1) 
Taylor expansion of A.1 yields: 
 ΔA = ∂A
∂W
ΔW +
∂A
∂H
ΔH + H.O.T (A.2) 
Neglecting higher order terms and substituting the partial derivatives of A.1 in equation A.2 
gives: 
 ΔA = πHΔW + πWΔH (A.3) 
Squaring both sides of A.3 and disregarding the cross terms of the right hand side, due to the fact 
that the uncertainty is very small, and taking the square root results in the most likely 
uncertainty:
~~~~

### Pagina 7

Cita: [pdf_3f8c275b6c39eaacc8df, p. 7]. Metodo: native.

~~~~text
7th US Combustion Meeting – Paper # OT11 Topic: Laminar Flames 
7 
 ΔA = (πHΔW )
2 + (πWΔH)
2 (A.4)
Acknowledgments 
NASA’s ISS Research Project via agreement NNX07AB55A supports this work. The efforts of 
the NASA Glenn Drop Tower staff are greatly appreciated. 
Disclaimer 
Product names and models are provided only for clarification and are in no way an endorsement 
on the part of NASA or the federal government. 
References 
[1] M. Belhi, P. Domingo, and P. Vervisch. Direct numerical simulation of the effect of an 
electric field on flame stability. Combustion and Flame, 2010. 
[2] E. Sher, G. Pinhasi, A. Pokryvailo, and R. Bar-on. Extinction of pool flames by means of a 
DC electric field. Combustion and Flame, 94:244–252, 1993. 
[3] M.J. Papac. Effects of electric fields on convection in combustion plasmas and surrounding 
gases. 36th AIAA Plasmadynamics and Lasers Conference, (AIAA 2005-4784), 2005. 
[4] M.J. Papac and D. Dunn-Rankin. Canceling buoyancy of gaseous fueled flames in a 
gravitational environment using an ion-driven wind. Annals of the N.Y Academy of 
Sciences, 1077:585–601, Oct. 2006. 
[5] F.B. Carleton, D. Dunn-Rankin, and F.J. Weinberg. The optics of small diffusion flames in 
microgravity. Twenty-Seventh Symposium (International) on Combustion/The 
Combustion Institute, pages 2567– 2572, 1998. 
[6] M.J. Papac, D. Dunn-Rankin, C.B. Stipe, and D. Lucas. N2 CARS thermometry and O2 
LIF concentration measurements in a flame under electrically induced microbuoyancy. 
Combustion and Flame, 133:241–254, 2003. 
[7] H.D Ross. Microgravity Combustion: Fire in Free Fall. 2001. 
[8] Z.G. Yuan and U. Hegde. Recent advances in electric field effects on diffusion flames in a 
spherically symmetric system. American Institute of Aeronautics and Astronautics, 2003. 
[9] K. Yamashita, O. Imamura, J. Osaka, Tsue M., and M. Kono. Influences of uniform 
electrical fields on burning rate constant of ethanol droplet combustion. Combustion
~~~~

### Pagina 8

Cita: [pdf_3f8c275b6c39eaacc8df, p. 8]. Metodo: native.

~~~~text
7th US Combustion Meeting – Paper # OT11 Topic: Laminar Flames 
8 
Science, and Technology, 180: 652–673, 2008. 
[10] F.B. Carleton and F.J. Weinberg. Electric field-induced flame convection in the absence of 
gravity. Nature, 330(17):635, 1987.
~~~~
