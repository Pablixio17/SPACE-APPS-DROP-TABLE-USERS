# 19056 test sheets

- Identificador: pdf_2d1ccba7b4cf5dd6c834
- Investigaciones: PSI-20
- Tipo de documento: Raw Data
- Estado: processed
- Temas detectados automaticamente: oxygen, pressure, ignition, hardware, soot

## Fuentes

- [PSI-20_Raw Data_19056 test sheets.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-20/Raw%20Data/PSI-20_Raw%20Data_19056%20test%20sheets.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_2d1ccba7b4cf5dd6c834, p. 1]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_2d1ccba7b4cf5dd6c834/p0001.jpg)

~~~~text
ACME / BRE - Science Test Sheet
est date: Fe | 45 | CME test
Local time: | est of day #:
MT: | Flame of day #:
Rack Officer (RO): | PD (ACME):
DMO (CIR): | Researcher:
TEST CONDITIONS | Control? | fully automated o 'manual'
Test type? o fiber o ignition no-flame o ramp o | o other
Oxygen conc. | •t D % (volume) * | Burner diameter: (25 mm 50 mm
Chamber pressure: | —7psia | Fuel Bottle: CH4
ent before? o noqyes, to -GD.Z- psia | Burner fuel conc.. | % (volume)
Air' added? no Y-yes, to | A.¯Z psia | Fuel flow rate: D.) slpm (N2 basis)
Iso just before? o fan GC scrub | D | slpm
INSTRUMENTATION | FP? Kno fixed o moving o back-n-forth
Z DataCam: filter? p:lear o BG7 c] CH* o CH20 | ROI? k full reduced | fps
_
E Intensified: filter? clear o CH* R CH20 0 none | ROI? cæfull o reduced | Z fps
XHiBMs: backlight filter? no Ayes | CIR backlight? no e yes fps?K15 30
FLAME BEHAVIOR | Ignited? dyes o no yes, but *
...
Flame hole/opening partially detached | Soot none Z ignition only little o lots
Flame oscillating o unsteady o blew out | oot@end none ignition o little o lots
POST-TEST CONDITIONS | Oxidizer bottle pressure: | 24 psia
Oxygen conc. | % (volume) | alve safety timer | 92— sec
*GENERAL COMMENTS
4k 3
w/ | s-h7D
6 Feb. 2019
~~~~

### Pagina 2

Cita: [pdf_2d1ccba7b4cf5dd6c834, p. 2]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_2d1ccba7b4cf5dd6c834/p0002.jpg)

~~~~text
ACME / BRE - Science Test Sheet
est date: Feb 35 2-21 | CME test #:
Local time: | (D:57 | est of day #: | 2-
GMT: | Flame of day #:
Rack Officer (RO): | PD (ACME):
DMO (CIR): | Researcher:
TEST CONDITIONS | Control? | fully automated o 'manual'
Test type? o fiber o ignition no-flame o ramp o stepping rstandard o other
Oxygen conc. | % (volume) | Burner diameter: R 25 mm 50 mm
Chamber pressure: | • 7 psia | Fuel Bottle: o CH4
ent | yes, to | psia | Burner fuel conc.: 50 % (volume)
Air' added? | o yes, to | psia | Fuel flow rate: 02—slpm (N2 basis)
Iso just before? | fan o GC o scrub | N.2.-.f4ew..rate.:— D slpm
INSTRUMENTATION | F P? | o o fixed o moving o back-n-forth
DataCam: filter? Qclear o BG7 0 CH* o CH20 | ROI? full o reduced | fps
Intensified: filter? clear ZCH* CH20 none | ROI? Lfull o reduced | 2 fps
QiiBMs: backlight filter? o noe/es | CIR backlight? no ayes fps? 15 30
FLAME BEHAVIOR | Ignited? yes no o yes, but *
...
Flame ßhole/opening partially detached | 00t none •gnition only o little o lots
Flame Xoscillating unsteady o blew out | oot@end none o ignition o little lots
POST-TEST CONDITIONS | Oxidizer bottle pressure: | psia
xygen conc. | % (volume) | alve safety timer | sec
*GENERAL COMMENTS
33>70 Dz— | 4-es+
6 Feb. 2019
~~~~

### Pagina 3

Cita: [pdf_2d1ccba7b4cf5dd6c834, p. 3]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_2d1ccba7b4cf5dd6c834/p0003.jpg)

~~~~text
ACME / BRE - Science Test Sheet
est date: | b z5 z | CME test #:
Local time: | est of day #:
GMT: | 1 05b | Flame of day #:
Rack Officer (RO): | PD (ACME):
DMO (CIR): | Researcher:
TEST CONDITIONS | Control? | g fully automated 'manual'
Test type? fiber o ignition no-flame ramp stepping "standard o other
xygen conc. | -S % (volume) | Burner diameter: Yd 25 mm 0 50 mm
Chamber pressure: | psia | Fuel Bottle: o CH4 | % nC2H4
ent before? o nonyes, to | psia | Burner fuel conc.: | D % (volume)
Air' added? o no Y-yes, to | psia | Fuel flow rate: 0.4-slpm (N2 basis)
Iso just before? o fan GC scrub | D slpm
INSTRUMENTATION | no o fixed moving o back-n-forth
filter? xclear o BG7 0 CH* o CH20 | ROI? K full o reduced | fps
Qlntensified: filter? o clear øCH* CH20 0 none | ROI? full o reduced | a fps
backlight filter? no Nies | CIR backlight? o no | fps? Q'15 30
FLAME BEHAVIOR | Ignited? gyes o no yes, but *
...
Flame Chole/opening«partially detached | 00t o none o ignition onlyZ little o lots
Flame | Unsteady (_blew out | oot@end y_none o ignition o little o lots
POST-TEST CONDITIONS | Oxidizer bottle pressure: 1)" psia
Oxygen conc. 25, | | % (volume) | alve safety timer | sec
*GENERAL COMMENTS
6 Feb. 2019
~~~~

### Pagina 4

Cita: [pdf_2d1ccba7b4cf5dd6c834, p. 4]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_2d1ccba7b4cf5dd6c834/p0004.jpg)

~~~~text
ACME / BRE - Science Test Sheet
est date: | 201? | CME test#: qo
Local time: | 2. | est of day#: 4
GMT: | Flame of day #:
Rack Officer (RO): | PD (ACME):
DMO (CIR): | Researcher:
TEST CONDITIONS | Control? | kfully automated o 'manual'
Test type? o fiber o ignition o no-flame o ramp o stepping R standard o other
Oxygen conc. | % (volume) | Burner diameter: u 25 mm 50 mm
Chamber pressure: | psia | Fuel Bottle: o CH4 | % C2H4 -20/0
4K
ent before? o no o yes, to | psia | Burner fuel conc.: | b % (volume)
Air' added? o no o yes, to | psia | Fuel flow rate: O, slpm (N2 basis)
Iso just before? | fan D GC scrub
INSTRUMENTATION | FP? X no o fixed o moving back-n-forth
DataCam: filter? Qclear BG7 | CH20 | ROI? x full o reduced | fps
_
Intensified: filter? clear RCH* CH20 none | ROI? < full o reduced | 2-3- fps
< HiBMs: backlight filter? no eyes | CIR backlight? no | fps?ø15 30
FLAME BEHAVIOR | Ignited? Wes no o yes, but ...*
Flame whole/opening Cpartially detached | 00t D none ignition only little o lots
Flamew oscillating Runsteady blew out | oot@end none o ignition o little o lots
POST-TEST CONDITIONS | Oxidizer bottle pressure: | psia
Oxygen conc. ZL | % (volume) | alve safety timer | sec
*GENERAL COMMENTS
6 Feb. 2019
~~~~

### Pagina 5

Cita: [pdf_2d1ccba7b4cf5dd6c834, p. 5]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_2d1ccba7b4cf5dd6c834/p0005.jpg)

~~~~text
ACME / BRE - Science Test Sheet
est date: F | CME test #:
Local time: | est of day #:
MT: | ) e56 | Flame of day #:
Rack Officer (RO): | PD (ACME):
DMO (CIR): | Researcher:
TEST CONDITIONS | Control? | *fully automated o 'manual'
Test type? o fiber o ignition o no-flame ramp o stepping g-standard o other
Oxygen conc. | 3 | % (volume) | Burner diameter: | mm 0 50 mm
Chamber pressure: | 3 | psia | Fuel Bottle: | CH4 | 0/0*-C2H4 5b %
ent before? o no | es, to | psia | Burner fuel conc.: go % (volume)
Air' added? no pfes, to | psia | Fuel flow rate: c, / slpm (N2 basis)
Iso just before? | an o GC p<crub | Slpm
INSTRUMENTATION | FP? kno o fixed o moving a back-n-forth
DataCam: filter? Qclear o BG7 0 CH* o CH20 | ROI? Rfull reduced | fps
_
*Intensified: filter? clear *CH* o CH20 0 none | ROI? R full o reduced | 23fps
KHiBMs: backlight filter? o no *yes | CIR backlight? no g_yes fps? (15 30
FLAME BEHAVIOR | Ignited? o yes no o yes, but *
...
Flame o hole/opening o partially detached | 00t o none ignition only little o lots
Flame o oscillating unsteady o blew out | oot@end o none o ignition o little o lots
POST-TEST CONDITIONS | Oxidizer bottle pressure: | psia
Oxygen conc. | % (volume) | alve safety timer | sec
*GENERAL COMMENTS
6 Feb. 2019
~~~~

### Pagina 6

Cita: [pdf_2d1ccba7b4cf5dd6c834, p. 6]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_2d1ccba7b4cf5dd6c834/p0006.jpg)

~~~~text
ACME / BRE - Science Test Sheet
est date: | CME test
Local time: | 250-6 | est of day #:
GMT: | Flame of day #:
Rack Officer (RO): | PD (ACME):
•ct---r 4
DMO (CIR): | Researcher:
TEST CONDITIONS | Control? | o fully automated 'manual'
Test type? o fiber ignition o no-flame o ramp o stepping o standard ü other
Oxygen conc. | % (volume) —V | Burner diameter: | 25 mm 50 mm
Chamber pressure: | psia | Fuel Bottle: o CH4 | % XC2H4
ent before? dno yes, to | psia | Burner fuel conc.: | o | % (volume)
Air' added? —no o yes, to | psia | Fuel flow rate: U / slpm (N2 basis)
.
Iso just before? | fan D GC scrub | N2 flow rate: | slpm
INSTRUMENTATION | no o fixed o moving o back-n-forth
DataCam: filter? ü clear BG7 0 CH* o CH20 | ROI?fjfull reduced | fps
Intensified: filter? c] clear ü CH* CH20 0 none | ROI?Äfull o reduced | fps
HiBMs: backlight filter? o no | es | CIR backlight? D no yes fps? 15 30
FLAME BEHAVIOR | Ignited? ß/es o no | but *
yes, | ...
Flame hole/opening o partially detached | oot o none Signition only o little o lots
Flame o oscillating o unsteady blew out | oot@end none ignition o little o lots
*GENERAL COMMENTS
6 Feb. 2019
~~~~

### Pagina 7

Cita: [pdf_2d1ccba7b4cf5dd6c834, p. 7]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_2d1ccba7b4cf5dd6c834/p0007.jpg)

~~~~text
ACME / BRE - Science Test Sheet
est date: | Z 5 | CME test
Local time: | 2? | est of day #:
GMT: | Flame of day #:
Rack Officer (RO): | PD (ACME):
DMO (CIR): | Researcher:
TEST CONDITIONS | Control? | fully automated o 'manual'
Test type? o fiber o ignition o no-flame o ramp o stepping standa do ot er
Oxygen conc. | % (volume) | urner diameter: | 25 mm 50 mm
Chamber pressure: | 3 i SY psia | uel Bottle: | CH4 | 0/0 C2H4SO %
ent before? Go o yes, to | psia | Burner fuel conc.: | % (volume)
c
Air' added? —no o yes, to | psia | Fuel flow rate: (2 | slpm (N2 basis)
Iso just before? | fan a GC o scrub | slpm
O
INSTRUMENTATION | o fixed o moving o back-n-forth
c(DataCam: filter? Aclear BG7 0 | CH20 | ROI? full o reduced | fps
A
Intensified: filter? o clear A CH* CH20 0 none | ROI? _z\full o reduced | fps
HiBMs: backlight filter? o no. yes | CIR backlight? o no yes fps? 15 30
FLAME BEHAVIOR | Ignited? Q yes o no o | but *
yes, | ... | GOh-vr
Flame hole/opening< partially detached | 00t o none "ignition only o little {lots
Flame [Koscillating | Xblew out | oot@end none o ignition o little o lots
POST-TEST CONDITIONS | Oxidizer bottle pressure: | psia
Oxygen conc. | % (volume) | alve safety timer | sec
*GENERAL COMMENTS
6 Feb. 2019
~~~~

### Pagina 8

Cita: [pdf_2d1ccba7b4cf5dd6c834, p. 8]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_2d1ccba7b4cf5dd6c834/p0008.jpg)

~~~~text
ACME / BRE - Science Test Sheet
est date: —'e-b | CME test #:
Local time: | 8 | est of day #:
GMT: | Flame of day #:
Rack Officer (RO): | PD (ACME):
DMO (CIR): | Researcher:
TEST CONDITIONS | Control? | o fully automated o 'manual'
Test type? o fiber o ignition no-flame ü ramp stepping•Qstandard o other
xygen conc. | % (volume) | Burner diameter: 05 mm 0 50 mm
hamber pressure: | psia | 4K Fuel Bottle: o CH4 | 0/0S-C2H4 | %
ent before? no o yes, to | psia | Burner fuel conc.: | b % (volume)
Air' added? no o yes, to | psia | Fuel flow rate: D. Itslpm (N2 basis)
Iso just before? Wan GC o scrub | Ö slpm
INSTRUMENTATION | FP? no o fixed o moving o back-n-forth
KDataCam: | o BG7 0 CH* o CH20 | ROI? d full o reduced | fps
klntensified: filter? o clear€CH* CH20 0 none | ROI? Null o reduced | Zfps
HiBMs: backlight filter? | CIR backlight? no ü-yes fps? 0 15 30
FLAME BEHAVIOR | Ignited? Qyes o no o yes, but *
...
Flame hole/openingz partially detached | 00t D none (ignition only o little o lots
Flame Zoscillating gunsteady E-blew out | oot@end | o ignition little o lots
POST-TEST CONDITIONS | Oxidizer bottle pressure: | psia
Oxygen conc. | % (volume) | alve safety timer | sec
*GENERAL COMMENTS
24/71 % | R4,---
•i-es-ß-
6 Feb. 2019
~~~~

### Pagina 9

Cita: [pdf_2d1ccba7b4cf5dd6c834, p. 9]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_2d1ccba7b4cf5dd6c834/p0009.jpg)

~~~~text
ACME / BRE - Science Test Sheet
est date: | CME test
Local time: | est of day #:
MT: | D 54 | Flame of day #:
Rack Officer (RO): | PD (ACME):
DMO (CIR): | Researcher:
TEST CONDITIONS | Control? | automated o 'manual'
Test type? o fiber o ignition no-flame ramp o stepping ü standards( other
xygen conc. | Z .5 % (volume) | Burner diameter: •05 mm 0 50 mm
hamber pressure: | DD psia | R Fuel Bottle: o CH4 | C2H4 50 0/0
ent before? a | to | 4 v 9 Burner fuel | 0/0
no o yes, | psia | conc.: | 9 | (volume)
Air' added? Eno o yes, to | psia | Fuel flow rate: 4/4 slpm (N2 basis)
Iso just before? Afan OGC o scrub | N•240w-rate: | Ö slpm
INSTRUMENTATION | FP? o no o fixed o moving o back-n-forth
filter? | o BG7 | CH20 | ROI? Kfull o reduced | fps
_
Intensified: filter? o clear Q CH* o CH20 0 none | ROI? "ull o reduced | 2-2- fps
HiBMs: backlight filter? no eyes | CIR backlight? noæ | fps? 0 15 30
yes
FLAME BEHAVIOR | Ignited? o yes ü no o yes, but *
...
Flame o hole/opening o partially detached | oot o none o ignition only o little o lots
Flame oscillating o unsteady o blew out | oot@end o none o ignition o little o lots
POST-TEST CONDITIONS | Oxidizer bottle pressure: | psia
Oxygen conc. | 2- % (volume) | alve safety timer | sec
*GENERAL COMMENTS
Z43c% e-z_ | 4z-5Fper
6 Feb. 2019
~~~~
