# SampleHFDropletImage

- Identificador: pdf_cf20cc3e0ddd9cb6959a
- Investigaciones: PSI-39
- Tipo de documento: Raw Data
- Estado: processed
- Temas detectados automaticamente: 

## Fuentes

- [PSI-39_Raw Data_SampleHFDropletImage.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-39/Raw%20Data/PSI-39_Raw%20Data_SampleHFDropletImage.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_cf20cc3e0ddd9cb6959a, p. 1]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_cf20cc3e0ddd9cb6959a/p0001.jpg)

~~~~text
32 31 30 29 28 27 26 25 24 23 22 21 20 19 18 17 16 15 14 13 12
mm
20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35 36 37 38 39 40
mm

[Complemento OCR de elementos visuales]
mm
20 21 | 22 23 24 25 26 27 28 29 30 31 | 32 33 34 35 36 37 38 39 40
~~~~
