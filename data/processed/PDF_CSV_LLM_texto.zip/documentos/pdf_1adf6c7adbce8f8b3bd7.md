# 21137 daily test point log

- Identificador: pdf_1adf6c7adbce8f8b3bd7
- Investigaciones: PSI-159
- Tipo de documento: Raw Data
- Estado: processed
- Temas detectados automaticamente: hardware

## Fuentes

- [PSI-159_Raw Data_21137 daily test point log.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-159/Raw%20Data/PSI-159_Raw%20Data_21137%20daily%20test%20point%20log.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_1adf6c7adbce8f8b3bd7, p. 1]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_1adf6c7adbce8f8b3bd7/p0001.jpg)

~~~~text
ACME Daily Test Point Log | 5/17/2021
Downlink Data Limit (MB) = 127,000 | Total =
103,043
Test Point Name Script Aborts | IPSU1/HiBMS | ACME Camera | Intensified Camera
all | Downlink
(enter | test | Before IPSUs | Archived | Archived | Archived
Data (MB)
points) | Open | Images | D/L? | Images | D/L? | Images | D/L?
21137A1 | 457 | 1483
5,576
21137A2 | 641 | 1973
7,511
21137A3 | 1526 | 3966
15,761
2113781 | 1354 | 3796
14,787
2113782 | 1567 | 4353
16,997
21137A4 | 606 | 1828
6,993
21137A5 | 676 | 1991
7,661
21137A6 | 490 | 1621
6,068
21137A7 | 582 | 1855
7,004
21137D1 | 326 | 1177
4,323
21137D2 | 427 | 1413
5,289
21137C1 | 315 | 1446
5,072
Date:
~~~~
