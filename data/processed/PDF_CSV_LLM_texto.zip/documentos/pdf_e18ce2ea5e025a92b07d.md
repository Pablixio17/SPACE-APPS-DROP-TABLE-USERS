# FLEX-1231_Summary_1

- Identificador: pdf_e18ce2ea5e025a92b07d
- Investigaciones: PSI-39
- Tipo de documento: Analyzed Data
- Estado: processed
- Temas detectados automaticamente: oxygen, cool_flames, droplets

## Fuentes

- [PSI-39_Analyzed Data_FLEX-1231_Summary_1.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-39/Analyzed%20Data/PSI-39_Analyzed%20Data_FLEX-1231_Summary_1.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_e18ce2ea5e025a92b07d, p. 1]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
1.0
0.8
0.6
0.4
0.2
0.0
( D / D0 )2
0.0 0.5 1.0 1.5 2.0 2.5 3.0
t / D
0
2
 ( s / mm
2
 )
20
15
105
Df ( mm ) , Df / Dd
1
23456
10
23456
Flame Radiance ( W )
30
25
20
15
1050
Df, cool ( mm )
10
0
10
1
10
2
10
3
10
4
Peak Cool Flame Grayscale
A
B Thu, Apr 6, 2017
FLEX-1231
F095A06
P = 2256.819 mmHg YO2 = 0.170 YN2 = 0.830 YCO2 = 0.000 YHe = 0.000
Dodecane D0 = 4.141 mm Dext = 4.111 mm kavg = 0.490 mm
2
/sec
 Droplet History
 Hot-Flame Diameter
 Hot-Flame FSR
 Cool Flame Diameter (FWHM)
 Cool Flame Diameter (peak-peak) 
 Cool Flame Grayscale
~~~~

### Pagina 2

Cita: [pdf_e18ce2ea5e025a92b07d, p. 2]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_e18ce2ea5e025a92b07d/p0002.jpg)

~~~~text
44 40 36 32 28 24 20 16 12
mm
25 30 35 40 45 50 55
mm
B
44 40 36 32 28 24 20 16 12
mm
25 30 35 40 45 50 55
mm
A

[Complemento OCR de elementos visuales]
mm | mm
25 | 30 | 35 | 40 | 45 | 50 | 55 | 25 | 30 | 35 | 45 | 50 | 55
~~~~
