# ACME_ASGSR_20131107

- Identificador: pdf_26a57bbcfbc6f41e6647
- Investigaciones: PSI-20, PSI-22, PSI-23
- Tipo de documento: Presentations
- Estado: processed
- Temas detectados automaticamente: hardware, soot, electric_fields, oxygen, ignition, microgravity, extinction, smoke_detection, computational_models, pressure, droplets, operations

## Fuentes

- [PSI-20_Presentations_ACME_ASGSR_20131107.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-20/Presentations/PSI-20_Presentations_ACME_ASGSR_20131107.pdf)
- [PSI-22_Presentations_ACME_ASGSR_20131107 - Burner-Stabilized Gaseous Flames for the Combustion Integrated Rack.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-22/Presentations/PSI-22_Presentations_ACME_ASGSR_20131107%20-%20Burner-Stabilized%20Gaseous%20Flames%20for%20the%20Combustion%20Integrated%20Rack.pdf)
- [PSI-23_Presentations_ACME_ASGSR_20131107.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-23/Presentations/PSI-23_Presentations_ACME_ASGSR_20131107.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_26a57bbcfbc6f41e6647, p. 1]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
www.nasa.gov 1
Burner-Stabilized Gaseous Flames 
for the Combustion Integrated Rack
29th Annual Meeting of the
American Society for Gravitational and Space Research
and
5th International Symposium for Physical Sciences in Space
Dennis P. Stocker1, Fumiaki Takahashi2, and J. Mark Hickman1
1NASA Glenn Research Center, Cleveland, Ohio
2National Center for Space Exploration Research, NASA Glenn, Cleveland, Ohio
~~~~

### Pagina 2

Cita: [pdf_26a57bbcfbc6f41e6647, p. 2]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_26a57bbcfbc6f41e6647/p0002.jpg)

~~~~text
National Aeronautics and Space Administration
www.nasa.gov
Outline
• Background
– Why combustion?
– Burner-stabilized 
gaseous flames
• ACME
– Science
– Hardware
– Status
• Questions
2

[Texto OCR de la imagen]
National Aeronautics and Space Administration
Outline
Background
Why combustion?
Burner-stabilized
gaseous flames
, ACME
Science | etional
Space
Hardware
Status
Questions
Advanced Combustion via Microgravity Experiments
www.nasa.gov 2
~~~~

### Pagina 3

Cita: [pdf_26a57bbcfbc6f41e6647, p. 3]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
www.nasa.gov
Why Study Combustion?
• Energy
– While we might associate fire with the Stone Age, we still make 
extensive use of combustion in our daily lives.
• Electricity – about 70% in the U.S. from combustion
• Heating of buildings, water, food, and in manufacturing processes
• Transportation
– Our reliance on imported fuel contributes to our national trade 
deficit and affects our national security.
• Environment
– Combustion is a source of greenhouse gases.
– Soot contributes to global warming and is a health problem.
• Fire Safety
Given its pervasive use with annual U.S. fuel costs on the order 
of a trillion dollars even small improvements in combustion 
technology can significantly reduce fuel needs and 
pollution production!
Background > Science > Hardware > Status 3
~~~~

### Pagina 4

Cita: [pdf_26a57bbcfbc6f41e6647, p. 4]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
www.nasa.gov
Burner-Stabilized Gaseous Flames
5 previous space experiments
• LSP: Laminar Soot Processes
– PI: G.M. Faeth (U. Michigan)
– Combustion Module
– STS-83 and STS-94 (1997), STS-107 (2003)
• TGDF: Turbulent Gas-jet Diffusion Flames
– PI: M.Y. Bahadori (SAIC)
– Get Away Special Canister (GAS can)
– STS-87 (1997)
• ELF: Enclosed Laminar Flames
– PI: L.-D. Chen (U. Iowa)
– Middeck Glovebox (MGBX)
– STS-87 (1997)
• SPICE: Smoke Point In Coflow Experiment
– PI: D.L. Urban (NASA Glenn) - initially G.M. Faeth
– Microgravity Science Glovebox (MSG)
– ISS Expeditions 18-19, 30 (2009, 2012)
• SLICE: Structure & Liftoff In Combustion Experiment
– PI: M.B. Long (Yale U.)
– Microgravity Science Glovebox (MSG)
– ISS Expedition 30 (2012)
Roger Crouch with CM 4 -1 on STS-83 (top), Michael Barratt with SPICE (bottom) ISS Space Shuttle
~~~~

### Pagina 5

Cita: [pdf_26a57bbcfbc6f41e6647, p. 5]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
www.nasa.gov 5
Advanced Combustion
via Microgravity Experiments
• Conduct 5+ distinct experiments using a single modular insert for 
the Combustion Integrated Rack (CIR) on the ISS
– The only existing insert (MDCA) is for the FLEX droplet combustion experiments
Koichi Wakata with MDCA in CIR (left), ISS (right)
~~~~

### Pagina 6

Cita: [pdf_26a57bbcfbc6f41e6647, p. 6]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
www.nasa.gov
5 Current ACME Experiments
11 Investigators and 7 Universities (+ NASA Glenn)
• BRE
– Burning Rate Emulator
– PIs: James G. Quintiere, Peter B. Sunderland (both U. Maryland) 
• CLD Flame
– Coflow Laminar Diffusion Flame
– PIs: Marshall Long, Mitchell Smooke (both Yale U.)
• E-FIELD Flames
– Electric-Field Effects on Laminar Diffusion Flames
– PI: Derek Dunn-Rankin (UC Irvine)
• Flame Design - a novel approach to clean, efficient diffusion flames
– PIs: Richard L. Axelbaum (Washington U. in St. Louis), Beei-Huan 
Chao (U. Hawaii), Peter B. Sunderland (U. Maryland), David L. 
Urban (NASA Glenn)
• s-Flame
– Structure and Response of Spherical Diffusion Flames
– PIs: C.K. Law (Princeton U.), Stephen D. Tse (Rutgers U.), Kurt R. 
Sacksteder (NASA Glenn)
Background > Science > Hardware > Status 6
~~~~

### Pagina 7

Cita: [pdf_26a57bbcfbc6f41e6647, p. 7]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
www.nasa.gov 7
BRE
• Burning Rate Emulator
– Jim Quintiere & Peter Sunderland (both U. Maryland)
• Concept
– Flat-plate burner with gaseous fuel flow simulating the 
combustion of condensed fuels
– Heat flux to the burner is measured, where the flux 
vaporizes condensed-phase fuels
– Fuels to be simulated include paper, plastic, alcohols
• Goals 
– Quantify the ignition and extinction behavior of 
condensed fuels in microgravity.
– Quantify the effects of burning at enhanced oxygen 
conditions in microgravity.
• Why?
– Spacecraft fire prevention through improved 
assessment for materials selection
Background > Science > Hardware > Status
prototype burner 75 C ambient 200 C
0g C2H4 flames as a
function of the heated
burner temperature.
~~~~

### Pagina 8

Cita: [pdf_26a57bbcfbc6f41e6647, p. 8]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
www.nasa.gov 8
CLD Flame
• Coflow Laminar Diffusion Flame
– Marshall Long & Mitchell Smooke (both Yale U.)
• Concept
– Lifted coflow (2D) flame, so little/no heat loss to burner
• enabling improved modeling of the flame
• Goals 
– Generation of modified kinetic mechanisms for 
hydrocarbon fuels that are able to model effectively 
diffusion flame structure under a larger parameter 
range than existing mechanisms.
– Development of submodels for soot formation that are 
capable of predicting both high and low soot loading 
levels in hydrocarbon flames of various fuels.
• Why?
– Improved design capability through validation of 
combustion models over wider parameter range
Background > Science > Hardware > Status
Attached
100% CH4 
flame on a 
1.6-mm ID 
burner tube, 
with soot 
temperature, 
soot volume 
fraction 
below.
~~~~

### Pagina 9

Cita: [pdf_26a57bbcfbc6f41e6647, p. 9]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
www.nasa.gov 9
E-FIELD Flames
• Electric-Field Effects on Laminar Diffusion Flames
– Derek Dunn-Rankin (UC Irvine), Felix Weinberg 
(Imperial College, London), Zeng-Guang Yuan (NCSER 
at NASA Glenn)
• Concept
– Gas-jet or coflow (2D) flame with high-voltage mesh (up 
to ±10 kV) electrode above (downstream of) burner
• Goal
– Understand chemi-ionization behavior and the resulting 
ion driven winds sufficiently well so that electrical 
properties of flames can be used to characterize (by 
monitoring ion current) and control them (via direct 
chemical or local convective influences).
• Why?
– Advanced control capability enabling improved 
combustion performance
1g, 0 kV, gas-jet
0g, -0.6 kV, gas-jet
0g, 0kv, 24 cm/s coflow
Background > Science > Hardware > Status
~~~~

### Pagina 10

Cita: [pdf_26a57bbcfbc6f41e6647, p. 10]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
www.nasa.gov 10
Flame Design • A novel approach to clean, efficient diffusion flames
– Rich Axelbaum (Washington U., St. Louis), Beei￾Huan Chao (U. Hawaii), Peter Sunderland (U. 
Maryland), David L. Urban (NASA Glenn)
• Concept
– Spherical (1D) flame with nitrogen exchange
• Goals 
– Evaluate the effects of flame structure on soot 
inception and flame extinction
– Obtain a correlation of sooting limits with 
stoichiometric mixture fraction, Zst, and adiabatic 
temperature, Tad
– Determine the importance of gas-phase oxidation on 
soot inception for high Zst flames
– Demonstrate the existence of steady spherical flames
– Identify pseudo-flammability limits for diffusion flames 
in terms of Zst and Tad
• Why?
– To reduce soot and NOx through nitrogen exchange
18% 
C2H4 
into
27%
O2
18%
C2H4 
Into
28%
O2
100% 
O2
into 
12%
C2H4 
100%
O2 
into
13% 
C2H4 
Background > Science > Hardware > Status
~~~~

### Pagina 11

Cita: [pdf_26a57bbcfbc6f41e6647, p. 11]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
www.nasa.gov 11
s-Flame
• Structure and Response of Spherical Diffusion Flames
– C.K. Law (Princeton U.), Stephen D. Tse (Rutgers U.), Kurt R. 
Sacksteder (NASA Glenn)
• Concept
– Spherical (1D) flame stabilized on a porous burner
• Goals
– Use spherical diffusion flames in ISS environment to:
• obtain experimental data in simple, well-defined flow fields
• understand various key elemental diffusion flame processes
– Compare data with independent computational simulation 
including detailed chemistry and transport to improve the 
accuracy and comprehensiveness of these descriptions
• Why?
– Improvements in the design of practical, high-efficiency, low￾emission combustion systems on Earth
flame 
evolution 
with time
Background > Science > Hardware > Status
~~~~

### Pagina 12

Cita: [pdf_26a57bbcfbc6f41e6647, p. 12]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
www.nasa.gov
ACME Approach
• ACME is not a technology demonstration, but is 
seeking to improve life on Earth via the path below.
12
Improved understanding of 
combustion fundamentals
Improved numerical models 
of combustion processes
Improved design tools
Improved practical 
combustion devices
ACME
from
ACME
Background > Science > Hardware > Status
Numerical prediction of flame structure
~~~~

### Pagina 13

Cita: [pdf_26a57bbcfbc6f41e6647, p. 13]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
www.nasa.gov
Similarities of Current Experiments
• Gaseous flame
– fuel is a gas, e.g., hydrogen, methane, ethylene
• Laminar flame
– flow is smooth and not turbulent (w/o vortices)
– but turbulent flames can be studied with ACME
• Diffusion, i.e., non-premixed, flame
– fuel and oxidizer (e.g., air) are on opposite sides of 
the reaction sheet 
– but premixed flames can be studied with ACME
• 1D or 2D flame
– but 3D flames can be studied with ACME
13
F
O2
O2
O2 O2
O2
F
F F
F
Normal flame Inverse flame
Background > Science > Hardware > Status
~~~~

### Pagina 14

Cita: [pdf_26a57bbcfbc6f41e6647, p. 14]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
www.nasa.gov 14
ACME Hardware
burners avionics package
modular insert
gas bottles and filters
digital 
color 
camera
Background > Science > Hardware > Status
~~~~

### Pagina 15

Cita: [pdf_26a57bbcfbc6f41e6647, p. 15]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_26a57bbcfbc6f41e6647/p0015.jpg)

~~~~text
National Aeronautics and Space Administration
www.nasa.gov
ACME Insert
3 Photomultiplier Tubes (PMTs)
Igniter, hot-wire, retracting
Electrode, mesh
Camera, color, analog
Radiometer array (6 thermopiles)
Thin-Filament Pyrometry (TFP) array
Burner
Thermocouples
3 Mass Flow 
Controllers 
(MFCs)
Background > Science > Hardware > Status

[Texto OCR de la imagen]
National Aeronautics and Space Administration
3 Photomultiplier Tubes (PMTs)
Thin-Filament Pyrometry (TFP) array
Thermocouples
3 Mass Flow
Controllers
(MFCs)
Camera, color, analog
Radiometer array (6 thermopiles)
Electrode, mesh
Burner
Igniter, hot-wire, retracting
Background > Science > Hardware > Status | www.nasa.gov
~~~~

### Pagina 16

Cita: [pdf_26a57bbcfbc6f41e6647, p. 16]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_26a57bbcfbc6f41e6647/p0016.jpg)

~~~~text
National Aeronautics and Space Administration
www.nasa.gov
• Delivers 3 gases from CIR to 
the chamber or burner
• fuel (2 slpm max in N2 basis)
• oxygen/inert mix or diluent 
(e.g., He or CO2)
• nitrogen (from ISS)
• Mass flow controllers (crew 
swappable to vary flow ranges)
Gas Flow System
Background > Science > Hardware > Status

[Texto OCR de la imagen]
National Aeronautics and Space Administration
Oxygen Manifold 2 | Delivers 3 | from CIR to
gases
Static
Diluent Manifold 1 | the chamber | burner
Mixer | or
anifold #3 Gas Bottle Line Not Used
ISS Nafrom GIS
ypass Li | • | fuel | in N2
(2 slpm max | basis)
PR A1 | Fuel Manifold 4
CIR FOMA | • | oxygen/inert mix or diluent
OD13 | QD12 | QD11
(e.g., He or C02)
Interface Re | rce Ring (IRR)
• | nitrogen (from ISS)
QD A1 | QD A4
ACME
FLOW System | Mass flow controllers
(crew
QDA8
QDA9 | swappable to | flow ranges)
vary
MFC A1 | MFC A2 | MFC A3
SVAI | SV A2 | SV A3
to | to | to
Chamber | Chamber | Chamber
SV A4 | SV A5 | SV A6 | SV A7 | SV A8 | SV A9
To Outer Coflow
To Inner Cofiow
To Gas-Jet Burner
To Spherical Bumer
Background > Science > Hardware > Status | www.nasa.gov
~~~~

### Pagina 17

Cita: [pdf_26a57bbcfbc6f41e6647, p. 17]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
www.nasa.gov
Burners & Igniter
• Four types of burners are planned for the first 5 experiments:
• gas-jet burners 0.4, 0.8, 1.3, 1.6, 2.1, 2.7 and 3.2 mm ID
• spherical burners 0.25, 0.375, 0.5 inch diameter, porous sintered metal
• coflow burner 2.1-mm ID inner tube, 25-mm ID outer tube 
• BRE burners 2.5, 5 cm diameter, porous (with heat flux transducers)
• Thermocouple for surface temperature on most burners
• Burners will be electrically isolated
• Hot-wire igniter, retracting, similar to that in use for MDCA
• Igniter tips are replaceable, e.g., to match the burner type/size
gas-jet burner
spherical 
burner
Igniter, hot-wire, 
retracting
Background > Science > Hardware > Status
coflow burner BRE burner
~~~~

### Pagina 18

Cita: [pdf_26a57bbcfbc6f41e6647, p. 18]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
www.nasa.gov
Electric Field
• ±10kV at copper mesh above (i.e., 
downstream of) isolated burner
• Ion current through flame is 
determined from Ohm’s law (I=V/R) 
and a measurement of the voltage 
difference across a shunt resistor 
(in series with the flame)
• copper mesh screen (removable)
• high-voltage source (removable)
• passive electronics (fixed)
H.V.
Chamber
Nozzle
Mesh 
electrode
Shunt for current 
measurement, Rs
Low voltage input, e.g., 0-24VDC
Gas supply 
tubes
Insulator
Coflow burner 
with flame
Electrode mesh
Background > Science > Hardware > Status
~~~~

### Pagina 19

Cita: [pdf_26a57bbcfbc6f41e6647, p. 19]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
www.nasa.gov 19
Basic Imaging • Color Imaging for Ops
– Analog color camera 
(removable) with a 45-degree 
turning mirror
– LEDs for optional illumination
• Color Imaging for Data
– Gig-E color camera, 1.4 
megapixel, 12 bit, 30 fps with 
motorized control of both 
zoom & iris
– 3 optional filters including a 
blue-green BG-7 filter (to 
balance light intensity for 
pyrometry), 430 and 450-nm 
for CH* (incl. soot subtraction)
• Ultraviolet (UV) Imaging
– Existing LLL-UV camera 
equipped with a 310-nm filter 
for imaging OH*
– Field of view (FOV) options: 
50-mm and 80-mm diameter
Background > Science > Hardware > Status
Color 
Camera
Motorized
Zoom Lens
Electronics
Enclosure
45° Fold
Mirror
Filters
(swap via 
rotating 
barrel)
~~~~

### Pagina 20

Cita: [pdf_26a57bbcfbc6f41e6647, p. 20]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
www.nasa.gov 20
Advanced Imaging • Pyrometry for Hot Sooty and 
Soot-Free Regions
– Determine temperature distribution from 
broadband thermal radiation using an 
existing HiBMs camera with liquid￾crystal tunable filter
– Thin-Filament Pyrometry (TFP) to 
determine temperature profiles from the 
broadband thermal radiation, where the 
spectrum is indicative of the fiber 
temperature. Array of 15-micron 
oxidized SiC fibers stretched across the 
flame with motor to allow for scanning or 
removal of the fibers from the flame.
– Field of view (FOV) options: 30-mm and 
50-mm diameter
• Soot Volume Fraction
– Existing CIR illumination package 
(based on 653-nm laser diode) and a 
second HiBMs camera
– Field of view (FOV) options: 30-mm, 50-
mm, and 90-mm diameter
TFP Soot vol. fraction HiBMs camera
Soot pyrometry
Background > Science > Hardware > Status
~~~~

### Pagina 21

Cita: [pdf_26a57bbcfbc6f41e6647, p. 21]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
www.nasa.gov
Emission Measurements
• 3 Photomultiplier Tubes (PMTs) • Broadband, OH*, CH*
• Array of 6 thermopile detectors • Broadband thermal radiation
• Wide and narrow angle
• Exchangeable
1
5
3 7
Radiometers
Color
Camera
PMT
Background > Science > Hardware > Status
60° offset, 120° FOV, 
Type: S60M
Center, 120° FOV, Type: 2M
30 mm Offset, 2mm Spot FOV, Type: 2M
-30 mm Offset, 2mm Spot FOV, Type: 2M
60 mm Offset 2mm Spot FOV, Type: 2M
-60 mm Offset, 2mm Spot FOV, Type: 2M
~~~~

### Pagina 22

Cita: [pdf_26a57bbcfbc6f41e6647, p. 22]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
www.nasa.gov
Optical 
Layout
1
5
3 7
Radiometers
Color
Camera
Single
IPSU
LLL-UV
Stacked 
2 IPSUs
Illumination
HiBMs (1 & 2)
PMT
Analog
Background > Science > Hardware > Status
~~~~

### Pagina 23

Cita: [pdf_26a57bbcfbc6f41e6647, p. 23]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_26a57bbcfbc6f41e6647/p0023.jpg)

~~~~text
National Aeronautics and Space Administration
www.nasa.gov 23
Additional Diagnostics
• Heat Flux (to BRE burners)
• Temperature
– Burner (with 1-2 TCs)
– Far-Field
• 2 fixed thermocouples (TCs)
• rake with 4 TCs is crew removable or 
swappable for different TC positions
• Ion Current (electric field tests only)
• Post-Test Gas Composition
MDCA and CIR
Thermocouple 
rake and 2 fixed 
thermocouples

[Texto OCR de la imagen]
National Aeronautics and Space Administration
Additional Diagnostics
Heat Flux (to BRE burners)
Temperature
Burner (with 1-2 TCs)
Far-Field
• 2 fixed thermocouples (TCs)
rake with 4 TCs is crew removable or
swappable for different TC positions
Ion Current (electric field tests only)
Post-Test Gas Composition
Thehnocouple
rake and 2 fixed
a-thermocouples
MDCA and CIR | www.nasa.gov 23
~~~~

### Pagina 24

Cita: [pdf_26a57bbcfbc6f41e6647, p. 24]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_26a57bbcfbc6f41e6647/p0024.jpg)

~~~~text
National Aeronautics and Space Administration
www.nasa.gov 24
Monitoring Measurements
• Chamber Pressure
• Oxygen Concentration
• Gas Flow Rates
• Burner Pressure Differential
• Electrical Potential
– for tests with the electric field
• Acceleration
These measurements are required to 
verify boundary & initial conditions and 
thus enable modeling and analysis.
Michael Barratt with MDCA in CIR

[Texto OCR de la imagen]
National Aeronautics and Space Administration
Monitoring Measurements
Chamber Pressure
Oxygen Concentration
Gas Flow Rates
Burner Pressure Differential
Electrical Potential
for tests with the electric field
Acceleration
These measurements are required to
verify boundary & initial conditions and
thus enable modeling and analysis.
Michael Barratt with MDCA in CIR | www.nasa.gov 24
~~~~

### Pagina 25

Cita: [pdf_26a57bbcfbc6f41e6647, p. 25]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
www.nasa.gov 25
Nominal Operational Sequence
• Flow > Ignite > Measure > Extinguish 
– Initiate burner flows at ignition condition 
– Ignite flame
• Wait for flame to stabilize
– If needed, adjust flows to (initial) test condition 
• Wait for flame to stabilize
– If desired:
• increase or decrease burner flow(s)
– to vary flow/velocity or concentration
• activate and adjust electric field
• translate TFP array
– Stop burner flows
• per extinction detection, test duration, etc.
• Control can be automated or “manual”
Nicole Stott with CIR
~~~~

### Pagina 26

Cita: [pdf_26a57bbcfbc6f41e6647, p. 26]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_26a57bbcfbc6f41e6647/p0026.jpg)

~~~~text
National Aeronautics and Space Administration
www.nasa.gov 26
ACME Status
• Schedule
• 2013 (Nov.) Critical Design Review (CDR)
• 2015 Hardware ready for launch
• 2016-2018 ISS ops
Mike Fossum with CIR (left), Satoshi Furukawa with CIR (right)

[Texto OCR de la imagen]
National Aeronautics and Space Administration
A | ACME Status
Schedule
2013 (Nov.) | Critical Design Review (CDR)
2015 | Hardware ready for launch
2016-2018 | Iss ops
Mike Fossum with CIR (left), Satoshi Furukawa with CIR (right) | www.nasa.gov 26
~~~~

### Pagina 27

Cita: [pdf_26a57bbcfbc6f41e6647, p. 27]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_26a57bbcfbc6f41e6647/p0027.jpg)

~~~~text
National Aeronautics and Space Administration
Mike Fossum with MDCA in CIR | www.nasa.gov 27
~~~~

### Pagina 28

Cita: [pdf_26a57bbcfbc6f41e6647, p. 28]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
www.nasa.gov 28
Acknowledgements
• NASA Glenn (Cleveland, OH)
• ISS Research Program Manager Fred Kohl
• ISS Research Project Manager Tom St. Onge
• R&T: Microgravity Combustion David Urban
• Drop Facilities Manager Eric Neumann
• NCSER (at NASA Glenn)
• Imaging Jay Owens
• ZIN Technologies, Inc. (Cleveland, OH)
• ACME Lead Brian Borowski
• Diagnostics Steve Lawn
• Electrical/Electronics Tim Gobeli
• Mechanical Adrian Drake
• Software Mike Medved
• Systems Chris Mroczka
~~~~
