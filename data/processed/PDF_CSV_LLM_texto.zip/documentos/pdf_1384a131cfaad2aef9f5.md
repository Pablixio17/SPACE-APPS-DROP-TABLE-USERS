# 21277 test parameter notes

- Identificador: pdf_1384a131cfaad2aef9f5
- Investigaciones: PSI-159
- Tipo de documento: Raw Data
- Estado: processed
- Temas detectados automaticamente: oxygen, ignition, extinction, hardware, operations

## Fuentes

- [PSI-159_Raw Data_21277 test parameter notes.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-159/Raw%20Data/PSI-159_Raw%20Data_21277%20test%20parameter%20notes.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_1384a131cfaad2aef9f5, p. 1]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_1384a131cfaad2aef9f5/p0001.jpg)

~~~~text
testpointName | 21277A1
dataCameraPrelgnifionExposureUs | 1000000
dataCameraTestExposureUs | 100000
analogCameraShutter | 2
uselntensifiedCamera | 1
intensifierlgnitionGain | 20000
intensifierTestGain | 60000
prelgnitionlmageTimeSec
postFlamelmagingTimeSe | 5
useDataCameraAutoGain
autoGainTolerancePercen | 5
autoGainMaxD | 33
autoGainMinDb
autoGainOutliers
autoGainRatePercen | 100
autoGainTargetPercen | 50
rampDataCameraGain
dataCameraGain1d | 0
dataCameraGain2dB
dataCameraGain3dB | 0
dataCameraHoldTime1Sec
dataCameraHoldTime2Sec
dataCameraRamp1t02TimeSe | 5
dataCameraRamp2t03TimeSec | 5
dataCameraManualGain | 33
useBracketedExposure
bracketinglmagesPerExposur | 1
bracketingNumberOfExposures | 4
bracketingExposureStartUsec | 50000
bracketin ExposureMultiplierTimes100 | 200
igniterStartPosition | 2170
igniterEndPosition | 2290
igniterVe'ocityCountsPerSec | 80
igniterP reheatPowe | 3
igniterPreheatDurationMs | 1000
igniterlgnitionPowe | 4
igniterlgnitionDurationMs | 3000
igniterDelayBeforeRetractMs | 1800
igniterRetractVelocityCountsPerSe | 500
pmt1Gain | 10
pmt2Gain | 8
pmt3Gain | 10
fiberlgnitionPosition
fiberTestPosition
fiberM0veDuringTest
fiberSegmentDistance | 100
fiberVelOcity | 3000
fiberH01dDurationSe | 1
fiberCycles | 100
useF0ma | 1
flowTimeou | 45
oxidizerFlowlgnitionDeltaMs | 2000
nitrogenFlowlgnitionDeltaMs
StabilizationTime1
stabilizationTime2Se | 5
oxidizerlgniti0nFlowSlpm | 0.295
nitrogenlgnitionFlowSlpm
oxidizerTestFlOw1Slpm | 0.295
nitrogenTestFlow1Slpm
oxidizerTestFlow2Slpm
nitrogenTestFlow2Slpm
oxidizerTestFlow3Slpm
nitrogenTestFlow3Slpm
constantFlowTime1Se | 15
constantFlowTime2Se
constantFlowTime3Sec
ignitionTOTestRampTimeSe
testFlOwRamp1T02Time
testFlowRamp2T03TimeSec
postExtinctionDelaySec | 3
postExtinctionF10wChangeOxidizerPercent
postExtincti0nFlowChangeNitrogenpercen
postExtinctionFlowChangeRampTimeSe
postExtinctionFlowChangeHoldSec
~~~~

### Pagina 2

Cita: [pdf_1384a131cfaad2aef9f5, p. 2]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_1384a131cfaad2aef9f5/p0002.jpg)

~~~~text
testpointName | 21277B1
dataCameraPrelgnitionExposureUs | 1000000
dataCameraTestExposureU | 100000
analogCameraShutte
usel ntensifiedCamera | 1
intensifierlgnitionGain | 20000
intensifierTestGain | 60000
preignitionlmageTimeSec
postFlamelmagingTimeSe | 5
useDataCameraAutoGain
autoGainTolerancePercen
autoGainMaxDb | 33
autoGainMinD
autoGainOutliers
autoGainRatePercen | 100
autoGainTargetPercen | 50
rampDataCameraGain
dataCameraGain1dB
dataCameraGain2dB
dataCameraGain3dB
dataCameraHoldTime1Se
dataCameraHOldTime2Se
dataCameraRamp1t02TimeSec
dataCameraRamp2t03TimeSec | 5
dataCameraManualGain
useBracketedExposures | 1
bracketinglmagesPerExposur | 1
bracketingNumberOfExposures
bracketingExposureStartUsec | 50000
bracketingExposureMultiplierTimes100 | 200
igniterStartPosition | 2170
igniterEndPOSitiOn | 2290
igniterVelocityCountsPerSe | 80
igniterPreheatPowe | 3
igniterPreheatDurationMs | 1000
igniterlgnitionpower
igniterlgnitionDurationMs | 3000
igniterDelayBeforeRetractMs | 1800
igniterRetractVeiocityC0untsPerSe | 500
pmt1Gain | 10
pmt2Gain | 8
pmt3Gain | 10
fiber'gnitionPosition | 10000
fiberTestPOSitiOn | 17000
fiberMoveDuringT
fiberSegmentDistance | 100
fiberVelocity | 3000
fiberHoldDurationSe
fiberCycles | 100
useFoma
flowTimeoutSec | 45
oxidizerFlowlgnitionDeltaM
nitrogenFlOwlgnitionDeltaM
stabilizationTime1Sec
stabilizationTime2Sec
oxidizerlgnitionFlowSlpm | 0.295
nitrogenlgnitionFlowSlpm
oxidizerTestFlow1Slpm | 0.295
nitrogenTestFlow1Slpm
oxidizer TestFlOw2Slpm
nitrogenTestF10w2Slpm
OxidizerTestFlow3Slpm
nitrogenTeStFlow3Slpm
constantFlowTime1Se | 15
constantFlowTime2Sec
constantFlowTime3Sec
ignitionToTestRampTimeS
testFlowRamp1T02Time
testFlowRamp2T03TimeS
postExtinctionDelaySec
postExtinctionFlowChangeOxidizerPercent
postExtinctionFlowChangeNitrogenPercent
postExtinctionFlowChangeRampTimeS
postExtinctionFlowChangeHoidSec
~~~~

### Pagina 3

Cita: [pdf_1384a131cfaad2aef9f5, p. 3]. Metodo: windows_ocr_grid_removed.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_1384a131cfaad2aef9f5/p0003.jpg)

~~~~text
testpointNam | 21277C1
dataCameraprelgnitionExposureUs | 1000000
.1
dataCameraTestExposureU | 100000
analogCameraShutte | 2
uselntensifiedCamera | 1
intensifierlgnitionGain | 20000
intensifierTestGain | 60000
prelgnitionlmageTimeSe
postFlamelmagingTimeSe | 5
useDataCameraAutoGain
autoGainTolerancePercen | 5
autoGainMaxDb | 33
autoGainMinDb
autoGainOutliers
autoGainRatePercen | 100
autoGainTargetPercent | 50
rampDataCameraGain | 0
dataCameraGain1dB
dataCameraGain2dB
dataCameraGain3dB
dataCameraHoldTime1Se
dataCameraHoldTime2Sec
dataCameraRamp1t02TimeSe | 5
dataCameraRamp2t03TimeSec | 5
dataCameraManuaJGainl | 33
useBracketedExposures
bracketinglmagesPerExposur | 1
bracketingNumberOfExposures
bracketingExposureStartUsec | 50000
bracketingExposureMultiplierTimes1 | 200
igniterStartPosition | 2170
igniterEndPosition | 2290
igniterVelocityCountsPerSe | 80
igniterPreheatPowerV | 3
igniterPreheatDurationMs | 1000
igniterlgniti0nPowe | 4
igniterlgnitionDurationMs | 3000
igniterDelayBeforeRetractMs | 1800
igniterRetractVelocityCou ntsPerSec | 500
pmt1Gain | 10
pmt2Gain | 8
pmt3Gain | 10
fiberlgnitionPosition
fiber TestPositi0
fiberMoveDuringTes
fiberSegmentDistance | 100
fiberVelocity | 3000
fiberHoldDurationSec | 1
fiberCycl | 100
useFoma | 1
flowTimeoutSec | 45
oxidizerFlowlgnitionDeltaM
nitrogenFlowlgnitionDeltaMs
stabilization TimelSec
stabilizationTime2Sec | 5
Oxidizerlgniti0nF10wSlpm | 0.295
nitrogenlgnitionFlowSlpm
Oxidizer TestFlOw1Slpm | 0.295
nitrogenTestFlow1Slpm
oxidizerTestFlow2Slpm
nitrogenTestFlow2Slpm
oxidizerTeStFlow3Slpm
nitrogenTeStFlow3Slpm
constantF10wTime1Sec | 15
constantFlowTime2Se
constantFlowTime3Sec
ignitionToTestRampTimeSec
testF10wRamp1T02Time
testFlowRamp2T03TimeSec
postExfinctionDelaySeC | 3
postExtinctionFlowChangeOxidizerpercen
postExtinctionFiowChangeNitrogenpercent
postExtinctionFlowChangeRampTimeSe
postExtincti0nFlowChangeH01dSe
~~~~

### Pagina 4

Cita: [pdf_1384a131cfaad2aef9f5, p. 4]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_1384a131cfaad2aef9f5/p0004.jpg)

~~~~text
testpointNam | 21277D1
dataCameraPrelgnitionExposureUs | 1000000
dataCameraTestExposurelJs | 100000
analogCameraShutter | 2
uselntensifiedCamera | 1
intensifierlgnitionGain | 20000
intensifierTestGain | 60000
prelgnitionlmageTimeSec
postFlamelmagingTimeSec | 5
useDataCameraAut0Gain | 0
autOGainT0ierancePercen | 5
autoGainMaxDb | 33
autoGainMinD
autoGainOutiiers | o
autoGainRatePercent | 100
autoGainTargetPercen | 50
rampDataCameraGain
dataCameraGain1dB
dataCameraGain2dB
dataCameraGain3dB
dataCameraHoldTime1Sec
dataCameraHoldTime2Sec
dataCameraRamp1t02TimeS | 5
dataCameraRamp2t03TimeSe | 5
dataCameraManualGain
useBracketedExposure | 1
bracketinglmagesPerExposur | 1
bracketingNumberOfExposureS | 4
bracketingExposureStartUsec | 50000
bracketingExposureMultiplierTimes100 | 200
igniterStartP0sition | 2170
igniterEndPosifion | 2290
igniterVelocityCountsperSe | 80
igniterPreheatP0wer | 3
igniterPreheatDurationMs | 1000
igniterlgnitionPower | 4
igniterlgnitionDurationM | 3000
igniterDelayBeforeRetractMs | 1800
igniterRetractVelocityCountsPerSec | 500
pmt1Gain | 10
pmt2Gain | 8
pmt3Gain | 10
fiberlgniti0nPosition | 10000
fiberTestPosition | 17000
fiberM0veDuringTes
fiberSegmentDistance | 100
fiberVelocity | 3000
fiberHoldDuration | 1
fiberCycles | 100
useF0ma | 1
flowTimeoutSec | 45
oxidizerF10wlgnitionDeltaMs
nitrogenFlowlgnitionDeltaMs
stabilizationTime1
stabilizationTime2Se | 5
oxidizerlgnitionFlOwSlpm | 0.295
nitrogenlgnitionFlOwSlpm
oxidizer TestFlOw1Slpm | 0.295
nitrogenTestF10w1Slpm
Oxidizer TestFlow2Slpm
nitrogenTestFlow2Slpm
oxidizerTeStFiow3Slpm
nitrogenTestFEow3Slpm | o
constantFlowTime1Sec | 15
constantFlowTime2Sec
constantFlowTime3Se
ignitionToTestRampTimeSe
testFlowRamp1T02TimeSec
testF10wRamp2T03TimeSe
postExtinctionDelaySe | 3
postExtinctionF10wChangeOxidizerPercen
postExtinctionFlowChangeNitrOgenPercen
postExtinctionFlowChangeRampTimeSe
postExtinctionFlowChangeHoldSec
~~~~

### Pagina 5

Cita: [pdf_1384a131cfaad2aef9f5, p. 5]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_1384a131cfaad2aef9f5/p0005.jpg)

~~~~text
testpointName | 21277F1
dataCameraPrelgnitionExposureUs | 1000000
dataCameraTestExposurelJs | 100000
analogCameraShutte | 2
uselntensifiedCamera | 1
intensifierlgnitionGain | 20000
intensifierTestGain | 60000
preignitionlmageTimeSe
postFlamelmagingTimeSec | 5
useDataCameraAutoGain
autoGainTolerancePercent | 5
autoGainMaxD | 33
autoGainMinD
autoGainOutliers
autoGainRatePercen | 100
autoGainTargetPercen | 50
rampDataCameraGain
dataCameraGain1dB
dataCameraGain2dB
dataCameraGain3dB
dataCameraHoldTime1Sec
dataCameraHotdTime2Se
dataCameraRamp1t02TimeSec | 5
dataCameraRamp2t03TimeSec | 5
dataCameraManualGain | 33
useBracketedExposure
bracketinglmagesPerExposur | 1
bracketingNumberOfExposures | 4
bracketingExposureStartUsec | 50000
bracketingExposureMultiplierTimes100 | 200
igniterStartPosition | 2170
igniterEndPosition | 2290
igniterVelocityCountsperSe | 80
igniterPreheatP0wer | 3
igniterPreheatDurationMs | 1000
igniterlgnitionpowerv | 4
igniterlgnitionDurationMs | 3000
igniterDe'ayBeforeRetractMs | 1800
igniterRetractVelocityC0untsperSec | 500
pmt1Gain | 10
prnt2Gain | 8
pmt3Gain | 10
fiberlgnitionPosition
fiberTestPositio
fiberMoveDuringTes
fiberSegmentDistan | 100
fibervelocity | 3000
fiberH01dDurationSec | 1
fiberCycles | 100
useFoma | 1
flowTimeoutSec | 90
oxidizerF10wlgnitionDeltaMs
nitrogenF10wlgnitionDeltaMs
stabilizationTime1Sec
stabilizationTime2Se | 5
oxidizerlgnitionFIOwSIpm | 0.295
nitrogenlgnitionF10wSlpm
oxidizerTestFlow1Slpm | 0.295
nitrogenTestFlow1Slpm
oxidizer TestFlow2Slpm
nitrogenTestF10w2Slp
OxidizerTestF10w3Slpm
nitrogenTestHow3Slpm
constantFlowTime1Sec
constantFlowTime2Sec
constantFlowTime3S
ignitionTOTestRampTimeSec
testF10wRamp1T02TimeSe
testFlowRamp2T03TimeSe | 0
postExtinctionDelaySec | 3
postExtinctionFlowChangeOxidizerPerce
postExhnctionFlowChangeNitrogenPercent
postExtinctionFlowChangeRampTime
postExtinctionFiowChangeHoldSe
~~~~

### Pagina 6

Cita: [pdf_1384a131cfaad2aef9f5, p. 6]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_1384a131cfaad2aef9f5/p0006.jpg)

~~~~text
testpointName | 21277G1
dataCameraprelgnitionExposureUs
1000000
dataCameraTestExposureUs
100000
analogCameraShutte
2
uselntensifiedCamera
1
intensifierlgnitionGain
20000
intensifierTestGain
60000
preignitionlmageTimeSe
postHamelmagingTimeSec
5
useDataCameraAutoGain
autoGainTolerancepercen
5
autoGainMaxDb
33
autoGainMinDb
autoGainOutlier
autoGainRatePercen
100
autoGainTargetPercent
50
rampDataCameraGain
dataCameraGain1dB
dataCameraGain2dB
dataCameraGain3dB
dataCameraHoldTime1Se
dataCameraHoldTime2Sec
dataCameraRamp1t02TimeSe
5
dataCameraRamp2t03TimeSe
5
dataCameraManualGain
useBracketedExposures
1
bracketinglmagesPerExposur
1
bracketingNumberOfExposures
4
bracketingExposureStartUse
50000
bracketing ExposureMu ItiplierTimes1
200
igniterStartPosition
2170
igniterEndPosition
2290
igniterVe10CityCountsperSec
80
igniterPreheatpower
3
igniterPreheatDurationMs
1000
igniterlgniti0nPowerV
4
igniterlgnitionDurationMs
3000
igniterDelayBeforeRetractMs
1800
igniterRetractVelocityCountsPerSec
500
pmt1Gain | 10
pmt2Gain
8
pmt3Gain
10
fiberlgnitionposition
10000
fiber TestPosition
17000
fiberMoveDuringTes
fiberSegmentDistance
100
fiberVelocity
3000
fiberHoldDurati0nSe
1
fiberCycles | 100
useFoma
1
flowTimeou
90
oxidizerFlowlgniäonDe'taMs
nitrogenFlowlgnitionDeltaMs
stabilizationTime1
stabilizationTime2Sec
5
oxidizerlgnitionFlowSlpm
0.295
nitrogenlgnitionFlowSlpm
oxidizer TestF10w1Slpm
0.295
nitrogenTestHow1Slpm
oxidizerTeStFlow2Slpm
nitrogenTestFlow2Slpm
oxidizer TestFlOw3Slpm
nitrogenTestFlOw3Slpm
constantFlowTime1Sec
60
constantFlowTime2
constantF10wTime3Sec
ignitionTOTestRampTimeSec
testFlowRamp1T02TimeSec
testFlowRamp2T03TimeSe
postExtinctionDelaySec
3
postExtincti0nFlowChangeOxidizerPercen
postExtinctionFlowChangeNitrogenPercent
postExtinctionFlOWChangeRampTime
postExfinctionFlowChangeHoldSec
~~~~
