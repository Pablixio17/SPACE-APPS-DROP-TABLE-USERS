# 19182 flow traces etc

- Identificador: pdf_bdbccc6bc300c77ccabe
- Investigaciones: PSI-10
- Tipo de documento: Raw Data
- Estado: processed
- Temas detectados automaticamente: oxygen, pressure, ignition, hardware, extinction, operations

## Fuentes

- [PSI-10_Raw Data_19182 flow traces etc.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-10/Raw%20Data/PSI-10_Raw%20Data_19182%20flow%20traces%20etc.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_bdbccc6bc300c77ccabe, p. 1]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_bdbccc6bc300c77ccabe/p0001.jpg)

~~~~text
1
Test 19182G1 – successful ignition, run with stabilizationTime1Sec=20, 
stabilizationTime2Sec=1, nitrogenIgnitionFlowRateN2Slpm=0.182, 
fuelBottleTestFlowRateN2Slpm=0.104, nitrogenTestFlowRateN2Slpm=0.243, 
ignitionToTestRampTimeSec=4, constantFlowTimeSec=15
dataCamera Gain=24 db
ignition detection: triggerLevel=1 (instead of 1.5), averagingDurationSecs=0.5 
(instead of 0.05), igniterOffDelayMs=0 (instead of 500)
After test, 939 on lowest valve safety timer, 1121 psia in oxidizer bottle

[Texto OCR de la imagen]
Test 19182G1 — successful ignition, run with stabilizationTime1Sec=20,
stabilizationTime2Sec=1, nitrogenlgnitionFIowRateN2Slpm=O.182,
fuelBottIeTestFIowRateN2SIpm=O.104, nitrogenTestFIowRateN2SIpm=O.243,
ignitionToTestRampTimeSec=4, constantFIowTimeSec=15
dataCamera Gain—24 db
ignition detection: triggerLevel=1 (instead of 1.5), averagingDurationSecs=O.5
(instead of 0.05), igniterOffDelayMs=O (instead of 500)
Gas flow Charts
state EXPERIMENT | 2019-07-01 13:52: 19
system
System Temperaües
State | Operate | c | 0.000 | SLPM | R | -0.020 | SLPM | Ful | 20,000 | SLPM | cpu | 32.200
Set All Gains
Static Mixer Line | Board | 34.000
(MFCAI)
Set
Cube Sensor 1 | 33.548
ACME_FLO | ACME_FLO | IXER_FLOW
Set | 33.578
Cube Sensor 2
-0•01 | Set | 25
Drive
1 Mon Jul 2019 | Time (s)
TC200A act) | 23.200666 | 0.045
State | Operate | c | 0.000 | SLPM | R | 0002 | SLPM | scale | 2.000 | 22058970 | -0.001
22. 104234 | 0.871
Bypass(MFCA2)
Array
ACME_ | YPASS_FLOW | Rake: Fat
37. 150258 | 0.611
invabd-low | 0.029
invabd40w | 0.010 | mV
1 Mon Jul 2019 | Time (s)
38.862952 | 0.681
State | Operate | c | 0.000 | SLPM | R | -0.001 | SLPM | scale | 0.200 | SLPM
Fuel(MFCA3) | Eurne•: | (l'
313.720316 | 11.895
0.10
Cube Connecion | Connected
1 Mon Jul 2019 | Time (s)
Time Series Chart
Software to-ernonic | I Low
ACME Teleme | 0.00
ACME Teleme | 0.00
ACME Teleme | 0.00
2.5
Select Items | End Plotting
Clear Selections | Restart
Graph | L
01 | 2019 | 1 Mon Jul 2019 | Tune
After test, 939 on lowest valve safety timer, 1121 psia in oxidizer bottle
1
~~~~

### Pagina 2

Cita: [pdf_bdbccc6bc300c77ccabe, p. 2]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
2
Test 19182G2 – successful ignition, run with useBracketedExposures=TRUE, 
fiberIgnitionPosition=12000, fiberTestPosition=15300, 
fiberMoveDuringTest=TRUE, fiberVelocity=400, stabilizationTime1Sec=0, 
stabilizationTime2Sec=1, fuelBottleIgnitionFlowRateN2Slpm=0.091, 
nitrogenIgnitionFlowRateN2Slpm=0.212, fuelBottleTestFlowRateN2Slpm=0.091, 
nitrogenTestFlowRateN2Slpm=0.212, ignitionToTestRampTimeSec=0, 
constantFlowTimeSec=30
dataCamera Gain=0 db, dataCamera Focus=13000, dataCamera Iris=25000
ignition detection: triggerLevel=1 (instead of 1.5), averagingDurationSecs=0.5 
(instead of 0.05), igniterOffDelayMs=0 (instead of 500)
After test, 882 on lowest valve safety timer, 1126 psia in oxidizer bottle
~~~~

### Pagina 3

Cita: [pdf_bdbccc6bc300c77ccabe, p. 3]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
3
Test 19182G3 – successful ignition, minor (fiber & imaging) variant of G2, run 
with useBracketedExposures=TRUE, bracketingExposureStartUsec=40000,
fiberIgnitionPosition=12000, fiberTestPosition=15300, 
fiberMoveDuringTest=TRUE, fiberVelocity=500, stabilizationTime1Sec=0, 
stabilizationTime2Sec=1, fuelBottleIgnitionFlowRateN2Slpm=0.091, 
nitrogenIgnitionFlowRateN2Slpm=0.212, fuelBottleTestFlowRateN2Slpm=0.091, 
nitrogenTestFlowRateN2Slpm=0.212, ignitionToTestRampTimeSec=0, 
constantFlowTimeSec=30
dataCamera Gain=0 db, dataCamera Focus=13000, dataCamera Iris=45000
ignition detection: triggerLevel=1 (instead of 1.5), averagingDurationSecs=0.5 
(instead of 0.05), igniterOffDelayMs=0 (instead of 500)
After test, 827 on lowest valve safety timer, 1126 psia in oxidizer bottle
~~~~

### Pagina 4

Cita: [pdf_bdbccc6bc300c77ccabe, p. 4]. Metodo: native.

~~~~text
4
Test 19182G4 – aborted due to IPSU-1 error, run with 
dataCameraIgnitionExposureUs=dataCameraTestExposureUs=
dataCameraExtinctionExposureUs=100000, useBracketedExposures=FALSE, 
bracketingExposureStartUsec=40000, fiberIgnitionPosition=fiberTestPosition=0, 
fiberMoveDuringTest=FALSE, fiberVelocity=500, stabilizationTime1Sec=4, 
stabilizationTime2Sec=5, fuelBottleIgnitionFlowRateN2Slpm=0.078, 
nitrogenIgnitionFlowRateN2Slpm=0.182, fuelBottleTestFlowRateN2Slpm=0.078, 
nitrogenTestFlowRateN2Slpm=0.312, ignitionToTestRampTimeSec=20, 
constantFlowTimeSec=5
dataCamera Gain=24 db, dataCamera Focus=14600, dataCamera Zoom=25000, 
dataCamera Iris=0
ignition detection: triggerLevel=1 (instead of 1.5), averagingDurationSecs=0.5 
(instead of 0.05), igniterOffDelayMs=0 (instead of 500)
No snapshot of console data recorded because of abort
After test, 827 on lowest valve safety timer, 1129 psia in oxidizer bottle
Test 19182G5 – aborted due to IPSU-1 error, exact repeat of G4, run with 
dataCameraIgnitionExposureUs=dataCameraTestExposureUs=
dataCameraExtinctionExposureUs=100000, useBracketedExposures=FALSE, 
bracketingExposureStartUsec=40000, fiberIgnitionPosition=fiberTestPosition=0, 
fiberMoveDuringTest=FALSE, fiberVelocity=500, stabilizationTime1Sec=4, 
stabilizationTime2Sec=5, fuelBottleIgnitionFlowRateN2Slpm=0.078, 
nitrogenIgnitionFlowRateN2Slpm=0.182, fuelBottleTestFlowRateN2Slpm=0.078, 
nitrogenTestFlowRateN2Slpm=0.312, ignitionToTestRampTimeSec=20, 
constantFlowTimeSec=5
dataCamera Gain=24 db, dataCamera Focus=14600, dataCamera Zoom=25000, 
dataCamera Iris=0
ignition detection: triggerLevel=1 (instead of 1.5), averagingDurationSecs=0.5 
(instead of 0.05), igniterOffDelayMs=0 (instead of 500)
No snapshot of console data recorded because of abort
After test, 827 on lowest valve safety timer, 1129 psia in oxidizer bottle
~~~~

### Pagina 5

Cita: [pdf_bdbccc6bc300c77ccabe, p. 5]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
5
Test 19182G6 – successful ignition, repeat of G4-G5 (which both aborted), run 
with dataCameraIgnitionExposureUs=dataCameraTestExposureUs=
dataCameraExtinctionExposureUs=100000, useBracketedExposures=FALSE, 
bracketingExposureStartUsec=40000, fiberIgnitionPosition=fiberTestPosition=0, 
fiberMoveDuringTest=FALSE, fiberVelocity=500, stabilizationTime1Sec=4, 
stabilizationTime2Sec=5, fuelBottleIgnitionFlowRateN2Slpm=0.078, 
nitrogenIgnitionFlowRateN2Slpm=0.182, fuelBottleTestFlowRateN2Slpm=0.078, 
nitrogenTestFlowRateN2Slpm=0.312, ignitionToTestRampTimeSec=20, 
constantFlowTimeSec=5
dataCamera Gain=24 db, dataCamera Focus=14600, dataCamera Zoom=25000, 
dataCamera Iris=0
ignition detection: triggerLevel=1 (instead of 1.5), averagingDurationSecs=0.5 
(instead of 0.05), igniterOffDelayMs=0 (instead of 500)
After test, 776 on lowest valve safety timer, 1129 psia in oxidizer bottle
~~~~

### Pagina 6

Cita: [pdf_bdbccc6bc300c77ccabe, p. 6]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
6
Test 19182G7 – successful ignition, run with 
dataCameraIgnitionExposureUs=dataCameraTestExposureUs=
dataCameraExtinctionExposureUs=100000, useBracketedExposures=FALSE, 
bracketingExposureStartUsec=40000, fiberIgnitionPosition=fiberTestPosition=0, 
fiberMoveDuringTest=FALSE, fiberVelocity=500, stabilizationTime1Sec=8, 
stabilizationTime2Sec=5, fuelBottleIgnitionFlowRateN2Slpm=0.091, 
nitrogenIgnitionFlowRateN2Slpm=0.212, fuelBottleTestFlowRateN2Slpm=0.053, 
nitrogenTestFlowRateN2Slpm=0.212, ignitionToTestRampTimeSec=40, 
constantFlowTimeSec=5
dataCamera Gain=24 db, dataCamera Focus=14600, dataCamera Zoom=25000, 
dataCamera Iris=0
ignition detection: triggerLevel=1 (instead of 1.5), averagingDurationSecs=0.5 
(instead of 0.05), igniterOffDelayMs=0 (instead of 500)
After test, 697 on lowest valve safety timer, 1129 psia in oxidizer bottle
~~~~

### Pagina 7

Cita: [pdf_bdbccc6bc300c77ccabe, p. 7]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
7
Test 19182G8 – successful ignition, run with 
dataCameraIgnitionExposureUs=dataCameraTestExposureUs=
dataCameraExtinctionExposureUs=100000, useBracketedExposures=FALSE, 
bracketingExposureStartUsec=40000, fiberIgnitionPosition=fiberTestPosition=0, 
fiberMoveDuringTest=FALSE, fiberVelocity=500, stabilizationTime1Sec=8, 
stabilizationTime2Sec=5, fuelBottleIgnitionFlowRateN2Slpm=0.083, 
nitrogenIgnitionFlowRateN2Slpm=0.194, fuelBottleTestFlowRateN2Slpm=0.065, 
nitrogenTestFlowRateN2Slpm=0.194, ignitionToTestRampTimeSec=40, 
constantFlowTimeSec=5
dataCamera Gain=24 db, dataCamera Focus=14600, dataCamera Zoom=25000, 
dataCamera Iris=0
ignition detection: triggerLevel=1 (instead of 1.5), averagingDurationSecs=0.5 
(instead of 0.05), igniterOffDelayMs=0 (instead of 500)
After test, 613 on lowest valve safety timer, 1129 psia in oxidizer bottle
~~~~

### Pagina 8

Cita: [pdf_bdbccc6bc300c77ccabe, p. 8]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
8
Test 19182G9 – successful ignition, run with
dataCameraIgnitionExposureUs=dataCameraTestExposureUs=
dataCameraExtinctionExposureUs=100000, useBracketedExposures=TRUE, 
bracketingExposureStartUsec=50000, 
bracketingExposureMultiplierTimes100=200, fiberIgnitionPosition=12000, 
fiberTestPosition=15500, fiberMoveDuringTest=TRUE,
fiberSegmentDistance=200, fiberVelocity=400, stabilizationTime1Sec=0, 
stabilizationTime2Sec=2, fuelBottleIgnitionFlowRateN2Slpm=0.078, 
nitrogenIgnitionFlowRateN2Slpm=0.182, fuelBottleTestFlowRateN2Slpm=0.078, 
nitrogenTestFlowRateN2Slpm=0.182, ignitionToTestRampTimeSec=0, 
constantFlowTimeSec=45
dataCamera Gain=0 db, dataCamera Focus=13900, dataCamera Zoom=25000, 
dataCamera Iris=60000
ignition detection: triggerLevel=1 (instead of 1.5), averagingDurationSecs=0.5 
(instead of 0.05), igniterOffDelayMs=0 (instead of 500)
After test, 543 on lowest valve safety timer, ~1130 psia in oxidizer bottle
~~~~

### Pagina 9

Cita: [pdf_bdbccc6bc300c77ccabe, p. 9]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
9
Test 19182N1 – successful ignition, similar to G3, run with 
dataCameraIgnitionExposureUs=dataCameraTestExposureUs=
dataCameraExtinctionExposureUs=100000, useBracketedExposures=FALSE,
bracketingExposureStartUsec=50000, 
bracketingExposureMultiplierTimes100=200, fiberIgnitionPosition=0, 
fiberTestPosition=0, fiberMoveDuringTest=FALSE, fiberSegmentDistance=200, 
fiberVelocity=400, stabilizationTime1Sec=0, stabilizationTime2Sec=5, 
fuelBottleIgnitionFlowRateN2Slpm=0.091, 
nitrogenIgnitionFlowRateN2Slpm=0.212, fuelBottleTestFlowRateN2Slpm=0.091, 
nitrogenTestFlowRateN2Slpm=0.212, ignitionToTestRampTimeSec=0,
constantflowtimesec=30
dataCamera Gain=24 db, dataCamera Focus=13750, dataCamera Zoom=30000, 
dataCamera Iris=0
ignition detection: triggerLevel=1 (instead of 1.5), averagingDurationSecs=0.5 
(instead of 0.05), igniterOffDelayMs=0 (instead of 500)
After test, 491 on lowest valve safety timer, 1129 psia in oxidizer bottle
~~~~

### Pagina 10

Cita: [pdf_bdbccc6bc300c77ccabe, p. 10]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
10
Test 19182N2 – successful ignition, identical to N1 (in test for repeatability), run 
with dataCameraIgnitionExposureUs=dataCameraTestExposureUs=
dataCameraExtinctionExposureUs=100000, useBracketedExposures=FALSE, 
bracketingExposureStartUsec=50000, 
bracketingExposureMultiplierTimes100=200, fiberIgnitionPosition=0, 
fiberTestPosition=0, fiberMoveDuringTest=FALSE, fiberSegmentDistance=200, 
fiberVelocity=400, stabilizationTime1Sec=0, stabilizationTime2Sec=5, 
fuelBottleIgnitionFlowRateN2Slpm=0.091, 
nitrogenIgnitionFlowRateN2Slpm=0.212, fuelBottleTestFlowRateN2Slpm=0.091, 
nitrogenTestFlowRateN2Slpm=0.212, ignitionToTestRampTimeSec=0, 
constantflowtimesec=30
dataCamera Gain=24 db, dataCamera Focus=13750, dataCamera Zoom=30000, 
dataCamera Iris=0
ignition detection: triggerLevel=1 (instead of 1.5), averagingDurationSecs=0.5 
(instead of 0.05), igniterOffDelayMs=0 (instead of 500)
After test, 437 on lowest valve safety timer, 1130 psia in oxidizer bottle
~~~~

### Pagina 11

Cita: [pdf_bdbccc6bc300c77ccabe, p. 11]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
11
Test 19182N3 – successful ignition, run with
dataCameraIgnitionExposureUs=dataCameraTestExposureUs=
dataCameraExtinctionExposureUs=100000, useBracketedExposures=TRUE, 
bracketingExposureStartUsec=40000, fiberIgnitionPosition=12000, 
fiberTestPosition=15500, fiberMoveDuringTest=TRUE, fiberVelocity=400, 
stabilizationTime1Sec=0, stabilizationTime2Sec=2, 
fuelBottleIgnitionFlowRateN2Slpm=0.078, 
nitrogenIgnitionFlowRateN2Slpm=0.182, fuelBottleTestFlowRateN2Slpm=0.078, 
nitrogenTestFlowRateN2Slpm=0.182, ignitionToTestRampTimeSec=0, 
constantFlowTimeSec=45
dataCamera Gain=0 db, dataCamera Focus=13900, dataCamera Zoom=25000, 
dataCamera Iris=60000
ignition detection: triggerLevel=1 (instead of 1.5), averagingDurationSecs=0.5 
(instead of 0.05), igniterOffDelayMs=0 (instead of 500)
After test, 363 on lowest valve safety timer, 1130 psia in oxidizer bottle
~~~~

### Pagina 12

Cita: [pdf_bdbccc6bc300c77ccabe, p. 12]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_bdbccc6bc300c77ccabe/p0012.jpg)

~~~~text
12
Test 19182A1 – successful ignition, run with the following changes from the 
planned A1 parameters: nitrogenIgnitionFlowRateN2Slpm=0.381, 
ignitionToTestRampTimeSec=10
dataCamera Gain=0 db, dataCamera Focus=13900, dataCamera Zoom=25000, 
dataCamera Iris=25000
ignition detection: triggerLevel=1 (instead of 1.5), averagingDurationSecs=0.5 
(instead of 0.05), igniterOffDelayMs=0 (instead of 500)
After test, 325 on lowest valve safety timer, 1130 psia in oxidizer bottle

[Texto OCR de la imagen]
Test 19182A1 — successful ignition, run with the following changes from the
planned A1 parameters: nitrogenlgnitionFIowRateN2SIpm=O.381,
ignitionToTestRampTimeSec=10
dataCamera Gain=O db, dataCamera Focus=13900, dataCamera Zoom=25000,
dataCamera Iris=25000
ignition detection: triggerLevel=1 (instead of 1.5), averagingDurationSecs=O.5
(instead of 0.05), igniterOffDelayMs=O (instead of 500)
Gas Flow Charts
-101 x
Graphs
EXPERIMENT | 2019-07-0121:29:24 | GMT
systemstate
System Temperatures
State | Operate | c | 0.000 | SLPM | R | -0.011 | SLPM | 20.000 | SLPM | 33.000
cpu
set AI Gains
Static Mixer Line (MFCAI) | cp..J Board | 36.000
Cube Sensor 1 | 34.644
50 | 34.581
Cube Sensor 2
-0.01 | 50
Hard Drive | 26
21:25 | 21:26 | 21:27 | 21:28 | 21:29
1 mon Jul 2019 | Time (s)
TC200A (TCI) | 24.874990
State | Operate | c | 0.000 | R | -0.005 | SLPM | scale | 2,000 | TC200B (TC2) | 23.710222 | mV
TCCJ | 23.799147 | 0.876
Bypass(MFCA2)
ACME_FLO | YPASS_SETPOINT | Rake:
31.418720 | 0.309
nvabd-low | 0.017
21:25 | 21:26 | 21:27 | 21:28 | 21:29
hvabd-/ow | -0.002 | mV
1 Mon Jul 2019 | Time (s)
27.744377 | 0.160
State | Operate | C | 0.000 | R | -0.001 | SLPM | F.,A scale | 0.200
Fuel(MFCA3) | Burner: Spheea,/
Burner | 75.968995 | 2.148
ACME FLOW '43 FUEL SETPOINT | ACME FLOW | FUEL FLOW
Canection
21:25 | 21:26 | 21:27 | 21:28 | 21:29
1 mon Jul 2019 | Tüne (s)
Time Series Chart
Packet | Software Mnemonic
ACME Teleme | DIAG PMT_TI | 0.00
ACME Teleme | 0.00
ACME | Aay1E DIAG PMT T3 | 0.00
2.5
2.]
Se!ect Items | End plotting
Clear Selections | Restart
Grazh | 1 mon Jul 2019
Star | 01 | 2019
After test, 325 on lowest valve safety timer, 1130 psia in oxidizer bottle
12
~~~~

### Pagina 13

Cita: [pdf_bdbccc6bc300c77ccabe, p. 13]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
13
Test 19182C1 – successful ignition, run with the following changes from the 
planned C1 parameters: fiberIgnitionPosition=12000, stabilizationTime1Sec=3, 
stabilizationTime2Sec=0, nitrogenIgnitionFlowRateN2Slpm=0.381, 
ignitionToTestRampTimeSec=8
dataCamera Gain=0 db, dataCamera Focus=13900, dataCamera Zoom=25000,
dataCamera Iris=60000
ignition detection: triggerLevel=1 (instead of 1.5), averagingDurationSecs=0.5 
(instead of 0.05), igniterOffDelayMs=0 (instead of 500)
After test, 259 on lowest valve safety timer, 1130 psia in oxidizer bottle
~~~~

### Pagina 14

Cita: [pdf_bdbccc6bc300c77ccabe, p. 14]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
14
Test 19182C2 – successful ignition, run with the following changes from the 
planned C1 parameters and camera settings: fiberIgnitionPosition=12000, 
stabilizationTime1Sec=3, stabilizationTime2Sec=0, 
nitrogenIgnitionFlowRateN2Slpm=0.381, 
nitrogenIgnitionFlowRateN2Slpm=0.560, ignitionToTestRampTimeSec=9
dataCamera Gain=0 db, dataCamera Focus=13900, dataCamera Zoom=25000,
dataCamera Iris=15000
ignition detection: triggerLevel=1 (instead of 1.5), averagingDurationSecs=0.5 
(instead of 0.05), igniterOffDelayMs=0 (instead of 500)
After test, 192 on lowest valve safety timer, 1130 psia in oxidizer bottle
~~~~

### Pagina 15

Cita: [pdf_bdbccc6bc300c77ccabe, p. 15]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
15
Test 19182N4 – successful ignition, intended to be exact repeat of N3 but 
accidentally had the wrong dataCamera Iris setting, run with the following 
(where only the wrong setting is highlighted), 
dataCameraIgnitionExposureUs=dataCameraTestExposureUs=
dataCameraExtinctionExposureUs=100000, useBracketedExposures=TRUE, 
bracketingExposureStartUsec=40000, fiberIgnitionPosition=12000, 
fiberTestPosition=15500, fiberMoveDuringTest=TRUE, fiberVelocity=400, 
stabilizationTime1Sec=0, stabilizationTime2Sec=2, 
fuelBottleIgnitionFlowRateN2Slpm=0.078, 
nitrogenIgnitionFlowRateN2Slpm=0.182, fuelBottleTestFlowRateN2Slpm=0.078, 
nitrogenTestFlowRateN2Slpm=0.182, ignitionToTestRampTimeSec=0, 
constantFlowTimeSec=45
dataCamera Gain=0 db, dataCamera Focus=13900, dataCamera Zoom=25000, 
dataCamera Iris=15000 (instead of the intended 60000)
ignition detection: triggerLevel=1 (instead of 1.5), averagingDurationSecs=0.5 
(instead of 0.05), igniterOffDelayMs=0 (instead of 500)
After test, 119 on lowest valve safety timer, 1130 psia in oxidizer bottle
~~~~

### Pagina 16

Cita: [pdf_bdbccc6bc300c77ccabe, p. 16]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
16
Test 19182F1 – successful ignition, run with the following changes from the 
planned F1 parameters: bracketingNumberOfExposures=3, 
bracketingExposureMultiplierTimes100=650, fiberIgnitionPosition=12000, 
flowTimeoutSec=115, stabilizationTime2Sec=45, constantFlowTimeSec=55
dataCamera Gain=0 db, dataCamera Focus=13000, dataCamera Zoom=30000,
dataCamera Iris=10000
ignition detection: triggerLevel=1 (instead of 1.5), averagingDurationSecs=0.5 
(instead of 0.05), igniterOffDelayMs=0 (instead of 500)
After test, 0 on lowest valve safety timer (while parameters were adjusted to 
account for the remaining time on the valve safety time, the margin was 
insufficient), 1129 psia in oxidizer bottle
~~~~
