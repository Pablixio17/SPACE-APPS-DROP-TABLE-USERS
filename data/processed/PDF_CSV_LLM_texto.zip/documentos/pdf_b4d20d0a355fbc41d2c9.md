# 19137 flow traces etc

- Identificador: pdf_b4d20d0a355fbc41d2c9
- Investigaciones: PSI-10
- Tipo de documento: Raw Data
- Estado: processed
- Temas detectados automaticamente: oxygen, pressure, hardware, ignition, operations

## Fuentes

- [PSI-10_Raw Data_19137 flow traces etc.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-10/Raw%20Data/PSI-10_Raw%20Data_19137%20flow%20traces%20etc.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_b4d20d0a355fbc41d2c9, p. 1]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_b4d20d0a355fbc41d2c9/p0001.jpg)

~~~~text
1
Test 19137A1- successful test, run as planned without parameter changes
After test, 967 on lowest valve safety timer, 685 psia in oxidizer bottle

[Texto OCR de la imagen]
Test 19137A1- successful test, run as planned without parameter changes
Gas Flow Charts
File Gr aphs
2019-05-17 | GMT
state | 2019-05-17 17:31:37
System Ternperatures
33.300
Operate | c | 0.000 | SLPM | R | -0.010 | SLPM | scale | 20.000 | All Gains
Board | 35.000
Static Mixer Line (MFCAI) | Set
Cube Sensor 1
set
Cube Sensor 2 | 'C
set | Hard Drive | 26
-0.010
17:27 | 17:28 | 17:29 | 17:30 | 17:31
17 fri may 2019 | Time (s)
CTCI) | 24.096198 | 0.040 | mV
22.930606 | -0.007 | mV
State | Operate | c | 0.000 | R | -0.001 | SLPM | scale | 0.500
23. 121190 | 874
Bypass(MFCA2)
Rake:
ACME FLOW r-•12 BYPASS SETPOINT | ACME FLOW | BYPASS FLOW
30.053287 | 0.281 | mV
invalid-low | 0.007 | mV
-I.oe-3
17:27 | 17:28 | 17:29 | 17:30 | 17:31 | invalid-low | 0002
mV
17 Fri May 2019 | Time (s)
30.201171 | 0.287 | mV
Sbte | Operate | c | 0.000 | SLPM | R | -0.002 | SLPM | scale | 0.200
Fuel(MFCA3) | Burn«: Spheeal (1/4)
93.665026 | 2.911
ACME FLOW M3 FUEL SETPOINT | ACME FLOW M3 FUEL FLOW
Cube Cornecbon
17:27 | 17:28 | 17:29 | 17:30 | 17:31
17 Fri May 2019 | Tine (s)
2. Time Series Chart #1 | -IOIS
Softv•e FhemoNc | I Low
ACME Teleme | 0.00
ACME | 0.00
ACME | 0.00
0.5
Select Items | End plotMg
17:30:45 | 17:31:00 | 17:31:15
17May 2019 | Restart | 17Fri May 2019 | Time
StartTme,
After test, 967 on lowest valve safety timer, 685 psia in oxidizer bottle
1
~~~~

### Pagina 2

Cita: [pdf_b4d20d0a355fbc41d2c9, p. 2]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_b4d20d0a355fbc41d2c9/p0002.jpg)

~~~~text
2
Test 19137B1 – successful test, run as planned without parameter changes
After test, 931 on lowest valve safety timer, 690 psia in oxidizer bottle

[Texto OCR de la imagen]
Test 19137B1- successful test, run as planned without parameter changes
Gas Flow Charts
File Graphs
2019-05-17
2019-05-17
System Temperatures
33,000
Sute | Operate | c | 0.000 | QPM | •0.008 | SLPM | Fl-I scale | 20.000 | Al Gains
Board | 35.000
Static Mixer Line (MFCAI)
Cube Sensor 1 | 34.340
ACME FLOW MI MIXER SETPOINT | ACME FLOW MI MIXER FLOW | Cube Sensor 2 | 34.332
Hard Drive | 26
-0.010
17:54 | 17:55 | 17:56 | 17:57 | 17:58
17fri may 2019 | Tine (s)
(TCI) | 24.269692 | 0.047 | mV
22.781720 | -0.013 | mV
State | Operate | c | 0.000 | SLPM | R | -0.000 | SLPM | scale | 0.500
23. 121190 | 0.874
Bypass(MFCA2)
ACME FLOW M2 BYPASS SETPOINT | ACME FLOW M2 BYPASS FLOW
0.15
32.097176 | 0.364 | mV
0.10
0.05
hvahd-low | -0.001 | mV
1754 | 17:55 | 17:56 | 17:57 | 17:58 | hvahd40w | -0.004
mV
17fri may 2019 | Time (s)
31.605035 | 0.344 | mV
State | Operate | c | 0.000 | SLPM | R | -0.000 | SLPM | scale | 0.200
Fuel(MFCA3)
90. 122187 | 2.764
ACME_FLOW M3 FUEL FLOW
0.15
0.10
0.05
Connection | Connected
17:54 | 17:55 | 17:56 | 17:57 | 17:58
17fri may 2019 | Time (s)
Time Series Chart #1
So ftv•e Mnemonic
ACME Teleme | 0.00
ACME Teleme ACME DIAG | T2 | 0.00
ACtGTeleme | 2.5
ACME DIAG PMT T3 | 0.00
> 2.0
Select Items | End Plotting
17MaY2019 | Restart | 17Fri May 2019 | Time
After test, 931 on lowest valve safety timer, 690 psia in oxidizer bottle
2
~~~~

### Pagina 3

Cita: [pdf_b4d20d0a355fbc41d2c9, p. 3]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_b4d20d0a355fbc41d2c9/p0003.jpg)

~~~~text
3
Test 19137C1 – successful test, run as planned without parameter changes
After test, 900 on lowest valve safety timer, 692 psia in oxidizer bottle

[Texto OCR de la imagen]
Test 19137C1- successful test, run as planned without parameter changes
Gds Flow Charts
File Gr aphs
2019-05-17 18:15:51 | GBIT
2019-05-17 18: 15:51
System Temperatures
cpu | 32.800 | 'C
Operate | c | 0.000 | SLPM | -0.009 | SLPM | 20.000 | Al
Board | 35,000
Static Mixer Line (MFCAI)
Cube Sensor 1 | 34, 339
Cube Sensor 2 | 34.337
Hard Drive | 26
-0.010
18:11 | 18:12 | 18:13 | 18:14 | 18:15
17 Fri May 2019 | Time (s)
24.584718 | 0.046
23.270820 | -0.007
State | Operate | c | 0.000 | SLPM | R | -0.001 | SLPM | scale | 0.500
TCCJ | 23.460169 | 0.875
Bypass(MFCA2)
Rake: Far
0.2 | 32.385300 | 0.362
0.1
invahd-low | -0.005
18:11 | 18:12 | 18:13 | 18:14 | 18:15 | invalid-low | -0.003
17 Fri May 2019 | Time (s)
TCD | 31.056353 | 0.308
State | Operate | c | 0.000 | SLPM | R | 0.000 | scale | 0.200
Fuel(MFCA3) | Burner: Spherical (1/4)
72.804431 | 2.030
0.15
0.10
0.05
0.00 | CA be Cmnectim
18:11 | 18:12 | 18:13 | 18:14 | 18:15
17 Fri May 2019 | Time (s)
Time Series Chart #1 | —IOS
Packet | Software Mnemmic | Low
Acta: Teleme | 0.00
ACME | 0.00
ACME | 0.00
> 2.0
Select Items | End Plotting
18:14:45 | 18:15:00
17 May 2019 | Restart | 17 Fri May 2019 | Time
StartTme,
After test, 900 on lowest valve safety timer, 692 psia in oxidizer bottle
3
~~~~

### Pagina 4

Cita: [pdf_b4d20d0a355fbc41d2c9, p. 4]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_b4d20d0a355fbc41d2c9/p0004.jpg)

~~~~text
4
Test 19137D1 – successful test, run as planned without parameter changes
After test, 871 on lowest valve safety timer, 692 psia in oxidizer bottle

[Texto OCR de la imagen]
Test 19137D1- successful test, run as planned without parameter changes
Gas Flow Charts | ¯ÄgJ
File Gr aphs
2019-05-17 18:28:53 | GMT
2019-05-17
System Temperatures
cpu | 32.700
State | Operate | c | 0.000 | SLPM | •0.009 | SLPM | FIN scale | 20.000 | A] Gans
cpu | 35.000
Static Mixer Line (MFCAI)
Cube Sensor 1 | 34.298
ACME FLOW MI MIXER SETPOINT | ACME FLOW MI MIXER FLOW | Cube Sensor 2 | 34.339
Set | Hard Drive | 26
18:24 | 18: 25 | 18: 26 | 18:27 | 18:28
17 fri may 2019 | Time (s)
24.584718
23.593242 | 0.006
Operate | c | 0.000 | R | -0.001 | SLPM | scale | 0.500
23.%0169 | 0.875
Bypass(MFCA2)
ay
Rake: Far
32.631218 | 0.372
0.2
invalid-low | -0.005
18:24 | 18:25 | 18:26 | 18:27 | 18:28 | invalid-low | -0.009
17 Fri May 2019 | Time (s)
32.213123 | 0.355
State | Operate | R | -0.000 | SLPM | scale | 0.200
Fuel(MFCA3) | Burnet Spherical (1/4)
64.005059 | 1.664 | mV
ACME FLOW M3 FUEL SETPOINT | ACME FLOW M3 FUEL FLOW
Cube Comecbon
18:24 | 18:25 | 18: 26 | 18:27 | 18:28
17 Fri may 2019 | Time (s)
Time Series Chart #1
Packet | Software Mrznonic
ACME Teleme | 0.00
ACME Teleme | 0.00
ACME Teleme | 0.00
2]
End Plottng
17May2019 | may 2019
StartTme,
After test, 871 on lowest valve safety timer, 692 psia in oxidizer bottle
4
~~~~

### Pagina 5

Cita: [pdf_b4d20d0a355fbc41d2c9, p. 5]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_b4d20d0a355fbc41d2c9/p0005.jpg)

~~~~text
5
Test 19137F1 – successful test, run as planned without parameter changes
After test, 846 on lowest valve safety timer, 693 psia in oxidizer bottle

[Texto OCR de la imagen]
Test 19137F1- successful test, run as planned without parameter changes
Gas Flow Charts | —IOS
2019-05-17 | GMT
state | 2019-05-17
system | System Temperatures
cpu | 32.
State | Operate | c | 0.000 | SLPM | R | -0•008 | SLPM | scale | 20.000 | All Gains
Board | 35.000
Static Mixer Line (MFCAI)
Cube Sensor 1 | 34.343 | 'C
Cube Sensor 2 | 34.370
Hard Drive | 26
-0.010
18:40 | 18:45 | 18:50
17 Fri May 2019 | Time (s)
(TCI) | 24.782905 | 0.054 | mV
23.295625 | -0.006
CC2)
State | Cperate | c | 0.000 | SLPM | R | -0.005 | SLPM | scale | 0.500
23.460169 | 0.875
Bypass(MFCA2)
ay
Rake: Far
ACME FLOW M2 BYPASS SETPOINT | ACME FLOW | BYPASS FLOW
30.366611 | 0.280
hvalid-low | 0.009
18:40 | 18:45 | 18:50 | nvalid-low | -0.001
17Fri May2019 | Time (s)
30.243396 | 0.275
Operate | c | 0.000 | SLPM | R | -0.002 | SLPM | scale | 0.200
Fuel(MFCA3) | Burnet Spherical (1/4)
52.861401 | 1.202
ACME FLOW M3 FUEL SETPOINT | ACME FLOW M3 FUEL FLOW
0.15
0.10
0.05
0.00 | Cube Cmnection | Connected
18:40 | 18:45 | 18:50
17 fri May 2019 | Time (s)
Time Series Chart
Packet | Software Mremonic | I Low
ACME Teleme | 0.00
ACME Teleme | 0.00
ACME Teleme ACME DIAG PPT T3 | 0.00
0.5
Select Items | End Plottng
18:49:30 | 18:49:45 | 18:50:00 | 18:50:15 | 18:50
17 May 2019 | 17 Fri May 2019 | Tine
startvme,
After test, 846 on lowest valve safety timer, 693 psia in oxidizer bottle
5
~~~~

### Pagina 6

Cita: [pdf_b4d20d0a355fbc41d2c9, p. 6]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_b4d20d0a355fbc41d2c9/p0006.jpg)

~~~~text
6
Test 19137F2 – successful test, run with
fuelBottleIgnitionFlowRateN2Slpm=0.13, 
nitrogenIgnitionFlowRateN2Slpm=0.435, fuelBottleTestFlowRateN2Slpm=0.13,
nitrogenIgnitionTestRateN2Slpm=0.435
After test, 816 on lowest valve safety timer, 692 psia in oxidizer bottle

[Texto OCR de la imagen]
Test 19137F2 — successful test, run with
fuelBottIeIgnitionFIowRateN2SIpm=O.13,
nitrogenlgnitionFlowRateN2SIpm=O.435, fuelBottleTestFIowRateN2Slpm=O.13,
nitrogenlgnitionTestRateN2SIpm=O.435
Gas Flow Charts | -ox
File Graphs
2019-05-17
2019-05-17 19:05:37
System Temperatures
cpu | 32. no
State | Operate | c | 0.000 | QPM | R | -0.009 | SLPM | FL" scale | 20.000 | AI Gains
cpu Board | 35.000
Static Mixer Line (MFCAI)
Cube | 1 | 34.359
ACME FLOW MI MIXER SETPOINT | ACME FLOW MI MIXER FLOW | Cube Sensor 2 | 34.289
Hard Drive | 26
19:01 | 19:02 | 19:03 | 19:04 | 19:05
17 fri may 2019 | Time (s)
A (TCI) | 24.535165
(TC2)
State | c | 0.000 | SLPM | R | -0.001 | SLPM | scale | 0.500
23.460169 | 0.875
Bypass(MFCA2)
Rake:
ACME FLOW M2 BYPASS SETPOINT | ACME FLOW M2 BYPASS FLOW
31.671814 | 0.333 | mV
invalid -low | -0.002 | mV
19:01 | 19:02 | 19:03 | 19:04 | 19:05 | invalid-low | -0.007
mV
17 | may 2019 | Tine (s)
31.25334) | 0.316 | mV
State | c | 0.000 | SLPM | R | -0.000 | SLPM | scale | 0.200
Fuel(MFCA3) | Burner: Sphere.' (1/4)
57.065237 | 1.376
ACME FLOW M3 FUEL SETPOINT | ACME FLOW M3 FUEL FLOW
0.10
0.05
Cube Comecbon | Connected
19:01 | 19:02 | 19:03 | 19:04 | 19:05
17 fri may 2019 | Tine (s)
Time Series Chart #1
Packet | So ft'.Nare Wiemoric | Low
ACME Teleme ACME DIAG PMT Tl | 0.00
ACME Teleme | 0.00
Teleme | 2.5
ACME | ACME DIAG PMT T3 | 0.00
> 2.0
select Items | End Plottng
19:04:45
17May 2019 | 17 fri nay 2019
Start Tme,
After test, 816 on lowest valve safety timer, 692 psia in oxidizer bottle
6
~~~~

### Pagina 7

Cita: [pdf_b4d20d0a355fbc41d2c9, p. 7]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_b4d20d0a355fbc41d2c9/p0007.jpg)

~~~~text
7
Test 19137F3 – successful test, same as F2 but without fiber array, run with
fiberIgnitionPosition=fiberTestPostition=0, fiberMoveDuringTest=FALSE, 
fuelBottleIgnitionFlowRateN2Slpm=0.13, 
nitrogenIgnitionFlowRateN2Slpm=0.435, fuelBottleTestFlowRateN2Slpm=0.13,
nitrogenIgnitionTestRateN2Slpm=0.435
Analog Camera Gain=21 dB
After test, 787 on lowest valve safety timer, 692 psia in oxidizer bottle

[Texto OCR de la imagen]
Test 19137F3 — successful test, same as F2 but without fiber | run with
array,
fiberIgnitionPosition=fiberTestPostition=O, fiberMoveDuringTest=FALSE,
fuelBottleIgnitionFlowRateN2Slpm=O.13,
nitrogenlgnitionFlowRateN2Slpm=O.435, fuelBottleTestFIowRateN2Slpm=O.13,
nitrogenlgnitionTestRateN2Slpm=O.435
Analog Camera Gain—21 dB
Gas Flow Charts
File Graphs
2019-05-17
2019-05-17
Systern Tanperatures
32.700
State | Operate | c | 0.000 | QPM | R | -0.008 | SLPM | FLASde | 20.000 | AN Gahs
CPU Board | 35.000 | 'C
Static Mixer Line (MFCAI) | Set
Cube Sensor 1 | 34.377
set | 34.303
ACME FLOW MI MIXER SETPOINT | ACME FLOW MI MIXER FLOW | Cube Sensor 2
Set | Hard Drive | 26
19:19 | 19:20 | 19:21 | 19:22 | 19:23
17fri may 2019 | Tine (s)
A (TCI) | 24.535165 | 0.044
23.419642 | -0.001 | mV
State | Operate | c | 0.000 | R | -0.000 | SLPM | scale | 0.500
23.460169 | 0.875
Bypass(MFCA2)
ay
Rake: Far
Acm
30.908589 | 0.302
0.25
invalid40w | -0.009 | mV
19:19 | 19:20 | 19:21 | 19:22 | 19:23 | invalid-low | -0.011
17 Fri May 2019 | Tüne (s)
TCD | 29.207815 | 0.233
State | Operate | c | 0.000 | SLPM | R | -0.000 | SLPM | scale | 0.200
Fuel(MFCA3)
52.933967 | 1.205
ACME FLOW M3 FUEL SETPOINT | ACME FLOW M3 FUEL FLOW
Cube Connection
19:19 | 19:20 | 19:21 | 19:22 | 19:23
17fri may 2019 | Tüne (s)
• Time Series Chart #1 | —IOS
.
Packet | Software Mnanonic | Low
ACME Teleme | 0.00
ACFETeleme | 0.00
ACME | 0.00
> 2.0
Select [terns | Plottjng
19:22:30 | 19:22:45 | 19:23:00 | 19:23:15 | 19:23::
17 May 2019 | Restart | 17 Fri May 2019 | Tune
41
After test, 787 on lowest valve safety timer, 692 psia in oxidizer bottle
7
~~~~

### Pagina 8

Cita: [pdf_b4d20d0a355fbc41d2c9, p. 8]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_b4d20d0a355fbc41d2c9/p0008.jpg)

~~~~text
8
Test 19137G1 – successful test, run without parameter changes
Analog Camera Gain=21 dB
After test, 753 on lowest valve safety timer, 692 psia in oxidizer bottle

[Texto OCR de la imagen]
Test 19137G1- successful test, run without parameter changes
Analog Camera Gain—21 dB
Gas Flow Charts
File Graphs
2019-05-17
state | 2019-05-17 19:38:30
System Temperatures
32. no
Operate | c | 0.000 | R | -0•009 | SLPM | scale | 20.000 | A1 Gains
cpu Board | 35.000
Static Mixer Line (MFCAI)
Cube Sensor 1 | 34.352
ACME FLOW MI MIXER SETPOINT | ACME FLOW MI MIXER FLOW | Cube Sensor 2 | 34.297
Hard Drive | 26
19:34 | 19:35 | 19:36 | 19:37 | 19:38
17 f-ri may 2019 | Time (s)
2485610 | 0.042
23.146787 | -0.012
(TC2)
State | Operate | c | 0.000 | R | -0.000 | SLPM | scale | 0.500
TCCJ | 23.460169 | 0.875
Bypass(MFCA2)
Rake: Far
ACME FLOW | BYPASS SETPOINT | ACME FLOW M2 BYPASS FLOW
31.327201 | 0.319
invahd-low | -0.004
-1,oe-3
19:34 | 19:35 | 19:36 | 19:37 | 19:38 | invahd-low | -0.010
17 Fri May 2019 | Tüne (s)
29.405146 | 0.241
Operate | c | 0.000 | SLPM | R | -0.000 | SLPM | scale | 0.200
Fuel(MFCA3) | Spherical
92.838276 | 2.863
0.15
0.10
0.05
Cube Cmnectim
19:34 | 19:35 | 19:36 | 19:37 | 19:38
17 Fri May 2019 | Time (s)
Time Series Chart #1 | —IOS
packet | Software Mnanonic
ACME Teleme | 0.00
ACME | 0.00
ACME | 0.00
> 2.0
Se'ect Items | End Plotting
17 May 2019 | R estart | 17 fri may 2019 | Time
Startrme,
After test, 753 on lowest valve safety timer, 692 psia in oxidizer bottle
8
~~~~

### Pagina 9

Cita: [pdf_b4d20d0a355fbc41d2c9, p. 9]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_b4d20d0a355fbc41d2c9/p0009.jpg)

~~~~text
9
Test 19137H1 – successful test, run without parameter changes
Analog Camera Gain=21 dB
After test, 722 on lowest valve safety timer, 692 psia in oxidizer bottle

[Texto OCR de la imagen]
Test 19137H1 — successful test, run without parameter changes
Analog Camera Gain—21 dB
Gas flow Charts | ÄIAJ k
File Graphs
2019-05-17 | GETT
2019-05-17
System Ternperatures
cpu | 32.700
State | Operate | c | 0.000 | SLPM | R | -0.021 | SLPM | FL" scale | 20.000 | All Gahs
Board | 35.000
Static Mixer Line (MFCAI) | set
Cube Sensor 1 | 34.494
Set | 34.478
Cube Sensor 2 | 'C
Set | Hard Drive | 26 | 'C
-0.02
20:04 | 20:05 | 20:06 | 20:07 | 20:08
17fri may 2019 | Tine (s)
24.634268 | 0.048 | mV
23.121979 | -0.013 | mV
State | Operate | c | 0.000 | SLPM | R | -0.000 | SLPM | scale | 0.500
23.460169 | 0.875
Bypass(MFCA2)
ay
ACME_FLOW_M2_BYPASS FLOW
30.514451 | 0.286 | mV
-OSe—3
hvalid-/ow | -0.004 | mV
-I.oe-3
20:04 | 20:05 | 20:06 | 20:07 | 20:08 | nvalid40w | -0.006
mV
17fri May 2019 | Time (s)
29.577782 | 0.248 | mV
State | Operate | c | 0.000 | R | -0.001 | SLPM | scale | o. 200
Fuel(MFCA3) | Burner: Spherical (1/4)
95.491627 | 2.973
ACME FLOW M3 FUEL SETPOINT | ACME FLOW | FUEL FLOW
0.15
0.10
0.05
Cl Ibe Connectim | Connected
20:04 | 20:05 | 20:06 | 20:07 | 20:08
17Fri May 2019 | Time (s)
Time Series Chart #1 | -101 x
Soffvare t•hemonu:
ACME Teleme ACME DIAG PMT Tl | 0.00
ACYE Teleme | 0.00
ACME | 0.00
> 2.0
Select [terns | End Ploting
20208:15
Restart | 17Fri May 2019 | Tune
StartTme,
After test, 722 on lowest valve safety timer, 692 psia in oxidizer bottle
9
~~~~

### Pagina 10

Cita: [pdf_b4d20d0a355fbc41d2c9, p. 10]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_b4d20d0a355fbc41d2c9/p0010.jpg)

~~~~text
10
Test 19137J1 – successful test, run without parameter changes
Analog Camera Gain=21 dB
After test, 691 on lowest valve safety timer, 695 psia in oxidizer bottle

[Texto OCR de la imagen]
Test 19137J1 — successful test, run without parameter changes
Analog Camera Gain—21 dB
-t. Gas Flow Charts | -ox
File Gr aphs
2019-05-17 | GBIT
system state | 2019-05-17
Systern Tenperab-res
cpu
State | Operate | c | 0.000 | SLPM | R | -0.010 | SLPM | FL" Scale | 20.000 | All Gains
cpc, Board | 35.
Static Mixer Line (MFCAI) | set
Cube Sensor 1 | 34.453
Set
ACME_FLOW | FLOW | (-ube Sensor 2
Set | Hard Drive
20:30 | 20:31 | 20:32 | 20:33 | 20:34
17 Fri May 2019 | Time (s)
A ÜCI) | 24.924527 | 0.046
23.635833 | -0.006
State | c | 0.000 | SLPM | R | -0.000 | SLPM | scale | 0.500
23.799147 | 0.876
Bypass(MFCA2)
ay
Rake: Far
ACME_FLOW | BYPASS_FLOW
30.827743 | mV
invalid -low | 0.000
20:30 | 20:31 | 20:32 | 20:33 | 20:34 | invalid-low | -0.006
17 Fri May 2019 | Tme (s)
29.620136 | 0.236
c | 0.000 | SLPM | R | -0.000 | SLPM | scale | 0.200
Fuel(MFCA3) | Burn.: Spherical (1/41
92.084196 | 2.818
0.10
0.05
Cube Connection
20:30 | 20:31 | 20:32 | 20:33 | 20:34
17 Fri May 2019 | Time (s)
Time Series Chart #1 | -101 x
Packet | Softvvare Mnemoric
ACME Teleme ACB-1E DIAG PMT Tl | 0.00
ACME Telerr,e | 0.00
ACME Teleme ACME | 0.00
0.5
Select Items | End plotting
20:33:45 | 20:34:15 | 20:34:30
17May 2019 | Restart | 17 Fri May 2019 | Tine
startTr-r,e
After test, 691 on lowest valve safety timer, 695 psia in oxidizer bottle
10
~~~~

### Pagina 11

Cita: [pdf_b4d20d0a355fbc41d2c9, p. 11]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_b4d20d0a355fbc41d2c9/p0011.jpg)

~~~~text
11
Test 19137K1 – successful test, run without parameter changes
Analog Camera Gain=21 dB
Late screenshot from science console
After test, 659 on lowest valve safety timer, 692 psia in oxidizer bottle

[Texto OCR de la imagen]
Test 19137K1 — successful test, run without parameter changes
Analog Camera Gain—21 dB
Late screenshot from science console
Gas Flow Charts
Fiie Graphs
2019-05-17 | Gt4T
State EXPERIMENT | 2019-05-17
System | Systern Ternwatures
32.300
Operate | c | 0.000 | SLPM | R | -0.009 | SLPM | scale | 20.000 | AI Gains
Board | 35.000
Static Mixer Line (MFCAI) | Set
Cl_be Sensor 1 | 34.388
Set | 34.393
Sensor 2
Set | Hard Drive | 26
20:51 | 20:52 | 20:53 | 20:54 | 20:55
17 Fri May 2019 | Time (s)
24.701592 | 0.037 | mV
24.453834 | 0.027
State | Operate | c | 0.000 | SLPM | R | -0.000 | SLPM | scale | 0.500
23.799147 | 0.876
Bypass(MFCA2)
ay
Rake: Far
le-3
28.435833 | 0.188 | mV
nvalid -low | -0.006 | mV
-le-3
20:51 | 20:52 | 20:53 | 20:54 | 20:55 | hvalid-low | -0.012
mV
17Fri May2019 | Tine (s)
24.998828 | 0.049 | mV
State | Operate | c | 0.000 | R | -0.000 | SLPM | scale | 0.200
Fuel(MFCA3) | Burn.•. Spheric-a/ (1/4)
69.361250 | 1.873
0.10
0.05
Cube Comectbn | Connected
20:51 | 20:52 | 20:53 | 20:54 | 20:55
17Fri May 2019 | Tüne (s)
Time Series Chart
0.014
0.012
Packet | So ffvare | I Low
0.010
ACME Teleme ACME DIAG | Tl | 0.00
ACME Teleme | 0.00
ACME | 0.00
2] | 0.000
Select terns | End Plottng
17May 2019 | Restart | 17 fri may 2019 | Time
After test, 659 on lowest valve safety timer, 692 psia in oxidizer bottle
11
~~~~

### Pagina 12

Cita: [pdf_b4d20d0a355fbc41d2c9, p. 12]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_b4d20d0a355fbc41d2c9/p0012.jpg)

~~~~text
12
Test 19137K2 – successful test, run with rampFlowToZeroSec=15
Analog Camera Gain=21 dB
Late screenshot from science console
After test, 692 on lowest valve safety timer, 692 psia in oxidizer bottle

[Texto OCR de la imagen]
Test 19137K2 — successful test, run with rampFIowToZeroSec=15
Analog Camera Gain—21 dB
Late screenshot from science console
Gas Flow Charts
File Graphs
2019435-17 21: 17:25 | Gtv1T
state | 2019-05-17 21: 17:25
system | System Ternperatu•es
32, no
State | Operate | c | 0.000 | SLPM | R | -0.008 | SLPM | Ful scale | 20.000 | All Gains
cpu Board | 35.000
Static Mixer Line (MFCAI) | set
Cube Sensor 1 | 34.348
ACME FLOW MI MIXER SETPOINT | ACME FLOW MI MIXER FLOW | Cube Sensor 2 | 34.385
Set | Hard Drive | 26
-0.010
21:13 | 21:14 | 21:15 | 21:16 | 21:17
17 Fri May 2019 | Time (s)
(TCI) | 24.602496 | 0.033
24.280370 | 0.020
State | Operate | c | 0.000 | SLPM | R | -0.001 | SLPM | scale | 0.500
23.799147 | 0.876
Bypass(MFCA2)
Rake:
ACME FLOW M2 BYPASS SETPOINT | ACME FLOW M2 BYPASS FLOW
28.090161 | 0.174
-0.5e-3
nvalid40w | -0.011
-I.oe-3
21:13 | 21:14 | 21:15 | 21:16 | 21: 17 | hvalid-low | -0.008
17Fri May 2019 | Tirne (s)
25.048359 | 0.051
Operate | C | 0.000 | SLPM | R | 0.000 | scale | 0.200
Fuel(MFCA3) | Burne-: Spheröä." (1/4)
64. 166717 | 1.657 | mV
0.10
0.05
Cube Connection
21:13 | 21:14 | 21:15 | 21:16 | 21:17
17fri may 2019 | Tine (s)
Time Series Chart
0.014
0.012
Software Mnemonic
0.010
ACME | 0.00
ACME Telerne | 0.00
ACME | ACME DIAG | T3 | 0.00
0.006
0.000
Select Items | End Plottng
21:16:15 | 21:16:30 | 21:16:45 | 21:17:00
Restart | 17Fri May 2019 | Time
Startme,
After test, 692 on lowest valve safety timer, 692 psia in oxidizer bottle
12
~~~~

### Pagina 13

Cita: [pdf_b4d20d0a355fbc41d2c9, p. 13]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_b4d20d0a355fbc41d2c9/p0013.jpg)

~~~~text
13
Test 19137L1 – successful test, run with 
fuelBottleIgnitionFlowRateN2Slpm=0.078, 
nitrogenIgnitionFlowRateN2Slpm=0.052, fuelBottleTestFlowRateN2Slpm=0.078,
nitrogenIgnitionTestRateN2Slpm=0.052, constantFlowTimeSec=115
dataCamera Focus=13750, dataCamera Zoom=30000
Analog Camera Gain=21 dB
After test, 594 on lowest valve safety timer, 693 psia in oxidizer bottle

[Texto OCR de la imagen]
Test 19137L1 — successful test, run with
fuelBottIeIgnitionFIowRateN2SIpm=O.078,
nitrogenlgnitionFlowRateN2Slpm=O.052, fuelBottIeTestFIowRateN2Slpm- -0.078,
nitrogenlgnitionTestRateN2Slpm=O.052, constantFlowTimeSec=115
dataCamera Focus=13750, dataCamera Zoom=30000
Analog Camera Gain—21 dB
Gas Flow Charts
File Graphs
2019-05-17 | GMT
state | 2019-05-17 21:39:25
System' Temperatures
CPU | 32.700
State | Operate | c | 0.000 | R | -0.010 | SLPM | Fu' Scale | 20.000 | AI Gains
Board | 35.000
Static Mixer Line (MFCAI)
Cube Sensor 1
ACME FLOW MI MIXER SETPOINT | ACME FLOW MI MIXER FLOW | Cube Sensor 2 | 34.422
Hard Drive | 26
21:35 | 21:36 | 21:37 | 21:38 | 21:39
17 Fri May 2019 | Tine (s)
24.584718 | 0.046 | mV
23.345234 | -0.004
(TC2) | mV
State | Operate | c | 0.000 | SLPM | R | 0.003 | SLPM | scale | 0.500
TCCJ | 23.460169 | 0.875
Bypass(MFCA2)
Rake: Far
E 0.050 | 29.651759 | 0.251
mV
nvalid-/ow | 0.010 | mV
21:35 | 21:36 | 21:37 | 21:38 | 21:39 | hvalid40w | -0.002
mV
17 Fri May 2019 | Time (s)
TCD | 27.454880 | o. 162 | mV
Sbte | Operate | c | 0.000 | R | 0.005 | scale | 0.200
Fuel(MFCA3) | Bume-: Sphere.' (1/4)
TC | 111.164601 | 3.620
ACME FLOW M3 FUEL SETPOINT | ACME FLOW M3 FUEL FLOW
0.10
0.05
Cube Cmnection | Connected
21:35 | 21:36 | 21:37 | 21:38 | 21:39
17 fri may 2019 | Time (s)
Time Series Chart
Packet | Softaare | Low
ACME Teleme ACME DIAG PMT_TI | 0.00
ACME Telerne ACME-DIAG—PMT _T2 | 0.00
ACME Teleme | 0.00
2.] | 0.5
Select [terns | End Plotting
21:38:15 | 21:38:30 | 21:38:45 | 21:39:00
17 May 2019 | Restart | 17Fri May2019 | Time
StartTme,
After test, 594 on lowest valve safety timer, 693 psia in oxidizer bottle
13
~~~~

### Pagina 14

Cita: [pdf_b4d20d0a355fbc41d2c9, p. 14]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_b4d20d0a355fbc41d2c9/p0014.jpg)

~~~~text
14
Test 19137L2 – successful test, run with
fuelBottleIgnitionFlowRateN2Slpm=0.078, 
nitrogenIgnitionFlowRateN2Slpm=0.052, fuelBottleTestFlowRateN2Slpm=0.078,
nitrogenIgnitionTestRateN2Slpm=0.052, constantFlowTimeSec=3
dataCamera Focus=13750, dataCamera Zoom=30000
Analog Camera Gain=21 dB
After test, 554 on lowest valve safety timer, 693 psia in oxidizer bottle

[Texto OCR de la imagen]
Test 19137L2 — successful test, run with
fuelBottIeIgnitionFIowRateN2Slpm=O.078,
nitrogenlgnitionFlowRateN2Slpm=O.052, fuelBottleTestFIowRateN2Slpm= 0.078,
nitrogenlgnitionTestRateN2Slpm=O.052, constantFlowTimeSec=3
dataCamera Focus=13750, dataCamera Zoom=30000
Analog Camera Gain—21 dB
Gas Flow Charts | -IOIS
File Graphs
2019-05-17 | Gtv1T
2019-05-17 22:50:48
System Ternperatures
cpc, | 32.300
State | Operate | c | 0.000 | SLPM | R | -0.008 | SLPM | scale | 20.000 | All Gahs
CPU Board | 35.000
Static Mixer Line (MFCAI) | Set
Cube Sensor 1 | 34.435
Cube Sensor 2 | 34.
set | Hard Drive | 26
-0.01
22:45 | 22:46 | 22:47 | 22:49 | 22:50
17 fri may 2019 | Time (s)
24.733362 | 0.052
23.246015 | -0.008 | mV
0.000 | 0.000 | 0.500 | CTC2)
State | Operate | c | SLPM | R | scale
0.875
Bypass(MFCA2)
ay
Rake:
ACME FLOW MZ BYPASS SETPOINT | ACME FLOW M2 BYPASS FLOW
30.095517 | 0.269
mV
invaüd40w | 0.000
22:45 | 22:46 | 2247 | 22:48 | 22:49 | 22:50 | invalid-low | -0.005
17 Fri May 2019 | Tirne (s)
28.269985 | 0.195
State | Operate | c | 0.000 | SLPM | R | -0.000 | SLPM | scale | 0.200
Fuel(MFCA3) | Burnet Spherical (1/4)
141.861765 | 4.871
ACME FLOW M3 FUEL SETPOINT | ACME FLOW '•13 FUEL FLOW
0.050
0.025
0.000 | Cube Comectim
22:45 | 22:46 | 22:47 | 22:48 | 22:49 | 22:50
17fri may 2019 | Time (s)
Time Series Chart
packet | Softw•a-e "-ternoric
ACME Teleme ACME DIAG PMT Tl | 0.00
ACME Teleme ACME DIAG | T2 | 0.00
ACME Teleme ACME DIAG PMT T3 | 0.00 | 2.5
2.] | os
Select Items | End Plotting
za:so::
17 May | Restart | 17 fri may 2019
StartTme,
After test, 554 on lowest valve safety timer, 693 psia in oxidizer bottle
14
~~~~

### Pagina 15

Cita: [pdf_b4d20d0a355fbc41d2c9, p. 15]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_b4d20d0a355fbc41d2c9/p0015.jpg)

~~~~text
15
Test 19137L3 – successful test, run with
fuelBottleIgnitionFlowRateN2Slpm=0.078, 
nitrogenIgnitionFlowRateN2Slpm=0.052, fuelBottleTestFlowRateN2Slpm=0.078,
nitrogenIgnitionTestRateN2Slpm=0.052, constantFlowTimeSec=3, 
rampFlowToZeroSec=30
dataCamera Focus=13750, dataCamera Zoom=30000
Analog Camera Gain=21 dB
After test, 514 on lowest valve safety timer, 692 psia in oxidizer bottle

[Texto OCR de la imagen]
Test 19137L3 — successful test, run with
fuelBottIeIgnitionFIowRateN2Slpm=O.078,
nitrogenlgnitionFlowRateN2Slpm=O.052, fuelBottleTestFIowRateN2Slpm= 0.078,
nitrogenlgnitionTestRateN2Slpm=O.052, constantFlowTimeSec=3,
rampFlowToZeroSec=30
dataCamera Focus=13750, dataCamera Zoom=30000
Analog Camera Gain=21 dB
Gas Flow Charts | —IOS
File Graphs
2019-05-17 23:09: 14 | GMT
EXPERIMENT | 2019-05-17 23:09: 14
System Temperab_r
33,000
State | Operate | c | 0.000 | SLPM | R | -0.010 | SLPM | scale | 20.000 | All Gains
Board | 35.000 | 'C
Static Mixer Line (MFCAI)
CLbe | 34.439
Sensor 1
ACME FLOW MI MIXER SETPOINT | ACME FLOW MI MIXER FLOW | CLbe | 2
Hæ•d Drive | 26
-0.010
23:05 | 23:06 | 23:07 | 23:08 | 23:09
17 fri may 2019 | Time (s)
(TCI) | 24.924527 | 0.046
23.561440 | -0.009
Operate | c | 0.000 | SLPt.•1 | R | -0.001 | SLPM | scale | 0.500
23.799147
Bypass(MFCA2)
Rake: Far
ACME FLOW | BYPASS SETPOINT | ACME FLOW M2 BYPASS FLOW
0.050 | 31.344866 | 0.306
0.025
0.000 | nvalid-low | -0.001
23:05 | 23:06 | 23:07 | 23:08 | 23:09 | nvalid-low | -0.012
may 2019 | Tune (s)
29.398180 | 0.227
State | Operate | c | 0.000 | R | -0.000 | SLPM | scale | 0.200
Fuel(MFCA3) | Burner: Spheöca/ (1/4
130.431828 | 4.394
ACME FLOW "3 R.JEL SETPOINT | ACME FLOW M3 FUEL FLOW
0.075
0.050
0.025
0.000 | be Comection
23:05 | 23:06 | 23:07 | 23:08 | 23:09
17 m | 2019 | Tine (s)
.2 Time Series Chart #1
Packet | Soft'.vare t•tznonic
ACtvE Teleme | 0.00
ACME Teleme | 0.00
Teleme | 2.5
ACE- | ACME DIAG PMT T3 | 0.00
> 2.0
Select Items | End Plottng
23:08:15 | 23:08230 | 23:08:45
17May 2019 | Restart | 17Fri May 2019 | Time
StartTme
After test, 514 on lowest valve safety timer, 692 psia in oxidizer bottle
15
~~~~

### Pagina 16

Cita: [pdf_b4d20d0a355fbc41d2c9, p. 16]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_b4d20d0a355fbc41d2c9/p0016.jpg)

~~~~text
16
Test 19137L4 – successful test, run with
fuelBottleIgnitionFlowRateN2Slpm=0.078, 
nitrogenIgnitionFlowRateN2Slpm=0.052, fuelBottleTestFlowRateN2Slpm=0.078,
nitrogenIgnitionTestRateN2Slpm=0.052, constantFlowTimeSec=3, 
rampFlowToZeroSec=20
dataCamera Focus=13750, dataCamera Zoom=30000
Analog Camera Gain=21 dB
After test, 475 on lowest valve safety timer, 693 psia in oxidizer bottle

[Texto OCR de la imagen]
Test 19137L4 — successful test, run with
fuelBottIeIgnitionFIowRateN2Slpm=O.078,
nitrogenlgnitionFlowRateN2Slpm=O.052, fuelBottleTestFIowRateN2Slpm= 0.078,
nitrogenlgnitionTestRateN2Slpm=O.052, constantFlowTimeSec=3,
rampFlowToZeroSec=20
dataCamera Focus=13750, dataCamera Zoom=30000
Analog Camera Gain=21 dB
Gas Flow Charts | —IOS
Graphs
2019-05-17 23: 2513 | GMT
state | 2019-05-17 23:25: 13
system | Systan
32.300
Operate | c | 0.000 | SLPM | R | -0.008 | SLPM | Fun scale | 20.000 | Al Gains
Board | 35.000
Static Mixer Line (MFCAI)
CLbe Sensor I | 34.516
ACME FLOW | MIXER SETPOINT | ACME FLOW | MIXER FLOW | CLbe Sensor 2 | 34.498
Hard Crive | 26
-0.01
23:21 | 23:22 | 23:23 | 23:24 | 23:25
17 Fri May 2019 | Tune (s)
A (TCI) | 24.751137 | 0.039
23.611036 | -0.007 | mV
(TC2)
State | Operate | c | 0.000 | SLPM | R | 0.000 | scale | 0.500
TCCJ | 23.799147 | 0.876
Bypass(MFCA2)
ay
Rake: Far
0.050 | 29.940656 | 0.249
0.025
TCB | invalid-low | 0.008 | mV
23:21 | 23:22 | 23:23 | 23:24 | 23:25 | invalid-low | -0.009
17 Fri May 2019 | Time (s)
TCD | 27.620855 | o, 155
State | Operate | c | 0.000 | SLPM | R | 0.000 | SLPM | scale | 0.200
Fuel(MFCA3) | Burns-:
136.640544
ACME_FLOW
0.075
0.050
0.025
Cube Connection
23:21 | 23:22 | 23:23 | 23:24 | 23:25
17 fri may 2019 | Time (s)
Time Series Chart #1
Packet | Software Mnemonic
ACME | 0.00
ACME Teleme ACME DIAG | T2 | 0.00
ACME Teleme | 0.00 | 2.5
0.5
Se'ect Items | End Plotting
17May 2019 | Restart | 17 Fri nay 2019 | Time
startTtme,
After test, 475 on lowest valve safety timer, 693 psia in oxidizer bottle
16
~~~~

### Pagina 17

Cita: [pdf_b4d20d0a355fbc41d2c9, p. 17]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_b4d20d0a355fbc41d2c9/p0017.jpg)

~~~~text
17
Test 19137L5 – successful test, run with
fuelBottleIgnitionFlowRateN2Slpm=0.078, 
nitrogenIgnitionFlowRateN2Slpm=0.052, fuelBottleTestFlowRateN2Slpm=0.078,
nitrogenIgnitionTestRateN2Slpm=0.052, constantFlowTimeSec=3, 
rampFlowToZeroSec=15
dataCamera Focus=13750, dataCamera Zoom=30000
Analog Camera Gain=21 dB
After test, 440 on lowest valve safety timer, 692 psia in oxidizer bottle

[Texto OCR de la imagen]
Test 19137L5 — successful test, run with
fuelBottIeIgnitionFIowRateN2Slpm=O.078,
nitrogenlgnitionFlowRateN2Slpm=O.052, fuelBottleTestFIowRateN2Slpm= 0.078,
nitrogenlgnitionTestRateN2Slpm=O.052, constantFlowTimeSec=3,
rampFlowToZeroSec=15
dataCamera Focus=13750, dataCamera Zoom=30000
Analog Camera Gain=21 dB
Gas Flow Charts | —IOS
File Graphs
2019-05-17 | GMT
2019-05-17 23:58:39
System Temper atures
32.700
Operate | c | 0.000 | SLPM | R | -0.009 | SLPM | Ft-ASca1e | 20.000 | All Gains
CPU Board | 34.000
Static Mixer Line (MFCAI) | Set
Cube Sensor 1 | 34.457
Set
ACME FLOW MI MIXER SETPOINT | ACME FLOW MI MIXER FLOW | Cube Sensor 2
0.005
E 0.000 | set | 26
Hard Drive
-0.005
-0.010
23:54 | 23:55 | 23:56 | 23:57 | 23:58
17 Fri May 2019 | Time (s)
24.708589 | 0.051
23.419642 | -0.001
State | Operate | c | 0.022 | R | 0.019 | scale | 0.500
23.460169 | 0.875
Bypass(MFCA2)
Rake: Far
0.075
28.887072 | 0.220
0.050
0.025
0.000 | nvaEd40w | 0.000
23:54 | 23:55 | 23:56 | 23:57 | 23:58 | unvaEd40w | -0.006
17 Fri May 2019 | Tune (s)
26.466035 | 0.122
State | Operate | c | 0.033 | SLPM | R | 0.032 | SLPM | scale | 0.200
Fuel(MFCA3) | Burnet Sph"a/ (1/4)
132.161315 | 4.478 | mV
0.025
0.000 | Cube Comecåon
23:54 | 23:55 | 23:56 | 23:57 | 23:58
nay 2019 | Tine (s)
Time Series Chart
Packet | Soffvare r•-henonic
ACME Teleme ACME | 0.00
ACME Telerne ACME DIAG | T2 | 0.00
ACME Teleme | 0.00 | 2.5
0.5
Select Items | End Plotting
17May2019 | Restart | 17 Fri May 2019
startrme,
After test, 440 on lowest valve safety timer, 692 psia in oxidizer bottle
17
~~~~

### Pagina 18

Cita: [pdf_b4d20d0a355fbc41d2c9, p. 18]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_b4d20d0a355fbc41d2c9/p0018.jpg)

~~~~text
18
Test 19137L6 – successful test, run with
fuelBottleIgnitionFlowRateN2Slpm=0.078, 
nitrogenIgnitionFlowRateN2Slpm=0.052, fuelBottleTestFlowRateN2Slpm=0.078,
nitrogenIgnitionTestRateN2Slpm=0.052, constantFlowTimeSec=3, 
rampFlowToZeroSec=50
dataCamera Focus=13750, dataCamera Zoom=30000
Analog Camera Gain=21 dB
After test, 402 on lowest valve safety timer, 692 psia in oxidizer bottle

[Texto OCR de la imagen]
Test 19137L6 — successful test, run with
fuelBottIeIgnitionFIowRateN2Slpm=O.078,
nitrogenlgnitionFlowRateN2Slpm=O.052, fuelBottleTestFIowRateN2Slpm= 0.078,
nitrogenlgnitionTestRateN2Slpm=O.052, constantFlowTimeSec=3,
rampFlowToZeroSec=50
dataCamera Focus=13750, dataCamera Zoom=30000
Analog Camera Gain=21 dB
Gas Flow Charts | —IOS | —lg]S
File Graphs
state | 2019-05-18
system | System Temperatures
cpu | 32.800
Operate | c | 0.000 | QPM | R | -0.009 | SLPM | Ft] Scale | 20.000 | AI Gains
cpu Board | 35.000
Static Mixer Line (MFCAI)
Cube Sensor 1 | 34.547
ACME FLOW MI MIXER SETPOINT | ACME FLOW MI MIXER FLOW | Cube Sens-cr 2 | 34.557
Hard Drive | 26
0:15 | o:zo | 0:25
18sat may 2019 | Time (s)
CTCI) | 24.881985 | 0.058
CTC2) | 22.997929 | -0.013 | mV
State | Operate | c | 0.000 | SLPM | R | 0.000 | scale | o. 500
TCCJ | 23.460169 | 0.875
Bypass(MFCA2)
ay
R.ke: Far
31.893292 | 0.342
TCS | m alid-low | -0.002 | mV
0:15 | 0220 | 0:25 | invalid-Io'" | -0.006
mV
18 Sat May 2019 | Time (s)
TCD | 29.528460 | 0.246 | mV
State | Operate | c | 0.000 | SLPM | R | •0.000 | SLPM | scale | 0.200
Fuel(MFCA3) | Sphe±ä/ (1/4)
128.226520 | 4.318 | Snap
0.10
± 0.05
CLbe Comecbon
0:15 | 0:20 | 0:25
18Sat May 2019 | Time (s)
Time Series Chart #1
Packet | So fta•are Mnemonc
ACME Teleme ACME DIAG | Tl | 0.00
ACYE | 0.00
Teleme | 2.5
ACFE | 0.00
> 2.0
Select Items | End Plotting
0:26:00 | 0:26:15 | 0:26:30 | 0:26:45
18May 2019 | Restart | 18sat | 2019
startnrne,
After test, 402 on lowest valve safety timer, 692 psia in oxidizer bottle
18
~~~~

### Pagina 19

Cita: [pdf_b4d20d0a355fbc41d2c9, p. 19]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_b4d20d0a355fbc41d2c9/p0019.jpg)

~~~~text
19
Test 19137L7 – successful test, repeat of L1 (neglecting vitiation), run with 
fuelBottleIgnitionFlowRateN2Slpm=0.078, 
nitrogenIgnitionFlowRateN2Slpm=0.052, fuelBottleTestFlowRateN2Slpm=0.078,
nitrogenIgnitionTestRateN2Slpm=0.052, constantFlowTimeSec=115,
rampFlowToZeroSec=40
dataCamera Focus=13750, dataCamera Zoom=30000
Analog Camera Gain=21 dB
After test, 367 on lowest valve safety timer, 693 psia in oxidizer bottle

[Texto OCR de la imagen]
Test 19137L7 — successful test, repeat of LI (neglecting vitiation), run with
fuelBottIeIgnitionFIowRateN2Slpm=O.078,
nitrogenlgnitionFlowRateN2Slpm=O.052, fuelBottleTestFIowRateN2Slpm= 0.078,
nitrogenlgnitionTestRateN2Slpm=O.052, constantFlowTimeSec=115,
rampFlowToZeroSec=40
dataCamera Focus=13750, dataCamera Zoom=30000
Analog Camera Gain=21 dB
.t. Gas Flow Charts
File Graphs
2019-05-18 00:39:36 | GMT
2019-05-18
System Temperaües
cpu | 33.000
State | Operate | c | 0.000 | SLPM | R | -0.003 | SLPM | scale | 20.000 | All Gains
Board | 35.000
Static Mixer Line (MFCAI)
Cube Sensor 1 | 34.424 | DC
Cube Sensor 2 | 34.460
0.000
-0.005 | Hard Drive | 26
-0.010
0:35 | 0:36 | 0:37 | 0:38 | 0:39
18 sat may 2019 | Time (S)
A (TCI)
CTC2) | 23.834192 | 0.002
Operate | c | 0.000 | SLPM | R | 0.000 | scale | 0.500
TCCJ | 23.799147 | 0.876 | v
Bypass(MFCA2)
ACME FLOW | BYPASS SETPOINT | ACME FLOW | BYPASS FLOW
31.664863 | 0.319
invalid-low | 0.000
0:35 | 0236 | 0:37 | 0:38 | 0:39 | invalid-low | -0.007
18 sat | 2019 | Tine (s)
29.866699
State | Operate | 0.000 | SLPM | R | -0.000 | SLPM | scale | 0.200
Fuel(MFCA3) | Sphee,a/ (1/4
118.128257 | 3.892
ACME FLOW "3 FUEL SETPOINT | ACME_FLOW | FUEL FLOW
0.075
0.050
0.025
0.000 | Cube Connection
0235 | 0:36 | 0:37 | 0:39
18 Sat May 2019 | Tine (s)
Time Series Chart #1
So ftvvare Mnemonic
ACME Teleme | DIAG PMT Tl | 0.00
ACME | 0.00
Teleme | 2.5
ACME | ACME DIAG PMT T3 | 0.00
> 2.0
Se!ect Items | End Plotting
o:38230 | 0:38:45 | 0239:15
Restart | 18 sat may 2019 | Time
StartTme,
After test, 367 on lowest valve safety timer, 693 psia in oxidizer bottle
19
~~~~

### Pagina 20

Cita: [pdf_b4d20d0a355fbc41d2c9, p. 20]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_b4d20d0a355fbc41d2c9/p0020.jpg)

~~~~text
20
Test 19137L8 – successful test, repeat of L2 (neglecting vitiation), run with 
fuelBottleIgnitionFlowRateN2Slpm=0.078, 
nitrogenIgnitionFlowRateN2Slpm=0.052, fuelBottleTestFlowRateN2Slpm=0.078,
nitrogenIgnitionTestRateN2Slpm=0.052, constantFlowTimeSec=3,
rampFlowToZeroSec=40
dataCamera Focus=13750, dataCamera Zoom=30000
Analog Camera Gain=21 dB
After test, 330 on lowest valve safety timer, 693 psia in oxidizer bottle

[Texto OCR de la imagen]
Test 19137L8 — successful test, repeat of L2 (neglecting vitiation), run with
fuelBottIeIgnitionFIowRateN2Slpm=O.078,
nitrogenlgnitionFlowRateN2Slpm=O.052, fuelBottleTestFIowRateN2Slpm= 0.078,
nitrogenlgnitionTestRateN2Slpm=O.052, constantFIowTimeSec=3,
rampFlowToZeroSec=40
dataCamera Focus=13750, dataCamera Zoom=30000
Analog Camera Gain=21 dB
2. Gas Flow Charts
File Graphs
2019-05-18 00:53:31 | GMT
state | 2019-05-18
system | System Ternperatures
CPU | 33.000
Operate | c | 0.000 | SLPM | R | -0.009 | SLPM | Fun scale | 20.000 | All Gains
cpc, Board | 35.000
Static Mixer Line (MFCAI)
Cube Sensor 1 | 34,517
0.1 be Sensor 2 | 34.539
Hard Drive | 26
-OJI
0:49 | 0:50 | 0:51 | 0:52 | 0:53
18sat may 2019 | Time (s)
0.047
23.611036 | -0.007
CC2)
Operate | c | 0.000 | SLPM | R | -0.001 | scale | 0.500
TCCJ | 23.799147 | 0.876
Bypass(MFCA2)
Rake: Far
ACME_FLOW M2 BYPASS SETPOINT | ACME_FLOW M2 BYPASS FLOW
31.098649 | 0.296
invalid-low | 0.005
0:49 | 0:50 | 0:51 | 052 | 0:53 | invalid-low | 0.000
18Sat May 2019 | Time (s)
29.028151 | 0.212
Operate | c | 0.000 | SLPM | R | -0.001 | SLPM | scale | 0.200
Fuel(MFCA3) | Burne-: Spherical (1/4)
134.051032 | 4.541
ACME FLOW "3 FUEL SETPOINT | ACME FLOW M3 FUEL FLOW
0.075
0.050
0.025
Cube Connection | Connected
0:49 | 0:50 | 0:51 | 0:52 | 0:53
18Sat May 2019 | Time (s)
Time Series Chart *1
packet | Softaare
ACME Teleme ACME DIAG | 0.00
Teleme | 0.00
2.5
ACME Teleme ACME DIAG | T3 | 0.00
> 2.0
Select Items | End PIO tong
0:52:15 | 0:52:30 | 0:52:45 | 0:53:00
18May 2019 | Restart | 18sat may 2019 | Time
StartTime
After test, 330 on lowest valve safety timer, 693 psia in oxidizer bottle
20
~~~~
