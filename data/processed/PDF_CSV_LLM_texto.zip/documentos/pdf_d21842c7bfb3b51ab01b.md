# 19070 test sheets

- Identificador: pdf_d21842c7bfb3b51ab01b
- Investigaciones: PSI-20
- Tipo de documento: Raw Data
- Estado: processed
- Temas detectados automaticamente: ignition, hardware, pressure, oxygen

## Fuentes

- [PSI-20_Raw Data_19070 test sheets.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-20/Raw%20Data/PSI-20_Raw%20Data_19070%20test%20sheets.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_d21842c7bfb3b51ab01b, p. 1]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_d21842c7bfb3b51ab01b/p0001.jpg)

~~~~text
ACME / BRE - Science Test Sheet
est date: | 1 | 20 | CME test#: | 70
Local time: | D5D | est of day #:
MT: | 070 1 5b | Flame of day #:
TEST CONDITIONS | Control? | fully automated 'manual'
Test type? o fiber ignition o no-flame o ramp o stepping Gandard o other
xygen conc. | 38 % (volume) | Burner diameter: A-25 mm D 50 mm
Chamber pressure: | ee2— psia | Fuel Bottle: | CH4 | % KC2H4SO %
ent before? o no | to | psia | Burner fuel conc.: | % (volume)
Air' added? D no Ayes, to | psia | Fuel flow rate: 0.1 slpm (N2 basis)
Iso just before? o fan D GC o scrub | slpm
INSTRUMENTATION | FP? no o fixed o moving ü back-n-forth
DataCam: filter? | o BG7 | CH20 | ROI? Afull o reduced | fps
D Intensified: filter? o | o CH20 none | ROI? E-full o reduced | fps
_
• backlight filter? D no Ryes | CIR backlight? (no o | fps? 0 15 D 30
yes
FLAME BEHAVIOR | Ignited? Kyes no o yes, but
.
Flame hole/opening o partially detached | 00t none Wgnition only o little o lots
Flame o oscillating o unsteady o blew out | oot@end none o ignition o little D lots
*GENERAL COMMENTS
361 love D-æ
6 Feb. 2019
~~~~

### Pagina 2

Cita: [pdf_d21842c7bfb3b51ab01b, p. 2]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_d21842c7bfb3b51ab01b/p0002.jpg)

~~~~text
ACME / BRE - Science Test Sheet
est date: | CME test
Local time: | est of day #:
MT: | Flame of day #:
TEST CONDITIONS | Control? | o fully automated o 'manual'
Test type? o fiber o ignition o no-flame o ramp o stepping o standard o other
xygen conc. | 6 % (volume) | Burner diameter: 8-25 mm 50 mm
Chamber pressure: | psia | 4Q Fuel Bottle: o CH4 | -20/6
ent before? n no o yes, to | psia | Burner fuel conc.: | % (volume)
Air' added? no o yes, to | psia | Fuel flow rate: D. 125 slpm (N2 basis)
Iso just before? (fan D GC scrub | slpm
INSTRUMENTATION | FP? | fixed o moving o back-n-forth
[RDataCam: filter? Rclear a BG7 | D CH20 | ROI?Qfull o reduced | fps
Intensified: filter? clear | a CH20 0 none | ROI? Qfull o reduced | a fps
-.g-HiBMs.• backlight filter? no a yes | CIR backlight? | yes fps? 0 15 0 30
FLAME BEHAVIOR | Ignited? | es no o yes, but *
...
Flame a hole/opening o partially detached | 00t o nonenjgnition only o little Xlots
Flame o oscillating a unsteady ü blew out | oot@end Enone o ignition little lots
*GENERAL COMMENTS
3RE-
6 Feb. 2019
~~~~

### Pagina 3

Cita: [pdf_d21842c7bfb3b51ab01b, p. 3]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_d21842c7bfb3b51ab01b/p0003.jpg)

~~~~text
ACME / BRE - Science Test Sheet
est date: | CME test#:
Local time: | est of day #:
MT: | ( 070 | Flame of day #:
TEST CONDITIONS | Control? | <fully automated o 'manual'
Test type? o fiber o ignition o no-flame D ramp o stepping o standardk other
INSTRUMENTATION | FP? o no o fixed o moving o back-n-forth
DataCam: filter? o clear o BG7 D | a CH20 | ROI? full o reduced | fps
O Intensified: filter? o clear CH* a CH20 none | ROI? o full o reduced | fps
_
o HiBMs: backlight filter? o no o yes | CIR | o yes fps? 0 15 0 30
FLAME BEHAVIOR | Ignited? Zyes Ü no o | but ...*
yes,
Flame o hole/opening a partially detached | 00t o none | nition only o little lots
Flame o oscillating o unsteady o blew out | oot@end none o ignition o little D lots
*GENERAL COMMENTS
342 | Öz—
6 Feb. 2019
~~~~

### Pagina 4

Cita: [pdf_d21842c7bfb3b51ab01b, p. 4]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_d21842c7bfb3b51ab01b/p0004.jpg)

~~~~text
ACME / BRE - Science Test Sheet
est date: | CME test #: | DP
Local time: | so | est of day#:
Flame of day #:
TEST CONDITIONS | ontrol? | automated o 'manual'
Test type? o fiber o ignition o no-flame o ramp o stepping Xstandard *other
xygen conc. | C % (volume) * Burner diameter: <-25 mm 0 50 mm
hamber pressure: | 3,2- psia | Fuel Bottle: CH4 | 0/6séC2H4CO/0
OR
ent before? no ryes; to | psia 4 | Burner fuel conc.: | 500/6 (volume)
Air' added? D no yes, to | psia | Fuel flow rate: 415bsl m (N2 basis)
Iso just before? | fan KGC o scrub | te: | slpm
no Scrub
INSTRUMENTATION | FP? no o fixed o moving o back-n-forth
A DataCam: filter? Vclear o BG7 D CH* o CH20 | ROI? (full o reduced | fps
Intensified: filter? clear | CH20 0 none | ROI? | o reduced | fps
o HiBMs: backlight filter? ono yes | CIR backlight? | 0 yes fps? 0 15 0 30
FLAME BEHAVIOR | Ignited? | D no o yes, but ...*
Flame o hole/opening o partially detached | 00t D none q ignition only o little
Flame o oscillating a unsteady o blew out | oot@end none ignition little o lots
z
*GENERAL COMMENTS
Zz.r
g % | -/-zs•k
3
411
6 Feb. 2019
~~~~

### Pagina 5

Cita: [pdf_d21842c7bfb3b51ab01b, p. 5]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_d21842c7bfb3b51ab01b/p0005.jpg)

~~~~text
ACME / BRE - Science Test Sheet
est date: | CME test | Z
Local time: | est of day | S
MT: | 07 | Flame of day
TEST CONDITIONS | ontrol? | <fully automated 'manual'
Test type? o fiber o ignition o no-flame o ramp o stepping «standard other
Oxygen conc. | 42-7-5 % (volume) | Burner diameter: | mm D 50 mm
hamber pressure: | Fuel Bottle: 0CH4 | 0/0üC2H4
ent before? o no (yes, to | psia | Burner fuel conc.: 50 % (volume)
Air' added? D no<yes, to | psia | Fuel flow rate: | 31pm (N2 basis)
Iso just before? o fan GC o scrub | te: | slpm
INSTRUMENTATION | FP? Kno fixed o moving o back-n-forth
DataCam: | o BG7 | D CH20 | ROI? <ull o reduced | fps
_
O Intensified: filter? o clear | o CH20 0 none | ROI? | a reduced
g-HiBMs: backlight filter? no Oes | CIR backlight? (no o yes fps? 15 0 30
FLAME BEHAVIOR | Ignited? nyes ü no o yes, but ...*
Flame o hole/opening o partially detached | 00t Xnone o ignition only o little o lots
Flame o oscillating o unsteady o blew out | oot@end Qnone o ignition o little D lots
*GENERAL COMMENTS
Ats,.
•ReA
6 Feb. 2019
~~~~

### Pagina 6

Cita: [pdf_d21842c7bfb3b51ab01b, p. 6]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_d21842c7bfb3b51ab01b/p0006.jpg)

~~~~text
ACME/ BRE - Science Test Sheet
est date: | It | 201? | CME test #:
Local time: | est of day #:
MT: | Flame of day #:
TEST CONDITIONS | Control? | <ully automated o 'manual'
Test type? o fiber o ignition o no-flame o ramp o steppingQstandard o other
xygen conc. | & 22 % (volume) | Burner diameter: 1(25 mm 50 mm
hamber pressure: | /D-2- psia | Fuel Bottle: | CH4 | % | 50-0/0
ent before? Qoo o yes, to | psia | Burner fuel conc.: | SD % (volume)
Air' added? üo o yes, to | psia | Fuel flow rate: DDCslpm (N2 basis)
Iso just before? (fan o GC o scrub | slpm
INSTRUMENTATION | FP? o no o fixed o moving back-n-forth
KDataCam: filter? Cclear o BG7 0 CH* o CH20 | ROI? (full o reduced | fps
Olntensified: filter? clear | CH20 0 none | ROI? Wfull o reduced | 23fps
€-HtBMs±acklight filter? o no Ayes | CIR backlight?Qno yes fps? 15 0 30
FLAME BEHAVIOR | o no yes, but ...*
Flame o hole/opening o partially d tached | 00tQnone o ignition only o little lots
Flame o oscillating o unsteady o blew out | oot@end &none D ignition a little lots
*GENERAL COMMENTS
6 Feb. 2019
~~~~

### Pagina 7

Cita: [pdf_d21842c7bfb3b51ab01b, p. 7]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_d21842c7bfb3b51ab01b/p0007.jpg)

~~~~text
ACME / BRE - Science Test Sheet
est date: | CME test#: | 70
Local time: | est of day #:
MT: | 07 | D e-t | Flame of day #:
TEST CONDITIONS | ontrol? | automated o 'manual'
Test type? o fiber o ignition a no-flame ramp o steppingXstandard o other
xygen conc. | % (volume) | Burner diameter: | mm 0 50 mm
hamber pressure: | 2— psia | Fuel Bottle: o CH4 | % c2H4EC0/0
ent before? o no o yes, to | psia | Burner fuel conc.: SD % (volume)
Air' added? o no o yes, to | psia | Fuel flow rate:0 056 slpm (N2 basis)
Iso just before? dfan D GC o scrub | slpm
INSTRUMENTATION | FP? no o fixed o moving o back-n-forth
*DataCam: filter? g-clear BG7 | o CH20 | ROI? o full o reduced | fps
Qlntensified: filter? o clear | o CH20 0 none | ROI? o full o reduced | Efps
s-HiBMsi backlight filter? o no Ryes | CIR backlight? | o yes fps? 0 15 a 30
FLAME BEHAVIOR | Ignited? yes o no c yes, but *
...
Flame o hole/opening partiall detached | 00t none o ignition only o little o lots
Flame o oscillating o unsteady o blew out | oot@end none o ignition o little lots
*GENERAL COMMENTS
F 267zP/o
6 Feb. 2019
~~~~

### Pagina 8

Cita: [pdf_d21842c7bfb3b51ab01b, p. 8]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_d21842c7bfb3b51ab01b/p0008.jpg)

~~~~text
ACME / BRE - Science Test Sheet
est date: | II | zol | CME test | ) e DJ
Local time: | est of day#:
MT: | Flame of day #:
TEST CONDITIONS | ontrol? | &lly automated o 'manual'
Test type? o fiber o ignition o no-flame o ramp o stepping Qstandard o other
xygen conc. | A-Z7- | % (volume) | Burner diameter: Q 25 mm 0 50 mm
hamber pressure: | psia | Fuel Bottle: o CH4 | 0/6 QC2H4 5b %
ent before? < no o yes, to | psia | Burner fuel conc.: 50 % (volume)
Air' added? pno o yes, to | psia | Fuel flow rate:D.b47 slpm (N2 basis)
Iso just before? | fan D GC o scrub | N.2-fIow-ca.t€+- | slpm
INSTRUMENTATION | FP? Koo o fixed moving o back-n-forth
<DataCam: filter? Y-clear BG7 0 | CH20 | ROI? A full reduced | fps
_
filter? o clearm CH* a CH20 0 none | ROI? R full o reduced | Zfps
Y-HiBMs•. backlight filter? o no nyes | CIR backlight? (no o yes fps? 0 15 0 30
FLAME BEHAVIOR | Ignited? o yes Eno a yes, but ...*
Flame ü hole/opening a partially detached | 00t none o ignition only o little o lots
Flame o oscillating o unsteady o blew out | oot@end o none o ignition o little D lots
*GENERAL COMMENTS
6 Feb. 2019
~~~~

### Pagina 9

Cita: [pdf_d21842c7bfb3b51ab01b, p. 9]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_d21842c7bfb3b51ab01b/p0009.jpg)

~~~~text
ACME / BRE - Science Test Sheet
est date: | CME test #:
Local time: | est of day #:
GMT: | Flame of day #:
TEST CONDITIONS | ontrol? | g-fully automated o 'manual'
Test type? o fiber o ignition o no-flame o ramp D stepping Cstandard D other
xygen conc. | % (volume) | Burner diameter: Ü5 mm 50 mm
hamber pressure: | psia | Fuel Bottle: o CH4 | 0/6QC2H4
ent before? o no yes, to | psia | Burner fuel conc.: | (volume)
Air' added? no o yes, to | psia | Fuel flow rate: | slpm (N2 basis)
Iso just before? o fan GC o scrub | slpm
INSTRUMENTATION | FP? | o fixed o moving o back-n-forth
L DataCam: filter? Eclear BG7 | CH20 | ROI? Cfull o reduced | fps
_
Elntensified: filter? o clear z CH* CH20 a none | ROI? Zfull o reduced | 2 fps
a-HiBMsybacklight filter? no sayes | CIR backlight? ZoO o yes fps? 0 15 0 30
FLAME BEHAVIOR | Ignited? c] yes | o yes, but *
...
Flame o hole/opening o partially detached | 00t none o ignition only o little o lots
Flame o oscillating o unsteady o blew out | oot@end o none o ignition o little o lots
*GENERAL COMMENTS
Vie /
6 Feb. 2019
~~~~
