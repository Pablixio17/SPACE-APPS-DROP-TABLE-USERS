# 21216 test parameter notes

- Identificador: pdf_b53d439fe4ed40dd492e
- Investigaciones: PSI-159
- Tipo de documento: Raw Data
- Estado: processed
- Temas detectados automaticamente: oxygen, ignition, extinction, hardware, operations

## Fuentes

- [PSI-159_Raw Data_21216 test parameter notes.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-159/Raw%20Data/PSI-159_Raw%20Data_21216%20test%20parameter%20notes.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_b53d439fe4ed40dd492e, p. 1]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_b53d439fe4ed40dd492e/p0001.jpg)

~~~~text
testpointName | 21216A1
dataCameraPrelgnitionExposureUs | 1000000
dataCameraTestExposureUs | 100000
analogCameraShutter | 2
uselntensifiedCamera | TRUE
intensifierlgnitionGain | 20000
intensifierTestGain | 60000
preignition'mageTimeSec
postFla melmagingTi meSec | 5
useDataCameraAutoGain | FALSE
autoGainTolerancePercent | 5
autoGainMaxDb | 33
autoGainMinDb
autoGainOutliers
autoGainRatePercent | 100
autoGainTargetPercent | 50
rampDataCameraGain | FALSE
dataCameraGain1dB
dataCameraGain2dB
data CameraGain3dB | 0
dataCameraHoldTime1Sec
dataCameraHoldTime2Sec
dataCameraRamp1t02TimeSec | 5
dataCameraRamp2t03TimeSec | 5
dataCameraManuaiGain | 33
useBracketedExposures | 'FALSE
bracketinglmagesPerExposure | 1
bracketingNumberOfExposures | 4
bracketingExposureStartUsec | sooo
bracketingExposureMultiplierTimes100 | 1000
igniterStartPosition | 2170
igniterEndPosition | 2290
igniterVelocityCountsPerSec | 80
igniterPreheatPowerV | 3
igniterPreheatDurationMs | 1000
igniterlgnitionPowerV | 4
igniterlgnitionDurationMs | 3000
igniterDelayBeforeRetractMs | 1800
igniterRetractVelocityCountsPerSec | 500
pmt1Gain | 10
pmt2Gain | 8
pmt3Gain | 10
fiberlgnitionposition
fiberTestPosition
fiberMoveDuringTest | FALSE
fiberSegmentDistance | 100
fiberVelocity | 3000
fiberHoldDurationSec | 1
fiberCycles | 100
useFoma | TRUE
flowTimeoutSec | go
oxidizerFlowlgnitionDeltaMs | 2000
nitrogenFlowlgnitionDeltaMs
stabilizationTime1Sec
stabilizationTime2Sec | 5
oxidizerlgnitionFlowSlpm | 0.205
nitrogenlgnitionFlowSlpm
oxidizerTestFlow1Slpm | 0.205
nitrogenTestFlow1Slpm
oxidizerTestFlow2Slpm
nitrogenTestFlow2Slpm
oxidizerTestFlOW3Slpm
nitrogenTestFlow3Slpm
constantFlowTime1Sec | 60
constantFlowTime2Sec
constantFlowTime3Sec
ignitionToTestRampTimeSec
testFlowRamp1T02TimeSec
testFlowRamp2T03TimeSec
postExtinctionDelaySec
postExtinctionFlowChangeOxidizerPercent
postExtinctionFlowChangeNitrogenPercent
postExtinctionFlowChangeRampTimeSec
postExtinctionFlowChangeHoldSec
~~~~

### Pagina 2

Cita: [pdf_b53d439fe4ed40dd492e, p. 2]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_b53d439fe4ed40dd492e/p0002.jpg)

~~~~text
testpointName | 21216A1
dataCameraPrelgnitionExposureUs | 1000000
dataCameraTestExposureUs | 100000
analogCameraShutter | 2
uselntensifiedCamera | TRUE
intensifierlgnitionGain | 20000
intensifierTestGain | 60000
prelgnitionlmageTimeSec
postFlamelmagingTimeSec | 5
useDataCameraAutoGain | FALSE
autoGainTolerancePercent | 5
autoGainMaxDb | 33
autoGainMinDb
autoGainOutliers
autoGainRatePercent | 100
autoGainTargetPercent | 50
rampDataCameraGain | FALSE
dataCameraGain1dB
dataCameraGain2dB
dataCameraGain3dB
dataCameraHoldTime1Sec
dataCameraHoldTime2Sec
dataCameraRamp1t02TimeSec
dataCameraRamp2t03TimeSec | 5
dataCameraManualGain | 33
useBracketedExposures | -FALSE
bracketing magesPerExposure | 1
bracketingNumberOfExposures | 4
bracketingExposureStartUsec | 5000
bracketingExposureMultiplierTimes100 | 1000
igniterStartPosition | 2170
igniterEndPosition | 2290
igniterVelocityCountsPerSec | 80
igniterPreheatPowerV | 3
igniterPreheatDurationMs | 1000
igniterlgnitionPowerV | 4
igniterlgnitionDurationMs | 3000
igniterDelayBeforeRetractMs | 1800
igniterRetractVelocityCountsPerSec | 500
pmt1Gain | 10
pmt2Gain | 8
pmt3Gain | 10
fiberlgnitionPosition
fiberTestPosition
fiberMoveDuringTest | FALSE
fiberSegmentDistance | 100
fiberVelocity | 3000
fiberHoldDurationSec | 1
fiberCycles | 100
useFoma | TRUE
flowTimeoutSec | 90
oxidizerFlowlgnitionDeltaMs | 2000
nitrogenFlowlgnitionDeltaMs
stabilizationTime1Sec
stabilizationTime2Sec | 5
oxidizerlgnitionFlowSlpm | 0.205
nitrogenlgnitionFlowSlpm
oxidizer TestFlow1Slpm | 0.205
nitrogenTestFlow1Slpm
oxidizerTestFlow2Slpm
nitrogenTestFlow2Slpm
oxidizerTestFlow3Slpm
nitrogenTestFlow3Slpm
constantFlowTime1Sec | 60
constantFlowTime2Sec
constantFlowTime3Sec
ignitionToTestRampTimeSec
testFlowRamp1T02TimeSec
testFlowRamp2T03TimeSec
postExtinctionDelaySec | 3
postExtinctionFlowChangeOxidizerPercent
postExtinctionFlowChangeNitrogenPercent
postExtinctionFlowChangeRampTimeSec
postExtinctionFlowChangeHoldSec
~~~~

### Pagina 3

Cita: [pdf_b53d439fe4ed40dd492e, p. 3]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_b53d439fe4ed40dd492e/p0003.jpg)

~~~~text
testpointName | 2121681
dataCameraPrelgnitionExposureUs | 1000000
dataCameraTestExposureUs | 100000
analogCameraShutter | 2
uselntensifiedCamera | TRUE
intensifierlgnitionGain | 20000
intensifierTestGain | 60000
preignitionlmageTimeSec
postFlamelmagingT1meSec | 5
useDataCameraAutoGain | FALSE
autoGainTolerancePercent | 5
autoGainMaxDb | 33
autoGainMinDb
autoGainOutliers
autoGainRatePercent | 100
autoGainTargetPercent | 50
rampDataCameraGain | FALSE
dataCameraGain1dB
dataCameraGain2dB
dataCameraGain3dB
dataCameraHoldTime1Sec
dataCameraHoldTime2Sec
dataCameraRamp1t02TimeSec
dataCameraRamp2t03TimeSec | 5
dataCameraManualGain
useBracketedExposures | TRUE
bracketinglmagesPerExposure | 1
bracketingNumberOfExposures | 4
bracketingExposureStartUsec | 50000
bracketingExposureMultiplierTimes100 | 200
igniterStartPositi0n | 2170
igniterEndPosition | 2290
igniterVelocityCountsPerSec | 80
igniterPreheatPowerV | 3
igniterPreheatDurationMs | 1000
igniterlgnitionPowerV | 4
igniterlgnitionDurationMs | 3000
igniterDelayBeforeRetractMs | 1800
igniterRetractVelocityCountsPerSec | 500
pmt1Gain | 10
pmt2Gain | 8
pmt3Gain | 10
fiberlgnitionPosition | 10000
fiberTestPosition | 17000
fiberMoveDuringTest | FALSE
fiberSegmentDistance | 100
fiberVelocity | 3000
fiberHoldDurationSec | 1
fiberCycles | 100
useFoma | TRUE
flowTimeoutSec | 90
OxidizerFlowlgnitionDeltaMs
nitrogenFlowlgnitionDeltaMs
stabilizationTime1Sec
stabilizationTime2Sec | 5
oxidizerlgnitionFlowSlpm | 0.205
nitrogenlgnitionFlowSlpm
oxidizerTestFlow1Slpm | 0.205
nitrogenTestFlow1Slpm
oxidizerTestFlow2Slpm
nitrogenTestFlow2Slpm
oxidizerTestFlow3Slpm
nitrogenTestFlow3Slpm
constantFlowTime1Sec | 60
constantFlowTime2Sec
constantFlowTime3Sec
ignitionToTestRampTimeSec
testFlowRamp1T02TimeSec
testFlowRamp2T03TimeSec
postExtinctionDelaySec
postExtinctionFlowChangeOxidizerpercent
postExtinctionFlowChangeNitrogenPercent
postExtinctionFlowChangeRampTimeSec
postExtinctionFlowChangeH01dSec
~~~~

### Pagina 4

Cita: [pdf_b53d439fe4ed40dd492e, p. 4]. Metodo: windows_ocr_grid_removed.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_b53d439fe4ed40dd492e/p0004.jpg)

~~~~text
testpointNamel | 21216C1
dataCameraPrelgnitionExposureUsl | 1000000
dataCameraTestExposureUsl | 100000 | 1
analogCameraShutterl | 2
uselntensifiedCameral | TRUE
intensifierlgnitionGainl | 20000
intensifierTestGainl | 60000
prelgnitionlmageTimeSecl
postFlamelmagingTmeSecl | 5
useDataCameraAutoGainl | FALSE
autoGainTolerancePercentl | 5
autoGainMaxDbl | 33
autoGainMinDbl
autoGainOutliersl
autoGainRatePercent | 100
autoGainTargetPercent | 50
rampDataCameraGain | FALSE
dataCameraGain1dB
dataCameraGain2dB
dataCameraGain3dB
dataCameraH01dTime1Sec
dataCameraHoldTime2Sec:
dataCameraRamp1t02TimeSec | 5
dataCameraRamp2t03TimeSec | 5
dataCameraManualGain | 83
useBracketedExposures | 'FALSE
bracketinglmagesPerExposure
bracketingNumberOfExposures | 4
bracketingExposureStartUsec | sooo
bracketingExposureMultiplierTimes100 | 1000
igniterStartPosition | 2170
igniterEndPosition | 2290
igniterVelocityCountsPerSec | 80
igniterPreheatPowerV | 3
igniterPreheatDurationMs | 1000
igniterlgnitionPowerV | 4
igniterlgnitionDurationMs | 3000
igniterDelayBeforeRetractMs | 1800
igniterRetractVelocityCountsPerSec | 500
pmt1Gain | 10
pmt2Gain | 8
pmt3Gain | 10
fiberlgnitionPosition
fiberTestPosition
fiberMoveDuringTest | FALSE
fiberSegmentDistance | 100
fiberVelocity | 3000
fiberHoldDurationSec | 1
fiberCycles | 100
useFoma | TRUE
flowTimeoutSec | 90
oxidizerFlowlgnitionDeltaMs
nitrogenFlowlgnitionDeltaMs | 4500
stabilizationTime1Sec
stabilizationTime2Sec | 5
oxidizerIgnitionFlowSlpm | 0.205 | o,3ö7
nitrogenlgnitionFlowSlpm | 0.141
oxidizerTestFlow1Slpm | 0.205
nitrogenTestFlow1Slpm | 0141 | D. i41
oxidizer TestFlow2Slpm
nitrogenTestFlow2SIpm
oxidizerTestFlow3Slpm
nitrogenTestFlow3Slpm
constantFlowTime1Sec | 60
constantFlowTime2Sec
constantFlowTime3Sec
ignitionToTestRampTimeSec
testFlowRamp1T02TimeSec
testFlowRamp2T03TimeSec
postExtinctionDelaySecl | 3
postExtinctionFlowChangeOxidizerPercentl
postExtinctionFlowChangeNitrogenPercentl
postExtinctionFlowChangeRampTimeSecl
postExtinctionFlowChangeHoldSecl
~~~~

### Pagina 5

Cita: [pdf_b53d439fe4ed40dd492e, p. 5]. Metodo: windows_ocr_grid_removed.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_b53d439fe4ed40dd492e/p0005.jpg)

~~~~text
testpointNamel | 21216F1 | 1.51
dataCameraPrelgnitionExposureUsl | 1000000
dataCameraTestExposureUsl | 100000
analogCameraShutterl | 2
uselntensifiedCamera | TRUE
intensifierlgnitionGain | 20000
intensifierTestGain | 60000
preignitionlmageTimeSec | o
postFlamelmagingTimeSec | 5
useDataCameraAutoGain | FALSE
autoGainTolerancePercent | 5
autoGainMaxDb | 33
autoGainMinDb
autoGainOutliers
autoGainRatePercent | 100
autoGainTargetPercent | 50
rampDataCameraGain | FALSE
dataCameraGain1dB
dataCameraGain2dB
dataCameraGain3dB
dataCameraHoldTime1Sec
dataCameraHoldTime2Sec
dataCameraRamp1t02TimeSec | 5
dataCameraRamp2t03TimeSec | 5
dataCameraManualGain | 33
useBracketedExposures | FALSE
bracketinglmagesPerExposure | 1
bracketingNumberOfExposures | 4
bracketingExposureStartUsec
bracketingExposureMultiplierTimes100 | 1000
igniterStartPosition | 2170
igniterEndPosition | 2290
igniterVelocityCountsPerSec | 80
igniterPreheatPowerV | 3
igniterPreheatDurationMs | 1000
igniterlgnitionPowerV | 4
igniterlgnitionDurationMs | 3000
igniterDelayBeforeRetractMs | 1800
igniterRetractVelocityCountsPerSec | 500
pmt1Gain | 10
pmt2Gain | 8
pmt3Gain | 10
fiberlgnitionPosition | 0
fiberTestPosition
fiberMoveDuringTest | FALSE
fiberSegmentDistance | 100
fiberVelocity | 3000
fiberHoldDurationSec | 1
fiberCycles | 100
useFoma | TRUE
flowTimeoutSec | 90
oxidizerFlowlgnitionDeltaMs
nitrogenFlowlgnitionDeltaMs | 4500
stabilizationTime1Sec
stabilizationTime2Sec | 5
oxidizerlgnitionFlowSlpm | 0.205 | D. 307 | D,Zö5
nitrogenlgnitionFlowSlpm | CX,3D6 | 0612 | DRIZ
oxidizerTestFlow1Slpm | 0.205 | A 307
nitrogenTestFlow1Slpm | -0.612
oxidizer TestFlow2Slpm
nitrogenTestFlow2Slpm
oxidizerTestFlow3Slpm
nitrogenTestFlow3Slpm
constantFlowTime1Sec | 60
constantFlowTime2Sec
constantFlowTime3Sec
ignitionToTestRampTimeSec
testFlowRamp1T02TimeSec
testFlowRamp2T03TimeSec
postExtinctionDelaySec | 3
postExtinctionFlowChangeOxidizerPercent
postExti nctionFlowChangeNitrogenPercen€
postExtinctionFlowChangeRampTimeSec
postExtinctionFlowChangeHoldSecl
~~~~

### Pagina 6

Cita: [pdf_b53d439fe4ed40dd492e, p. 6]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_b53d439fe4ed40dd492e/p0006.jpg)

~~~~text
testpointName | 2121601
dataCameraPrelgnitionExposureUs | 1000000
dataCameraTestExposureUs | 100000
analogCameraShutter | 2
uselntensifiedCamera | TRUE
intensifierlgnitionGain | 20000
intensifierTestGain | 60000
preignitionlmageTimeSec
postFlamelmagingTimeSec | 5
useDataCameraAut0Gain | FALSE
autoGainTolerancePercent
autoGainMaxDb | 33
autoGainMinDb
autoGainOutliers
autoGainRatePercent | 100
autoGainTargetPercent | 50
rampDataCameraGain | FALSE
dataCameraGain1dB
dataCameraGain2dB
dataCameraGain3dB
dataCameraHoldTime1Sec
dataCameraHoldTime2Sec
dataCameraRamp1t02TimeSec | 5
dataCameraRamp2t03TimeSec | 5
dataCameraManualGain
useBracketedExposures | TRUE
bracketinglmagesPerExposure | 1
bracketingNumberOfExposures | 4
bracketingExposureStartUsec | soooo
bracketingExposureMultiplierTimes100 | 200
igniterStartPosition | 2170
igniterEndPosition | 2290
igniterVelocityCountsPerSec | 80
igniterPreheatPowerV | 3
igniterPreheatDurationMs | 1000
igniterlgnitionPowerV | 4
igniterlgnitionDurationMs | 3000
igniterDelayBeforeRetractMs | 1800
igniterRetractVelocityCountsPerSec | 500
pmt1Gain | 10
pmt2Gain | 8
pmt3Gain | 10
fiberlgnitionPosition | 10000
fiberTestPosition | 17000
fiberMoveDuringTest | FALSE
fiberSegmentDistance | 1
fiberVelocity | 3000
fiberH01dDurationSec | 1
fiberCycles | 100
useFoma | TRUE
flowTimeoutSec | 90
oxidizerFlowlgnitionDeltaMs
nitrogenFlowlgnitionDeltaMs | 4500
stabilizationTime1Sec
stabilizationTime2Sec | 5
oxidizerlgnitionFlowSlpm | 0.205
nitrogenlgnitionFlowSlpm | 0.141
oxidizer TestFlow1Slpm | 0.205
nitrogenTestFlow1Slpm | 0.141
oxidizerTestFlow2Slpm
nitrogenTestFlow2Slpm
oxidizer TestFlow3Slpm
nitrogenTestFlow3Slpm
constantFlowTime1Sec | 60
constantFlowTime2Sec
constantFlowTime3Sec
ignitionTOTestRampTimeSec
testFlowRamp1T02TimeSec
testFlowRamp2T03TimeSec
postExtinctionDelaySec | 3
postExtinctionFlowChangeOxidizerPercent
postExtinctionFlowChangeN itrogenPercent
postExtinctionFlowChangeRampTimeSec
postExtinctionFlowChangeH01dSec
~~~~

### Pagina 7

Cita: [pdf_b53d439fe4ed40dd492e, p. 7]. Metodo: windows_ocr_grid_removed.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_b53d439fe4ed40dd492e/p0007.jpg)

~~~~text
testp0intNamel | 21216G1
dataCameraPrelgnitionExposureUsl | 1000000
dataCameraTestExposureUsl | 100000
analogCameraShutter' | 2
uselntensifiedCamera | TRUE
intensifierlgnitionGain | 20000
intensifierTestGain | 60000
prelgnitionlmageTimeSec
postFlamelmagingTimeSec | 5
useDataCameraAutoGain | FALSE
autoGainTolerancePercent | 5
autoGainMaxDb | 33
autoGainMinDb
autoGainOutliersil
autoGainRatePercent' | 100
autoGainTargetPercent | 50
rampDataCameraGain | FALSE
dataCameraGain1dB
dataCameraGain2dB
dataCameraGain3dB
dataCameraHoldTime1Sec
dataCameraH01dTime2Sec
dataCameraRamp1t02TimeSec | 5
dataCameraRamp2t03TimeSec | 5
dataCameraManualGain
useBracketedExposures | TRUE
bracketinglmagesPerExposure | 1
bracketingNumberOfExposures | 4
bracketingExposureStartUsec
bracketingExposureMultiplierTimes100 | 200
igniterStartPosition | 2170
igniterEndPosition | 2290
igniterVelocityCountsPerSec | 80
igniterPreheatPowerV | 3
igniterPreheatDurationMs | 1000
igniterlgnitionPowerV | 4
igniterlgnitionDurationMs | 3000
igniterDelayBeforeRetractMs | 1800
igniterRetractVelocityCountsPerSec | 500
pmt1Gain | 10
pmt2Gain | 8
pmt3Gain | 10
fiberlgnitionPosition | 10000
fiberTestPosition | 17000
fiberMoveDuringTest | FALSE
fiberSegmentDistance | 100
fiberVelocity | 3000
fiberHoldDurationSec | 1
fiberCycles | 100
useFoma | TRUE
flowTimeoutSec | 90
oxidizerFIowlgnitionDeltaMs
nitrogenFlowlgnitionDeltaMs | 4500
stabilizationTime1Sec
stabilizationTime2Sec | 5
oxidizerlgnitionFlowSlpm | 0.205
nitrogenlgnitionFlowSlpm | 0.612
oxidizerTestFlow1Slpm | 0.205
nitrogenTestFlow1Slpm | 0.612
oxidizer TestFlow2Slpm
nitrogenTestFlow2Slpm
oxidizerTestFlow3Slpm
nitrogenTestFlow3Slpm
constantFlowTime1Sec | 60
constantFlowTime2Sec
constantFlowTime3Sec
ignitionToTestRampTimeSec
testFlowRamp1T02TimeSec
testFlowRamp2T03TimeSec
postExtinctionDelaySec | 3
postExtinctionFlowChangeOxidizerPercent
postExtinctionFlowChangeNitrogenPercent
postExtinctionFlowChangeRampTimeSec
postExtinctionFIowChangeHoldSec
~~~~
