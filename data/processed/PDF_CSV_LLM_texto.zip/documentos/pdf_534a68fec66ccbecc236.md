# 19156 flow traces etc

- Identificador: pdf_534a68fec66ccbecc236
- Investigaciones: PSI-10
- Tipo de documento: Raw Data
- Estado: processed
- Temas detectados automaticamente: oxygen, pressure, hardware, ignition, extinction

## Fuentes

- [PSI-10_Raw Data_19156 flow traces etc.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-10/Raw%20Data/PSI-10_Raw%20Data_19156%20flow%20traces%20etc.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_534a68fec66ccbecc236, p. 1]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_534a68fec66ccbecc236/p0001.jpg)

~~~~text
1
Test 19156A1 – no ignition (where the fuel was dilute), run with 
stabilizationTime2Sec=3
Analog camera gain=21 dB, HiBMs illumination on, but accidentally didn’t 
record HiBMs images
After test, 972 on lowest valve safety timer, 1193 psia in oxidizer bottle

[Texto OCR de la imagen]
Test 19156A1 — no ignition (where the fuel was dilute), run with
stabilizationTime2Sec=3
Analog camera gain—21 dB, HiBMs illumination on, but accidentally didn't
record HiBMs images
Gas Flow Charts
File Graphs
2019-06-05 | GMT
state | 2019-06-05 17: 1
System' | ab_res
33.200
Operate | c | 0.000 | SLPM | R | -0.011 | SLPM | a-a scale | 20.00C | set All Gains
CPU Board | 35.000
Static Mixer Line (MFCAI)
Cube Sensor 1 | 34.227
ACME FLOW MI MIXER SETPOINT | ACME FLOW MI MIXER FLOW | Cube Sensor 2 | 34.266
Hard Drive | 26
-0.010
17:12 | 17:13 | 17:14 | 17:15 | 17:1
5Wed Jun 2019 | Time (s)
200A (TCI) | 24.046624 | 0.038
TC20E (TC2) | 22.880930 | -0.009
State | Oper ate | c | 0.000 | QPM | R | -0.004 | SLPM | scale | 2.000
23.121190 | 0.874 | v
Bypass(MFCA2)
Array
Rake:
2
27.363122 | 0.172
invabd-/ow | 0.002
17:12 | 17:13 | 17:14 | 17:15 | 17:1 | invabd-low | -0.013
5Wed Jun 2019 | Time (s)
23.600352
Operate | 0.000 | R | -0.000 | SLPM | scale | 0.200
Fuel(MFCA3)
24.715692 | 0.065 | mV
ACME FLOW M3 FUEL SETPOINT | ACME FLOW | FUEL FLOW
0.15
0.10
0.05
Cube Connectin
17:12 | 17:13 | 17:14 | 17:15 | 17:1
5 wed Jun 2019 | Tine (s)
Time Series Chart #1
Packet | Somvare t•hemmic
ACME Telerne ACME DIAG PMT Tl | 0.00
ACME Telerne ACME DIAG PMT_T2 | 0.00
ACME | 0.00
> 2.0
Select Items | Ploting | I
17:15:15
051m 2019 | 5 wed Jun 2019
StartTjrr,e,
After test, 972 on lowest valve safety timer, 1193 psia in oxidizer bottle
1
~~~~

### Pagina 2

Cita: [pdf_534a68fec66ccbecc236, p. 2]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_534a68fec66ccbecc236/p0002.jpg)

~~~~text
2
Test 19156A2 – no ignition, run with igniterIgnitionPosition=2240, 
fuelFlowIgnitionDeltaMs=900, stabilizationTime2Sec=3, 
nitrogenIgnitionFlowRateN2Slpm=nitrogenTestFlowRateN2Slpm=1.832
Analog camera gain=21 dB, using HiBMs and illumination package
After test, 953 on lowest valve safety timer, 1193 psia in oxidizer bottle

[Texto OCR de la imagen]
Test 19156A2 — no ignition, run with igniterIgnitionPosition=2240,
fuelFlowIgnitionDeItaMs=900, stabilizationTime2Sec=3,
nitrogenlgnitionFIowRateN2SIpm=nitrogenTestFIowRateN2SIpm=1.832
Analog camera gain—21 dB, using HiBMs and illumination package
Gas Flow Charts
Fife Graphs
2019-06-05
state | 2019-06-05 17:z
system | Systern Temperatures
33.300
Operate | c | 0.000 | QPM | R | -0.010 | SLPM | FUlsca1e | 20.OOC | Set AI Gains
Board | 35.000
Static Mixer Line (MFCAI)
Cube Sensor 1 | 34.328
ACME FLOW MI MIXER SETPOINT | ACME FLOW MI MIXER FLOW | Cube Sensor 2 | 34.298
0.000
Hard Crive | 26
-0.005
-0.010
17:34 | 17:35 | 17:36 | 17:37 | 17:38
5 wed Jun 2019 | Tine (s)
200A (TCI) | 24.584718 | 0.046
TC200E | 23.221209 | 0009 | mV
(TC2)
State | Operate | c | 0.000 | SLPM | R | -0.003 | SLPM | scale | 2.000
23.460169 | 0.875
Bypass(MFCA2)
Rake: Far
ACME FLOW M2 BYPASS SETPOINT | ACME FLOW | BYPASS FLOW
27.677243 | 0.171
1
invalid-low | -0.011
17:34 | 17:35 | 17:36 | 17:37 | 17:38 | invalid-low | -0.006
5 wed Jun 2019 | Time (s)
24.336933 | 0.036
State | Operate | c | 0.000 | R | -0.000 | SLPM | scale | 0.200
Fuel(MFCA3)
25. 129646 | 0.068
ACME FLOW M3 FUEL SETPOINT | ACME FLOW M3 FUEL FLOW
0.15
0.10
0.05
Cube Cornecåon
17:34 | 17:35 | 17:36 | 17:37 | 17:38
5 wed Jun 2019 | Time (s)
. t. Time Series Chart #1
4.5
Softvvare Mnemmic
0.00
ACbETelerne | 0.00
ACMETeleme ACME DIAG | T3 | 0.00
> 2.0
Select Items | End Plotting
17:38
05 | 2019 | 5 wed Jun 2019
StartTrne I,
After test, 953 on lowest valve safety timer, 1193 psia in oxidizer bottle
2
~~~~

### Pagina 3

Cita: [pdf_534a68fec66ccbecc236, p. 3]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_534a68fec66ccbecc236/p0003.jpg)

~~~~text
3
Test 19156B1 – flashes but no sustained ignition, run with 
igniterIgnitionPosition=2240, igniterPreheatPowerV=3.75, 
igniterIgnitiondurationMs=1500, igniterDelayBeforeRetractMs=1000, 
fuelFlowIgnitionDeltaMs=1000, stabilizationTime2Sec=3 
Analog camera gain=21 dB, using HiBMs and illumination package
After test, 936 on lowest valve safety timer, 1193 psia in oxidizer bottle

[Texto OCR de la imagen]
Test 19156B1 — flashes but no sustained ignition, run with
igniterIgnitionPosition=2240, igniterPreheatPowerV=3.75,
igniterlgnitiondurationMs=1500, igniterDeIayBeforeRetractMs=1000,
fuelFIowIgnitionDeltaMs=1000, stabilizationTime2Sec=3
Analog camera gain—21 dB, using HiBMs and illumination package
Gas Flow Charts | -ox
File Graphs
201906-05
2019-06-05 18: 1
System Ternperatures
cpu | 33.300
State | Operate | c | 0.000 | SLPM | R | -0.011 | SLPM | Fu Scale | 20.OOC | Set All Gains
CPU Board | 35.000
Static Mixer Line (MFCAI)
Cube Sensor 1 | 34.
ACME FLOW MI MIXER SETPOINT | ACME FLOW MI MIXER FLOW | Sensor 2 | 34.411
-0.01 | Hard Drive | 26
-0.02
18:09 | 18:10 | 18:11 | 18:12 | 18:13
5 Wed Jun 2019 | Time (s)
(TCI) | 24.634268 | 0.048 | mV
TC200B (TC2) | mV
State | Operate | c | 0.000 | SLPM | R | -0.003 | SLPM | scale | 2.000
TCCJ | 23.460169 | 0.875
Bypass(MFCA2)
Array
ACME FLOW M2 BYPASS SETPOINT | ACME FLOW | BYPASS FLOW
27.701948 | 0.172
invalid-low | -0.009 | mV
18:09 | 18:10 | 18:11 | 18:12 | 18:13 | invalid qow | -0.009 | mV
5 Wed Jun 2019 | Tine (s)
24.881985 | 0.058 | mV
State | Operate | c | 0.000 | R | -0.000 | SLPM | scale | 0.200
Burner Sphere—I (1/4)
Fuel(MFCA3)
Burner | 29.577782 | 0.248 | mV
ACME FLOW M3 FUEL SETPOINT | ACME_FLOW M3 FUEL_FLOW
0.1
he Cornecton | Connected
18:09 | 18:10 | 18:11 | 18:12 | 18:13
5 wed Jun 2019 | Time (s)
t. Time Series Chart #1
Packet | Software tvlnernonic
Teleme | 0.00
ACME Teleme | 0.00
ACME Teleme ACME DIAG | T3 | 0.00
> 2.0
2.]
Select Items | End Plotting
18: 12:00
051m 2019 | Restart | 5Wed Jun 2019 | Time
StartTrne,
After test, 936 on lowest valve safety timer, 1193 psia in oxidizer bottle
3
~~~~

### Pagina 4

Cita: [pdf_534a68fec66ccbecc236, p. 4]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
4
Test 19156B2 – successful test in which flame extinguished in an asymmetric 
fashion, run with igniterIgnitionPosition=2240, igniterPreheatPowerV=3.75, 
igniterIgnitiondurationMs=2000, igniterDelayBeforeRetractMs=1500, 
fuelFlowIgnitionDeltaMs=500, stabilizationTime1Sec=2, 
stabilizationTime2Sec=3, nitrogenIgnitionFlowRateN2Slpm=0.467, 
ignitionToTestRampTimeSec=3
Analog camera gain=21 dB, using HiBMs and illumination package
After test, __913 on lowest valve safety timer, __1193 psia in oxidizer bottle
~~~~

### Pagina 5

Cita: [pdf_534a68fec66ccbecc236, p. 5]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
5
Test 19156B3 – flash(es) but no sustained ignition, run with
igniterIgnitionPosition=2280, igniterPreheatPowerV=2.25, 
igniterIgnitiondurationMs=2500, igniterDelayBeforeRetractMs=2000, 
fuelFlowIgnitionDeltaMs=500, stabilizationTime1Sec=2, 
stabilizationTime2Sec=3, fuelBottleIgnitionFlowRateN2Slpm=0.104
nitrogenIgnitionFlowRateN2Slpm=0.243, fuelBottleTestFlowRateN2Slpm=0.104
nitrogenTestFlowRateN2Slpm=0.991, ignitionToTestRampTimeSec=4,
constantFlowTimeSec=60 
Analog camera gain=21 dB, using HiBMs and illumination package
dataCamera Focus=12700, dataCamera Zoom=35000
After test, _889_ on lowest valve safety timer, 1193__ psia in oxidizer bottle
~~~~

### Pagina 6

Cita: [pdf_534a68fec66ccbecc236, p. 6]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
6
Test 19156 B4 – successful test, except flame not spherical when nitrogen flow 
ramped up, duplicate of B3 except for ignition detection settings
igniterIgnitionPosition=2280, igniterPreheatPowerV=2.25, 
igniterIgnitiondurationMs=2500, igniterDelayBeforeRetractMs=2000, 
fuelFlowIgnitionDeltaMs=500, stabilizationTime1Sec=2, 
stabilizationTime2Sec=3, fuelBottleIgnitionFlowRateN2Slpm=0.104
nitrogenIgnitionFlowRateN2Slpm=0.243, fuelBottleTestFlowRateN2Slpm=0.104
nitrogenTestFlowRateN2Slpm=0.991, ignitionToTestRampTimeSec=4,
constantFlowTimeSec=60 
Analog camera gain=21 dB, using HiBMs and illumination package
dataCamera Focus=12700, dataCamera Zoom=35000
Ignition detection set with averaging ignition duration=0.5 s (instead of default 
of 0.05 s)
After test, 797 on lowest valve safety timer, 817 psia in oxidizer bottle
~~~~

### Pagina 7

Cita: [pdf_534a68fec66ccbecc236, p. 7]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_534a68fec66ccbecc236/p0007.jpg)

~~~~text
7
Test 19156K1 – successful test, like as-run 19142F1 except 
constantFlowTimeSec=20, useRampFlowToZero=FALSE
Analog camera gain=21 dB, using HiBMs and illumination package
dataCamera Focus=10025, dataCamera Zoom=45000
After test, 757 on lowest valve safety timer, 1195 psia in oxidizer bottle

[Texto OCR de la imagen]
Test 19156K1 — successful test, like as-run 19142F1 except
constantFIowTimeSec=20, useRampFIowToZero=FALSE
Analog camera gain—21 dB, using HiBMs and illumination package
dataCamera Focus=10025, dataCamera Zoom=45000
Gds Flow Charts
File Graphs
2019-06-05 | GMT
state | 2019-06-05 20:z
system | System Terrperatures
cpu | 33.100
Operate | c | 0.000 | SLPM | R | -0.010 | SLPM | scale | 20.ooc | Set AN Gains
Board | 35.000
Static Mixer Line (MFCAI) | 0.000
Cube Sensor 1 | 34.731
0.000 | 34.703
ACME FLOW MI MIXER SETPOINT | ACME FLOW MI MIXER FLOW | Cube Sensor 2
0.000 | 26
Hard Crive
-0.010
20:19 | 20:20 | 20:21 | 20:22 | 20:23
5 wed Jun 2019 | Time (s)
TC200A (TCI) | 24.453834 | 0.027
TC20E CC2) | 24.800680 | 0.041
Operate | c | 0.000 | R | -0.000 | SLPM | scale | 2.000
23.799147 | 0.876
Bypass(MFCA2)
Array
Rake: Far
ACME FLOW M2 BYPASS SETPOINT | ACME FLOW M2 BYPASS FLOW
28.4111% | o. 187
0.25
invahd40w | -0.003
20:19 | 20:20 | 20:21 | 20:22 | 20:23 | invahd-low | -0.004
5 wed Jun 2019 | Time (s)
25.147415 | 0.055
Operate | c | 0.000 | R | 0.000 | scale | 0.200
Fuel(MFCA3)
51.475204 | 1. 131 | mV
0.1
Connecbm
20:19 | 20:20 | 20:21 | 20:22 | 20:23
5Wed Jun 2019 | Tine (s)
Time Series Chart #1
-O.Ie-3
-o.ze-3
packet | Soft,vare Mnemnic
-03e-3
ACME | ACME DIAG PMT Tl | 0.00
-0.4e-3
ACME Teleme | 0.00
ACME Teleme | 0.00 | -OSe-3
> -OSe-3
-0.7e-3
-0.8e-3
-I.Oe-3
Select Items | End Plotting
2019 | Restart | 5 Wed Jun 2019 | Time
Startme
After test, 757 on lowest valve safety timer, 1195 psia in oxidizer bottle
7
~~~~

### Pagina 8

Cita: [pdf_534a68fec66ccbecc236, p. 8]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_534a68fec66ccbecc236/p0008.jpg)

~~~~text
8
Test 19156C1 – successful test, run with no changes
Analog camera gain=21 dB, using HiBMs and illumination package
dataCamera Focus and dataCamera Zoom as planned for C1
After test, 715 on lowest valve safety timer, 1195 psia in oxidizer bottle

[Texto OCR de la imagen]
Test 19156C1 — successful test, run with no changes
Analog camera gain—21 dB, using HiBMs and illumination package
dataCamera Focus and dataCamera Zoom as planned for Cl
Gas Flow Charts
File Graphs
2019-06-05 | GMT
2019-06-05 20::
System Temperatures
cpu | 33,000
State | Operate | c | 0.000 | R | -0.009 | SLPM | scale | 20.ooc | Set All Gains
Board | 36.000
Static Mixer Line (MFCAI)
Cube Sensor 1 | 34, 719
cube sensor 2 | 693
0.000
Hard Drive | 26
-0.010
20:35 | 20:36 | 20:37 | 20:38 | 20:39
5Wed Jun 2019 | Time (s)
TC200A (TCI) | 25.518795 | 0.070
TC20E | 23.561440 | -0.009
(TC2)
State | Operate | c | 0.000 | SLPM | R | -0.007 | SLPM | scale | 2.000
23.799147 | 0.876
Bypass(MFCA2)
Array
Rake: Far
ACME FLOW '•12 BYPASS SETPOINT | ACME FLOW M2 BYPASS FLOW
43.439888 | 0.677
-5e-3 | nvalid-low | 0.000
20:35 | 20:36 | 20:37 | 20:38 | 20:39 | nvalid40w | 0.003
5Wed Jun 2019 | Time (s)
TCD | 41.708749 | 0.729
c | 0.000 | SLPM | R | -0.000 | SLPM | scale | 0.200
Bumer: | (1/4
Fuel(MFCA3)
Burner | 195.761701 | 7.018
ACME FLOW M3 FUEL SETPOINT | ACME FLOW M3 FUEL FLOW
Canectjm | Connected
20:35 | 20:36 | 20:37 | 20:38 | 20:39
5Wed Jun 2019 | Time (s)
Time Series Chart #1
Packet | Soffvare Mnenonic
ACME Teler•n€ | 0.00
ACME | 0.00
2.5
ACME Teleme | 0.00
> 2.0
Select Items | End Plotting
20:38:45 | 20:39:00 | 20:39:15
05Jur-,2019 | 5 Wed Jun 2019 | Tüne
startTrne,
After test, 715 on lowest valve safety timer, 1195 psia in oxidizer bottle
8
~~~~

### Pagina 9

Cita: [pdf_534a68fec66ccbecc236, p. 9]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_534a68fec66ccbecc236/p0009.jpg)

~~~~text
9
Test 19156C2 – successful test, same as C1 except 
burnerTemperatureLimitC=500 (before triggering shut off)
Analog camera gain=21 dB, using HiBMs and illumination package
dataCamera Focus and dataCamera Zoom as planned for C1
After test, 638 on lowest valve safety timer, 1195 psia in oxidizer bottle

[Texto OCR de la imagen]
Test 19156C2 — successful test, same as Cl except
burnerTemperatureLimitC=500 (before triggering shut off)
Analog camera gain—21 dB, using HiBMs and illumination package
dataCamera Focus and dataCamera Zoom as planned for Cl
Gds Flow Charts
File Graphs
2019-06-05 21: 14: 14 | GtvtT
2019-06-05 21: | Systen•l Temperatures
33.100
State | Operate | C | 0.000 | SLPM | R | -0.009 | SLPM | 20.OOC | Set All Gains
Board | 35.000
Static Mixer Line (MFCAI) | set
Cube Sensor 1 | 34.710
Set | 34.658
Cube Sensor 2 | 'C
0.00 | 50 | set | 26
Hard Drive
-0.01
-0.02
21: 10 | 21:11 | 21:12 | 21:13 | 21:14
swed Jun 2019 | Time (s)
TC200A (TCI) | 26.582706 | 0.113
TC200B (TC2) | 23.759812 | -0.001
State | Operate | c | 0.000 | 0.001 | SLPM | scale | 2.000
23.799147
Bypass(MFCA2)
Array
Rake: Far
55.223451 | 1.286
o
-Ze-3 | invahd-low | 0.016
21:10 | 21:11 | 21:12 | 21:13 | 21:14 | invabd-low | 0.007
5Wed Jun 2019 | Tüne (s)
54.015240 til | 1.236
State | Operate | c | 0.000 | -0.000 | SLPM | scale | 0.200
Bume-: | (1/4)
Fuel(MFCA3)
Burner | 264.269467 | mV
Cube Comectim | Connected
21:10 | 21:11 | 21:12 | 21:13 | 21:14
5Wed Jun 2019 | Tune (s)
Time Series Chart | —IOS
Packet | So ff.vare Mnemoric
ACME Teleme | 0.00
ACME Teleme | 0.00
ACME Teleme ACME OTAG PMT T3 | 0.00
0.6
2.]
Select Items | End Plottng
21:13:00 | 21:13:15
05 Jun 2019 21:1413.000 | Restart | swed Jun 2019 | Time
StartTme,
After test, 638 on lowest valve safety timer, 1195 psia in oxidizer bottle
9
~~~~

### Pagina 10

Cita: [pdf_534a68fec66ccbecc236, p. 10]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
10
Test 19156C3 – successful test, run with
dataCameraPreIgnitionExposureUs=1000000, dataCameraIgnitionExposureUs=
dataCameraTestExposureUs=dataCameraExtinctionExposureUs=33000, 
useBracketedExposures=FALSE, fiberIgnitionPosition=fiberTestPostition=0, 
fiberMoveDuringTest=FALSE, burnerTemperatureLimitC=500
Analog camera gain=21 dB, using HiBMs and illumination package
data camera gain=33 dB, dataCamera Focus and dataCamera Zoom as planned
Minutes late in screen capture!
After test, 559 on lowest valve safety timer, 1195 psia in oxidizer bottle
~~~~

### Pagina 11

Cita: [pdf_534a68fec66ccbecc236, p. 11]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
11
Test 19156J1 – successful test, run with 
dataCameraPreIgnitionExposureUs=1000000, dataCameraIgnitionExposureUs=
dataCameraTestExposureUs=dataCameraExtinctionExposureUs=33000, 
useBracketedExposures=FALSE, igniterIgnitionPosition=2280, 
fiberIgnitionPosition=fiberTestPostition=0, fiberMoveDuringTest=FALSE, 
fuelFlowIgnitionDeltaMs=1000, stabilizationTime1Sec=3, 
fuelBottleIgnitionFlowRateN2Slpm=0.078, ignitionToTestRampTimeSec=4,
constantFlowTimeSec=10, burnerTemperatureLimitC=500
Analog camera gain=21 dB, using HiBMs and illumination package
data camera gain=33 dB, dataCamera Focus and dataCamera Zoom as planned
After test, 488 on lowest valve safety timer, 1195 psia in oxidizer bottle
~~~~

### Pagina 12

Cita: [pdf_534a68fec66ccbecc236, p. 12]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
12
Test 19156J2 – successful test, run with 
dataCameraPreIgnitionExposureUs=1000000, dataCameraIgnitionExposureUs=
dataCameraTestExposureUs=dataCameraExtinctionExposureUs=33000, 
useBracketedExposures=FALSE, igniterIgnitionPosition=2280, 
fiberIgnitionPosition=fiberTestPostition=0, fiberMoveDuringTest=FALSE, 
fuelFlowIgnitionDeltaMs=1000, stabilizationTime1Sec=0, 
stabilizationTime2Sec=5, fuelBottleIgnitionFlowRateN2Slpm=0.091,
fuelBottleTestFlowRateN2Slpm=0.091, ignitionToTestRampTimeSec=0,
constantFlowTimeSec=60, burnerTemperatureLimitC=500
Analog camera gain=12 dB, using HiBMs and illumination package
data camera gain=33 dB, dataCamera Focus and dataCamera Zoom as planned
After test, 416 on lowest valve safety timer, 1195 psia in oxidizer bottle
~~~~

### Pagina 13

Cita: [pdf_534a68fec66ccbecc236, p. 13]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
13
Test 19156J3 – successful test, run with 
dataCameraPreIgnitionExposureUs=1000000, dataCameraIgnitionExposureUs=
dataCameraTestExposureUs=dataCameraExtinctionExposureUs=33000, 
useBracketedExposures=FALSE, igniterIgnitionPosition=2280, 
fiberIgnitionPosition=fiberTestPostition=0, fiberMoveDuringTest=FALSE, 
fuelFlowIgnitionDeltaMs=1000, stabilizationTime1Sec=0, 
stabilizationTime2Sec=5, fuelBottleIgnitionFlowRateN2Slpm=0.104,
fuelBottleTestFlowRateN2Slpm=0.104, ignitionToTestRampTimeSec=0,
constantFlowTimeSec=60, burnerTemperatureLimitC=500
Analog camera gain=12 dB, using HiBMs and illumination package
data camera gain=33 dB, dataCamera Focu=12700, dataCamera Zoom=35000
After test, 336 on lowest valve safety timer, 1195 psia in oxidizer bottle
~~~~

### Pagina 14

Cita: [pdf_534a68fec66ccbecc236, p. 14]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
14
Test 19156J4 – successful test, run with 
dataCameraPreIgnitionExposureUs=1000000, dataCameraIgnitionExposureUs=
dataCameraTestExposureUs=dataCameraExtinctionExposureUs=33000, 
useBracketedExposures=FALSE, igniterIgnitionPosition=2280, 
fiberIgnitionPosition=fiberTestPostition=0, fiberMoveDuringTest=FALSE, 
fuelFlowIgnitionDeltaMs=1000, stabilizationTime1Sec=0, 
stabilizationTime2Sec=5, fuelBottleIgnitionFlowRateN2Slpm=0.083,
fuelBottleTestFlowRateN2Slpm=0.083, ignitionToTestRampTimeSec=0,
constantFlowTimeSec=60, burnerTemperatureLimitC=500
Analog camera gain=12 dB, using HiBMs and illumination package
data camera gain=33 dB, dataCamera Focu=12700, dataCamera Zoom=35000
After test, 274 on lowest valve safety timer, 1195 psia in oxidizer bottle
~~~~

### Pagina 15

Cita: [pdf_534a68fec66ccbecc236, p. 15]. Metodo: native.

~~~~text
15
Test 19156J5 – successful test, run with 
dataCameraPreIgnitionExposureUs=1000000, dataCameraIgnitionExposureUs=
dataCameraTestExposureUs=dataCameraExtinctionExposureUs=33000, 
useBracketedExposures=FALSE, igniterIgnitionPosition=2280, 
fiberIgnitionPosition=fiberTestPostition=0, fiberMoveDuringTest=FALSE, 
fuelFlowIgnitionDeltaMs=1000, stabilizationTime1Sec=0, 
stabilizationTime2Sec=2, fuelBottleIgnitionFlowRateN2Slpm=0.104,
fuelBottleTestFlowRateN2Slpm=0.104, ignitionToTestRampTimeSec=0,
constantFlowTimeSec=2, useRampFlowToZero=TRUE, rampFlowToZero=120, 
rampPostExtinctionFlowChangeFuelPercent=100,
rampPostExtinctionFlowChangeN2Percent=100, 
rampPostExtinctionFlowChangeRampTimeSec=2,
rampPostExtinctionFlowChangeHoldSec=5, burnerTemperatureLimitC=500
Analog camera gain=12 dB, using HiBMs and illumination package
data camera gain=33 dB, dataCamera Focu=12700, dataCamera Zoom=35000
Forgot to get screenshot until too late!
After test, 206 on lowest valve safety timer, 1195 psia in oxidizer bottle
~~~~

### Pagina 16

Cita: [pdf_534a68fec66ccbecc236, p. 16]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
16
Test 19156J6 – successful test, run with 
dataCameraPreIgnitionExposureUs=1000000, dataCameraIgnitionExposureUs=
dataCameraTestExposureUs=dataCameraExtinctionExposureUs=50000, 
useBracketedExposures=FALSE, igniterIgnitionPosition=2280, 
fiberIgnitionPosition=fiberTestPostition=0, fiberMoveDuringTest=FALSE, 
fuelFlowIgnitionDeltaMs=1000, stabilizationTime1Sec=0, 
stabilizationTime2Sec=2, fuelBottleIgnitionFlowRateN2Slpm=0.093,
fuelBottleTestFlowRateN2Slpm=0.093, ignitionToTestRampTimeSec=0,
constantFlowTimeSec=1, useRampFlowToZero=TRUE, rampFlowToZero=360, 
rampPostExtinctionFlowChangeFuelPercent=100,
rampPostExtinctionFlowChangeN2Percent=100, 
rampPostExtinctionFlowChangeRampTimeSec=2,
rampPostExtinctionFlowChangeHoldSec=5, burnerTemperatureLimitC=500
Analog camera gain=12 dB, using HiBMs and illumination package
data camera gain=33 dB, dataCamera Focu=12700, dataCamera Zoom=35000
After test, 133 on lowest valve safety timer, 1195 psia in oxidizer bottle
~~~~

### Pagina 17

Cita: [pdf_534a68fec66ccbecc236, p. 17]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
17
Test 19156J7 – successful test, run with 
dataCameraPreIgnitionExposureUs=1000000, dataCameraIgnitionExposureUs=
dataCameraTestExposureUs=dataCameraExtinctionExposureUs=33000, 
useBracketedExposures=FALSE, igniterIgnitionPosition=2280, 
fiberIgnitionPosition=11000, fiberTestPostition=14500, 
fiberMoveDuringTest=TRUE, fiberSegmentDistance=900, flowTimeoutSec=130,
fuelFlowIgnitionDeltaMs=1000, stabilizationTime1Sec=0, 
stabilizationTime2Sec=2, fuelBottleIgnitionFlowRateN2Slpm=0.093,
fuelBottleTestFlowRateN2Slpm=0.093, ignitionToTestRampTimeSec=0,
constantFlowTimeSec=1, useRampFlowToZero=TRUE, rampFlowToZero=360, 
rampPostExtinctionFlowChangeFuelPercent=100,
rampPostExtinctionFlowChangeN2Percent=100, 
rampPostExtinctionFlowChangeRampTimeSec=2,
rampPostExtinctionFlowChangeHoldSec=5, burnerTemperatureLimitC=500
Analog camera gain=12 dB, using HiBMs and illumination package
data camera gain=33 dB, dataCamera Focu=12700, dataCamera Zoom=35000
After test, 54 on lowest valve safety timer, 1195 psia in oxidizer bottle
~~~~
