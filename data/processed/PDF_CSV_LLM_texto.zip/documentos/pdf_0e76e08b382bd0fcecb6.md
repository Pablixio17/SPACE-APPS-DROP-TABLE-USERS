# SampleCCHotFlameImage

- Identificador: pdf_0e76e08b382bd0fcecb6
- Investigaciones: PSI-39
- Tipo de documento: Raw Data
- Estado: processed
- Temas detectados automaticamente: 

## Fuentes

- [PSI-39_Raw Data_SampleCCHotFlameImage.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-39/Raw%20Data/PSI-39_Raw%20Data_SampleCCHotFlameImage.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_0e76e08b382bd0fcecb6, p. 1]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, sparse_text_or_visual_only, table_structure_not_manually_validated, tiled_ocr_not_manually_verified.

[Imagen de la pagina](../imagenes/pdf_0e76e08b382bd0fcecb6/p0001.jpg)

~~~~text
mm
10 | 20 | 30 | 40 | 50 | 60 | 70 | 80 | 90
~~~~
