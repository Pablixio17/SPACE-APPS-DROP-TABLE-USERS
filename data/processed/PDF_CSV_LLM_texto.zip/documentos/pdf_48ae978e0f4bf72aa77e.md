# 22024 flow traces etc

- Identificador: pdf_48ae978e0f4bf72aa77e
- Investigaciones: PSI-10
- Tipo de documento: Raw Data
- Estado: processed
- Temas detectados automaticamente: hardware, oxygen, pressure, ignition, operations

## Fuentes

- [PSI-10_Raw Data_22024 flow traces etc.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-10/Raw%20Data/PSI-10_Raw%20Data_22024%20flow%20traces%20etc.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_48ae978e0f4bf72aa77e, p. 1]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_48ae978e0f4bf72aa77e/p0001.jpg)

~~~~text
1
Flame Design: Round 2, inverse-flame day 6
Chamber filled to 14.7 psia with 19% ethylene (balance N2)
Test 22024A1 (test 1 of 20, flame 1 of 20) – sustained ignition, run as planned 
(without changes to the script parameters)

[Texto OCR de la imagen]
Flame Design: Round 2, inverse-flame day 6
Chamber filled to 14.7 psia with 19% ethylene (balance N2)
Test 22024A1 (test 1 of 20, flame 1 of 20) — sustained ignition, run as planned
(without changes to the script parameters)
Gas Flow Chans | x
Graphs
State EXPERIMENT | 2022-01-24 | GMT
System
State | (>erate | c | 0.000 | SLPM | R | -0.000 | SLPM | scale | 0.500 | SLPM
Static Mixer Line (MFCAI)
ACME FLOW MI MIXER SETPOINT | ACME FLOW MI MIXER FLOW
0.10
19:21 | 19:22 | 19:23 | 19:24 | 19:25
24 mon Jan | Tine (S)
State | Operate | c | 0.000 | SLPM | R | -0.004 | SLPM | scale | 2.000 | SLPM
Bypass(MFCA2)
E_ FLOW_
Ze-3
le-3
-Ze-3
_ 3e—3
19:21 | 19:22 | 19:23 | 19:24 | 19:25
24 Mon Jan 2022 | Time (s)
State | Operate | c | 0.000 | SLPM | 0.002 | SLPM | scale | 2.000 | SLPM
Fuel(MFCA3)
se-3
4e-3
2+3
19:21 | 19:22 | 19:23 | 19:24 | 19:25
24 mon Jan 2022 | Time (s)
1
~~~~

### Pagina 2

Cita: [pdf_48ae978e0f4bf72aa77e, p. 2]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_48ae978e0f4bf72aa77e/p0002.jpg)

~~~~text
Test 22024A1, continued
o GMTClock | x
https://sams.grc.nasa.gov/GMTC | Ill \
copy
GMT
Fwd | S | Rtn | Fwd | Ku | Rtn
A | 35:01 | A | 35.•01
00:20 | 00:20
EST 024/
Diagnostic Sensors | x
state | 2022-01-24 19:24:57 | GI-4T
System Temperatures
5.000 | 33.100
Power
Set All Gains
W/m2 | Board | 35.000
PMT 1 | 0.000 | 0.000 | Gain | 0.000
Cube Sensor 1 | 35.011
PMT 2 | 0.000 | -0.000 | Gain | 0.000 | 34.991
Cube Sensor 2
PMT 3 | 0.000 | -O. 001 | Gain | 0.000 | 26
Hard Drive
W/cm2 | Volts
-0.003300 | -0.000 | TC200A (TC 1) | 24.450369 | 0.068 | mV
-60 mm
-0.003077 | -0.000 | TC200B | 22.391815 | -0.015 | mV
-30 rnm | (TC2)
-0.004146 | -0.074 | 22.782211 | 0.873
center
+30 | -0.002128 | 0.101
mm
Rake:
+60 mm | -0.003121 | 0.095
35.788133 | 0.528 | mV
60 Deg Offset | 0.000545 | 1.586
nvalid40w | 0.004 | mV
nalid-low | 0.004 | mV
Radometer Cold Jl-nctjons
Volts
37.723224 | 0.607 | mV
-60 nmCJ | -0.000
-30 mm CJ | 154.049483 | -0.000
Burner: Spherical (1/4)
Center CJ | 197.652076 | -0.561
Burner | 285.120862 | 10.682 | mV
+30 | 63.907692 | 1.113
+60 | 69.149939 | 1.050
60 Deg Offset | 24.992962 | 1.574 | Cube Connection
CJ
2
~~~~

### Pagina 3

Cita: [pdf_48ae978e0f4bf72aa77e, p. 3]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_48ae978e0f4bf72aa77e/p0003.jpg)

~~~~text
3
Test 22024A1, continued
After test: 948 on lowest valve safety timer, 45 psia in oxidizer bottle, 196 psia 
in fuel bottle

[Texto OCR de la imagen]
Test 22024A1, continued
Soffvare r•hemor-ic | Low
0.00
0.00
ACME DIAG PMT T3 | 0.00
End Plotting
Restart
Serties
19:24:15 | 19:24:30 | 19:24:45
2022 | 24 mon Jan 2022 | Tüne
Chart#2 | o | x
ftware Mnemonic | Low
ACME DIAG RAD D60 | 0.00
D30 | 0.00
0.00
ACME DIAG RAD DMIWS30 | 0.00
ACME DIAG RAD DMINUS60 | 0.00
0.00
ems | End Plottng
ctions | Restart
Jan 2022 | 24 mon Jan 2022
After test: 948 on lowest valve safety timer, 45 psia in oxidizer bottle, 196 psia
in fuel bottle
3
~~~~

### Pagina 4

Cita: [pdf_48ae978e0f4bf72aa77e, p. 4]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_48ae978e0f4bf72aa77e/p0004.jpg)

~~~~text
4
Test 22024A2 (test 2 of 20, flame 2 of 20) – sustained ignition, nominal repeat of 
A1, run with oxidizerFlowIgnitionDeltaMs=0
use HiBMS Camera?=NO, HiBMS Illumination Level (backlight)=0

[Texto OCR de la imagen]
Test 22024A2 (test 2 of 20, flame 2 of 20) — sustained ignition, nominal repeat of
A1, run with oxidizerFIowIgnitionDeItaMs=O
Gas Flow Charts | x
Graphs
2022-01-24 | GMT
State | Operate | c | 0•000 | SLPM | R | -0.001 | scale | 0.500 | SLPM
Static Mixer Line (MFCAI)
0.15
'A 0.10
19:37 | 19:38 | 19:39 | 19:40 | 19:41
24 mon Jan 2022 | Tine (s)
State | (Wate | c | 0.000 | SLPM | R | -0.002 | SLPM | scale | 2.000 | SLPM
Bypass(MFCA2)
le-3
le-3
-ae-3
-3e-3
19:37 | 19:38 | 19:39 | 19:40 | 19:41
24 mon Jan 2022 | Time (s)
State | Operate | c | 0.000 | SLPM | R | 0.001 | SLPM | scale | 2.000 | SLPM
Fuel(MFCA3)
4e-3
ze-3
1+3
19:37 | 19:38 | 19:39 | 19:40 | 19:41
24 mon Jan | Tine (s)
use HiBMS Camera?=NO, HiBMS Illumination Level (backlight)=O
4
~~~~

### Pagina 5

Cita: [pdf_48ae978e0f4bf72aa77e, p. 5]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_48ae978e0f4bf72aa77e/p0005.jpg)

~~~~text
Test 22024A2, continued
o GMTClock
-5 | https://sams.grc.nasa.gov/GMTC | Ill \
COPY
GMT 024/
Fwd | S | Rtn | Fwd | Ku | Rtn
A | 19:03 | A | 19:03
00:20 | 00:20
EST 024/
Diagnostic Sensors | x
2022-01-24 | Gt<T
ptvlTs | System Temperatures
5.000 | Set | CPU | 33.100
Power
Set Al Gains
Wiar,2 | CPU Board | 35.
PMT 1 | 0.000 | -0.001 | Gain | 0.000
Cube Sensor 1 | 34.960
PMT 2 | 0.000 | -0.000 | Gain | 0.000 | 34.953
Cube Sensor 2
0.000 | -0.000 | Gain | 0.000 | 26
Hard Drive
Radometers
W Ian 2
-0.003300 | -0.000 | TC200A (TCI) | 24.641371 | 0.062 | mV
-60 mm
-0.003077 | -0.000 | TC200B (TC2) | 22.632813 | -0.019 | mV
-30 mm
-0.004166 | -0.081 | 23.121190 | 0.874
Center
+30 | -0.002151 | 0.088 | Array
mm
Rake: Far
+60 nym | -0.003155 | 0.082
36.295728 | 0.535 | mV
60 Deg Ofret | 0.000469 | 1.544
maid-low | 0.001 | mV
nvabd40w | -0.008 | mV
Radiometer Cold Junctions
Volts
38.498976 | 0.625 | mV
-60 mm CJ | 154.049483 | -0.000
-30 mm CJ | 154.049483 | -0.000
Burner: Sphe.oa/ (1/4)
center | 197.882205 | 564
Burner | 275.620532 | 10.277 | mV
+30 CJ | 76.525587 | 0.961
+60 | 80.818850 | 0.909
60 Deg Offset | 25.078467 | 1.573 | a-be Connection
CJ
5
~~~~

### Pagina 6

Cita: [pdf_48ae978e0f4bf72aa77e, p. 6]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_48ae978e0f4bf72aa77e/p0006.jpg)

~~~~text
6
Test 22024A2, continued
After test: 895 on lowest valve safety timer, 43 psia in oxidizer bottle, 195 psia 
in fuel bottle

[Texto OCR de la imagen]
Test 22024A2, continued
Chart
Soft%'are Mnemonic | Low
ACME DIAG PMT Tl | 0.00
ACME DIAG | T2 | 0.00
0.00
End Plotting
Restart
Serties
19:40:00 | 19:40:15 | 19:40:30 | 19:40:45
Ian 2022 | 24 Mon Jan 2022
Software Mnemcnc | Low
ACME DIAG RAD 060 | 0.00
ACME DIAG RAD 030 | 0.00
0.00
0.00
ACME DIAG RAD DMINUS60 | 0.00
ACME DIAG RAD DOFFSET | 0.00
2.5
ems | End Plottng
'ctions | Restart
Berties
Jan 2022 | 24 Mon Jan 2022 | Tine
After test: 895 on lowest valve safety timer, 43 psia in oxidizer bottle, 195 psia
in fuel bottle
6
~~~~

### Pagina 7

Cita: [pdf_48ae978e0f4bf72aa77e, p. 7]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_48ae978e0f4bf72aa77e/p0007.jpg)

~~~~text
7
Test 22024B1 (test 3 of 20, flame 3 of 20) – sustained ignition, TFP variant of A1-
A2, run with fiberTestPosition=15500, oxidizerFlowIgnitionDeltaMs=0, 
stabilizationTime2Sec=4, constantFlowTime1Sec=20
use HiBMS Camera?=NO, HiBMS Illumination Level (backlight)=0

[Texto OCR de la imagen]
Test 2202481 (test 3 of 20, flame 3 of 20) - sustained ignition, TFP variant of A1-
A2, run with fiberTestPosition=15500, oxidizerFlowIgnitionDeltaMs=O,
stabilizationTime2Sec=4, constantFIowTime1Sec=20
Gas Flow Charts | x
Graphs
2022-01-24 | GMT
State | Operate | c | 0•000 | SLPM | R | O. 001 | SLPM | FLAsca1e | 0.500
Static Mixer Line (MFCAI)
'•a 0.10
19:50 | 19:51 | 19:52 | 19:53 | 19:5
24 mon Jan 2022 | TÉne (s)
State | Operate | c | 0.000 | SLPM | R | -0.001 | SLPt•.1 | scale | 2.000 | SLPT•.I
Bypass(MFCA2)
I.oe-3
OSe-3
-I.Oe-3
-Ise-3
-2.oe-3
-2.5e-3
-3.oe-3
19:50 | 19:51 | 19:52 | 19:53 | 19:5
24 Mon Jan 2022 | Time (s)
State | Operate | c | 0.000 | SLPM | R | -0.000 | SLPM | scale | 2.000 | SLPt•.1
Fuel(MFCA3)
3.oe-3
2.5e-3
2.oe-3
ISe-3
I.Oe-3
ose-3
-OSe-3
-I.oe-3
19:50 | 19:51 | 19:52 | 19:53 | 19:5
24 Mon Jan 2022 | Time (s)
use HiBMS Camera?=NO, HiBMS Illumination Level (backlight)=O
7
~~~~

### Pagina 8

Cita: [pdf_48ae978e0f4bf72aa77e, p. 8]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_48ae978e0f4bf72aa77e/p0008.jpg)

~~~~text
Test 2202481, continued
o GMTClock
https://sams.grc.nasa.gov/GMTC | lil\
COPY
GMT
Fwd | S | Rtn | Fwd | Ku | Rtn
A | 06:27 | A | 06:27
00:20 | 00:20
EST 024/
Diagnostic Sensors | x
2022-01-24 19:53:32 | GMT
Ptvrs | Systern Ternperatures
5.000 | Set | cpo | 33.100
Power
Set Al Gains
W/crn2 | Board | 35.000
-58.000 | -0.000 | Gain | 5.500
Cube Sensor 1 | 34.960
728.000 | -0.000 | 5.000 | 34.938
be Sensor 2
911.000 | -0.001 | 5.000 | 26
Hard Drive
Radiometers
W/cm2 | Volts
-0.003300 | -0.000 | TC200A (TCI) | 24.690919 | 0.064
-60 mm
-0.003077 | -0.000 | TC200B | 22.806535 | -0.012 | mV
-30 mm | (TC2)
-0.004135 | -0.070 | 23.121190 | 0.874
Center
+30 | -0.002106 | 0.113 | Array
mm
Rake: Far
+60 mm | -0.003103 | 0.102
35.658408 | 0.509
60 Deg Ofret | 0.000530 | 1.578
invahd-low | 0.018
invahd-bw | -0.001
Radiometer Cold Junctions
Volts
37.128584 | 0.569
-60 mm CJ | 154.049483 | -0.000
-30 mm CJ | 154.049483 | -0.000
Butner: Sphe,'ica/ (1/4)
Center CJ | 197.498643 | -0.559
Burner TC | 275.64-843 | 10.278 | mV
+30 | 53.369521 | 1.239
+60 | 62.823745 | 1.126
60 Deg Offset | 25.163957 | 1.572 | Cube Connection
CJ
8
~~~~

### Pagina 9

Cita: [pdf_48ae978e0f4bf72aa77e, p. 9]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_48ae978e0f4bf72aa77e/p0009.jpg)

~~~~text
9
Test 22024B1, continued
After test: 848 on lowest valve safety timer, 42 psia in oxidizer bottle, 196 psia 
in fuel bottle

[Texto OCR de la imagen]
Test 2202481, continued
Chart —l
Software Yhernonic | Low
ACt.E DIAG PMT Tl | 0.00
ACME DIAG | T2 | 0.00
0.00
End Plotting
ctions
jerties
19:52:30 | 19:52:45 | 19:53:00 | 19:53:15
an 2022 | 24 Mon Jan 2022 | Time
Softnare Mnernonic | Low
0.00
0.00
ACME DIAG RAD DCENTER | 0.00
0.00
0.00
0.00
2.5
erns | End Plotting
Ctions | Restart
Jerties
Jan 2022 | 24Mon Jan 2022 | Time
After test: 848 on lowest valve safety timer, 42 psia in oxidizer bottle, 196 psia
in fuel bottle
9
~~~~

### Pagina 10

Cita: [pdf_48ae978e0f4bf72aa77e, p. 10]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_48ae978e0f4bf72aa77e/p0010.jpg)

~~~~text
10
Test 22024C1 (test 4 of 20, flame 4 of 20) – sustained ignition, dilution variant of 
B1, run with fiberTestPosition=15700, oxidizerFlowIgnitionDeltaMs=0, 
nitrogenFlowIgnitionDeltaMs=0,
stabilizationTime2Sec=1, constantFlowTime1Sec=20
use HiBMS Camera?=NO, HiBMS Illumination Level (backlight)=0

[Texto OCR de la imagen]
Test 22024C1 (test 4 of 20, flame 4 of 20) — sustained ignition, dilution variant of
Bl, run with fiberTestPosition=15700, oxidizerFIowIgnitionDeItaMs=O,
nitrogenFlowIgnitionDeltaMs=O,
stabilizationTime2Sec=1, constantFlowTime1Sec=20
use HiBMS | HiBMS Illumination Level (backlight)=O
Gas Flow Charts | x
Graphs
State | Operate | c | 0.000 | SLPM | -0.001 | SLPM | ELA scale | 0.500 | SLPM
Static Mixer Line (MFCAI)
ACME FLOW MI MIXER SETPOINT | ACME FLOW MI MIXER FLOW
0.10
ao:oo | 20:01 | 20:02 | 20:03 | 20:04 | 20:05
24Mon Jan 2022 | Time (s)
State | Operate | c | 0.000 | -0.002 | scale | 2. ooo
Bypass(MFCA2)
ACME FLOW | BYPASS SETPOINT | ACME FLOW | BYPASS FLOW
0.15
0.10
ao:oo | 20:01 | ao:oa | 20:03 | 20:04 | 20:05
24mon Jan 2022 | Time (s)
State | Operate | c | 0.000 | SLPM | R | 0.001 | SLPM | scale | 2.000 | SLPM
Fuel(MFCA3)
ACME FLOW | FUEL SETPOINT | ACME FLOW '.13 FUEL FLOW
3e-3
ze-3
le-3
o
-le-3
-Ze-3
zo:oo | 20:01 | 20:02 | 20:03 | 20:04 | 20:05
24 mon Jan 2022 | Time (s)
10
~~~~

### Pagina 11

Cita: [pdf_48ae978e0f4bf72aa77e, p. 11]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_48ae978e0f4bf72aa77e/p0011.jpg)

~~~~text
Test 22024C1, continued
GMTClock | x
https://sams.grc.nasa.gov/GMTC | Ill\
COPY
GMT 024/
Fwd | S | Rtn | Fwd | Ku | Rtn
A | 29:16 | A | 29:16
00:20 | 00:20
EST 024/
Diagnostic Sensors | x
state | 2022-01-24 | GMT
PMTs | System Temperab-res
5.000 | Set | 33.100
Power
Set Al Gains
W/cm2 | CPI_J Board | 35.000
PMT 1 | 0.000 | 0.000 | Gain | 0.000
Cube Sensor 1 | 34.947
PMT 2 | 0.000 | -0.000 | Gain | 0.000 | Set | 34.964
Cube Sensor 2
PMT 3 | 0.000 | -0.001 | Gain | 0.000 | 26
Hard Drive
W/cm 2 | Volts
-0.003300 | -0.000 | TC200A (TCI) | 24.715692 | 0.065 | mV
-60 mm
-0.003077 | -0.000 | TC200B (TC2) | 22.682451 | -0.017 | mV
-30 mm
-0.004216 | -0.098 | 23.121190 | 0.874
center
+30 | -0.002209 | 0.056 | Array
mm
Rake: Far
+60 mm | -0.003231 | 0.053
34.750806 | 0.472
60 Deg Offset | 0.000268 | 1.432
nvalid-low | 0.008 | mV
nvalid40w | -0.001 | mV
Radiometer Cold Junctions
Volts
34.161681 | 0.448
-60 | CJ | 154.04983 | -0.000
-30 | CJ | 154.04983 | -0.000
Burner: Spherea/ (1/4)
Center CJ | 197.958906 | -0.565
Burner | 205.323569 | 7.428 | mV
+30 CJ | 105.036199 | 0.613
+60 | 106.983590 | 0.589
60 Deg Offset | 25.249453 | 1.571 | be Connection
11
~~~~

### Pagina 12

Cita: [pdf_48ae978e0f4bf72aa77e, p. 12]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_48ae978e0f4bf72aa77e/p0012.jpg)

~~~~text
12
Test 22024C1, continued
After test: 801 on lowest valve safety timer, 40 psia in oxidizer bottle, 196 psia 
in fuel bottle

[Texto OCR de la imagen]
Test 22024C1, continued
hart Sl | o | x
Software Mnemoric | Low
0.00
ACME | 0.00
ACME DIAG PMT T3 | 0.00
End Plotting
tions | Restart
2022 | 24 Mon Jan 2022 | Time
o | x
Software Vhernonic | Low
0.00
ACME DIAG RAD D30 | 0.00
ACME DIAG RAD DCENTER | 0.00
0.00
ACME DIAG RAD DMIWS60 | 0.00
ACME DIAG RAD DOFFSET | 0.00
erns | End Plotting
tiorrs | Restart
erties
Jan 2022 | 24Mon Jan 2022 | Time
After test: 801 on lowest valve safety timer, 40 psia in oxidizer bottle, 196 psia
in fuel bottle
12
~~~~

### Pagina 13

Cita: [pdf_48ae978e0f4bf72aa77e, p. 13]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_48ae978e0f4bf72aa77e/p0013.jpg)

~~~~text
13
Test 22024D1 (test 5 of 20, flame 5 of 20) – sustained ignition, run with 
fiberTestPosition=15700, oxidizerFlowIgnitionDeltaMs=200,
nitrogenFlowIgnitionDeltaMs=0, stabilizationTime2Sec=0, 
constantFlowTime1Sec=20
use HiBMS Camera?=NO, HiBMS Illumination Level (backlight)=0

[Texto OCR de la imagen]
Test 22024D1 (test 5 of 20, flame 5 of 20) - sustained ignition, run with
fiberTestPosition=15700, oxidizerFIowIgnitionDeItaMs=200,
nitrogenFlowIgnitionDeltaMs=O, stabilizationTime2Sec=O,
constantFIowTime1Sec=20
use HiBMS | HiBMS Illumination Level (backlight)=O
Gas Flow Charts | x
Graphs
2022-01-24 m: 19:59 | g...1T
State | Operate | c | SLPM | -0.000 | SLPM | Fun scale | 0.500
Static Mixer Line (MFCAI)
ACME FLOW | r.11XER SETPOINT | ACME FLOW MI r.11XER FLOW
20:16 | 20:17 | 20:18 | 20:19
24 Mon Jan 2022 | Time (s)
State | Operate | c | 0.000 | SLPM | R | 0.001 | SLPM | scale | 2.000 | SLPM
Bypass(MFCA2)
0.10
20:16 | 20:17 | 20:18 | 20:19
24 Hon Jan 2022 | Time (s)
State | Operate | c | 0.000 | SLPM | 0.002 | SLPM | scale | 2.000 | SLPM
Fuel(MFCA3)
ACME FLOW | FUEL SETPOINT | ACME FLOW "3 FUEL FLOW
40e-3
3.se-3
3ne-3
2Se-3
2,0e-3
Ise-3
1Æe-3
OSe-3
20:16 | 20:17 | 20:18 | 20:19
24 mon Jan 2022 | Time (s)
13
~~~~

### Pagina 14

Cita: [pdf_48ae978e0f4bf72aa77e, p. 14]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_48ae978e0f4bf72aa77e/p0014.jpg)

~~~~text
Test 22024D1, continued
o GMTClock
https://sams.grc.nasa.gov/GMTC | 9T•6 | Ill \
IScopyD
GMT
Fwd | S | Rtn | Fwd | Ku | Rtn
A | 14:52 | A | 14:52
00:20 | 00:20
EST
Diagnostic Sensors | x
state | 2022-01-24 20: 19:23 | GMT
Pt«s | System Temperatures
5.000 | Set | 33.200
Power
Set All Gains
W/crn2 | Board | 35.000
0.000 | -0.000 | 0.000 | set
PMT 1 | Gain | 35.062
Cube Sensor 1
PMT 2 | 0.000 | -0.001 | Gain | 0.000 | 35.051
Cube Sensor 2
PMT 3 | 0.000 | -0.001 | Gain | 0.000 | 26
Hard Drive
Radiometers
W/crn2 | Volts
-0.003300 | -0.000 | TC200A (TCI) | 24. 7936 | 0.055 | mV
-60 rnrn
-0.003077 | -0.000 | TC200B | 22.756903 | -0.014 | mV
-30 mm | (TC2)
-0.004190 | -0.089 | 23.121190 | 0.874
center
+30 | -0.002173 | 0.076 | Array
tyn
Rake:
+60 rnrn | -0.003192 | 0.068
34.701724 | 0.470 | mV
60 Deg Offset | 0.000322 | 1.462
invalid40w | 0.001 | mV
invalid-low | 0.002 | mV
Radometer Cold Junctions
Volts
34.652641 | 0.468 | mV
-60 mm CJ | 154.049483 | -0.000
-30 mm CJ | 154.049483 | -0.000
Burner: Spherical ( 1/4'
Center | 197.652076 | -0.561
Burner | 169.061737 | 5.978
+30 CJ | 86.743964 | 0.837
+60 CJ | 93.710218 | 0.752
60 Deg Offset | 25.334933 | 1.570 | Cube Connection
14
~~~~

### Pagina 15

Cita: [pdf_48ae978e0f4bf72aa77e, p. 15]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_48ae978e0f4bf72aa77e/p0015.jpg)

~~~~text
15
Test 22024D1, continued
After test: 755 on lowest valve safety timer, 39 psia in oxidizer bottle, 196 psia 
in fuel bottle

[Texto OCR de la imagen]
Test 22024D1, continued
o | x
Software tvlnernonic | I Low
0.00
AOE- DIAG | T2 | 0.00
0.00
End Plotting
ctions | Restart
20: 18:30
an 2022 20: 19*3.OOO | 24 mon Jan 2022
Chart | o | x
Software '*lemonic
ACME | 0.00
0.00
ACME DIAG RAD DCENTER | 0.00
0.00
ACME DIAG RAD DMIWS60 | 0.00
ACME DIAG RAD DOFFSET | 0.00
2-5
err's | End Plotting
Qions | Restart
'erties
20:19:00
2022 | 24 Hon Jan 2022 | Tüne
After test: 755 on lowest valve safety timer, 39 psia in oxidizer bottle, 196 psia
in fuel bottle
15
~~~~

### Pagina 16

Cita: [pdf_48ae978e0f4bf72aa77e, p. 16]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_48ae978e0f4bf72aa77e/p0016.jpg)

~~~~text
16
Test 22024F1 (test 6 of 20, flame 6 of 20) – sustained ignition, run with 
fiberTestPosition=15700, oxidizerFlowIgnitionDeltaMs=500,
nitrogenFlowIgnitionDeltaMs=0, stabilizationTime2Sec=0,
constantFlowTime1Sec=20
use HiBMS Camera?=NO, HiBMS Illumination Level (backlight)=0

[Texto OCR de la imagen]
Test 22024F1 (test 6 of 20, flame 6 of 20) - sustained ignition, run with
fiberTestPosition=15700, oxidizerFIowIgnitionDeItaMs=500,
nitrogenFlowIgnitionDeltaMs=O, stabilizationTime2Sec=O,
constantFIowTime1Sec=20
use HiBMS Camera?=NO, HiBMS Illumination Level (backlight)=O
Gas Flow Chats
Graphs
2022-01-24 20:33:08 | a•1T
State | Operate | c | 0.000 | SLPM | R | -O. 000 | scale | 0.500 | SLPM
Static Mixer Line (MFCAI)
20:29 | 20:30 | 20:31 | 20:32 | 20:33
24 mon Jan 2022 | Tune (s)
State | Operate | c | 0.000 | SLPM | R | -0.000 | SLPM | scale | 2.000 | SLPM
Bypass(MFCA2)
ACME FLOW | BYPASS SETPOINT | ACME FLOW | BYPASS FLOW
0.10
20:29 | 20:30 | 20:31 | 20:32 | 20:33
24 Mon Jan 2022 | Tune (s)
State | Operate | c | 0.000 | SLPM | 0.001 | scale | 2. ooo
Fuel(MFCA3)
ACME FLOW | FUEL SETPOINT | ACME FLOW | FUEL FLOW
3ne-3
2.5e-3
2,0e-3
Ise-3
I.Oe-3
ose-3
-OSe-3
-I.oe-3
20:29 | 20:30 | 20:31 | 20:32 | 20:33
24 Hon Jan 2022 | Tune (s)
16
~~~~

### Pagina 17

Cita: [pdf_48ae978e0f4bf72aa77e, p. 17]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_48ae978e0f4bf72aa77e/p0017.jpg)

~~~~text
Test 22024F1, continued
GMTClock | x
https://sams.grc.nasa.gov/GMTC | Ill\
copy
GMT 024/
Fwd | S | Rtn | Fwd | Ku | Rtn
A | 01:31 | A | 01:31
00:20 | 00:20
EST 024/ 15:32:28
Diagnostic Sensors | x
2022-01-24 20:32:44 | GMT
PMTs | System Ternperatures
5.000 | set | cpu | 33,
Power
Set All Gains
W /an2 | Board | 35.000
-58.000 | -0.000 | 5.500 | Set
Gain | 34.966
Cube Sensor 1
728.000 | -0.001 | Gain | 5.000 | Set | 34.970
Cube Sensor 2
911.000 | -0.000 | Gain | 5.000 | Set | 26
Hard Drive
Radiorneters
W/crn 2 | Volts
-0.003300 | -0.000 | TC200A (TCI) | 24.981056 | 0.062 | mV
-60 mn-l
-0.003077 | -0.000 | TC200B (TC2) | 23.121979 | -0.013 | mV
-30 mm
-0.004184 | -0.087 | TCCJ | 23.460169 | 0.875
center
+30 | -0.002162 | 0.082 | Array
mm
Rake: Far
+60 mm | -0.003186 | 0.070
35.970087 | 0.508 | mV
60 Deg Ofret | 0.000332 | 1.468
maid-low | 0.019 | mV
maid-low | -0.001 | mV
Radiometer Cold Jl-nctjons
Volts
TCD | 38.149522 | 0.597 | mV
-60 mm CJ | 154.049483 | -0.000
-30 mm CJ | 154.049483 | -0.000
Burner: Sphecica/ (1/4)
Center CJ | 198.188992 | -0.568
Burner | 125.477387
+30 CJ | 81.643125 | 0.899
+60 CJ | 92.319433 | 0.769
60 Deg Offset | 25.334933 | 1.570 | Cube Connection
17
~~~~

### Pagina 18

Cita: [pdf_48ae978e0f4bf72aa77e, p. 18]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_48ae978e0f4bf72aa77e/p0018.jpg)

~~~~text
18
Test 22024F1, continued
After test: 709 on lowest valve safety timer, 38 psia in oxidizer bottle, 196 psia 
in fuel bottle

[Texto OCR de la imagen]
Test 22024F1, continued
o | x
Software "lemonic | I Low
ACME DIAG PMT Tl | 0.00
0.00
0.00
End Plotbng
:tions | Restart
ffties
20:31:45
an 2022 | 24 mon Jan 2022 | Time
Chart
Software Mnemonic | Low
0.00
ACME DIAG RAD D30 | 0.00
ACME DIAG RAD DCEP.,TER | 0.00
0.00
ACME DIAG RAD DMIWS60 | 0.00
0.00
2.0
End PIO tong
ctions | Res tart
)erties
Ian 2022 | 24 Hon Jan 2022 | Time
After test: 709 on lowest valve safety timer, 38 psia in oxidizer bottle, 196 psia
in fuel bottle
18
~~~~

### Pagina 19

Cita: [pdf_48ae978e0f4bf72aa77e, p. 19]. Metodo: native.

~~~~text
19
Test 22024B2 (test 7 of 20, flame 7 of 20) – sustained ignition, up/down flow 
ramping, run with fiberTestPosition=15700, oxidizerFlowIgnitionDeltaMs=0, 
nitrogenFlowIgnitionDeltaMs=0, stabilizationTime2Sec=8, 
oxidizerIgnitionFlowSlpm=oxidizerTestFlow1Slpm=0.207, 
oxidizerTestFlow2Slpm=0.494, oxidizerTestFlow3Slpm=0.207, 
constantFlowTime1Sec=7, constantFlowTime2Sec=constantFlowTime3Sec=10, 
testFlowRamp1To2TimeSec=testFlowRamp2To3TimeSec=5, 
burnerTemperatureLimitC=500
dataCamera Zoom=35000, dataCamera Focus=12700
use HiBMS Camera?=NO, HiBMS Illumination Level (backlight)=0
~~~~

### Pagina 20

Cita: [pdf_48ae978e0f4bf72aa77e, p. 20]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_48ae978e0f4bf72aa77e/p0020.jpg)

~~~~text
Gas Flow Charts | x
Graphs
State | 2022-01-24 | GMT
State | Operate | c | 0.000 | SLPM | -0.000 | SLPM | Fu' Scale | 0.500 | SLPM
Static Mixer Line (MFCAI)
ACNE_ | IXER_SETPOINT
0.2
20:50 | 20:51 | 20:52 | 20:53 | 20:54
24 Mon Jan 2022 | Tüne (s)
State | Operate | c | 0.000 | R | -0.003 | SLPM | Ful scale | 2.000
Bypass(MFCA2)
ACME FLOW "2 BYPASS SETPOINT | ACME FLOW | BYPASS FLOW
le-3
-3e-3
20:50 | 20:51 | 20:52 | 20:53 | 20:54
24 | Jan 2022 | Tine (s)
State | Operate | c | 0.000 | SLPM | 0.002 | SLPM | scale | 2.000 | SLPM
Fuel(MFCA3)
5e-3
4e-3
3e-3
Ze-3
le-3
-le-3
20:50 | 20:51 | 20:52 | 20:53 | 20:54
24 | Jan 2022 | Tune (s)
Radiometers | Thermocouples
Volts
Test | -0.003300 | -0.000 | TC200A (TCI) | 26.441302 | o. 121 | mV
-60 mm
-0.003077 | -0.000 | TC200B (TC2) | 23.072360 | -0.015 | mV
22024 | -30 rnrn
-0.004135 | -0.070 | 23.460169 | 0.875
center
82,
+30 | -0.002113 | o. 109 | Array
mm
contin | Rake: Far
+60 mm | -0.003097 | o. 104
ued | 45.903135 | 0.915 | mV
60 Deg Offset | 0.000615 | 1.625
hvalid40w | 0.017 | mV
nvalid-low | 0.001 | mV
Radiometer Cold Junctions
Volts
45.514189 | 0.899 | mV
-60 mm CJ | 154.049483 | -0.000
-30n•mCJ | 154.049483 | -0.000
Burner: Sphere—I (1/4)
Center CJ | 198.112297 | -0.567
Burner | 320.893225 | 12.139 | mV
+30 | 57.057712 | 1.195
61.321639 | l. 144
60 Deg Offset | 25.420419 | 1.569 | Cube Connection
CJ
~~~~

### Pagina 21

Cita: [pdf_48ae978e0f4bf72aa77e, p. 21]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_48ae978e0f4bf72aa77e/p0021.jpg)

~~~~text
21
Test 22024B2, continued
After test: 640 on lowest valve safety timer, 34 psia in oxidizer bottle, 196 psia 
in fuel bottle

[Texto OCR de la imagen]
Test 2202482, continued
hart Sl
Soft'.vare Mnemonic
0.00
0.00
ACME DIAG PMT T3 | 0.00
End Plotting
tians | Restart
erties
20:53
24 Mon Jan 2022 | Time
Chart
Softvvare Whemonic | Low
0.00
ACME DIAG RAD 030 | 0.00
ACME DIAG RAD DCENTER | 0.00
0.00
ACME DIAG RAD DMINUS60 | 0.00
ACME DIAG RAD DOFFSET | 0.00
2.5
End Plotting
tions | Restart
20:53
Jar-1 2022 | 24 Hon Jan 2022 | Tune
After test: 640 on lowest valve safety timer, 34 psia in oxidizer bottle, 196 psia
in fuel bottle
21
~~~~

### Pagina 22

Cita: [pdf_48ae978e0f4bf72aa77e, p. 22]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
22
Test 22024B3 (test 8 of 20, flame 8 of 20) – sustained ignition, up/down/up flow 
ramping, run with dataCameraManualGain=24, useBracketedExposures=FALSE,
fiberIgnitionPosition=fiberTestPosition=0, oxidizerFlowIgnitionDeltaMs=0, 
nitrogenFlowIgnitionDeltaMs=0, stabilizationTime1Sec=10, 
stabilizationTime2Sec=0, oxidizerIgnitionFlowSlpm=0.207,
oxidizerTestFlow1Slpm=0.414, oxidizerTestFlow2Slpm=0.207, 
oxidizerTestFlow3Slpm=0.414, constantFlowTime1Sec=10, 
constantFlowTime2Sec=constantFlowTime3Sec=10, 
ignitionToTestRampTimeSec=5, testFlowRamp1To2TimeSec=5, 
testFlowRamp2To3TimeSec=5, burnerTemperatureLimitC=500
dataCamera Zoom=35000, dataCamera Focus=12700
use HiBMS Camera?=NO, HiBMS Illumination Level (backlight)=0
~~~~

### Pagina 23

Cita: [pdf_48ae978e0f4bf72aa77e, p. 23]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_48ae978e0f4bf72aa77e/p0023.jpg)

~~~~text
Test 2202483, continued
O GMTClock | x
https://sams.grc.nasa.gov/GMTC | 9T6 | Ill \
COPY
GMT
Fwd | s | Rtn | Fwd | Ku | Rtn
A | 36:33 | A | 36:33
00:20 | 12:10
EST
Diagnostic Sensors | x
2022-01-24 21: 12:36 | GMT
Ptvrs | System Temperatures
5.000 | CPI_J | 33.200
Power
Set All Gains
W /crn2 | Board | 35.000
0.000 | -0.001 | Gain | 0.000
Cube Sensor 1 | 35.194
PMT 2 | 0.000 | -0.001 | Gain | 0.000 | 35.202
Cube Sensor 2
PMT 3 | 0.000 | -0.000 | Gain | 0.000 | 26
Hard Drive
Radiorneters
-0.003300 | -0.000 | TC200A (TCI) | 26.836959 | 0.137 | mV
-60
-0.003077 | -0.000 | TC200B | 23.171595 | -0.011 | mV
-30 mm | (TC2)
-0.004039 | -0.037 | 23.460169 | 0.875
center
+30 | -0.002013 | o. 165 | Array
mm
Rake: Far
+60 rnrn | -0.002961 | 0.156
49.350083 | 1.057 | mV
60 Deg Offset | 0.000937 | 1.804
invahd40w | 0.024 | mV
invahd-bw | 0.013 | mV
Radiometer Cold Junctions
Volts
TCD | 51.603084 | 1.150 | mV
-60 mm CJ | 154.049483 | -0.000
-30 mm CJ | 154.049483 | -0.000
Burner: Spherical (1/4)
center | 188.806660 | -0.446
Burner | 314.508890 | 11.873 | mV
+30 CJ | 4.590%1 | 1.811
+60 CJ | 12.198598 | 1.723
60 Deg Ofret | 25.591366 | 1.567 | Cube Connection
23
~~~~

### Pagina 24

Cita: [pdf_48ae978e0f4bf72aa77e, p. 24]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_48ae978e0f4bf72aa77e/p0024.jpg)

~~~~text
24
Test 22024B3, continued
After test: 558 on lowest valve safety timer, 31 psia in oxidizer bottle, 196 psia 
in fuel bottle

[Texto OCR de la imagen]
Test 2202483, continued
Chart $1
Software Phernonic | Low
0.00
ACME DIAG PMT T2 | 0.00
ACME DIAG | T3 | 0.00
End Plotting
Restart
Jetties
Ian 2022 | 24 Mon Jan 2022 | Time
Software Mnemonic
ACME DIAG RAD D60 | 0.00
0.00
ACME DIAG RAD DCEF,'TER | 0.00
ACME DIAG RAD DMIWS30 | 0.00
ACME DIAG RAD DMT-u_lS60 | 0.00
0.00
2.5
ems | End Plotting
.ctions | Restart
erties
Jan 2022 | 12:52.OOO | 24 Hon Jan 2022 | Time
After test: 558 on lowest valve safety timer, 31 psia in oxidizer bottle, 196 psia
in fuel bottle
24
~~~~

### Pagina 25

Cita: [pdf_48ae978e0f4bf72aa77e, p. 25]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
25
Chamber vented and refilled to 7.35 psia with 19% ethylene (balance N2)
resetting the valve safety timers
Test 22024G1 (test 9 of 20, flame 9 of 20) – sustained ignition, pressure variant 
of A1, run with dataCameraManualGain=24, useBracketedExposures=FALSE,
fiberIgnitionPosition=fiberTestPosition=0, oxidizerFlowIgnitionDeltaMs=200,
nitrogenFlowIgnitionDeltaMs=0, stabilizationTime1Sec=0, 
stabilizationTime2Sec=0, oxidizerIgnitionFlowSlpm=0.259, 
oxidizerTestFlow1Slpm=0.259, oxidizerTestFlow2Slpm=0,
oxidizerTestFlow3Slpm=0, constantFlowTime1Sec=20, 
constantFlowTime2Sec=constantFlowTime3Sec=ignitionToTestRampTimeSec=0, 
testFlowRamp1To2TimeSec=testFlowRamp2To3TimeSec=0,
burnerTemperatureLimitC=450
dataCamera Zoom=30000, dataCamera Focus=13750
use HiBMS Camera?=YES, HiBMS Illumination Level (backlight)=65
~~~~

### Pagina 26

Cita: [pdf_48ae978e0f4bf72aa77e, p. 26]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_48ae978e0f4bf72aa77e/p0026.jpg)

~~~~text
Test 22024G1, continued
O GMTClock
https://sams.grc.nasa.gov/GMTC | Ill \
ecopV
GMT
Fwd | s | Rtn | Fwd | Ku | Rtn
A | 32:13 | A | 32:13
00:20 | 00:20
EST
Diagnostic Sensors | x
state | 2022-01-24 | GtvTT
pt.(Ts | System Temperatures
5.000 | Set | 33.300
Power
Set All Gains
W /cm2 | CPI_J Board | 36.000
-58.000 | -0.000 | 5.500 | Set
Gain | 35.550
Cube Sensor 1
728.000 | 0.001 | Gain | 5.000 | Set | 35.533
Cube Sensor 2
911.000 | -0.000 | Gain | 5.000 | Set | 26
Hard Drive
Radorneters
W/cm 2 | Volts
-0.003300 | -0.000 | TC200A (TCI) | 25.253455 | 0.073 | mV
-60 mm
-0.003077 | -0.000 | TC200B | 22.898679 | -0.022 | mV
-30 mm | (TC2)
-0.004178 | -0.085 | 23.460169 | 0.875
center
+30 | -0.002151 | 0.088 | Array
rnm
Rake:
+60 rnrn | -0.003173 | 0.075
37.292955 | 0.562 | mV
60 Deg Offset | 0.000466 | 1.542
hvalid-low | 0.011 | mV
invalid-low | -0.004 | mV
Radiometer Cold Junctions
Volts
39.396487 | 0.648 | mV
-60 mm CJ | -0.000
-30 mm CJ | 154.049483 | -0.000
Burner: Spherical (1/4)
Center CJ | 197.191730 | -0.555
Burner | 264.105290 | 9.791 | mV
+30 CJ | 76.442909 | 0.962
+60 CJ | 87.236717 | 0.831
60 Deg Offset | 25.591366 | 1.567 | Cube Connection
26
~~~~

### Pagina 27

Cita: [pdf_48ae978e0f4bf72aa77e, p. 27]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_48ae978e0f4bf72aa77e/p0027.jpg)

~~~~text
27
Test 22024G1, continued
After test: 955 on lowest valve safety timer, 30 psia in oxidizer bottle, 86 psia in 
fuel bottle

[Texto OCR de la imagen]
Test 22024G1, continued
Chart Sl | x
Software Mnemoric | Low
0.00
ACYE DIAG | T2 | 0.00
ACME DIAG PMT T3 | 0.00
ems | End Plotting
ctions | Restart
jerries
an 2022 | 24Mon Jan 2022 | Time
5.0
So ftaare Mnemonic | Low
ACME DIAG RAD 060 | 0.00
0.00
ACME DIAG RAD DCENTER | 0.00
ACME DIAG RAD DMINUS30 | 0.00
ACME DIAG RAD DMINUS60 | 0.00
0.00
2.5
erns | End Plotbng
L-tions | Restart
3erties
2022 | 24 Mon Jan 2022
After test: 955 on lowest valve safety timer, 30 psia in oxidizer bottle, 86 psia in
fuel bottle
27
~~~~

### Pagina 28

Cita: [pdf_48ae978e0f4bf72aa77e, p. 28]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
28
Test 22024H1 (test 10 of 20, flame 10 of 20) – sustained ignition, TFP variant of 
G1, run with dataCameraManualGain=0, useBracketedExposures=TRUE,
fiberIgnitionPosition=10000, fiberTestPosition=15700,
oxidizerFlowIgnitionDeltaMs=0, nitrogenFlowIgnitionDeltaMs=0, 
stabilizationTime1Sec=0, stabilizationTime2Sec=3, 
oxidizerIgnitionFlowSlpm=0.259, oxidizerTestFlow1Slpm=0.259,
oxidizerTestFlow2Slpm=0, oxidizerTestFlow3Slpm=0, 
constantFlowTime1Sec=20, 
constantFlowTime2Sec=constantFlowTime3Sec=ignitionToTestRampTimeSec=0, 
testFlowRamp1To2TimeSec=testFlowRamp2To3TimeSec=0, 
burnerTemperatureLimitC=450
dataCamera Zoom=30000, dataCamera Focus=13750
use 
HiB
MS 
Cam
era?
=NO, 
HiB
MS 
Illum
inati
on 
Level 
(back
light)
=0
~~~~

### Pagina 29

Cita: [pdf_48ae978e0f4bf72aa77e, p. 29]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_48ae978e0f4bf72aa77e/p0029.jpg)

~~~~text
Test 22024H1, continued
GMTCloc
https://sams.grc.nasa.gov/GMTC | lil\
copy
GMT
Fwd | S | Rtn | Fwd | Ku | Rtn
A | 19:59 | A | 19:59
00:20 | 00:20
EST
Diagnostic Sensors | x
state | 2022-01-24 | GMT
PMTS | System Temperatures
5.000 | Set | cpu | 33.300
Power
Set All Gains
W/crn2 | CPU Board | 35.000
0.000 | -0.001 | 0.000 | Set
PMT 1 | Gain | 35.432
Cube Sensor 1
PMT 2 | 0.000 | -0.000 | Gain | 0.000 | Set | 35.444
Cube Sensor 2
0.000 | -0.001 | Gain | 0.000 | Set | 26
Hard Drive
W/an 2 | Volts
-0.003300 | -0.000 | TC200A (TCI) | 25.327734 | 0.076 | mV
-60 mm
-0.003077 | -0.000 | TC200B (TC2) | 22.997929 | -0.018 | mV
-30 mrn
-0.004192 | -0.090 | TCCJ | 23.460169 | 0.875
center
+30 | -0.002164 | 0.081 | Array
mm
Rake: Far
+60 mm | -0.003186 | 0.070
40.080510 | 0.676 | mV
60 Deg Ofret | 0.000419 | 1.516
maid-low | 0.013 | mV
hvalid-low | -0.002 | mV
Radiometer Cold Junctions
39.885116 | 0.668 | mV
-60 nn CJ | 154.049483 | -0.000
-30 nrnCJ | 154.049483 | -0.000
Spherical
Center CJ | 198.725731 | -0.575
Burner | 289.756249 | 10.8% | mV
+30 CJ | 82.878723 | 0.884
+60 CJ | 92.073871 | 0.772
60 Deg Offset | 25.676838 | 1.566 | Cube Connection
CJ
29
~~~~

### Pagina 30

Cita: [pdf_48ae978e0f4bf72aa77e, p. 30]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_48ae978e0f4bf72aa77e/p0030.jpg)

~~~~text
30
Test 22024H1, continued
After test: 906 on lowest valve safety timer, 28 psia in oxidizer bottle, 86 psia in 
fuel bottle

[Texto OCR de la imagen]
Test 22024H1, continued
Chart Sl
Soffvare t•hemonic
ACME DIAG PMT Tl | 0.00
DIAG PMT T2 | 0.00
ACME DIAG PMT T3 | 0.00
terns | End plotting
Restart
±ctions
iperties
23:05:45
Jan 2022 | 24 Hon Jan 2022
Chart
Softaare Mnemonic | Low
0.00
ACME | 0.00
ACME DIAG RAD DCENTER | 0.00
ACME DIAG RAD DMINUS30 | 0.00
ACME DIAG RAD DMIWS60 | 0.00
ACME DIAG RAD DOFFSET | 0.00
2.5
ttems | End Plotting
ections
Verties
Jan 2022 | 24 mon Jan 2022
After test: 906 on lowest valve safety timer, 28 psia in oxidizer bottle, 86 psia in
fuel bottle
30
~~~~

### Pagina 31

Cita: [pdf_48ae978e0f4bf72aa77e, p. 31]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
31
Test 22024J1 (test 11 of 20, flame 11 of 20) – sustained ignition, dilution variant 
of H1 (pressure variant of C1), run with dataCameraManualGain=0, 
useBracketedExposures=TRUE, fiberIgnitionPosition=10000, 
fiberTestPosition=15700, oxidizerFlowIgnitionDeltaMs=0, 
nitrogenFlowIgnitionDeltaMs=0, stabilizationTime1Sec=0, 
stabilizationTime2Sec=0, oxidizerIgnitionFlowSlpm=0.259, 
nitrogenIgnitionFlowSlpm=0.094, oxidizerTestFlow1Slpm=0.259,
nitrogenTestFlow1Slpm=0.094, oxidizerTestFlow2Slpm=0,
oxidizerTestFlow3Slpm=0, constantFlowTime1Sec=15,
constantFlowTime2Sec=constantFlowTime3Sec=ignitionToTestRampTimeSec=0, 
testFlowRamp1To2TimeSec=testFlowRamp2To3TimeSec=0, 
burnerTemperatureLimitC=450
dataCamera Zoom=30000, dataCamera Focus=13750
use 
HiBMS 
Camer
a?=NO
, 
HiBMS 
Illumin
ation 
Level 
(backli
ght)=0
~~~~

### Pagina 32

Cita: [pdf_48ae978e0f4bf72aa77e, p. 32]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_48ae978e0f4bf72aa77e/p0032.jpg)

~~~~text
Test 22024J1, continued
O GMTClock | x
e | https://sams.grc.nasa.gov/GMTC | 9T6 | lil\
COPY
GMT 024/
Fwd | S | Rtn | Fwd | Ku | Rtn
A | 06:37 | A | 06:37
00:20 | 00:20
EST 024/
Diagnostic Sensors | x
state | 2022-01-24 23:20:04 | GMT
PMTs | System Temperatures
5.000 | 33.300
Power
Set Al Gains
W/crn2 | cpu Board | 35.000
-58.000 | 0.000 | Gain | 5.500
CA Ibe Sensor 1 | 35.453
728.000 | -0.000 | Gain | 5.000 | Set | 35.466
Cube Sensor 2
911.000 | 0.000 | Gan | 5.000 | Set | 26
Hard Drive
Radometers
W/cm12 | Volts
-0.003300 | -0.000 | TC200A (TCI) | 25.370258 | 0.064
-60 rnm
-0.003077 | -0.000 | TC200B (TC2) | 23.363032 | -0.017
-30 mm
-0.004190 | -0.089 | 23.799147 | 0.876
center
+30 | -0.002165 | 0.080 | Array
mm
Rake: Far
+60 mm | -0.003189 | 0.069
38.313847 | 0.590 | mV
60 Deg Ofret | 0.000385 | 1.497
invalid-low | 0.013
invalid40w | -0.002 | mV
Radiometer Cold Junctions
Volts
38.925188 | 0.615
-60 mm CJ | 154.049483 | -0.000
-30 | CJ | 154.049483 | -0.000
Burner: Spherical (1/4)
Center CJ | 196.808010 | -0.550
Burner | 200.162355 | 7.194 | mV
+30 CJ | 83.455005 | 0.877
+60 CJ | 92.646787 | 0.765
60 Deg Offset | 25.676838 | l. 566 | be Connection
32
~~~~

### Pagina 33

Cita: [pdf_48ae978e0f4bf72aa77e, p. 33]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_48ae978e0f4bf72aa77e/p0033.jpg)

~~~~text
33
Test 22024J1, continued
After test: 863 on lowest valve safety timer, 27 psia in oxidizer bottle, 86 psia in 
fuel bottle

[Texto OCR de la imagen]
Test 22024J1, continued
Chart
Softvvare Mnernonic
0.00
0.00
ACME DIAG PMT T3 | 0.00
terns | End Plotting
Restart
perties
Jan 2022 | 24Mon Jan 2022 | Tine
Chart $2
5.0
Software tvhemonic | Low
DIAG RAD 060 | 0.00
ACME DIAG RAD D30 | 0.00
0.00
DMItWS30 | 0.00
ACME DIAG RAD DMIWS60 | 0.00
ACME DIAG RAD DOFFSET | 0.00
2-5
[terns | End Plotting
ections
)perties
23:19:00 | 23:19:15 | 23:19:30 | 23:19:45
Jan 2022 | 24 Mon Jan 2022 | Tine
After test: 863 on lowest valve safety timer, 27 psia in oxidizer bottle, 86 psia in
fuel bottle
33
~~~~

### Pagina 34

Cita: [pdf_48ae978e0f4bf72aa77e, p. 34]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
34
Test 22024K1 (test 12 of 20, flame 12 of 20) – sustained ignition, pressure 
variant of D1, run with dataCameraManualGain=0, 
useBracketedExposures=TRUE, pmt1Gain=4, fiberIgnitionPosition=10000, 
fiberTestPosition=15700, oxidizerFlowIgnitionDeltaMs=200,
nitrogenFlowIgnitionDeltaMs=0, stabilizationTime1Sec=0, 
stabilizationTime2Sec=0, oxidizerIgnitionFlowSlpm=0.207, 
nitrogenIgnitionFlowSlpm=0.244, oxidizerTestFlow1Slpm=0.207, 
nitrogenTestFlow1Slpm=0.244, oxidizerTestFlow2Slpm=0,
oxidizerTestFlow3Slpm=0, constantFlowTime1Sec=15, 
constantFlowTime2Sec=constantFlowTime3Sec=ignitionToTestRampTimeSec=0, 
testFlowRamp1To2TimeSec=testFlowRamp2To3TimeSec=0, 
burnerTemperatureLimitC=450
dataCamera Zoom=30000, dataCamera Focus=13750
use 
HiBMS 
Camer
a?=NO
, 
HiBMS 
Illumin
ation 
Level 
(backli
ght)=0
~~~~

### Pagina 35

Cita: [pdf_48ae978e0f4bf72aa77e, p. 35]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_48ae978e0f4bf72aa77e/p0035.jpg)

~~~~text
Test 220241<1, continued
O GMTClock | x
https://sams.grc.nasa.gov/GMTC 1 90% | Ill \
cop/
GMT 024/
Fwd | S | Rtn | Fwd | Ku | Rtn
A | 28•.oo | A | 34:OO
06:02 | 02:00
EST 024/
Diagnostic Sensors
System state | 2022-01-24 23:31: 16 | GMT
ptv1Ts | System Temperatures
power | 5.000 | cpu
Set AM Gains
W/an2 | Board | 35.000
0.000 | -0.001 | 0.000 | Set
PMT 1 | Gain | Cube
Sensor 1
PMT 2 | 0.000 | -0.001 | Gain | 0.000 | Set | 35.410
Cube Sensor 2
PMT 3 | 0.000 | -0.000 | Gain | 0.000 | Set | 26
Hard Drive
Radiometers
W/cm 2 | Volts
-0.003300 | -0.000 | TC200A (TCI) | 25.295982 | 0.061 | mV
-60 mrn
-0.003077 | -0.000 | TC200B | 23.437439 | -0.014 | mV
-30 mm | (TC2)
-0.004268 | -0.116 | TCCJ | 23.799147 | 0.876
Center
+30 | -0.002259 | 0.028 | Array
Rake: Far
+60 rnrn | -0.003299 | 0.027
35.816078 | 0.488 | mV
60 Deg Offset | 0.000149 | 1.366
invalid40w | 0.003 | mV
invalid-low | -0.004 | mV
Radiometer Cold Junctions
Volts
TCD | 35.203006 | 0.463 | mV
-60 mm CJ | 154.049483 | -0.000
-30 mm CJ | 154.049483 | -0.000
Burner: Spherical
center | 196.654495 | -0.548
Burner | 154.360975 | 5.361 | mV
+30 CJ | 129.929026 | 0.304
130.648301 | 0.295
60 Deg Offset | 25.762294 | 1.565 | Cube Connection
35
~~~~

### Pagina 36

Cita: [pdf_48ae978e0f4bf72aa77e, p. 36]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_48ae978e0f4bf72aa77e/p0036.jpg)

~~~~text
36
Test 22024K1, continued
After test: 826 on lowest valve safety timer, 27 psia in oxidizer bottle, 86 psia in 
fuel bottle

[Texto OCR de la imagen]
Test 220241<1, continued
Chart | o | x
Soffvare Mnemonic | LOW
0.00
0.00
0.00
:ems | End Plotting
perties
Jan 2022 | 24Mon Jan | Time
Chart | x
So ftveare Mnernonic
ACME DIAG RAD 060 | 0.00
0.00
DCENTER | 0.00
ACME DIAG_RAD DMINUS30 | 0.00
ACME DIAG RAD DMINlJS60 | 0.00
DOFFSET | 0.00
tems | End Plotting
±ctions | Restart
perties
23:30:30 | 23:30:45
Jan 2022 | 24Mon Jan 2022 | Time
After test: 826 on lowest valve safety timer, 27 psia in oxidizer bottle, 86 psia in
fuel bottle
36
~~~~

### Pagina 37

Cita: [pdf_48ae978e0f4bf72aa77e, p. 37]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
37
Test 22024L1 (test 13 of 20, flame 13 of 20) – sustained ignition, pressure 
variant of F1, run with dataCameraManualGain=0, 
useBracketedExposures=TRUE, pmt1Gain=4, fiberIgnitionPosition=10000, 
fiberTestPosition=15700, oxidizerFlowIgnitionDeltaMs=500,
nitrogenFlowIgnitionDeltaMs=0, 
stabilizationTime1Sec=stabilizationTime2Sec=0, 
oxidizerIgnitionFlowSlpm=0.172, nitrogenIgnitionFlowSlpm=0.398, 
oxidizerTestFlow1Slpm=0.172, nitrogenTestFlow1Slpm=0.398, 
oxidizerTestFlow2Slpm=oxidizerTestFlow3Slpm=0, constantFlowTime1Sec=15, 
constantFlowTime2Sec=constantFlowTime3Sec=ignitionToTestRampTimeSec=0, 
testFlowRamp1To2TimeSec=testFlowRamp2To3TimeSec=0, 
burnerTemperatureLimitC=450
dataCamera Zoom=30000, dataCamera Focus=13750
use 
HiB
MS 
Cam
era?
=NO, 
HiB
MS 
Illum
inati
on 
Level 
(bac
kligh
t)=0
~~~~

### Pagina 38

Cita: [pdf_48ae978e0f4bf72aa77e, p. 38]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_48ae978e0f4bf72aa77e/p0038.jpg)

~~~~text
Test 22024L1, continued
o GMTClock
-5 | https://sams.grc.nasa.gov/GMTC | Ill \
COPY
GMT
Fwd | S | Rtn | Fwd | Ku | Rtn
A | 14:09 | A | 20:09
06:02 | 02:00
EST
Diagnostic Sensors
2022-01-24 23:45:06 | GMT
PMTs | System Temperatl-res
5.000 | Set | CPU | 33.500
Power
Set All Gains
W /cm2 | Board | 35.000
0.000 | -0.001 | 0.000 | set
PMT 1 | Gain | 35.436
Cube Sensor 1
PMT 2 | 0.000 | -0.000 | Gain | 0.000 | Set | 35.457
Cube Sensor 2
0.000 | -0.000 | Gain | 0.000 | Set | 26
Hard Drive
Radorneters
W/cm 2 | Volts
-0.003300 | -0.000 | TC200A (TCI) | 25.469285 | 0.068 | mV
-60 nn
-0.003077 | -0.000 | TC200B (TC2) | 23.363032 | -0.017 | mV
-30 mm
-0.004273 | -0.118 | TCCJ | 23.799147 | 0.876
center
+30 | -0.002264 | 0.025
mm
Rake: Far
+60 | -0.003312 | 0.022
38.240465 | 0.587 | mV
60 Deg Ofret | 0.000133 | 1.357
invalid40w | 0.004 | mV
hvalid-low | 0.002 | mV
Radiometer Cold Junctions
Volts
35.938651 | 0.493 | mV
-60 mm CJ | 154.049%3 | -0.000
-30 mm CJ | 154.049483 | -0.000
Burner: Spherical (1/4)
Center CJ | 196.884760 | -0.551
Burner | 111.449646 | 3.618
+30 CJ | 132.484990 | 0.272
+60 | 134.399314 | 0.248
60 Deg Offset | 25.762294 | 1.565 | Cube Connection
38
~~~~

### Pagina 39

Cita: [pdf_48ae978e0f4bf72aa77e, p. 39]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_48ae978e0f4bf72aa77e/p0039.jpg)

~~~~text
39
Test 22024L1, continued
After test: 787 on lowest valve safety timer, 25 psia in oxidizer bottle, 86 psia in 
fuel bottle

[Texto OCR de la imagen]
Test 22024L1, continued
Software rvhernonic | Low
0.00
ACME DIAG | T2 | 0.00
ACME DIAG PMT T3 | 0.00
Items | End Plotting
ections | Restart
'perties
23:44:15 | 23:44:30 | 23:44:45
Jan 2022 | 24 mon Jan 2022
Chart
Mnemonic | Low
0.00
ACME DIAG RAD 030 | 0.00
ACME DIAG RAD DCENTER | 0.00
0.00
ACME DIAG RAD DMINUS60 | 0.00
ACME DIAG RAD DOFFSET | 0.00
Items | End Plottng
lections | Restart
nperties
23:44:15 | 23:44:30 | 23:44:45 | 23:45:00
• Jan 2022 | 24 non Jan 2022 | Time
After test: 787 on lowest valve safety timer, 25 psia in oxidizer bottle, 86 psia in
fuel bottle
39
~~~~

### Pagina 40

Cita: [pdf_48ae978e0f4bf72aa77e, p. 40]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
40
Test 22024L2 (test 14 of 20, flame 14 of 20) – sustained ignition, dilution variant 
of L1, run with dataCameraManualGain=0, useBracketedExposures=TRUE, 
pmt1Gain=4, fiberIgnitionPosition=10000, fiberTestPosition=15700, 
oxidizerFlowIgnitionDeltaMs=500, nitrogenFlowIgnitionDeltaMs=0, 
stabilizationTime1Sec=stabilizationTime2Sec=0, 
oxidizerIgnitionFlowSlpm=0.172, nitrogenIgnitionFlowSlpm=0.278, 
oxidizerTestFlow1Slpm=0.172, nitrogenTestFlow1Slpm=0.278, 
oxidizerTestFlow2Slpm=oxidizerTestFlow3Slpm=0, constantFlowTime1Sec=15, 
constantFlowTime2Sec=constantFlowTime3Sec=ignitionToTestRampTimeSec=0, 
testFlowRamp1To2TimeSec=testFlowRamp2To3TimeSec=0, 
burnerTemperatureLimitC=450
dataCamera Zoom=30000, dataCamera Focus=13750
use 
HiB
MS 
Cam
era?
=NO, 
HiB
MS 
Illum
inati
on 
Level 
(bac
kligh
t)=0
~~~~

### Pagina 41

Cita: [pdf_48ae978e0f4bf72aa77e, p. 41]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_48ae978e0f4bf72aa77e/p0041.jpg)

~~~~text
Test 22024L2, continued
o GMTClock
https://sams.grc.nasa.gov/GMTC | 9Té | Ill \
'cop/
GMT
Fwd | S | Rtn | Fwd | Ku | Rtn
A | 33:53 | A | 33:53
00:20 | 00:20
EST
Diagnostic Sensors | x
state | 2022-01-25 | GWIT
PMTs | System Temperatures
5.000 | Set | CPU | 33.300
Power
Set All Gains
W/cm2 | Board | 35.000
PMT 1 | 0.000 | -0.001 | Gain | 0.000
Cube Sensor 1 | 35.391
PMT 2 | 0.000 | -0.001 | Gain | 0.000 | Set | 35.385
Cube Sensor 2
PMT 3 | 0.000 | -0.000 | Gait, | 0.000 | 26
Hard Drive
Radiometers
W/cm2 | Volts
-0.003300 | -0.000 | TC200A (TCI) | 25.055354 | 0.065 | mV
-60
-0.003077 | -0.000 | TC200B | 22.799420 | -0.026 | mV
-30 mm | (TC2)
-0.004256 | -0.112 | 23.460169 | 0.875
Center
+30 | -0.002246 | 0.035 | Array
nn
Rake:
+60 nn | -0.003289 | 0.031
35.504250 | 0.489 | mV
60 Deg Offset | 0.000176 | 1.381
invalid-low | 0.002 | mV
invalid-low | 0.001 | mV
Radiometer Cold Junctions
Volts
TCD | 35.773969 | 0.500 | mV
-60 mm CJ | 154.049483 | -0.000
-30 mm CJ | 154.049483 | -0.000
Burner: Sphehca/ (1/4)
center | 196.961507 | -0.552
Burner | 141.094843 | 4.840
+30 CJ | 123.681813 | 0.382
+60 CJ | 127.128790 | 0.339
60 Deg Offset | 25.505900 | 1.568 | Cube Connection
41
~~~~

### Pagina 42

Cita: [pdf_48ae978e0f4bf72aa77e, p. 42]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_48ae978e0f4bf72aa77e/p0042.jpg)

~~~~text
42
Test 22024L2, continued
After test: 745 on lowest valve safety timer, 25 psia in oxidizer bottle, 86 psia in 
fuel bottle

[Texto OCR de la imagen]
Test 22024L2, continued
o | x
Software Mnemcnc | Low
0.00
ACME_DIAG PBff_T2 | 0.00
ACME DIAG PMT T3 | 0.00
Items | End Plotting
ections | Restart
jperties
0:23:
Jan 2022 | 25Tue Jan 2022 | Tirne
s Chart | o | x
So ftv•are tvhemonic
0.00
ACME DIAG RAD D30 | 0.00
ACME DIAG RAD DCENTER | 0.00
ACME DIAG RAD DMIWS30 | 0.00
0.00
0.00
2.0
Items | End Plotting
lections | Restart
operties
0:23:
i Jan 2022 | 25 Tue Jan 2022 | Time
After test: 745 on lowest valve safety timer, 25 psia in oxidizer bottle, 86 psia in
fuel bottle
42
~~~~

### Pagina 43

Cita: [pdf_48ae978e0f4bf72aa77e, p. 43]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
43
Test 22024L3 (test 15 of 20, flame 15 of 20) – sustained ignition, dilution variant
of L1-L2, run with dataCameraManualGain=0, useBracketedExposures=TRUE, 
pmt1Gain=4, fiberIgnitionPosition=10000, fiberTestPosition=15700, 
oxidizerFlowIgnitionDeltaMs=500, nitrogenFlowIgnitionDeltaMs=0, 
stabilizationTime1Sec=stabilizationTime2Sec=0, 
oxidizerIgnitionFlowSlpm=0.172, nitrogenIgnitionFlowSlpm=0.188, 
oxidizerTestFlow1Slpm=0.172, nitrogenTestFlow1Slpm=0.188, 
oxidizerTestFlow2Slpm=oxidizerTestFlow3Slpm=0, constantFlowTime1Sec=15, 
constantFlowTime2Sec=constantFlowTime3Sec=ignitionToTestRampTimeSec=0, 
testFlowRamp1To2TimeSec=testFlowRamp2To3TimeSec=0, 
burnerTemperatureLimitC=450
dataCamera Zoom=30000, dataCamera Focus=13750
use 
HiB
MS 
Cam
era?
=NO, 
HiB
MS 
Illum
inati
on 
Level 
(bac
kligh
t)=0
~~~~

### Pagina 44

Cita: [pdf_48ae978e0f4bf72aa77e, p. 44]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_48ae978e0f4bf72aa77e/p0044.jpg)

~~~~text
Test 22024L3, continued
o GMTClock | x
—y | https://sams.grc.nasa.gov/GMTC | Ill \
•copyc
GMT
Fwd | S | Rtn | Fwd | Ku | Rtn
A | 22:57 | A | 22:57
00:20 | 00:20
EST
Diagnostic Sensors
state | 2022-01-25 | GBIT
PMTs | System Temperatures
5.000 | Set | CPU | 33.300
power
Set All Gains
W/a•n2 | Board | 35.000
-0.000 | -0.001 | Gan | 4.000
Cube Sensor 1 | 35.247
728.000 | 0.000 | Gain | 5.000 | 35.239
Cube Sensor 2
PMT 3 | 911.000 | -0.000 | Gain | 5.000 | 26
Hard Drive
Radiometers
Volts
-0.003300 | -0.000 | TC200A (TCI) | 25.005823 | 0.063 | mV
-60 ryn
-0.003077 | -0.000 | TC200B (TC2) | 23.047550 | -0.016 | mV
-30 mm
-0.004210 | -0.096 | 23.460169 | 0.875
Center
+30 | -0.002191 | 0.066
mm
Rake: Far
+60 mrrl | -0.003226 | 0.055
34.792850 | 0.460 | mV
60 Deg Offset | 0.000288 | 1.443
invalid-low | 0.006 | mV
invalid-low | -0.010 | mV
Radometer Cold Junctions
Volts
36.631722 | 0.535 | mV
-60 mm CJ | 154.049483 | -0.000
-30 mm CJ | 154.049483 | -0.000
Burner: Spherical (1/4'
center | 198.802394 | -0.576
Burner | 192.616969 | 6.906
+30 CJ | 96.406477 | 0.719
+60 CJ | 105.604433 | 0.606
60 Deg Offset | 25.591366 | 1.567 | Cube Connection
~~~~

### Pagina 45

Cita: [pdf_48ae978e0f4bf72aa77e, p. 45]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_48ae978e0f4bf72aa77e/p0045.jpg)

~~~~text
45
Test 22024L3, continued
After test: 705 on lowest valve safety timer, 24 psia in oxidizer bottle, 86 psia in 
fuel bottle

[Texto OCR de la imagen]
Test 22024L3, continued
ChartS1
Software tvlnemonic | Low
0.00
0.00
0.00
terns | End Plotting
ections | Restart
iperties
0:33:00 | 0:33:15 | 0:33:30 | 0:33:45
2022 | 25 Tue Jan 2022 | Tüne
Chart
Software t•hemonic | Low
0.00
DIAG RAD 030 | 0.00
ACME DIAG RAD DCENTER | 0.00
ACTG DIAG RAD DMINUS30 | 0.00
ACNE DIAG RAD DMINUS60 | 0.00
0.00
2.0
Items | End Plotbng
lections | Restart
3perr_ies
0:33:15
2022 | 25Tue Jan 2022 | Time
After test: 705 on lowest valve safety timer, 24 psia in oxidizer bottle, 86 psia in
fuel bottle
45
~~~~

### Pagina 46

Cita: [pdf_48ae978e0f4bf72aa77e, p. 46]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
46
Test 22024H2 (test 16 of 20, flame 16 of 20) – sustained ignition, nominal 
repeat of H1, run with dataCameraManualGain=0, 
useBracketedExposures=TRUE, pmt1Gain=4, fiberIgnitionPosition=10000, 
fiberTestPosition=15700, oxidizerFlowIgnitionDeltaMs=0,
nitrogenFlowIgnitionDeltaMs=0, stabilizationTime1Sec=0, 
stabilizationTime2Sec=2, oxidizerIgnitionFlowSlpm=0.259, 
nitrogenIgnitionFlowSlpm=0, oxidizerTestFlow1Slpm=0.259, 
nitrogenTestFlow1Slpm=0, oxidizerTestFlow2Slpm=oxidizerTestFlow3Slpm=0, 
constantFlowTime1Sec=15, constantFlowTime2Sec=constantFlowTime3Sec=0, 
ignitionToTestRampTimeSec=0, testFlowRamp1To2TimeSec=0, 
testFlowRamp2To3TimeSec=0, burnerTemperatureLimitC=450
dataCamera Zoom=30000, dataCamera Focus=13750
use 
HiBM
S 
Came
ra?=
NO, 
HiBM
S 
Illumi
natio
n 
Level 
(back
light)
=0
~~~~

### Pagina 47

Cita: [pdf_48ae978e0f4bf72aa77e, p. 47]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_48ae978e0f4bf72aa77e/p0047.jpg)

~~~~text
Test 22024H2, continued
o GMTClock
—Y | e | https://sams.grc.nasa.gov/GMTC ' 9T6 | Ill\
•cop/
GMT
Fwd | S | Rtn | Fwd | Ku | Rtn
A | 13:56 | A | 13:56
00:20 | 00:20
EST
Diagnostic Sensors
System state | 2022-01-25 | GMT
PMTs | System Temperatures
5.000 | Set | 33.300
power
Set All Gains
W/crn2 | cpu Board | 36.000
0.000 | -0.000 | 0.000 | Set
PMT 1 | Gain | 35.262
Cube Sensor 1
PMT 2 | 0.000 | -0.000 | Gain | 0.000 | Set | 35.298
Cube Sensor 2
PMT 3 | 0.000 | -0.001 | Gan | 0.000 | Set | 26
Hard Drive
Radometers
W/m2 | Volts
-0.003300 | -0.000 | TC200A (RI) | 25.104883 | 0.067 | mV
-60 rnrn
-0.003077 | -0.000 | TC200B (TC2) | 22.873865 | -0.023
-30 mm
-0.004207 | -0.095 | TCCJ | 23.460169 | 0.875
center
+30 | -0.002185 | 0.069 | Array
Rake: Far
+60 rm•n | -0.003210 | 0.061
37.611186 | 0.575 | mV
60 Deg Offet | 0.000350 | 1.478
invahd-low | 0.011
invalid-low | 0.003
Radiometer Cold Junctions
Volts
37.635661 | 0.576
-60 mm CJ | 154.049483 | -0.000
-30 mm CJ | 154.049483 | -0.000
Burner: Spherical (1/4'
center | 196.424203 | -0.545
Burner | 246.293256 | 9.065 | mV
+30 CJ | 93.219490 | 0.758
+60 CJ | 100.482960 | 0.669
60 Deg Offset | 25.676838 | I. 566 | Cube Connection
47
~~~~

### Pagina 48

Cita: [pdf_48ae978e0f4bf72aa77e, p. 48]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_48ae978e0f4bf72aa77e/p0048.jpg)

~~~~text
48
Test 22024H2, continued
After test: 665 on lowest valve safety timer, 24 psia in oxidizer bottle, 86 psia in 
fuel bottle

[Texto OCR de la imagen]
Test 22024H2, continued
Softveare t•hemonic | Low
0.00
0.00
ACME DIAG PMT T3 | 0.00
terns | End Plottng
ections | Restart
jperties
Jan 2022 | 25Tue Jan 2022 | Tine
; Chart
So ft'.vare Mnernoric
ACME DIAG RAD 060 | 0.00
030 | 0.00
DCENTER | 0.00
0.00
ACME DIAG RAD DMINUS60 | 0.00
0.00
Items | End Plotting
lections | Restart
3perties
0:42:30 | 0:42:45
Jan 2022 | 25 Tue Jan 2022 | Time
After test: 665 on lowest valve safety timer, 24 psia in oxidizer bottle, 86 psia in
fuel bottle
48
~~~~

### Pagina 49

Cita: [pdf_48ae978e0f4bf72aa77e, p. 49]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
49
Test 22024M1 (test 17 of 20, flame 17 of 20) – sustained ignition, pressure 
variant of B2 (up/down ramp), run with dataCameraManualGain=0, 
useBracketedExposures=TRUE, pmt1Gain=4, fiberIgnitionPosition=10000, 
fiberTestPosition=15700, oxidizerFlowIgnitionDeltaMs=0, 
nitrogenFlowIgnitionDeltaMs=0, stabilizationTime1Sec=0, 
stabilizationTime2Sec=8, oxidizerIgnitionFlowSlpm=0.207, 
nitrogenIgnitionFlowSlpm=0, oxidizerTestFlow1Slpm=0.207, 
nitrogenTestFlow1Slpm=0, oxidizerTestFlow2Slpm=0.494, 
oxidizerTestFlow3Slpm=0.207, constantFlowTime1Sec=7, 
constantFlowTime2Sec=constantFlowTime3Sec=10,
ignitionToTestRampTimeSec=0, testFlowRamp1To2TimeSec=5, 
testFlowRamp2To3TimeSec=5, burnerTemperatureLimitC=500
dataCamera Zoom=35000, dataCamera Focus=12700
use 
HiBMS 
Camer
a?=NO
, 
HiBMS 
Illumin
ation 
Level 
(backli
ght)=0
~~~~

### Pagina 50

Cita: [pdf_48ae978e0f4bf72aa77e, p. 50]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_48ae978e0f4bf72aa77e/p0050.jpg)

~~~~text
Test 22024M1, continued
o GMTClock | x
https://sams.grc.nasa.gov/GMTC | Ill \
COPY
GMT
Fwd | S | Rtn | Fwd | Ku | Rtn
A | 35:23 | A | 35:23
I I : 27 | 10:09
EST 024/
Diagnostic Sensors | x
GBIT
Pt«s | System Temperatures
5.000 | CPU | 33.500
Power
Set All Gains
W/an2 | Board | 35.000
PMT 1 | 0.000 | -0.001 | Gain | 0.000
Cube Sensor 1 | 35.467
PMT 2 | 0.000 | -O. 001 | Gain | 0.000 | 35.447
Cube Sensor 2
PMT 3 | 0.000 | -0.001 | Gain | 0.000 | Set | 26
Hard Drive
W/cm12 | Volts
-0.003300 | -0.000 | TC200A (TCI) | 26.268156 | o. 114 | mV
-60 mm
-0.003077 | -0.000 | TC200B (TC2) | 22.948305 | -0.020 | mV
-30 nn
-0.004242 | -o. 107 | 23.460169 | 0.875
center
+30 | -0.002223 | 0.048
mm
Rake: Far
+60 mm | -0.003247 | 0.047
44.151950 | 0.843 | mV
60 Deg Offset | 0.000327 | 1.465
nalid-low | 0.006 | mV
nvalid40w | 0.002 | mV
Radiometer Cold Junctions
Volts
41.569301 | 0.737 | mV
-60 mm CJ | 154.049483 | -0.000
-30 mm CJ | 154.049483 | -0.000
Burner: Sphere-a/ (1/4)
Center CJ | 196.270653 | -0.543
Burner | 336.984597 | 12.811 | mV
+30 CJ | 112.084173 | 0.526
+60 | 112.245831 | 0.524
60 Deg Offset | 25.762294 | 1.565 | Cube Connection
CJ
50
~~~~

### Pagina 51

Cita: [pdf_48ae978e0f4bf72aa77e, p. 51]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_48ae978e0f4bf72aa77e/p0051.jpg)

~~~~text
51
Test 22024M1, continued
After test: 593 on lowest valve safety timer, 21 psia in oxidizer bottle, 86 psia in 
fuel bottle

[Texto OCR de la imagen]
Test 22024M1, continued
ZhartS1
Software Mnemoric
0.00
ACME DIAG PMT T2 | 0.00
0.00
End Plottng
:tion5 | Restart
erties
an 2022 | 25 Tue Jan 2022 | Tüne
Chart
Software Mnemonic | Low
0.00
ACME DIAG RAD 030 | 0.00
0.00
ACME DIAG RAD DMINUS30 | 0.00
ACME DIAG RAD DMINLJS60 | 0.00
ACME | 0.00
2.5
End Plotting
ctions | Restart
jerties
Ian 2022 | 25Tue Jan 2022 | Time
After test: 593 on lowest valve safety timer, 21 psia in oxidizer bottle, 86 psia in
fuel bottle
51
~~~~

### Pagina 52

Cita: [pdf_48ae978e0f4bf72aa77e, p. 52]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
52
Test 22024M2 (test 18 of 20, flame 18 of 20) – sustained ignition, pressure 
variant of B3 (up/down/up ramp), run with dataCameraManualGain=24, 
useBracketedExposures=FALSE, pmt1Gain=4, fiberIgnitionPosition=0, 
fiberTestPosition=0, oxidizerFlowIgnitionDeltaMs=0, 
nitrogenFlowIgnitionDeltaMs=0, stabilizationTime1Sec=10, 
stabilizationTime2Sec=0, oxidizerIgnitionFlowSlpm=0.207,
nitrogenIgnitionFlowSlpm=0, oxidizerTestFlow1Slpm=0.414, 
nitrogenTestFlow1Slpm=0, oxidizerTestFlow2Slpm=0.207, 
oxidizerTestFlow3Slpm=0.414, constantFlowTime1Sec=10, 
constantFlowTime2Sec=constantFlowTime3Sec=10, 
ignitionToTestRampTimeSec=5, testFlowRamp1To2TimeSec=5, 
testFlowRamp2To3TimeSec=5, burnerTemperatureLimitC=500
dataCamera Zoom=35000, dataCamera Focus=12700
use 
HiBMS 
Camer
a?=NO
, 
HiBMS 
Illumin
ation 
Level 
(backli
ght)=0
~~~~

### Pagina 53

Cita: [pdf_48ae978e0f4bf72aa77e, p. 53]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_48ae978e0f4bf72aa77e/p0053.jpg)

~~~~text
Test 22024M2, continued
o GMTClock | x
https://sams.grc.nasa.gov/GMTC j | Ill\
copy
GMT
Fwd | S | Rtn | Fwd | Ku | Rtn
A | 19:28 | A | 19:28
I I : 27 | 10:09
EST
Diagnostic Sensors | x
state | 2022-01-25 | GMT
PMTs | System Temperatures
5.000 | CPU | 33.500
power
Set All Gains
W/cm2 | CPU Board | 35.000
PMT 1 | 0.000 | -0.000 | Gain | 0.000
Cube Sensor 1 | 35.469
PMT 2 | 0.000 | -0.000 | Gain | 0.000 | 35.433
Cube Sensor 2
PMT 3 | 0.000 | -0.000 | Gain | 0.000 | 26
Hard Drive
Radiometers
W/cm12
-0.003300 | 0.000 | TC200A (TCI) | 27.274918 | o. 141
-60 mm
-0.003077 | -0.000 | TC200B (TC2) | 23.437439 | -0.014
-30 mm
-0.004178 | -0.085 | 23.799147 | 0.876
center
+30 | -0.002151 | 0.088 | Array
mm
Rake: Far
+60 mm | -0.003152 | 0.083
48.130499 | 0.993 | mV
60 Deg Offset | 0.000554 | 1.591
invalid-low | 0.014
invalid-low | 0.007
Radiorneter Cold Junctions
48.712741 | 1.017
-60 mm CJ | 154.049483 | -0.000
-30 mm CJ | 154.049483 | -0.000
Bumer: Spherical (1/4)
Center CJ | 196.654495 | -0.548
Burner | 353.621364 | 13.494 | mV
+30 | 76.277541 | 0.964
+60 | 80.406550 | 0.914
60 Deg Offset | 25.933212 | 1.563 | Cube Connecton
CJ
53
~~~~

### Pagina 54

Cita: [pdf_48ae978e0f4bf72aa77e, p. 54]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_48ae978e0f4bf72aa77e/p0054.jpg)

~~~~text
54
Test 22024M2, continued
After test: 513 on lowest valve safety timer, 18 psia in oxidizer bottle, 86 psia in 
fuel bottle

[Texto OCR de la imagen]
Test 22024M2, continued
o | x
So ftv•are Mnernonic | Low
0.00
0.00
ACME DIAG PMT T3 | 0.00
err'S | End Plotting
ctions
)erties
1:23:30 | 1:23:45
Ian 2022 | 25Tue Jan 2022
o | x
Software Mnemonic | Low
ACtvE DIAG RAD D60 | 0.00
D30 | 0.00
ACME DIAG RAD DCENTER | 0.00
0.00
ACME DIAG RAD DMIWS60 | 0.00
ACME DIAG RAD DOFFSET | 0.00
2.5
:erns | End Plottng
n:tions | Restart
perries
1:23:00 | 1:23:15 | 1:23:30 | 1:23:45
Jan 2022 | 25 Tue Jan 2022
After test: 513 on lowest valve safety timer, 18 psia in oxidizer bottle, 86 psia in
fuel bottle
54
~~~~

### Pagina 55

Cita: [pdf_48ae978e0f4bf72aa77e, p. 55]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
55
Test 22024K2 (test 19 of 20, flame 19 of 20) – sustained ignition, run with 
dataCameraManualGain=24, useBracketedExposures=FALSE, pmt1Gain=4, 
fiberIgnitionPosition=0, fiberTestPosition=0, oxidizerFlowIgnitionDeltaMs=500,
nitrogenFlowIgnitionDeltaMs=0, stabilizationTime1Sec=0, 
stabilizationTime2Sec=0, oxidizerIgnitionFlowSlpm=0.3, 
nitrogenIgnitionFlowSlpm=0.244, oxidizerTestFlow1Slpm=0.3, 
nitrogenTestFlow1Slpm=0.244, oxidizerTestFlow2Slpm=0, 
oxidizerTestFlow3Slpm=0, constantFlowTime1Sec=60, 
constantFlowTime2Sec=constantFlowTime3Sec=0
ignitionToTestRampTimeSec=testFlowRamp1To2TimeSec=0, 
testFlowRamp2To3TimeSec=0, burnerTemperatureLimitC=450
dataCamera Zoom=30000, dataCamera Focus=13750
use 
HiB
MS 
Cam
era?
=NO, 
HiB
MS 
Illum
inati
on 
Level 
(back
light)
=0
~~~~

### Pagina 56

Cita: [pdf_48ae978e0f4bf72aa77e, p. 56]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_48ae978e0f4bf72aa77e/p0056.jpg)

~~~~text
Test 220241<2, continued
o GMTClock
e | https://sams.grc.nasa.gov/GMTC | Ill\
COPY
GMT
Fwd | S | Rtn | Fwd | Ku | Rtn
A | 39:46 | A | 39•.46
00:20 | 00:20
EST
Diagnostic Sensors
state | 2022-01-25 | Gtv1T
PMTs | System Temperatres
5.000 | Set | 33.500
Power
Set All Gains
W/cm2 | cpu Board | 35.000
0.000 | 0.000 | 0.000 | Set
PMT 1 | Gain | 35.488
Cube Sensor 1
PMT 2 | 0.000 | -0.001 | Gain | 0.000 | Set | 35.469
Cube Sensor 2
PMT 3 | 0.000 | -0.000 | Gain | 0.000 | Set | 26
Hard Drive
Radiometers
W/crn2
-0.003300 | -0.000 | TC200A (TCI) | 26.935851 | o. 141 | mV
-60 mm
-0.003077 | -0.000 | TC200B (TC2) | 22.973117 | -0.019 | mV
-30 mm
-0.004265 | -o. 115 | TCCJ | 23.460169 | 0.875
center
+30 | -0.002255 | 0.030 | Array
mm
Rake: Far
+60 mm | -0.003281 | 0.034
46.194766 | 0.927 | mV
60 Deg Offset | 0.000250 | 1.422
invalid-low | 0.012 | mV
invalid-low | -0.003 | mV
Radometer Cold Junctions
44.638632 | 0.863 | mV
-60 mm CJ | 154.049483 | -0.000
-30 mm CJ | 154.049483 | -0.000
Spherical ,/1/4)
Center CJ | 196.347432 | 544
Burner | 230.157102 | 8.412 | mV
+30 | 128.009387 | 0.328
124. | 0.372
60 Deg Offset | 25.847755 | 1.564 | Cube Connection
CJ
56
~~~~

### Pagina 57

Cita: [pdf_48ae978e0f4bf72aa77e, p. 57]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_48ae978e0f4bf72aa77e/p0057.jpg)

~~~~text
57
Test 22024K2, continued
After test: 430 on lowest valve safety timer, 14 psia in oxidizer bottle, 86 psia in 
fuel bottle

[Texto OCR de la imagen]
Test 220241<2, continued
hart
9 ftv•are Mnemonic | I Low
ACME DIAG PMT Tl | 0.00
0.00
0.00
0.5
End Plottng
tions | Restart
erti±f
2:01:
2022 | ooo | 25 Tue Jan 2022 | Time
Soft.vare Mnemonic
ACtG DIAG RAD D60 | 0.00
0.00
ACME DIAG RAD DCENTER | 0.00
ACYE DIAG RAD DMIN-lS30 | 0.00
0.00
ACNE DIAG RAD DOFFSET | 0.00
2-5
End Plotting
tians | Restart
2:01:
Jan 2022 | 25Tue Jan 2022 | Time
After test: 430 on lowest valve safety timer, 14 psia in oxidizer bottle, 86 psia in
fuel bottle
57
~~~~

### Pagina 58

Cita: [pdf_48ae978e0f4bf72aa77e, p. 58]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
58
Test 22024K3 (test 20 of 20, flame 20 of 20) – sustained ignition, run with 
dataCameraTestExposureUs=100000, dataCameraManualGain=24, 
useBracketedExposures=FALSE, pmt1Gain=5, fiberIgnitionPosition=0, 
fiberTestPosition=0, flowTimeoutSec=400, oxidizerFlowIgnitionDeltaMs=500, 
nitrogenFlowIgnitionDeltaMs=0, stabilizationTime1Sec=0, 
stabilizationTime2Sec=0, oxidizerIgnitionFlowSlpm=0.4, 
nitrogenIgnitionFlowSlpm=0.2, oxidizerTestFlow1Slpm=0.4, 
nitrogenTestFlow1Slpm=0.2, oxidizerTestFlow2Slpm=0, 
oxidizerTestFlow3Slpm=0, constantFlowTime1Sec=360, 
constantFlowTime2Sec=constantFlowTime3Sec=0
ignitionToTestRampTimeSec=testFlowRamp1To2TimeSec=0, 
testFlowRamp2To3TimeSec=0, burnerTemperatureLimitC=450
dataCamera Zoom=30000, dataCamera Focus=13750
use 
HiB
MS 
Ca
mer
a?=
NO, 
HiB
MS 
Illu
min
atio
n 
Lev
el 
(bac
klig
ht)=
0
~~~~

### Pagina 59

Cita: [pdf_48ae978e0f4bf72aa77e, p. 59]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_48ae978e0f4bf72aa77e/p0059.jpg)

~~~~text
Test 220241<3, continued
O GMTClock
e | https://sams.grc.nasa.gov/GMTC | 90% | lil\
copr
GMT
Fwd | S | Rtn | Fwd | Ku | Rtn
A | 18:39 | A | 18:39
00:20 | 00:20
EST
Diagnostic Sensors | x
state | 2022-01-25 | GMT
pMTs | System Temperatures
5.000 | cpu | 33.500
Power
Set Al Gains
W/crn2 | cpu Board | 36.000
0.000 | -0.000 | 0.000 | Set
PMT 1 | Gain | 35.581
Cube Sensor 1
0.000 | -0.001 | Gain | 0.000 | Set | 35.612
Cube Sensor 2
PMT 3 | 0.000 | 0.000 | Gain | 0.000 | Set | 26
Hard Drive
W/cm 2 | Volts
-0.003300 | -0.000 | TC200A (TCI) | 26.755801 | 0.120 | mV
-60 mm
-0.003077 | TC200B (TC2) | 23.263814 | -0.021
-30 mm
-0.004268 | -0.116 | 23.799147 | 0.876
center
+30 | -0.002250 | 0.033 | Array
mm
Rake: Far
+60 mm | -0.003283 | 0.033
42.440164 | 0.759 | mV
60 Deg Ofret | 0.000261 | 1.428
invalid-low | 0.008 | mV
invalid-low | -0.011 | mV
Radiometer Cold Junctions
Volts
42.147651 | 0.747
-60 mm CJ | 154.049483 | -0.000
-30 | CJ | 154.049483 | -0.000
Burner: Spheric-a/ (1/4)
Center CJ | 198.112297 | -0.567
Burner | 354.074458 | 13.513 | mV
+30 | 125.446304 | 0.360
+60 | 124.724702 | 0.369
60 Deg 0%et | 26.018654 | 1.562 | Cube Connection
CJ
59
~~~~

### Pagina 60

Cita: [pdf_48ae978e0f4bf72aa77e, p. 60]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_48ae978e0f4bf72aa77e/p0060.jpg)

~~~~text
60
Test 22024K3, continued
After test: 284 on lowest valve safety timer, 9 psia in oxidizer bottle, 86 psia in 
fuel bottle

[Texto OCR de la imagen]
Test 220241<3, continued
Soft"Nare Vhemonic | Low
ACME DIAG | Tl | 0.00
0.00
0.00
End Plotting
:tions
erties
an 2022 | 25 Tue Jan 2022 | Time
Chart
Softvare Mnernonic | Low
0.00
ACME | 0.00
ACME DIAG RAD DCENTER | 0.00
0.00
ACME DIAG RAD DMINUS60 | 0.00
0.00
41.5
ems | End Plottng
ctions | Restart
'erties
an 2022 | 25 Tue Jan 2022 | Time
After test: 284 on lowest valve safety timer, 9 psia in oxidizer bottle, 86 psia in
fuel bottle
60
~~~~

### Pagina 61

Cita: [pdf_48ae978e0f4bf72aa77e, p. 61]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_48ae978e0f4bf72aa77e/p0061.jpg)

~~~~text
Test 22024RAD2
O GMTClock | x
est
e | https://sams.grc.nasa.gov/GMTC | 90% | Ill \
22024
RAD2,
COPY
GMT
contin
ued
Fwd | S | Rtn | Fwd | Ku | Rtn
A | 14:51 | A | 14:51
00:20 | 00:20
EST 024/
Diagnostic Sensors | x
System state | 2022-01-25 02:26:24 | GNIT
PMTS | System Temperatures
5.000 | Set | 33.500
Power
Set Al Gains
W/crn2 | CA-I Board | 36.000
PMT 1 | 3.000 | 0.000 | Gain | 7.000
Cube Sensor 1 | 35.626
2.000 | -0.001 | Gain | 35.612
Cube Sensor 2
911.000 | -0.000 | Gain | 5.000 | 26
Hard Drive
Radometers
W Ian 2
-0.003300 | -0.000 | TC200A (TCI) | 25.147415 | 0.055 | mV
-60 mm
-0.003077 | -0.000 | TC200B (TC2) | 23.114972 | -0.027 | mV
-30 mm
-0.004352 | -0.145 | 23.799147 | 0.876
Center
+30 | -0.002348 | -0.022 | Array
Rake: Far
+60 mm | -0.003417 | -0.018
29.768081 | 0.242 | mV
60 Deg Offset | -0.000065 | 1.247
nvalid40w | -0.003 | mV
nvalid40w | -O .013 | mV
Radiometer Cold Junctions
25.865300 | 0.084 | mV
-60 mm CJ | 154.049483 | -0.000
-30 mm CJ | 154.049483 | -0.000
Burner: Spherical (1/4)
center | 196.884760 | -0.551
Burner | 78.972305 | 2.273 | mV
+30 CJ | 173.855548 | -0.253
169.648104 | -0.199
60 Deg Offset | 26.018654 | 1.562 | Cube Comection
CJ
61
~~~~

### Pagina 62

Cita: [pdf_48ae978e0f4bf72aa77e, p. 62]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_48ae978e0f4bf72aa77e/p0062.jpg)

~~~~text
Chart | x
So ft'.vare Mnernonic
0.00
0.00
ACME DIAG PMT T3 | 0.00
End Plotting
ctions | Restart
3erties
2022 | 25Tue Jan 2022 | Tüne
Software tvhernonic | I Low
0.00
ACtæ DIAG RAD 030 | 0.00
ACME DIAG RAD DCENTER | 0.00
0.00
ACME DIAG RAD DMINUS60 | 0.00
ACME DIAG RAD DOFFSET | 0.00
0.8
:ems | End Plottng
Restart
parties
Jan 2022 | 25 Tue Jan 2022 | Time
62
~~~~
