# 21153 flow traces etc

- Identificador: pdf_beb8028ea2244fd6f2e1
- Investigaciones: PSI-159
- Tipo de documento: Raw Data
- Estado: processed
- Temas detectados automaticamente: hardware, oxygen, pressure, ignition, cool_flames, extinction

## Fuentes

- [PSI-159_Raw Data_21153 flow traces etc.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-159/Raw%20Data/PSI-159_Raw%20Data_21153%20flow%20traces%20etc.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_beb8028ea2244fd6f2e1, p. 1]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_beb8028ea2244fd6f2e1/p0001.jpg)

~~~~text
CFI-G Round 1, day 8, with 30% ethane (C2H6)
Chamber filled to 0.5 atm with ~40% O2 (balance N2)
Extinction detection effectively turned off so tests were ended ‘manually’
Test 21153A1 (test 1 of 14, hot flame 1 of 14) – sustained ignition, run as 
planned 
1

[Texto OCR de la imagen]
CFI-G Round 1, day 8, with 30% ethane (C2H6)
Chamber filled to 0.5 atm with '"40% 02 (balance N2)
Extinction detection effectively turned off so tests were ended 'manually'
Test 21153A1 (test 1 of 14, hot flame 1 of 14) — sustained ignition, run as
planned
Gas Flow Charts
Graphs
2021-06-02 | GMT
State | Operate | SLPM | 0.005 | SLPM | FUlsca1e | 20.000
Static Mixer Line (MFCAI)
0.010
11
15:58 | 15:59 | 16:00 | 16:01 | 16:02
2 wed Jun 2021 | Tüne (s)
State | Operate | c | 0.000 | SLPM | R | -0.002 | QPM | scale | 2.000 | SLPM
Bypass(MFCA2)
ACME FLOW | BYPASS SETPOINT | ACME FLOW | BYPASS FLOW
I.oe-3
ose-3
-ose-3
-1.0e-3
-1.5e-3
-2.Oe-3
-2.5e-3
-3.0e-3
15:58 | 15:59 | 16:00 | 16:01 | 16:02
2 wed Jun 2021 | Tune (s)
State | Operate | c | 0.000 | SLPM | R | 0.001 | scale | 0.500 | SLPM
Fuel(MFCA3)
ACME FLOW "3 FUEL SETPOINT | ACME FLOW | FUEL FLOW
0.3
v. 0.2
15:58 | 15:59 | 16:00 | 16:01 | 16:02
2 wed Jun 2021 | Tirne (s)
1
~~~~

### Pagina 2

Cita: [pdf_beb8028ea2244fd6f2e1, p. 2]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_beb8028ea2244fd6f2e1/p0002.jpg)

~~~~text
Test 21153A1, continued
- VLC media player | Diagnostic Cool Flame Sensors | o | x
EXPERIMENT | 2021-06-02 | GMT
System Ternperaües
5.000 | Set | 32.600
Power
Set AJI
W/crn2 | v | 34.00)
-58.000 | -0.000 | 5,500 | set
PMT 1 | 34.030
Sensor 1
PMT 2 | 71.000 | -0.000 | 6.000 | set | 34.006
CLbe Sensor 2
PMT 3 | 0.000 | -0.000 | 5.500 | Set | 25
Hard Drive
Radmeters
W/cm 2
-0.002791 | -0.109 | TC200A act) | 29.919817 | 0.303
-IO mm Lo Gain
-0.000922 | -0.555 | TC2008 (TC2) | 22026696 | -0.016
-10 mm Gan
4).000303 | 0.045 | 22443212 | 0.872
+30 mm Lo
+30 | H Gah | 0.000424 | 0.488
mm
Rake: Far
+60 mm Lo | -0.000093 | 0.069
75.756486 | 2, 194
+60 mm H Gah | 0.000898 | 0.765
hvaüd-bw | 0.100
60 Deg Chet | 0.000541 | 1.584
invaid-bw | 0.042
77.918794 | 2.284
Radiometer Cdd Juncticn
Volts
60 Deg 0%et | 24.394320 | 1.581
Burner: Sphe•ea/ (1/4'
Burner | 182.755020 | 6.553
CL.& Connection
Time Senes Chat
Packet | So ftvvare Whernonic
ACME Telerne | 0.00
ACME Teleme ACME DIAG | T2 | 0.00
ACME Teleme ACME DIAG PW T3 | 0.00
2-5
Select Items | End Plotüng
Clear Selections | Restart
Graph Properties
16:01:00
202116:01A0.ooo | 2 Wed Jun 2021 | Tine
StartTme
2
~~~~

### Pagina 3

Cita: [pdf_beb8028ea2244fd6f2e1, p. 3]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Test 21153A1, continued
After test: 907 on lowest valve safety timer, 1533 psia in oxidizer bottle, 204 
psia in fuel bottle
3
~~~~

### Pagina 4

Cita: [pdf_beb8028ea2244fd6f2e1, p. 4]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_beb8028ea2244fd6f2e1/p0004.jpg)

~~~~text
Test 21153A2 (test 2 of 14, hot flame 2 of 14) – sustained ignition, run with 
flowTimeoutSec=300, fuelFlowIgnitionDeltaMs=0, fuelIgnitionFlowSlpm=0.317,
fuelTestFlow1Slpm=0.317, constantFlowTime1Sec=270
4

[Texto OCR de la imagen]
Test 21153A2 (test 2 of 14, hot flame 2 of 14) — sustained ignition, run with
flowTimeoutSec=300, fuelFlowIgnitionDeItaMs=O, fuellgnitionFIowSIpm=O.317,
fuelTestFlow1Slpm=O.317, constantFlowTime1Sec=270
Gas Flow Charts
Graphs
2021-06-02 16:17:35
State | Operate | c | 0.000 | R | 0.006 | SLPM | Fl-ASca1e | 20.000 | SLPM
Static Mixer Line (MFCAI)
ACME FLOW MI MIXER SETPOINT | ACME FLOW MI MIXER FLOW
0.010
III
16: 13 | 16:14 | 16:15 | 16:16 | 16:17
2 Wed Jun 2021 | Time (s)
State | Operate | C | 0.000 | SLPM | R | -0.002 | SLPM | scale | 2.000
Bypass(MFCA2)
YPASS_SETPOINT
-OSe-3
-I.Oe-3
1.5e-3
-2.0e-3
-2.5e-3
-3.0e-3
16:13 | 16: 14 | 16:15 | 16:16 | 16:17
2 wed Jun 2021 | Time (s)
State | Operate | C | 0.000 | SLPM | R | 0.000 | SLPM | scale | 0.500 | SLPM
Fuel(MFCA3)
16:13 | 16:14 | 16:15 | 16:16 | 16:17
2 Wed Jun 2021 | Time (s)
4
~~~~

### Pagina 5

Cita: [pdf_beb8028ea2244fd6f2e1, p. 5]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_beb8028ea2244fd6f2e1/p0005.jpg)

~~~~text
Test 21153A2, continued
- VLC media player | Diagnostic Cool Flame Sensors | x
Systen State | 2021-06-02 16: 16:53
System Temperatures
5.000 | set | 32.500
Power
set All
W /crn2 | Board | 34000
-58.000 | 001 | Gan | 5.500
Cabe Sensor 1 | 3413)
PMT 2 | 71.000 | -0.000 | Gan | 6.000 | 34.1+
Sensor 2
0.000 | -0.001 | Gan | 5.500 | 25
Drive
Radometers
W /crn2 | Volts
-0.002774 | -0.108 | TC200A (TCI) | 26.957413 | o, 183
-10 | Lo Gan
-0.000922 | -0.555 | TC20æ (TC2) | 22051529 | -0.015 | mV
-IO mrn H Gan
-0.000287 | 22443212 | 0.872
+30 rrrn Lo Gah
+30 | H Gain | 0.000442 | 0.502 | Array
rrrn
Rake: Far
+60 rm' LO Gah | -0.000161 | 0.065
70, 134073 | 1,960
+60 mm Hi Gan | 0.000833 | 0.722
in v aid-low | 0.057
60 Deg 0%et | 0.000505 | 1.564
invalid-bw | 0.022
72.128595 | 2043
Radometer Cold Junction
vets
60 Deg Offset | 24.565383 | 1.579
Butner: | (1/4)
238.395854 | 8.786
Cube Comecbon
Time Series Chart —1
Packet | Softvvare Mrern«ic
ACME | ACME DIAG +1T_T1 | 0.00
ACME Teleme ACME | 0.00
ACME | 0.00
2.5
Select Items | End Plotting
Clear Selections
Graph properties
02 Jun 2021 16: 16253.000 | 2 wed Jun 2021
start
5
~~~~

### Pagina 6

Cita: [pdf_beb8028ea2244fd6f2e1, p. 6]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Test 21153A2, continued
After test: 786 on lowest valve safety timer, 1540 psia in oxidizer bottle, 197 
psia in fuel bottle
6
~~~~

### Pagina 7

Cita: [pdf_beb8028ea2244fd6f2e1, p. 7]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_beb8028ea2244fd6f2e1/p0007.jpg)

~~~~text
Test 21153A3 (test 3 of 14, hot flame 3 of 14) – sustained ignition, run with 
flowTimeoutSec=300, fuelFlowIgnitionDeltaMs=0, fuelIgnitionFlowSlpm=0.211,
fuelTestFlow1Slpm=0.211, constantFlowTime1Sec=270
7

[Texto OCR de la imagen]
Test 21153A3 (test 3 of 14, hot flame 3 of 14) — sustained ignition, run with
flowTimeoutSec=300, fuelFlowIgnitionDeItaMs=O, fuellgnitionFlowSlpm=O.211,
fuelTestFlow1Slpm=O.211, constantFlowTime1Sec=270
Gas Flow Charts | o | x
Graphs
2021-06-02 16:45:22 | GMT
State | Operate | c | 0.000 | SLPM | R | 0.006 | SLPM | Fun Scale | 20.000 | SLPM
Static Mixer Line (MFCAI)
0.010
16:41 | 16:42 | 16:43 | 16:44 | 16:45
2 Wed Jun 2021 | Time (s)
State | q•erate | c | 0.000 | R | -0.001 | scale | 2.000
Bypass(MFCA2)
ACME FLOW | BYPASS SETPOINT | ACME FLOW "2 BYPASS FLOW
I.oe-3
ose-3
-ose-3
-I.Oe-3
-1.5e-3
-2.0+3
-2.5e-3
-3.0e-3
16:41 | 16:42 | 16:43 | 16:44 | 16:45
2 wed Jun 2021 | Time (s)
State | Operate | c | 0.000 | SLPM | R | 0.000 | SLPB•I | scale | 0.500 | SLPM
Fuel(MFCA3)
ACME FLOW "3 FUEL SETPOINT | ACME FLOW "3 FUEL FLOW
0.10
16:41 | 16:42 | 16:43 | 1644 | 16:45
2 wed Jun 2021 | Tine (s)
7
~~~~

### Pagina 8

Cita: [pdf_beb8028ea2244fd6f2e1, p. 8]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_beb8028ea2244fd6f2e1/p0008.jpg)

~~~~text
Test 21153A3, continued
- VuC media player | Diagnostic Cool Flame Sensors
PMTS | System
5.000 | 32.700
power
Set Al Gahs
W /crn2 | v | CPU Board | 34.000
0.000 | -0.001 | 0.000 | Set
1 | 34.464
PMT 2 | omo | -0.000 | 0.000 | set
be Senscr 2
PMT 3 | 0.000 | -0.000 | Gan | 0.000 | Set | 25
Drive
W/crn2
-0.003179 | -o. 131 | TC200A (TCI) | 26.455591 | 0.149
-10 mm Lo Gah
-0.000913 | -0.549 | TC200B | 22218029 | -0.022
-10 run H Gah | (TQ)
-0.000937 | 0.005 | 22.782211 | 0.373
+30 mm Lo Gah
+30 | Gan | -0.000139 | 0.053 | Array
Rake: Far
+60 mm Lo Gah | -0.000896 | 0.022
58.092501
+60 mm Gü | 0.000109 | 0.245
maid-low | 0.026
60 | Offset | 0.000268 | 1.432
ünvü40w | 0.007
57.223968 | 1.410
Cold Jtnction
60 Deg 0%et | 24.992962 | 1.574
Burner | (1/4'
Burner | 245.543893 | 9.062 | mV
CLbe Comecåon
Time Series Chart
Packet | Software phemonic | Low
ACME Teleme ACME DIAG | Tl | 0.00
ACME Teleme ACME DIAG | T2 | 0.00
ACME Teleme ACME DIAG | T3 | 0.00
2-5
Select Items | End Plotting
Clear Selections
Graph Properties
16:44:15
02 Jun 2021 | awed Jun 2021 | Time
start
8
~~~~

### Pagina 9

Cita: [pdf_beb8028ea2244fd6f2e1, p. 9]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Test 21153A3, continued
After test: 500 on lowest valve safety timer, 1544 psia in oxidizer bottle, 185 
psia in fuel bottle
9
~~~~

### Pagina 10

Cita: [pdf_beb8028ea2244fd6f2e1, p. 10]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_beb8028ea2244fd6f2e1/p0010.jpg)

~~~~text
Test 21153F1 (test 4 of 14, hot flame 4 of 14) – sustained ignition, run with 
dataCameraManualGain=0, useBracketedExposures=TRUE, 
bracketingExposureStartUsec=50000, 
bracketingExposureMultiplierTimes100=200, fiberIgnitionPosition=10000,
fiberTestPosition=17000, flowTimeoutSec=300, fuelFlowIgnitionDeltaMs=0,
fuelIgnitionFlowSlpm=fuelTestFlow1Slpm=0.317, constantFlowTime1Sec=270
dataCamera Zoom=45000, dataCamera Focus=10025
10

[Texto OCR de la imagen]
Test 21153F1 (test 4 of 14, hot flame 4 of 14) — sustained ignition, run with
dataCameraManuaIGain=O, useBracketedExposures=TRUE,
bracketingExposureStartUsec=50000,
bracketingExposureMuItipIierTimes100=200, fiberIgnitionPosition=10000,
fiberTestPosition=17000, flowTimeoutSec=300, fuelFIowIgnitionDeItaMs=O,
fuellgnitionFIowSlpm=fueITestFIow1SIpm=O.317, constantFlowTime1Sec=270
dataCamera Zoom=45000, dataCamera Focus=10025
Gas Flow Charts
Graphs
2021-06-02 | GMT
State | Operate | c | 0.000 | SLPM | -0.005 | SLPM | FLASca1e | 20.000
Static Mixer Line (MFCAI)
0.010
17:04 | 17:05 | 17:06 | 17:07 | 17:08
2 Wed Jun 2021 | Time (s)
State | Operate | c | 0.000 | SLPM | R | -0.002 | SLPM | scale | 2.000 | SLPM
Bypass(MFCA2)
ACME FLOW | BYPASS SETPOINT | ACME FLOW | BYPASS FLOW
le-3
-le-3
-Ze-3
-3e-3
-4e-3
17:04 | 17:05 | 17:06 | 17:07 | 17:08
awed Jun 2021 | Tirne (s)
State | Operate | c | 0.000 | SLPM | R | 0.002 | scale | 0.500
Fuel(MFCA3)
0.15
0.10
17:04 | 17:05 | 17:06 | 17:07 | 17:08
2 Wed Jun 2021 | Time (s)
10
~~~~

### Pagina 11

Cita: [pdf_beb8028ea2244fd6f2e1, p. 11]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_beb8028ea2244fd6f2e1/p0011.jpg)

~~~~text
Test 21153F1, continued
- VLC media player | Diagnostic Cool Flame Sensors
system state | 2021-06-02 | GMT
PMTs | Systan Tem—atures
5.000 | Set | cpu | 32.700
power
Set Al CÄns
W/an2 | cpu Board | 35,000
-58.000 | -0.000 | 5.500 | Set
Cube Sensor 1 | 34.492
PMT 2 | 71.000 | 0.001 | 6.000 | Set | 34.498
Cube Sensor 2
PMT 3 | 0.000 | -0.000 | 5,500 | set | 25
Hard Drive
Wlan
-o. 002968 | -o, 119 | TC200A (TCI) | 25.911331 | o. 177
-10 mm LO Gain
-0.000908 | TC200B | 22.118710 | -0.026
-10 mm Gdn
-o. 000683 | 0.021 | 22.782211 | 0.873
+30 n-rn Lo
H Gan | 0.000079 | 0.222
mm
Rake: Far
+60 rm•n Lo Gan | -0.000640 | 0.037
56.910241 | 1.397
0.000361 | 0.411
invalid-low | 0.031
60 Deg Offet | 0.000246 | 1.420
invalid-low | 0.007
53.600879 | 1.260
Radorneter Cold Junction
60 Deg Offset | 24.821947 | 1.576
Burner | 191.730751 | 6.898
Cube Connecåon
Tme Series Chart
Packet | Soft'*8e MnemoNc | Low
ACME | 0.00
ACME Teleme | 0.00
ACME Teleme | 0.00
Select Items | End Plotting
Clear Selections
Graph Properties
02 Jun 2021 | 2Wed Jun 2021 | Time
StartTme
11
~~~~

### Pagina 12

Cita: [pdf_beb8028ea2244fd6f2e1, p. 12]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Test 21153F1, continued
After test: 428 on lowest valve safety timer, 1546 psia in oxidizer bottle, 182 
psia in fuel bottle
12
~~~~

### Pagina 13

Cita: [pdf_beb8028ea2244fd6f2e1, p. 13]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_beb8028ea2244fd6f2e1/p0013.jpg)

~~~~text
Test 21153A4 (test 5 of 14, hot flame 5 of 14) – sustained ignition, run with 
dataCameraManualGain=33, useBracketedExposures=FALSE, 
bracketingExposureStartUsec=5000, 
bracketingExposureMultiplierTimes100=1000, fiberIgnitionPosition=0,
fiberTestPosition=0, flowTimeoutSec=300, fuelFlowIgnitionDeltaMs=0,
fuelIgnitionFlowSlpm=fuelTestFlow1Slpm=0.106, constantFlowTime1Sec=270
dataCamera Zoom=25000, dataCamera Focus=14600
13

[Texto OCR de la imagen]
Test 21153A4 (test 5 of 14, hot flame 5 of 14) — sustained ignition, run with
dataCameraManuaIGain=33, useBracketedExposures=FALSE,
bracketingExposureStartUsec=5000,
bracketingExposureMuItipIierTimes100=1000, fiberIgnitionPosition=O,
fiberTestPosition=O, flowTimeoutSec=300, fuelFIowIgnitionDeltaMs=O,
fuellgnitionFIowSIpm=fuelTestFIow1SIpm=O.106, constantFlowTime1Sec=270
dataCamera Zoom=25000, dataCamera Focus-14600
Gas Flow Charts
Graphs
2021-06-02 | GMT
Sbte | Operate | c | 0.000 | SLPM | R | 0.000 | SLPM | FUlsca1e | 20.000 | s.LPM
Static Mixer Line (MFCAI)
ACME FLOW MI MIXER SETPOINT | ACME FLOW MI MIXER FLOW
0.010
17:40 | 17:41 | 17:42 | 17:43 | 17:44
2 Wed Jun 2021 | Time (s)
State | Operate | c | 0.000 | R | -0.000 | SLPB•I | scale | 2.000
Bypass(MFCA2)
I.Oe-3
ose-3
-Ise-3
-2.oe-3
-2.5e-3
-3.0e-3
17:40 | 17:41 | 17:42 | 17:43 | 17:44
2 Wed Jun 2021 | Time (s)
State | Operate | c | 0.000 | R | 0.001 | scale | 0.500
Fuel(MFCA3)
ACME FLOW 1-13 FUEL SETPOINT | ACME FLOW "3 FUEL FLOW
0.14
0.12
0.10
0.08
0.06
17:40 | 17:41 | 17:42 | 17:43 | 17:44
2 Wed Jun 2021 | Time (s)
13
~~~~

### Pagina 14

Cita: [pdf_beb8028ea2244fd6f2e1, p. 14]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_beb8028ea2244fd6f2e1/p0014.jpg)

~~~~text
Test 21153A4, continued
VLC media player | Diagnostic Cool Flame Sensors | x
state | 2021-06-02 | aqT
PMTS | System Tenperanres
5.000 | 32.700
Power
Set Al Gans
Wlan2 | cpu Board | 35.000
0.000 | -0.001 | Gan | 0.000
Clie Sensor 1 | 34.467
0.000 | -0.000 | 0.000 | 34.477
CLbe Sensor 2
0.000 | -0.001 | Gain | 0.000 | 25
Hard Drive
w,'crnz | Volts
-0.002862 | -0.113 | TC200A crcl) | 24.499925 | 0.070 | mV
-IO | Lo Gan
-0.000906 | —O. 544 | TC20æ CTC2) | 22069047 | -0.028 | mV
-10 ryn H Gan
-0.000335 | 0.043 | TCCJ | 22.782211 | 0.873 | v
+30
+30 mm H Gah | 0.000399 | 0.469 | Array
Rake:
+60 mm Lo Gail | -0.000554 | 0.042
41.949194 | 0.780
+60 mm Hi Gain | 0.000435 | 0.460
nvaid40w | 0.014 | mV
60 Deg Offret | 0.000311 | 1.456
maid-low | -0.003 | mV
42485500 | 0.802 | mV
Radorneter Cold Junction
Volts
60 Deg Offet | 24.650913 | 1.578
CJ | Burner: Sphere-a/ (1/4)
401.504671 | 15.59 | mV
übe Cmnection
Tame Series Chan
Packet | Soft-nare Nhemonic | Low
ACME Teleme | 0.00
AC'G Teleme | 0.00
ACME Teleme ACME DIAG | T3 | 0.00
> 1.0
Select Items | End Plottng
Clear Selections | Restart
Graph Properties
17:42:45 | 17:43:00 | 17:43:15 | 17:43:30
02 | 2 Wed Jun 2021 | Tune
Start Tirre
14
~~~~

### Pagina 15

Cita: [pdf_beb8028ea2244fd6f2e1, p. 15]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Test 21153A4, continued
After test: 356 on lowest valve safety timer, 1547 psia in oxidizer bottle, 181 
psia in fuel bottle
15
~~~~

### Pagina 16

Cita: [pdf_beb8028ea2244fd6f2e1, p. 16]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_beb8028ea2244fd6f2e1/p0016.jpg)

~~~~text
Test 21153A5 (test 6 of 14, hot flame 6 of 14) – sustained ignition, run with 
dataCameraManualGain=33, useBracketedExposures=FALSE, 
bracketingExposureStartUsec=5000, 
bracketingExposureMultiplierTimes100=1000, fiberIgnitionPosition=0,
fiberTestPosition=0, flowTimeoutSec=300, fuelFlowIgnitionDeltaMs=0,
fuelIgnitionFlowSlpm=fuelTestFlow1Slpm=0.159, constantFlowTime1Sec=270
dataCamera Zoom=25000, dataCamera Focus=14600
16

[Texto OCR de la imagen]
Test 21153A5 (test 6 of 14, hot flame 6 of 14) — sustained ignition, run with
dataCameraManuaIGain=33, useBracketedExposures=FALSE,
bracketingExposureStartUsec=5000,
bracketingExposureMultiplierTimes100=1000, fiberIgnitionPosition=O,
fiberTestPosition=O, flowTimeoutSec=300, fuelFlowIgnitionDeItaMs=O,
fuellgnitionFIowSIpm=fueITestFIow1Slpm=O.159, constantFlowTime1Sec=270
dataCamera Zoom=25000, dataCamera Focus=14600
Gas Flow Charts | o | x
Graphs
state | 2021-06-02 17:59:09 | GMT
system
State | Operate | C | 0.000 | SLPM | R | -0.003 | SLPM | Fun Scale | 20.000
Static Mixer Line (MFCAI)
ACME FLOW MI MIXER SETPOINT | ACME FLOW MI MIXER FLOW
0.010
17:55 | 17:56 | 17±7 | 17:58 | 17:59
awed Jun 2021 | Time (s)
State | Operate | C | 0.000 | SLPM | R | 0.000 | SLPM | Fl-AScale | 2.000 | SLPM
Bypass(MFCA2)
2.0e-3
1.5e-3
I.Oe-3
OSe-3
-ose-3
-I.Oe-3
17:55 | 17:56 | 17:57 | 17:58 | 17:59
awed Jun 2021 | Tme (s)
State | Operate | C | 0.000 | SLPM | R | -0.000 | SLPM | scale | 0.500
Fuel(MFCA3)
ACME FLOW | FUEL SETPOINT | ACME FLOW | FUEL FLOW
0.16
0.14
0.10
0.08
17:55 | 17:56 | 17:57 | 17:58 | 17:59
2 Wed Jun 2021 | Time (s)
16
~~~~

### Pagina 17

Cita: [pdf_beb8028ea2244fd6f2e1, p. 17]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_beb8028ea2244fd6f2e1/p0017.jpg)

~~~~text
Test 21153A5, continued
• VLC media player | Diagnostic Cool Flame Sensors | x
System state | 2021-06-02 17:58: 18 | GMT
PMTS | System TenperatLres
5.000 | Set | cpu | 32.800
Set Al Gans
W lcm2 | v | Board | 35.000
PMT I | 0.000 | -0.001 | Gain | 0.000
Q.be Sensor 1 | 34620
PMT 2 | 0.000 | -0.000 | 0.000 | 34.613
Cube Sensor 2
PMT 3 | 0.000 | -0.000 | Gain | 0.000 | set | 25
Y-fard Drive
Wlan
-0.002985 | -0.120 | TC200A (TCI) | 26.356655 | 0.145 | mV
-10 mm LO Gan
-0.000908 | TC20G (TC2) | 22366990 | -0.016 | mV
-IO mm Hi Gdn
-0.000557 | 0.029 | 22782211 | 0.873
+30 | LO Gdn
+30 | GSn | 0.000197 | 0.313 | Array
mm
Rake: Far
+60 nm•n Lo | -0.000520 | 0.044
59.587490 | 1.508 | mV
+60 rnrrl H Gah | 0.000472 | 0.484
hvü40w | 0.036
60 Deg Offset | 0.000381 | 1.495
hvü40w | 0.014 | mV
59.322322 | 1.497 | mV
Radiorneter Cold Junction
60 | Offret | 25.078467 | 1.573
CJ | Burner: | (I/"
Burr,er | 313.970292 | 11.378 | mV
Cube Connection
Tame Series Chart
packet | Software Mrenynic | Low
ACME Teleme ACFIE DIAG | Tl | 0.00
Teleme ACME DIAG | T2 | 0.00
ACME | ACME DIAG | T3 | 0.00
Select Items | End plottng
Clear Selections | Restart
Gr aph Properties
02 | 2 wed Jun 2021 | Time
start
17
~~~~

### Pagina 18

Cita: [pdf_beb8028ea2244fd6f2e1, p. 18]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_beb8028ea2244fd6f2e1/p0018.jpg)

~~~~text
Test 21153A5, continued
Radiometers
MINus10 MM LO GAIN | MINUSIO mm HI GAIN | PLUS30 MM LO GAIN
PLUS30 | HI GAIN | PLUS60 MM LO GAIN | PLUS60 MM HI GAIN
4.0
2.0
os
17:54 | 17:55 | 17:56 | 17:57 | 17:58
2 wed Jun 2021 | Time (s)
After test: 66 on lowest valve safety timer, psia in oxidizer bottle, psia in fuel
bottle
18
~~~~

### Pagina 19

Cita: [pdf_beb8028ea2244fd6f2e1, p. 19]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_beb8028ea2244fd6f2e1/p0019.jpg)

~~~~text
Chamber filled to 2 atm with ~40% O2 (balance N2)
Test 21153C1 (test 7 of 14, hot flame 7 of 14) – sustained ignition, run with 
dataCameraManualGain=33, useBracketedExposures=FALSE, 
bracketingExposureStartUsec=5000, 
bracketingExposureMultiplierTimes100=1000, fiberIgnitionPosition=0,
fiberTestPosition=0, flowTimeoutSec=150, fuelFlowIgnitionDeltaMs=2000, 
fuelIgnitionFlowSlpm=fuelTestFlow1Slpm=0.499, constantFlowTime1Sec=120
dataCamera Zoom=25000, dataCamera Focus=14600
19

[Texto OCR de la imagen]
Chamber filled to 2 atm with '"40% 02 (balance N2)
Test 21153C1 (test 7 of 14, hot flame 7 of 14) — sustained ignition, run with
dataCameraManuaIGain=33, useBracketedExposures=FALSE,
bracketingExposureStartUsec=5000,
bracketingExposureMultiplierTimes100=1000, fiberIgnitionPosition=O,
fiberTestPosition=O, flowTimeoutSec=150, fuelFIowIgnitionDeItaMs=2000,
fuellgnitionFlowSlpm=fueITestFIow1Slpm=O.499, constantFlowTime1Sec=120
dataCamera Zoom=25000, dataCamera Focus=14600
Gas Flow Cherts | x
Graphs
state | 2021-06-02 19:50: 17
system
State | Operate | c | 0.000 | SLPM | R | -0.006 | SLPM | Fun Scale | 20.000 | SLPM
Static Mixer Line (MFCAI)
ACME FLOW MI MIXER SETPOINT | ACME FLOW | MIXER FLOW
0.010
0.000
-0.010
-0.015
19:46 | 1947 | 19:48 | 19:49 | 19:50
awed Jun 2021 | Tune (s)
State | Operate | c | 0.000 | SLPM | R | -0.003 | scale | 2.000 | SLPM
Bypass(MFCA2)
ACME FLOW | BYPASS SETPOINT | ACME FLOW | BYPASS FLOW
le-3
-le-3
Ze-3
-3e-3
-5e-3
19:46 | 19:47 | 19:48 | 19:49 | 19:50
awed Jun 2021 | Time (s)
State | Operate | c | 0.000 | SLPt•.1 | R | 0.001 | SLPM | scale | 0.500 | SLPM
Fuel(MFCA3)
0.3
0.1
19:46 | 19:47 | 19:48 | 19:49 | 19:50
2 Wed Jun 2021 | Time (s)
19
~~~~

### Pagina 20

Cita: [pdf_beb8028ea2244fd6f2e1, p. 20]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_beb8028ea2244fd6f2e1/p0020.jpg)

~~~~text
Test 21153C1, continued
- VLC media player | Diagnostic Cool Flame Sensors | x
system state | GMT
System Tenperatures
5.000 | CPU | 32.300
power
Set AI Gans
CPU | 35.000
-58.000 | -0.001 | 5.500 | set
Cube Sensor 1 | 34.320
71. ooo | -0.000 | 6.000 | set | 34.261
Cube Sensor 2
3 | 0.000 | -0.000 | 5.500 | Set | 25
Hard Drive
-0.002738 | -0.106 | TC200A (TCI) | 24.152983 | 0.056
-10 nun Lo Gan
-0.000905 | -0.543 | TC200B | 22218029 | -0.022
-10 rrrn H Gah | CTC2)
-0.000097 | 0.058 | 22782211 | 0.873
+30 mm Lo Gah
+30 | Hi Gan | 0.000617 | 0.637 | Array
m
Rake: Far
+60 mm Lo Gan | 0.000044 | 0.077
37.698750 | 0.606
+60 nn Hi Gan | 0.001024 | 0.848
hvdid-•low | 0.023
60 Deg Offset | 0.000534 | 1.580
invalid -•low | 0.008
37.23363) | 0.587
Radometer Cold 3_Jncåcn
60 Deg Offret | 24.821947 | 1.576
CJ | Burner:
Burner TC | 158.016849 | 5.549
Cl.be Cmnecbon
Time Series Chart
Packet | So ft',vare Mnernonic
ACFETelerne ACME DIAG | Tl | 0.00
Teleme | 0.00
ACME Teleme | 0.00
2-5
Select Items | End Plotting
Clear Selections
Graph Properties
19:49:00
02 | 2021 | awed Jun 2021 | Time
Start Tme
20
~~~~

### Pagina 21

Cita: [pdf_beb8028ea2244fd6f2e1, p. 21]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Test 21153C1, continued
After test: 934 on lowest valve safety timer, 295 psia in oxidizer bottle, 165 psia 
in fuel bottle
21
~~~~

### Pagina 22

Cita: [pdf_beb8028ea2244fd6f2e1, p. 22]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_beb8028ea2244fd6f2e1/p0022.jpg)

~~~~text
Test 21153C2 (test 8 of 14, hot flame 8 of 14) – sustained ignition, run with 
dataCameraManualGain=33, useBracketedExposures=FALSE, 
bracketingExposureStartUsec=5000, 
bracketingExposureMultiplierTimes100=1000, fiberIgnitionPosition=0,
fiberTestPosition=0, flowTimeoutSec=300, fuelFlowIgnitionDeltaMs=0, 
fuelIgnitionFlowSlpm=fuelTestFlow1Slpm=0.317, constantFlowTime1Sec=270
dataCamera Zoom=25000, dataCamera Focus=14600
22

[Texto OCR de la imagen]
Test 21153C2 (test 8 of 14, hot flame 8 of 14) — sustained ignition, run with
dataCameraManuaIGain=33, useBracketedExposures=FALSE,
bracketingExposureStartUsec=5000,
bracketingExposureMultiplierTimes100=1000, fiberIgnitionPosition=O,
fiberTestPosition=O, flowTimeoutSec=300, fuelFIowIgnitionDeItaMs=O,
fuellgnitionFIowSlpm=fueITestFIow1SIpm=O.317, constantFlowTime1Sec=270
dataCamera Zoom=25000, dataCamera Focus=14600
Gas Flow Charts
Graphs
2021-06-02 20: | GMT
State | Operate | c | 0.000 | SLPM | -0.005 | SLPM | FUlSca1e | 20.000
Static Mixer Line (MFCAI)
ACME FLOW MI MIXER SETPOINT | ACME FLOW MI MIXER FLOW
0.010
20:10 | 20:11 | 20:12 | 20:13 | 20:14
2 Wed Jun 2021 | Tüne (s)
State | Operate | c | 0.000 | SLPM | R | -0.002 | SLPM | scale | 2.000 | SLPM
Bypass(MFCA2)
-le-3
-Ze-3
-3e-3
-4e-3
-5e-3
20:11 | 20:12 | 20:13 | 20:14
2 wed Jun 2021 | Time (s)
State | Operate | c | 0.000 | SLPM | R | 0.002 | QPM | Ful scale | 0.500 | SLPM
Fuel(MFCA3)
ACME FLOW "3 FUEL SETPOINT | ACME FLOW "3 FUEL FLOW
0.10
0.00
20:10 | 20:11 | 20:12 | 20:13 | 20:14
2 Wed Jun 2021 | Time (s)
22
~~~~

### Pagina 23

Cita: [pdf_beb8028ea2244fd6f2e1, p. 23]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_beb8028ea2244fd6f2e1/p0023.jpg)

~~~~text
Test 21153C2, continued
- VLC media player | Diagnostic Cool Flame Sensors
EXPERIMENT | 2021-06-02
System Tempera tres
5.000 | set | 33.000
power
set All Gans
W/crn2 | cpu Board | 35.000
PMT 1 | 0.000 | -0.001 | Gain | 0.000
Cube Sensor 1 | 34.250
PMT 2 | 0.000 | -0.000 | 0.000 | 34.264
Cube Sensor 2
PMT 3 | 0.000 | -0.000 | 0.000 | 25
Hard Drive
Radiometers
W/cm2
-0.002844 | 112 | TC200A CCI) | 23.880310 | 0.045
-10 mm Lo
-0.000904 | -0.542 | TC200B ÜC2) | 22.044215 | -0.029
-10 mm
0.036 | 22.782211 | 0.873
+3) rnrn Lo
+30 | H Gail | 0.000304 | 0.395
mm
Rake: Far
+60 rnm Lo | -0.000400 | 0.051
34.414333 | 0.472
+60 Tn H Gail | 0.000596 | 0.566
invdid-low | 0.006
60 Deg Offret | 0.000323 | 1.463
invdid-low | -0.005
TCD | 42.851025 | 0.817
Radicrneter Cdd JunctiN1
60 | Ofret | 24, 736427 | 1.577
Burner: | (1/4)
195.758200 | 7.059
Cube Connection
Time Series Chart
Packet | Software Fherronic | Low
Teleme | 0.00
ACFE Teleme ACME DIAG PMT T2 | 0.00
ACME Teleme ACME DIAG | T3 | 0.00
0.6
Select [terns | End Plotting
Clear Selections
Graph Properties
02 Jun | ooo | 2 Wed Jun 2021 | Time
St&tTme
23
~~~~

### Pagina 24

Cita: [pdf_beb8028ea2244fd6f2e1, p. 24]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Test 21153C2, continued
After test: 854 on lowest valve safety timer, 294 psia in oxidizer bottle, 162 psia 
in fuel bottle
24
~~~~

### Pagina 25

Cita: [pdf_beb8028ea2244fd6f2e1, p. 25]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_beb8028ea2244fd6f2e1/p0025.jpg)

~~~~text
Test 21153C3 (test 9 of 14, hot flame 9 of 14) – sustained ignition, run with 
dataCameraManualGain=33, useBracketedExposures=FALSE, 
bracketingExposureStartUsec=5000, 
bracketingExposureMultiplierTimes100=1000, fiberIgnitionPosition=0,
fiberTestPosition=0, flowTimeoutSec=300, fuelFlowIgnitionDeltaMs=0,
fuelIgnitionFlowSlpm=fuelTestFlow1Slpm=0.211, constantFlowTime1Sec=270
dataCamera Zoom=25000, dataCamera Focus=14600
25

[Texto OCR de la imagen]
Test 21153C3 (test 9 of 14, hot flame 9 of 14) — sustained ignition, run with
dataCameraManuaIGain=33, useBracketedExposures=FALSE,
bracketingExposureStartUsec=5000,
bracketingExposureMultiplierTimes100=1000, fiberIgnitionPosition=O,
fiberTestPosition=O, flowTimeoutSec=300, fuelFlowIgnitionDeItaMs=O,
fuellgnitionFIowSlpm=fueITestFIow1SIpm=O.211, constantFlowTime1Sec=270
dataCamera Zoom=25000, dataCamera Focus=14600
Gas Flow Charts
Graphs
2021-06-02 | GMT
State | Operate | c | 0.000 | SLPM | -0.004 | SLPM | Fu' Scale | 20.000
Static Mixer Line (MFCAI)
0.010
-ou:no
20:32 | 20:33 | 20:34 | 20:35 | 20:36
2 Wed Jun 2021 | Time (s)
State | Operate | c | 0.000 | SLPM | R | -0.002 | SLPM | scale | 2.000 | SLPM
Bypass(MFCA2)
ACME FLOW | BYPASS SETPOINT | ACME FLOW "2 BYPASS FLOW
I.oe-3
ose-3
-ose-3
-1.0e-3
-ISe-3
-2.Oe-3
I'l'lW
-2.5e-3
-3.0e-3
20:32 | 20:33 | 20:34 | 20:35 | 20:36
2 wed Jun 2021 | Time (s)
State | Operate | c | 0.000 | SLPM | R | 0.000 | Ft-nscale | 0.500
Fuel(MFCA3)
0.15
20:32 | 20:33 | 20:34 | 20:35 | 20:36
2 wed Jun 2021 | Tine (s)
25
~~~~

### Pagina 26

Cita: [pdf_beb8028ea2244fd6f2e1, p. 26]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_beb8028ea2244fd6f2e1/p0026.jpg)

~~~~text
Test 21153C3, continued
- VLC media player | Diagnostic Cool Flame Sensors | x
System state | 2021-06-02 | GMT
System Temper atures
5,000 | cpu | 33.100
Power
Set Al Gahs
v | CPU Board | 35.000
0.000 | -0.001 | 0.000 | set
abe Sensor 1 | 34.332
0.000 | -0.000 | 0.000 | Set | 34.311
Cube Sensor 2
PMT 3 | 0.000 | -0.000 | 0.000 | Set | 25
Drive
W/an2
-0.002791 | 109 | TC200A (TCI) | 24.128198 | 0.055
-10 mm Lo Gü
-0.000904 | -0.542 | TC200B (TC2) | 22.093879 | -0.027 | mV
-10 nn Gah
-0.000271 | 0.047 | 22.782211 | 0.873
+30 mm | Gan
+30 | Gan | 0.000451 | 0.509
mm
Rake: Far
+60 mm Lo Gain | -0.000178 | 0.064
41.510219 | 0.762
+60 mm H Gan | 0.000810 | o. 707
invü40w | 0.013
60 Deg Offset | 0.000449 | 1.533
hvü40w | 0.001
0.935
Radorneter Cold indon
60 Deg 0%et | 24.821947 | 1.576
Sphere.'
Burner | 260.915488 | 9.688
CLbe Cmne•cåm
Time Series Chart $1
0.9
ACNE | 0.00
Teleme | 0.00
ACME Teleme ACME DIAG PMT T3 | 0.00
0.7
Select Items | End Plotting
Clear Selections | Restart
Graph Properties | uuvÅ
0.1
2021 | 2 wed Jun 2021
Startrme
26
~~~~

### Pagina 27

Cita: [pdf_beb8028ea2244fd6f2e1, p. 27]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Test 21153C3, continued
After test: 700 on lowest valve safety timer, 295 psia in oxidizer bottle, 155 psia 
in fuel bottle
27
~~~~

### Pagina 28

Cita: [pdf_beb8028ea2244fd6f2e1, p. 28]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_beb8028ea2244fd6f2e1/p0028.jpg)

~~~~text
Test 21153G1 (test 10 of 14, hot flame 10 of 14) – sustained ignition, run with 
dataCameraManualGain=0, useBracketedExposures=TRUE, 
bracketingExposureStartUsec=50000, 
bracketingExposureMultiplierTimes100=200, fiberIgnitionPosition=10000,
fiberTestPosition=17000, flowTimeoutSec=300, fuelFlowIgnitionDeltaMs=0,
fuelIgnitionFlowSlpm=fuelTestFlow1Slpm=0.211, constantFlowTime1Sec=270
dataCamera Zoom=45000, dataCamera Focus=10025
28

[Texto OCR de la imagen]
Test 21153G1 (test 10 of 14, hot flame 10 of 14) — sustained ignition, run with
dataCameraManuaIGain=O, useBracketedExposures=TRUE,
bracketingExposureStartUsec=50000,
bracketingExposureMuItipIierTimes100=200, fiberIgnitionPosition=10000,
fiberTestPosition=17000, flowTimeoutSec=300, fuelFlowIgnitionDeltaMs=O,
fuellgnitionFlowSlpm=fuelTestFlow1Slpm=O.211, constantFlowTime1Sec=270
dataCamera Zoom=45000, dataCamera Focus-10025
Gas Flow Charts
Graphs
state | 202106-02
State | Operate | c | 0•000 | SLPM | R | -0.006 | SLPM | Fun Scale | 20.000 | SLPM
Static Mixer Line (MFCAI)
0.010
21:08 | 21:09 | 21:10 | 21:11 | 21:12
2 wed Jun 2021 | Tine (s)
State | c | 0.000 | SLPM | R | -0.002 | SLPFI | scale | 2,000
Bypass(MFCA2)
ACME FLOW r-•12 BYPASS SETPOINT | ACME FLOW "2 BYPASS FLOW
3e-3
Ze-3
le-3
-Ze-3
-3e-3
-4e-3
-se-3
21:08 | 21:09 | 21:10 | 21:11 | 21:12
2 Wed Jun 2021 | Tine (s)
State | Operate | c | 0.000 | SLPM | R | 0.001 | scale | 0.500
Fuel(MFCA3)
ACME FLOW | FUEL SETPOINT | ACME FLOW | FUEL FLOW
0.10
21:08 | 21:09 | 21:10 | 21:11 | 21:12
awed Jun 2021 | Tine (s)
28
~~~~

### Pagina 29

Cita: [pdf_beb8028ea2244fd6f2e1, p. 29]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_beb8028ea2244fd6f2e1/p0029.jpg)

~~~~text
Test 21153G1, continued
- VLC media player | Diagnostic Cool Flame Sensors | ><
Yc:lz
system state | 2021-06-02 21:1216
pt.-TTS | Systern Terroeratures
5.000 | cpu | 33.200
Power
Set Al Gains
W/crn2 | v | cpu Board | 35.000
PMT 1 | -58,000 | 5.500
Cube Sensor 1 | 34.362
71. ooo | -0.001 | Gan | 6.000 | 34.318
Cube Sensor 2
PMT 3 | 0.000 | -0.000 | 5.500 | 25
Hard Drive
Radometers
W/a•n 2
-o. 002421 | -0.088 | TC200A (TCI) | 24.524702 | 0.071
-10 nn LO Gdn
-0.000901 | -0.54) | TC20E (TC2) | 21.920047 | 034 | mV
-10 mm H Gah
0.000410 | 0.090 | TCCJ | 22.782211 | 0.873
+30 mm Lo Gah
+30 nn H Gah | 0.001074 | 0.990 | Array
Rake: FU
+60 | Lo Gah | 0.000539 | 0.106
43.459990 | 0.842
+60 nn Hi Gan | 0.001521 | 1.176
invalid-low | 0.025
60 Deg Offset | 0.000723 | 1.685
invabd-/ow | 0.007
43.727838 | 0.853
Radometer Cold incfion
Volts
60 Deg Offset | 24.821947 | 1.576
CJ
294, 919345 | 11.087 | mV
Cube Connection
Time Senes Chart
Packet | Software bhernonic
0.00
0.00
ACME-Teleme ACME DIAG | T3 | 0.00
> 0.4
Select Items | End Plotthg
Clear Selections
Gr sph Properties
2021 21:1215.OOO | 2 Wed Jun 2021 | Tune
StartTme
29
~~~~

### Pagina 30

Cita: [pdf_beb8028ea2244fd6f2e1, p. 30]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Test 21153G1, continued
After test: 540 on lowest valve safety timer, 296 psia in oxidizer bottle, 149 psia 
in fuel bottle
30
~~~~

### Pagina 31

Cita: [pdf_beb8028ea2244fd6f2e1, p. 31]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_beb8028ea2244fd6f2e1/p0031.jpg)

~~~~text
Test 21153C4 (test 11 of 14, hot flame 11 of 14) – sustained ignition, run with 
dataCameraManualGain=33, useBracketedExposures=FALSE, 
bracketingExposureStartUsec=5000, 
bracketingExposureMultiplierTimes100=1000, fiberIgnitionPosition=0,
fiberTestPosition=0, flowTimeoutSec=300, fuelFlowIgnitionDeltaMs=0,
fuelIgnitionFlowSlpm=fuelTestFlow1Slpm=0.159, constantFlowTime1Sec=270
dataCamera Zoom=25000, dataCamera Focus=14600
31

[Texto OCR de la imagen]
Test 21153C4 (test 11 of 14, hot flame 11 of 14) — sustained ignition, run with
dataCameraManuaIGain=33, useBracketedExposures=FALSE,
bracketingExposureStartUsec=5000,
bracketingExposureMuItipIierTimes100=1000, fiberIgnitionPosition=O,
fiberTestPosition=O, flowTimeoutSec=300, fuelFlowIgnitionDeItaMs=O,
fuellgnitionFIowSIpm=fueITestFIow1Slpm=O.159, constantFlowTime1Sec=270
dataCamera Zoom=25000, dataCamera Focus-14600
Gas Flow Charts
Graphs
2021-06-02 | GMT
State | Operate | c | 0.000 | SLPM | R | -0.005 | SLPM | Fai Scale | 20.000
Static Mixer Line (MFCAI)
-Ze-3
—4e-3
-6e-3
21:29 | 21:30 | 21:31 | 21:32 | 21:33
2 wed Jun 2021 | Tüne (s)
State | Operate | C | 0.000 | SLPM | R | -0.003 | SLPM | scale | 2.000
Bypass(MFCA2)
o
-le-3
-3e-3
-4e-3
-5e-3
21:29 | 21:30 | 21:31 | 21:32 | 21:33
2 wed Jun 2021 | Time (s)
State | Operate | c | 0.000 | SLPM | R | 0.000 | SLPM | scale | 0.500 | SLPM
Fuel(MFCA3)
ACHE_FLOW "3 FUEL_SETPOINT | ACME_FLOW | FUEL_FLOW
0.16
0.14
0.12
0.10
0.06
0.04
0.02
21:29 | 21:30 | 21:31 | 21:32 | 21:33
2 Wed Jun 2021 | Time (s)
31
~~~~

### Pagina 32

Cita: [pdf_beb8028ea2244fd6f2e1, p. 32]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_beb8028ea2244fd6f2e1/p0032.jpg)

~~~~text
Test 21153C4, continued
- VLC media player | Diagnostic Cool Flame Sensors | x
2021-06-02 21:32: 55
PMTS | System Temperab-res
5.000 | cpu | 33.200
power
Set All G*ns
v | CPU Board | 35.000
-58.000 | -0.000 | 5.500
CLbe Sensor 1 | 34.
PMT 2 | 71,000 | -0.000 | 6,000 | Set | 34.421
CLbe Sensor 2
PMT 3 | 0.000 | -0.000 | 5.500 | 25
Drive
W/crn 2
-0.002121 | -0.071 | TC200A act) | 25.310074 | 0.089
-10 mm Lo
-0.000901 | TC200B trc2) | 22.483886 | -0.025
-IO | Hi
0.000901 | o. 121 | 23. 121190 | 0.874
+3) mm LO Gü
+32 mm H Gail | 0.001514 | 1.330
Rake:
+60 mm Lo Gan | 0.001086 | 0,138
48.508237 | 1.036
+60 mm H Gan | 0.002057 | 1.530
invahd40w | 0.033
60 Deg Offset | 0.000942 | 1.807
maid-bw | 0.015
49.550973 | 1.079
Radmeter Cdd Juncåcn
60 Deg Offset | 24.992962 | I. 574
Burner: Sph"a/
Burner | 357.092159 | 13.667 | mV
Connection
Time Series Chart
packet | So | Fhenu.nic
ACME Teleme ACME DIAG PW Tl | 0.00
ACME Teleme | 0.00
ACME | 0.00
0.30
Select Items | End PIO tting
Clear Selections | Restart
0.15
Graph Ptoperties | 0.10
02 Jun 2021 | awed Jun 2021
startTrne
32
~~~~

### Pagina 33

Cita: [pdf_beb8028ea2244fd6f2e1, p. 33]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Test 21153C4, continued
After test: 251 on lowest valve safety timer, 296 psia in oxidizer bottle, 140 psia 
in fuel bottle
33
~~~~

### Pagina 34

Cita: [pdf_beb8028ea2244fd6f2e1, p. 34]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_beb8028ea2244fd6f2e1/p0034.jpg)

~~~~text
Test 21153C5 (test 12 of 14, hot flame 12 of 14) – sustained ignition, run with 
dataCameraManualGain=33, useBracketedExposures=FALSE, 
bracketingExposureStartUsec=5000, 
bracketingExposureMultiplierTimes100=1000, fiberIgnitionPosition=0,
fiberTestPosition=0, flowTimeoutSec=300, fuelFlowIgnitionDeltaMs=0,
fuelIgnitionFlowSlpm=fuelTestFlow1Slpm=0.106, constantFlowTime1Sec=270
dataCamera Zoom=25000, dataCamera Focus=14600
34

[Texto OCR de la imagen]
Test 21153C5 (test 12 of 14, hot flame 12 of 14) — sustained ignition, run with
dataCameraManuaIGain=33, useBracketedExposures=FALSE,
bracketingExposureStartUsec=5000,
bracketingExposureMultiplierTimes100=1000, fiberIgnitionPosition=O,
fiberTestPosition=O, flowTimeoutSec=300, fuelFlowIgnitionDeItaMs=O,
fuellgnitionFIowSIpm=fuelTestFIow1SIpm=O.106, constantFlowTime1Sec=270
dataCamera Zoom=25000, dataCamera Focus=14600
Gas Flow Charts
Graphs
2021-06-02
State | c | 0.000 | R | -0.004 | SLPM | 20.000 | QpM
Static Mixer Line (MFCAI)
le-3
-le-3
-Ze-3
-3e—3
11
-5e-3
-6e-3
-re-3
21:45 | 21:46 | 21:47 | 21:48 | 21:49
a Wed Jun 2021 | Time (s)
State | C)perate | c | 0.000 | R | -0.002 | SLPM | scale | 2.000
Bypass(MFCA2)
ACME FLOW "2 BYPASS SETPOINT | ACME FLOW "2 BYPASS FLOW
3e-3
Ze-3
le-3
-le-3
-Ze-3
-3e-3
21:45 | 21:46 | 21:47 | 21:48 | 21:49
2 Wed Jun 2021 | Time (s)
State | Operate | c | 0.000 | R | 0003 | SLPM | scale | 0.500
Fuel(MFCA3)
ACME FLOW | FUEL SETPOINT | ACME FLOW "3 FUEL FLOW
0.10
21:45 | 21:46 | 21:47 | 21:48 | 21:49
2 Wed Jun 2021 | Time (s)
34
~~~~

### Pagina 35

Cita: [pdf_beb8028ea2244fd6f2e1, p. 35]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_beb8028ea2244fd6f2e1/p0035.jpg)

~~~~text
Test 21153C5, continued
VLC media player | Diagnostic Cool Flame Sensors
system state | 2021-06-02 21:48: 48 | GMT
Syste-n Temperatures
5.000 | Set | CPU | 33.300
Power
Set All Gains
W/crr,2 | Board | 35,000
0.000 | 0001 | Gain | 0.000
Cube Sensor 1 | 34, 264
2 | 0.000 | -0.000 | Gain | 0.000 | 34, 258
Cube Sensor 2
3 | 0.000 | -0.000 | Gain | 0.000 | 25
Hard Drive
w,'cmz | vets
-0.002703 | -0.104 | TC200A (TCI) | 23.873095 | 0.031 | mV
-10 | Lo Gah
-0.000902 | -0.541 | TC2008 (TC2) | 22.409416 | -0.028 | mV
-10 rrrn H Gah
-0.000018 | 0.063 | 23.121190 | 0.874
+30 mm Lo Gah
+30 | Hi Gain | 0.000680 | 0.686 | Array
mm
Rake.- Far
+60 mm Lo Gan | -0.000264 | 0.059
29.091537 | 0.242 | mV
+60 mm | 0.000731 | 0.655
nvabd-/ow | 0.002 | mV
60 | Offset | 0.000413 | 1.513
hvabd-/ow | -0.001 | mV
31.161911 | 0.326 | mV
Radorneter COE inction
vets
60 Deg Offret | 24.736427 | 1.577
Burner: Sphetea/ (1/4
Burner | 424.678840 | 16.517
Canecticn
Series Chart
Packet | Software Mrernonic | Low
ACME Teleme | 0.00
ACME Teleme | 0.00
ACME Teleme ACME DIAG | T3 | 0.00
Select Items | End Plotting
Clear Selections
Graph Properties
21:47:45
02 | 2021 21t48A8.ooo | 2 Wed Jun 2021 | Time
Start Tln•ve
35
~~~~

### Pagina 36

Cita: [pdf_beb8028ea2244fd6f2e1, p. 36]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Test 21153C5, continued
After test: 187 on lowest valve safety timer, 296 psia in oxidizer bottle, 139 psia 
in fuel bottle
36
~~~~

### Pagina 37

Cita: [pdf_beb8028ea2244fd6f2e1, p. 37]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_beb8028ea2244fd6f2e1/p0037.jpg)

~~~~text
Test 21153C6 (test 13 of 14, hot flame 13 of 14) – sustained ignition, run with 
dataCameraManualGain=33, useBracketedExposures=FALSE, 
bracketingExposureStartUsec=5000, 
bracketingExposureMultiplierTimes100=1000, fiberIgnitionPosition=0,
fiberTestPosition=0, flowTimeoutSec=160, fuelFlowIgnitionDeltaMs=0,
fuelIgnitionFlowSlpm=fuelTestFlow1Slpm=0.317, constantFlowTime1Sec=130
dataCamera Zoom=25000, dataCamera Focus=14600
37

[Texto OCR de la imagen]
Test 21153C6 (test 13 of 14, hot flame 13 of 14) — sustained ignition, run with
dataCameraManuaIGain=33, useBracketedExposures=FALSE,
bracketingExposureStartUsec=5000,
bracketingExposureMultiplierTimes100=1000, fiberIgnitionPosition=O,
fiberTestPosition=O, flowTimeoutSec=160, fuelFlowIgnitionDeItaMs=O,
fuellgnitionFIowSlpm=fueITestFIow1SIpm=O.317, constantFlowTime1Sec=130
dataCamera Zoom=25000, dataCamera Focus=14600
Gas Flow Charts | o | x
Graphs
2021-06-02
State | Operate | c | 0.000 | SLPM | -0.006 | SLPM | a scale | 20.000
Static Mixer Line (MFCAI)
ACME FLOW MI MIXER SETPOINT | ACME FLOW MI MIXER FLOW
8e-3
6e-3
4e-3
ä Ze-3
-Ze-3
—4e—3
22:01 | 22:02 | 22:03 | 22:04 | 22:05
2 Wed Jun 2021 | Time (s)
State | Operate | c | 0.000 | SLPM | 0.001 | scale | 2.000
Bypass(MFCA2)
Ze-3
le-3
-Ie—3
-Ze-3
-3e-3
22:01 | 22:02 | 22:03 | 22:04 | 22:05
2 Wed Jun 2021 | Time (s)
State | Operate | c | 0.000 | SLPM | R | 0.000 | SLPM | scale | 0.500 | SLPM
Fuel(MFCA3)
0.4
0.3
22:01 | 22:02 | 22:03 | 22:04 | 22:05
awed Jun 2021 | Time (s)
37
~~~~

### Pagina 38

Cita: [pdf_beb8028ea2244fd6f2e1, p. 38]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_beb8028ea2244fd6f2e1/p0038.jpg)

~~~~text
Test 21153C6, continued
- VuC media player | Diagnostic Cool Flame Sensors
system state | 2021-06-02
pMTS | System Ternperatures
5.000 | 33.500
Power
Set AI Gans
W/crn2 | v | Board | 35.000
0.000 | -0.000 | 0.000 | Set
PMT I | Gan | Cabe | 33.949
Sensor 1
PMT 2 | 0.000 | -0.001 | 0.000 | 33.957
PMT 3 | 0.000 | 0.000 | tsar, | 0.000 | set | 25
Hard
Radometers
W Ian 2
-0.002862 | -0.113 | TC200A CTCI) | 24.170556 | 0.043
-10 mm Lo Gan
-0.000902 | -0.541 | TC200E (TC2) | 22.632813 | -0.019
-10 mm H Gan
-0.000525 | 0.031 | 23.121190
+30
+30 nn H Gah | 0.000234 | 0.341 | Array
Rake:
+60 nn Lo Gan | -0.000503 | 0.045
33.342436 | 0.435
+60 nn H Gah | 0.000490 | 0.496
m aid-bw | -0.002 | mV
60 Deg Chet | o. 000255 | 1.425
maid -low | -O •009 | mV
44.5420 | 0.873
Ratiometer Cold Junctbn
60 Deg Ofret | 24.736427 | 1.577
Burner. | (1/4)
180.388415 | 6.431
Cube Connection
Time Series Chart Sl
Packet | Softveare Mnemonic
ACME Teleme ACME | 0.00
0.00
ACME Teleme | 0.00
Select Items | End plottirg
Clear Selections | Restart
Graph Properties
02 Jun 2021 2204245.000 | awed Jun 2021 | Time
start
38
~~~~

### Pagina 39

Cita: [pdf_beb8028ea2244fd6f2e1, p. 39]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Test 21153C6, continued
After test: 111 on lowest valve safety timer, 295 psia in oxidizer bottle, 135 psia 
in fuel bottle
39
~~~~

### Pagina 40

Cita: [pdf_beb8028ea2244fd6f2e1, p. 40]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_beb8028ea2244fd6f2e1/p0040.jpg)

~~~~text
Test 21153C7 (test 14 of 14, hot flame 14 of 14) – sustained ignition, run with 
dataCameraManualGain=33, useBracketedExposures=FALSE, 
bracketingExposureStartUsec=5000, 
bracketingExposureMultiplierTimes100=1000, fiberIgnitionPosition=0,
fiberTestPosition=0, flowTimeoutSec=85, fuelFlowIgnitionDeltaMs=0,
fuelIgnitionFlowSlpm=fuelTestFlow1Slpm=0.211, constantFlowTime1Sec=55
dataCamera Zoom=25000, dataCamera Focus=14600
40

[Texto OCR de la imagen]
Test 21153C7 (test 14 of 14, hot flame 14 of 14) — sustained ignition, run with
dataCameraManuaIGain=33, useBracketedExposures=FALSE,
bracketingExposureStartUsec=5000,
bracketingExposureMultiplierTimes100=1000, fiberIgnitionPosition=O,
fiberTestPosition=O, flowTimeoutSec=85, fuelFlowIgnitionDeltaMs=O,
fuellgnitionFIowSlpm=fueITestFIow1SIpm=O.211, constantFlowTime1Sec=55
dataCamera Zoom=25000, dataCamera Focus=14600
Gas Flow Charts
Graphs
2021-06-02 | GMT
State | Operate | c | 0•000 | SLPM | R | -0.005 | SLPM | FL-A Scale | 20.000
Static Mixer Line (MFCAI)
ACME FLOW MI MIXER SETPOINT | ACME FLOW MI MIXER FLOW
-0.010
22:14 | 22:15 | 22:16 | 22:17 | u: 18
2 Wed Jun 2021 | Time (s)
State | Operate | c | 0.000 | SLPM | R | -0.001 | SLPM | scale | 2.000
Bypass(MFCA2)
ACME_FLO
Ze-3
le-3
-Ie-3
-Ze-3
-3e-3
22:14 | 22:15 | 22:16 | 22:17 | 22:18
2 Wed Jun 2021 | Time (s)
State | Operate | c | 0.000 | R | 0.001 | scale | 0.500
Fuel(MFCA3)
ACME FLOW "3 FUEL SETPOINT | ACME FLOW "3 FUEL FLOW
0.20
0.15
0.10
u: 14 | u: 15 | 22:16 | 22:17 | 22:18
2 Wed Jun 2021 | Time (s)
40
~~~~

### Pagina 41

Cita: [pdf_beb8028ea2244fd6f2e1, p. 41]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_beb8028ea2244fd6f2e1/p0041.jpg)

~~~~text
Test 21153C7, continued
VLC media player | Diagnostic Cool Flame Sensors | x
system state | 2021-06-02 22: 17:51 | GMT
PMTs | System
5.000 | 33, 100
power
Set Al G*ns
CAJ Board | 35.000
0.000 | -0.000 | 0.000 | set
CLbe Sensor 1 | 34.053
0.000 | -0.001 | Gain | 0.000 | Set | 34.071
a-be Senscr 2
0.000 | -0.000 | Gain | 0.000 | set | 25
W /cm2
-0.003656 | -0.158 | TC200A (TCI) | 24.021336 | 0.037 | mV
-10 rnm Lo Gan
-0.000904 | -0.542 | TC200B (TC2) | 23.253127 | 0.006 | mV
-10 | H Gain
-0.001365 | -0.022 | 23.121190 | 0.874 | v
+30 mm Lo Gain
+30 | Hi Gan | -0.000523 | -0.243
mm
Rake: Far
+60 mm Lo Gain | -0.001511 | -0.014
27.709030 | 0.186 | mV
+60 mm H | -0.153
in vdid-bw | -0.005 | mV
60 Deg Ofret | -0.000051 | 1.255
invalid-low | -0.006 | mV
25.037689 | 0.078 | mV
Radon-eter Cold Junction
60 Deg Ofret | 24.650913 | 1.578
Burner: Sphere-a/ (1/4)
Burner | 216.571832 | 7.879
CLbe
Time Series Chart $1
0.7
Packet | Software Mnemonc
ACME Teleme ACME DIAG PMT Tl | 0.00
ACFE Teleme ACTG DIAG | T2 | 0.00
ACME Teleme | 0.00
Select [terns | End Plotfing
Clear Selections | Restart
Graph Properties
0.1
02 Nn | awed Jun 2021
start Tr.r,e
41
~~~~

### Pagina 42

Cita: [pdf_beb8028ea2244fd6f2e1, p. 42]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Test 21153C7, continued
After test: 34 on lowest valve safety timer, 296 psia in oxidizer bottle, 132 psia 
in fuel bottle
42
~~~~
