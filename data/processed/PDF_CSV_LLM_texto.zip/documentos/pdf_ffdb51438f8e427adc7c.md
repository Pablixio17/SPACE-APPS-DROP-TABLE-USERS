# E-FIELD Flames SCR 200802

- Identificador: pdf_ffdb51438f8e427adc7c
- Investigaciones: PSI-22
- Tipo de documento: Science Documents
- Estado: processed
- Temas detectados automaticamente: electric_fields, hardware, soot, microgravity, oxygen, ignition, computational_models, pressure, extinction, operations

## Fuentes

- [PSI-22_Science Documents_E-FIELD Flames SCR 200802.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-22/Science%20Documents/PSI-22_Science%20Documents_E-FIELD%20Flames%20SCR%20200802.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Pasajes de orientacion (extractivos, no resumen validado)

### summary - pagina 59

Summary – Potential Interaction
• Chemistry of chemi-ionization added to 
mechanisms
• Burner overlap (jet and co-flow)
• Soot control
• Combustion control
• Flame analysis (alternative fuels)

### objective - pagina 33

Objectives
Understand flame ion production and use ions to control 
diffusion flames by modifying local convection (via the ion 
wind) and local species transport (via direct ion drift)
A) Determine the relationship between electric field voltage and 
chemi-ion current as functions of total fuel flow rate and the 
amount of inert in the fuel.
B) Obtain the time response of flame chemiluminescence, luminosity, 
and ion current to large step changes in voltage, as functions of 
total fuel flow rate and amount of inert added to the fuel stream.
C) Evaluate and control sooting behavior (i.e., soot volume fraction 
and location of luminous soot) in relation to the electric field 
voltage and chemi-ion current as functions of total fuel flow rate 
and amount of inert added to the fuel stream.
D) Use the variation of the chemi-ion current as a function of applied 
voltage to characterize and control the combustion behavior of 
near-limit lifted flames in a coflow burner.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_ffdb51438f8e427adc7c, p. 1]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_ffdb51438f8e427adc7c/p0001.jpg)

~~~~text
E-FIELD Flames
Electric Field Effects on Laminar Diffusion 
Flames
Derek Dunn-Rankin
Mechanical and Aerospace Engineering
University of California, Irvine
Co-Investigators: 
Felix Weinberg; Imperial College, London 
Zeng-Guang Yuan, NCSER
Project Scientist: Dennis Stocker, NASA GRC
NASA Glenn - SCR; February 20-21, 2008

[Texto OCR de la imagen]
-FIELD Flame
El ctric Field Effects on Laminar Diffu ion
Flames
Derek Dunn-Rankin
Mechanical and Aerospace Engineering
University of California, Irvine
Co-lnvestigators:
Felix Weinberg; Imperial College, London
Zeng-Guang Yuan, NCSER
tQject Scientist: Dennis Stocker, NASA GR
NASA Glenn - SCR; February 20-21, 20
~~~~

### Pagina 2

Cita: [pdf_ffdb51438f8e427adc7c, p. 2]. Metodo: native.

~~~~text
Outline
• Background
– Ion Driven Wind in Flames
– Examples of laboratory experiments
• Scientific Opportunity
• Experimental Objectives
• Approach
• Justification for Microgravity
• Scientific Data End Products
• Operational Sequence
• Test Matrix
• Success Criteria
• Post-Flight Data Analysis
• Summary
~~~~

### Pagina 3

Cita: [pdf_ffdb51438f8e427adc7c, p. 3]. Metodo: native.

~~~~text
Ion Transport
E

 =
Ion mobility

q
  = −
2
j = q(KE +V ) − Dq
  
 j = 0

(a) Poisson equation governs 
electric field (Gauss’ Law); q is the 
charge density [e.g., 
Coulombs/m3
]
(c) Charge drifts through the 
ambient gas by electric field 
forces, convection, and diffusion
(b) Charge conservation
Current surface density Ion diffusivity
electric field
electric potential
For our conditions, ion diffusion 
and convection are negligible 
KqE relative to electrokinetic drift j
 
=
~~~~

### Pagina 4

Cita: [pdf_ffdb51438f8e427adc7c, p. 4]. Metodo: native.

~~~~text
Electric Body Force on Neutral Fluid
( )

=

F E q
 
j K q E
 
=
 

= K
F j /
 
Electric body force binds ion transport 
and neutral fluid transport; depends on 
mobility and current density
VV P F
  
 ( ) = − +   +
Neutral fluid 
momentum 
equation
Total body force = electric and 
gravitational
~~~~

### Pagina 5

Cita: [pdf_ffdb51438f8e427adc7c, p. 5]. Metodo: native.

~~~~text
Electric Fields act on 
Combustion Generated Ions
• Fundamental Interaction
–Radical ions are generated at the flame 
–Majority of ions are short lived (flame zone)
–H3O+ is predominant outside the flame zone
–Momentum transfer via collision between 
ions and neutrals
–Electric body force applied to the fluid
• Electric Field Influences
–Ion driven wind 
–Chemical effect (removal of ions from the 
flame zone)
• Observed Effects 
–Reshaping of the reaction zone
–Enhanced flammability limits
–Controlled heat transfer
–Reduced and enhanced soot formation
–Forced extinguishment
–NOX and SO2 pollutant reduction
Applied E-Field
+ + + + + + + + + + + + + + +
+ + + + +
+
+
+
+
+
+
+
+
+
+
+
+
+
V
Anode
Cathode
+
+
+
++ + +
+ +
++ + +
No Field
reaction zone
~~~~

### Pagina 6

Cita: [pdf_ffdb51438f8e427adc7c, p. 6]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_ffdb51438f8e427adc7c/p0006.jpg)

~~~~text
Hydrocarbon Flame Ion Chemistry
Pederson and Brown
Starik and Titova
Increase in O atom 
increases ion 
production
H3O+
is the 
dominant ion that 
survives the flame 
zone
Electrons and 
neutrals they attach 
to are the negative 
charge carriers

[Texto OCR de la imagen]
Hydrocarbon Flame Ion Chemistry
+ | Starik and Titova
1-1 0 -e-..-.-H O | CH
3
C.HO + air
o
Pederson and Brown
Increase in O atom | H2,co
HCO'
increases ion
202
production | H20
0.02
H30+ is the | H 200 | Hoo•
dominant ion that | HCN
021 | C2H2 'H2 70 | 024M C02+M
survives the flame
OH
zone | 02 | 1 C2HJO• | C0ä
H20
Electrons and | IOH M | INO
neutrals | attach | o | 03
they | o; | No;
to are the negative | 02
NO,»,
charge carriers | ü
c02 +
~~~~

### Pagina 7

Cita: [pdf_ffdb51438f8e427adc7c, p. 7]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Ion Wind Force and Velocity Estimate
Assume zero gravity and constant pressure so that only the 
electric body force drives the flow
K
j
dx
d Vx
=
( )
2

• K is mobility of the charge carrier ~ 1 
cm2
/s/V
• g is gravitational acceleration;  is the 
neutral gas density
• x is the distance over which the field acts
• j is current density – flame: 1 mA/cm2
; 
corona: 100 mA/cm2
Flame: order of 1 m/s 
over 1 cm distance
Flame: order of 1-2
~~~~

### Pagina 8

Cita: [pdf_ffdb51438f8e427adc7c, p. 8]. Metodo: native.

~~~~text
Laboratory 1-g Experiments
• Basic configuration
• Typical voltage-current curve or 
characteristic (VI curve or VCC)
• Ion flux from flames
• Modeling ion driven wind
~~~~

### Pagina 9

Cita: [pdf_ffdb51438f8e427adc7c, p. 9]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Varying Force on a Capillary Flame
V
Neutralization by 
electrons at the cathode
Ions travel from 
the flame 
towards ground
Electrons conduct 
through the 
flame to the 
capillary 
e
- e
-
+
+
+
++ + +
+
+
+
+
+
+
+
+
+
++
+ +
+
+
+
+
+
Combustible fuel
Ion production in 
the reaction zone
Electrically conductive capillary
qE
T
T
F g
o
net o
 

 +





=  1−
Fb Fe
~~~~

### Pagina 10

Cita: [pdf_ffdb51438f8e427adc7c, p. 10]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_ffdb51438f8e427adc7c/p0010.jpg)

~~~~text
Effect on 
Small 
Diffusion 
Flame
Methane fuel flowrate: 9 cc/min
Capillary diameter: 1.7 mm
Electrode Spacing: 7 cm
Conditions
1. Naturally Buoyant – 0 Volts
2. Microbuoyant – 2880 Volts
3. Negatively buoyant – 4300 
Volts
0 1000 2000 2500 3000 4000 5000
Applied Potential (Volts)
CH Chemiluminescence

[Texto OCR de la imagen]
Potential | Effect on
Applied | (Volts)
0 | 1000 2000 250 | 3000 4000 5000 | Small
Diffusion
Flame
CH Chemiluminescence
Methane fuel flowrate: 9 cc/min
Capillary diameter: 1.7 mm
Electrode Spacing: 7 cm
Conditions
1. Naturally Buoyant — 0 Volts
2. Microbuoyant — 2880 Volts
3. Negatively buoyant — 4300
Volts
~~~~

### Pagina 11

Cita: [pdf_ffdb51438f8e427adc7c, p. 11]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Key Aspects of the VCC
• Subsaturation regime
– Steeper increase in 
current with voltage in 
horizontal orientation
• Saturation
– Saturation current 
increases linearly with 
flowrate
– Higher saturation current 
in horizontal configuration
• Increased ionization
– Reaction rate increases 
creating additional ions
– Flame more unstable in 
horizontal configuration
Ion wind 
creates 
instability
Quadratic 
increase in 
subsaturation 
region
Saturation current
Flame shape changes, 
increasing ionization
~~~~

### Pagina 12

Cita: [pdf_ffdb51438f8e427adc7c, p. 12]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Methane 14.1 mg/min
0
0.2
0.4
0.6
0.8
1
-50 -30 -10 10 30 50
Radius [mm]
Normalized Ion Current [j/jo]
H = 35 mm 2850V
H =60 mm
Warburg 35 mm
Warburg 60 mm
Ion Current Profiles
• Point-to-plane 
distribution, Warburg 
Law = cos5Q
• Integrated current 
provides ion density 
boundary conditon
• Current distribution 
for model validation
~~~~

### Pagina 13

Cita: [pdf_ffdb51438f8e427adc7c, p. 13]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, sparse_text_or_visual_only, table_structure_not_manually_validated, tiled_ocr_not_manually_verified.

[Imagen de la pagina](../imagenes/pdf_ffdb51438f8e427adc7c/p0013.jpg)

~~~~text
Chemiluminescence & Schlieren
trZJl | Oyerc]rjverJ
2000 v | 2850 v | 4000 v
~~~~

### Pagina 14

Cita: [pdf_ffdb51438f8e427adc7c, p. 14]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Numerical Simulation
o o
e
ce V
 

 = =
2
( ) ( u) ceE
T
T
u u P g
t
u o
o
 +   +





+  = − + −


   1 m
+ ( ) = 0


u
t


( )
u (c T ) u P (k T )
t
c T
p
p
+  =  + 


 
(u )c (D c ceK V )
t
c
+  =   + 


+
Ion concentration
Energy
Mass
Momentum
Gauss’s Law
~~~~

### Pagina 15

Cita: [pdf_ffdb51438f8e427adc7c, p. 15]. Metodo: native.

~~~~text
Computational Model
• FEMLAB simulation
• Finite element method
• General equation solver
• Staged solution
1. Electrokinetic (V, c)
2. Electrodynamic (V, c)
3. Hot flow (V, u, v, P, T, c) 
• 2-D axisymmetric
• Assumptions
– Balance condition
– Isotropic Fickian diffusion
– Single ion species (positive ions)
– Temperature is constant within the flame (hot flow)
– Uniform ion concentration at the flame
– Ion properties are of H3O+
Gravity
direction
Symmetry boundary
Anode boundary
Cathode boundary
Infinite condition
RADIAL DIRECTION
AXIAL DIRECTION
hcap
Rflame (3.0 mm)
Rcap (0.5 mm)
63.5 mm
Gravity
direction
Symmetry boundary
Anode boundary
Cathode boundary
Infinite condition
RADIAL DIRECTION
AXIAL DIRECTION
hcap
Rflame (3.0 mm)
Rcap (0.5 mm)
63.5 mm
~~~~

### Pagina 16

Cita: [pdf_ffdb51438f8e427adc7c, p. 16]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_ffdb51438f8e427adc7c/p0016.jpg)

~~~~text
Experimental Results
Buoya nt | Neutral | Overdriven
ov | 2000 v | 2850 v | 4000 v
~~~~

### Pagina 17

Cita: [pdf_ffdb51438f8e427adc7c, p. 17]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
475 K
410 K
315 K
350 K
Position (m)
Calculation Results
Internal 
temperature 
contours at 100 K 
increments to 
1300 K at ion 
source boundary
Maximum Velocity = 0.4 m/s
Velocity Vectors and Temperature Contours
~~~~

### Pagina 18

Cita: [pdf_ffdb51438f8e427adc7c, p. 18]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Physical Description
Induced electric field 
(causes horiz. migration)
V
Re-circulation driven by 
neutralized buoyant gas 
redirection
• Source of unstable T and O2
• Observed in shadowgraphs
Neutralization by 
electrons at the cathode
Ions travel from the 
flame towards ground
Electrons conduct 
through the flame to the 
capillary 
High ion concentration at 
the center decreasing 
radially outward
+
+ +
+ +
+
+ +
+ + +
+ + + + +
+ +
+ + +
+
+
+
+
+
+
+
+
+++
+
+
+
+
+
+
+
+++
+
+
+
+
+
+
+
+
+++
+
+
+
+
+
+
+
+++
e
- e
-
+
+
+
++ + +
+
+
+
+
+
+
+
+
+
++
+ +
+
+
+
+
+
+
~~~~

### Pagina 19

Cita: [pdf_ffdb51438f8e427adc7c, p. 19]. Metodo: native.

~~~~text
Scientific Opportunities in Microgravity
• Ion current behavior for diffusion flames 
unaffected by buoyancy
• Role of ion driven wind in secondary ion increase
• Time scales of electrically manipulated diffusion 
flames (ion drift, ion chemistry, ion driven 
convection, diffusion)
• Electrical effects and the role of ions on soot 
production and transport in diffusion flames
• Role of ions and their driven wind in manipulating 
lifted flames
~~~~

### Pagina 20

Cita: [pdf_ffdb51438f8e427adc7c, p. 20]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_ffdb51438f8e427adc7c/p0020.jpg)

~~~~text
Time Response
• Flame ion current time response ~15 
ms
• Convective time response ~100 ms
• Same response without flame 
indicates electronics time response
Leakage current or small corona
Initial flame 
ion current
50 ms

[Texto OCR de la imagen]
Flame ion current time response —15
Time | ms
Response
Convective time response —100 ms
Same response without flame
step response | indicates electronics time response
step response with no flame
Voltage [kV]
Current [micro A]
2.5
2
1.5
50 ms
0.5 | Initial fla e
ion current
Leakage current or small c rona
0.55 | 0.6 | 0.65 | 0.6 | 0.65 | 0.7 | 0.75
time [s] | time [s]
~~~~

### Pagina 21

Cita: [pdf_ffdb51438f8e427adc7c, p. 21]. Metodo: native.

~~~~text
Soot and Electric Fields
➢ Soot particle charge
▪ Soot particles may be originally charged, especially if they are formed 
through an ionic route 
▪ Soot particles gain a net charge through ion-attachment 
▪ Measurements indicate that in the hottest zone, soot particles may be 
charged to equilibrium, but this is not always the case and the initial 
particle charge seems to depend upon the material burnt 
▪ Net charge of soot particles in flames is generally positive even in the 
flame region where a large excess of electrons exist
▪ Soot particle primary size is found to be ~20 nm in non-electric flames; 
size can be reduced in electric fields
➢ Electric field effects on soot in laminar diffusion flames
▪ Ion wind can induce partial premixing (changes reaction zone)
▪ Ion precursors can be removed or reduced in number
▪ Soot residence time can be changed (increased or decreased)
~~~~

### Pagina 22

Cita: [pdf_ffdb51438f8e427adc7c, p. 22]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_ffdb51438f8e427adc7c/p0022.jpg)

~~~~text
Ethylene Flame in Electric Field
• Soot can be a source of ions
• Soot is charged and its 
transport is affected by the 
electric field
• Soot production and growth 
can be influenced by ion 
precursors
Ethylene 50 mg/min

[Texto OCR de la imagen]
Ethylene Flame in Electric Field
Soot can be a source of ions
• Soot is charged and its
transport is affected by the
electric field
• Soot production and growth
can be influenced by ion | Eth lene 50 /min
m
precursors
6
Ethylene 1 1 -8 rng/rnin
o | 6 | 8
Applied Voltage [k VJ
~~~~

### Pagina 23

Cita: [pdf_ffdb51438f8e427adc7c, p. 23]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_ffdb51438f8e427adc7c/p0023.jpg)

~~~~text
VCC for a Co-Flow Burner
ion current vs. applied voltage - co-flow with air and N2 (lifted) | ion current vs. applied voltage - co-flow with air and N2 (lifted)
Positive mesh
1.4 | -0.2
11 | -0.3
-0.4
0.8 | -0.5
0.6 | -0.6
Negative mesh
0.4 | -0.7
CH4 w/o to-flowing air
0.2 | -0.8 | CH4 w/ to-flowing air
CH4 w/ to-flowing air & N
30.8mL/min
-0.9 | CH4 w/ co-flowing air & N2(Iifted)
41. Iml/min
-0.2
-1000 | 1000 | 2000 | 3000 | 4000 | 5000 | 6000 | 7000 | 8000 | -8000 -7000 -6000 -5000 -4000 -3000 -2000 -1000 | I OOO
Applied Voltage [V] | Applied Voltage [VI
~~~~

### Pagina 24

Cita: [pdf_ffdb51438f8e427adc7c, p. 24]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_ffdb51438f8e427adc7c/p0024.jpg)

~~~~text
Liftoff and Blowout
Co-flow burner with methane fuel in I-g
Ion current and Applied Voltage vs. time
0 Volts
0.5
-0.5
-5000 Volts
-1.5
-2.5
2.5
time [sl
~~~~

### Pagina 25

Cita: [pdf_ffdb51438f8e427adc7c, p. 25]. Metodo: native.

~~~~text
Microgravity Justification
• High Quality Microgravity -- confounding effects of 
buoyancy
– Ion driven wind velocity approximately equal to buoyant wind 
velocity so convection and mixing effects are difficult to separate
– Complex flow patterns created in 1-g
– Stability of weak flames (liftoff and blowout) – as in CLD Flame
• Extended Duration -- time scales to reproducible state
– Electrical response (RC time constant)
– Ion transport time
– Ion wind convection
– Soot formation and transport
– Flow field establishment
– Thermal inertia effects
~~~~

### Pagina 26

Cita: [pdf_ffdb51438f8e427adc7c, p. 26]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_ffdb51438f8e427adc7c/p0026.jpg)

~~~~text
Effects of Orientation
Horizontal | CH4 14.1 mymin
Simulated capillary
ov | 2850 v | 3200 v
Vertical
ov | 2850 v | 4000 v
~~~~

### Pagina 27

Cita: [pdf_ffdb51438f8e427adc7c, p. 27]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_ffdb51438f8e427adc7c/p0027.jpg)

~~~~text
Horizontal Configuration
Methane 14.1 mghnin
capillary
ground
plane
2000V | 2500V | 3000V | 3500V
~~~~

### Pagina 28

Cita: [pdf_ffdb51438f8e427adc7c, p. 28]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Methane 14.1 mg/min
0
0.2
0.4
0.6
0.8
1
1.2
1.4
1.6
1.8
2
0 1 2 3 4 5 6
Applied Voltage [kV]
Ion Current [microamps]
Vertical d=35mm
Horizontal d=35mm
14.1 mg/min fuel
35 mm electrode spacing
VCC -- Effects of Orientation
~~~~

### Pagina 29

Cita: [pdf_ffdb51438f8e427adc7c, p. 29]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_ffdb51438f8e427adc7c/p0029.jpg)

~~~~text
Net Body Force
Net vertical body 
force scaled with 
gravity; less than 
zero is down 
force.
Buoyancy dominates
Ion driven wind
dominates

[Texto OCR de la imagen]
Net Body Force
0.02 | 1.5
0.3
Buoyancy dominates
0.01
0.5
2850 v
'Ion driven wind
-0.01
dominates | Net vertical body
-0.5
force scaled with
gravity; less than
-0.02
zero is down
force.
-0.03 | -1.5
~~~~

### Pagina 30

Cita: [pdf_ffdb51438f8e427adc7c, p. 30]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Burner Thermal Inertia in 1-g
0 5
0
1
2
Time (sec)
0 0.1 0.2
-2
-1
0
Time (sec)
0 1 2 3 4 5
0
1
2
Time (sec)
CH Chemiluminescence 
(a) (b) 
(c) 
2850 V
0 V
CH* response 
after step voltage 
change in 1-g
~ 3 sec
~~~~

### Pagina 31

Cita: [pdf_ffdb51438f8e427adc7c, p. 31]. Metodo: native.

~~~~text
31
Relevant Time Scales
Parameters –
Vion_wind ~ 1 m/s
Lflame ~ 1 cm
D ~ 0.1 cm2/s
Vion ~ 100 m/s
Vbuoyancy ~ 1 m/s
Lsystem ~ 10 cm
C ~ 300 m/s
10-6 10-5 10-4 10-3 10-2 10-1 100 101 102
acoustic 
time
RC
convection
burner
microseconds milliseconds seconds
timescales (seconds)
Time scales –
Ion drift time – 1-10 ms
Acoustic time ~ 0.1 ms
Electronic RC time – 50 ms
Convective transport time (ion wind or 
buoyancy) – L/V ~ 0.1-1 sec
Diffusion transport time – Lflame
2/D ~ 10 sec
Flowfield time – Lsystem/Vconvection ~ 10 sec
Burner thermal response time ~ 10 sec
ion drift diffusion
flowfield
~~~~

### Pagina 32

Cita: [pdf_ffdb51438f8e427adc7c, p. 32]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Extended Microgravity –
Experience of other investigators
• CLD Flame discussion showed the necessity for high quality microgravity for 
near limit lifted co-flow flames (i.e., buoyant mixing has substantial effect)
• Co-flow flame experiments showed problems with g-jitter on parabolic flights
• Z.-G. Yuan et. al showed difficulties in achieving steady flames in a 2.2 sec. 
drop tower.
Graph reproduced from: 1100 AIAA￾2003-0812, Z. Yuan and U. Hegde
Note: if not carried out 
sequentially, a single EFIELD 
Flame measurement requires 
both time to reach a stable 
initial condition and time to 
reach the final condition 
following the electric field 
impulse.
~~~~

### Pagina 33

Cita: [pdf_ffdb51438f8e427adc7c, p. 33]. Metodo: native.

~~~~text
Experimental Objectives
Understand flame ion production and use ions to control 
diffusion flames by modifying local convection (via the ion 
wind) and local species transport (via direct ion drift)
A) Determine the relationship between electric field voltage and 
chemi-ion current as functions of total fuel flow rate and the 
amount of inert in the fuel.
B) Obtain the time response of flame chemiluminescence, luminosity, 
and ion current to large step changes in voltage, as functions of 
total fuel flow rate and amount of inert added to the fuel stream.
C) Evaluate and control sooting behavior (i.e., soot volume fraction 
and location of luminous soot) in relation to the electric field 
voltage and chemi-ion current as functions of total fuel flow rate 
and amount of inert added to the fuel stream.
D) Use the variation of the chemi-ion current as a function of applied 
voltage to characterize and control the combustion behavior of 
near-limit lifted flames in a coflow burner.
~~~~

### Pagina 34

Cita: [pdf_ffdb51438f8e427adc7c, p. 34]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_ffdb51438f8e427adc7c/p0034.jpg)

~~~~text
Experimental Approach
Mesh
Mesh
support
electrode
rails
PMT | Color & UV
Imaging
Thermocouple
Igniter
A HV Power
Supply &
Conductive
Current Sensor
Burner
Electrical
Insulation
Gas Feed Tubes
~~~~

### Pagina 35

Cita: [pdf_ffdb51438f8e427adc7c, p. 35]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_ffdb51438f8e427adc7c/p0035.jpg)

~~~~text
Ion Current Measurement
Mesh
Electrode
Variable
Flame
High Voltage
(current source)
Supply | Conductive
Burner Nozzle
Conductive
Bumer Base
Shunt
AV | Resistor | Protective
Protective
Electrically | Capacitor
Resistor (Rp)
Insulated
Mount
Gas Supply Tubes
CIR Insert
Chassis Ground
~~~~

### Pagina 36

Cita: [pdf_ffdb51438f8e427adc7c, p. 36]. Metodo: native.

~~~~text
• Controlled Variables
– Voltage (small step, large step,)
– Data sampling rate
– Fuel/air flow rates
– Ignition
• Measurements
– Current
– Flame shape (reaction zone) – chemiluminescence
– Luminosity – spatially integrated
– Chemiluminescence – spatially integrated
– Soot volume fraction
– Burner temperature
– Soot temperature
Experiments
~~~~

### Pagina 37

Cita: [pdf_ffdb51438f8e427adc7c, p. 37]. Metodo: native.

~~~~text
Science Data End Products
Objective A.) Steady state chemi-ionizaton in flames 
Objective B.) Time response of flames to electric forcing 
Objective C.) The influence of chemi-ions in soot production 
Objective D.) Control of near-limit flames using electric fields
Four Primary Objectives:
~~~~

### Pagina 38

Cita: [pdf_ffdb51438f8e427adc7c, p. 38]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Steady state chemi-ionization in flames
Objective A -- Characterize the dependence of electric field 
strength on flame behavior at steady state as a function of fuel 
and dilution and burner type.
color 
image
filtered 
image
schlieren 
image 
(desired)
0 500 1000 1500 2000 2500 3000 3500 4000 4500
0
0.5
1
1.5
Current (Amps)
0 500 1000 1500 2000 2500 3000 3500 4000 4500
0.7
0.8
0.9
1
Applied Potential (Volts) Relative CH430 nm Emission
Zone 1
Zone 2
Zone 3
Zone 1
Zone 2
Zone 3
VCC spatially integrated luminosity
~~~~

### Pagina 39

Cita: [pdf_ffdb51438f8e427adc7c, p. 39]. Metodo: native.

~~~~text
A.1) Plots of voltage versus ion current for gas-jet 
and co-flow flames, using CH4 and C2H4
A.2) Flame images (color and OH*) at transition 
points in the VI curves
A.7) Flame luminosity (CH* and broadband visible) 
as a function of voltage and current for both 
burners
A.9) Thermal imaging of the plume as a function of 
electric field (desired)
Measured Data End Products 
Objective A
~~~~

### Pagina 40

Cita: [pdf_ffdb51438f8e427adc7c, p. 40]. Metodo: native.

~~~~text
A.4) Voltage and current at the onset of 
enhanced ion production (secondary 
saturation) as a function of fuel and diluent for 
both burners 
A.5) Voltage and current at flame blowoff as a 
function of fuel and diluent for both burners
Extracted Data End Products 
Objective A
~~~~

### Pagina 41

Cita: [pdf_ffdb51438f8e427adc7c, p. 41]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
A.3) Model saturation current as a function of inert 
concentration for both fuels and burners 
A.6) Saturation ion current per carbon influx as a 
function of fuels and diluent for both burners
A.8) Saturation current as a function of flame area
Derived Data End Products 
Objective A
~~~~

### Pagina 42

Cita: [pdf_ffdb51438f8e427adc7c, p. 42]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_ffdb51438f8e427adc7c/p0042.jpg)

~~~~text
Time response of flames
Objective B -- Obtain the time response of flame 
chemiluminescence, luminosity, and ion current to large 
step changes in voltage, as functions of total fuel flow rate 
and amount of inert added to the fuel stream.
0 5
0
1
2
Time (sec)
0 0.1 0.2
-2
-1
0
Time (sec)
0 1 2 3 4 5
0
1
2
Time (sec)
CH Chemiluminescence 
(a) (b) 
(c) Time resolved ion current
Time resolved 
chemiluminescence

[Texto OCR de la imagen]
Time | of flames
response
Objective B -- Obtain the time response of flame
chemiluminescence, luminosity, and ion current to large
step changes in voltage, as functions of total fuel flow rate
and amount of inert added to the fuel stream.
—Voltage (kVl
Estimated ion current [PA] | 2
3.5 - | Collected ion current [PAI
3- | 1 | -1
25 -4------4- | (a) | (b)
-2
5 | 0.1 | 0.2
2- | Time (sec) | Time (sec)
2
18 -
1
0.5 | (c)
1 | 2 | 3 | 4 | 5
Time (sec)
082 064 | 07 072
time [s] | Time resolved
Time resolved ion current | chemiluminescence
~~~~

### Pagina 43

Cita: [pdf_ffdb51438f8e427adc7c, p. 43]. Metodo: native.

~~~~text
B.1) Time resolved ion current after step 
changes in voltage
B.2) Time resolved luminosity after step 
changes in voltage
Measured Data End Products 
Objective B
Measurement requires relatively high data 
rate (100 Hz, minimum; 1 kHz desired) 
from current measurement and PMTs
~~~~

### Pagina 44

Cita: [pdf_ffdb51438f8e427adc7c, p. 44]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
B.3) Electrical time constant of the flame as a 
function of fuel, flow rate, diluent, and burner type
B.4) Luminosity time constant (broadband and CH*) 
of the flame as a function of inert concentration in 
fuel, flow rate, and burner type
Derived Data End Products 
Objective B
T
T
k
B.5) Equivalent 

RC circuit for gas￾jet and coflowing 
flames for 
possible use in 
control algorithms
Time constant extracted 
from time response data
~~~~

### Pagina 45

Cita: [pdf_ffdb51438f8e427adc7c, p. 45]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_ffdb51438f8e427adc7c/p0045.jpg)

~~~~text
Effects of Electric Fields on Soot
Objective C -- Evaluate 
and control sooting 
behavior in relation to the 
electric field voltage and 
chemi-ion current as 
functions of fuel flow rate 
and amount of inert 
added to the fuel.
Ethylene 50 mg/min

[Texto OCR de la imagen]
Effects of Electric Fields on Soot
Objective C -- Evaluate
and control sooting
behavior in relation to the
electric field voltage and | Eth lene 50 m /min
chemi-ion current as
6
functions of fuel flow rate | Ethylene 1 1.8 mg/min
and amount of inert
added to the fuel.
1
o | 1 | 2 | 3 | 5 | 6 | 7 | 8
Applied Voltage [kVJ
~~~~

### Pagina 46

Cita: [pdf_ffdb51438f8e427adc7c, p. 46]. Metodo: native.

~~~~text
C.1) Average soot volume fraction as a function 
of ion wind for various inert concentration 
C.2) Images showing location and temperature 
of soot for different ion wind conditions
Measured Data End Products 
Objective C
Soot volume fraction measurement and color 
imaging measurements already described in 
other proposed ACME experiments (issues of 
young soot versus old soot).
~~~~

### Pagina 47

Cita: [pdf_ffdb51438f8e427adc7c, p. 47]. Metodo: native.

~~~~text
C.5) Voltage at which soot is suppressed 
for different inert levels
Extracted Data End Products 
Objective C
Provides electric field strength to 
evaluating mobility of ions and soot
~~~~

### Pagina 48

Cita: [pdf_ffdb51438f8e427adc7c, p. 48]. Metodo: native.

~~~~text
C.3) Soot mean size based on soot volume 
fraction, temperature, and total ion current
C.4) Spatially resolved soot volume fraction 
at transition conditions
Derived Data End Products 
Objective A
Using classical Dushman equation can relate 
temperature, and soot surface area to ion current; 
identifies the role of soot size versus soot number in 
volume fraction.
e kT j BT e
2 −  /
=
~~~~

### Pagina 49

Cita: [pdf_ffdb51438f8e427adc7c, p. 49]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Open Loop Control of Coflow Flame
Objective D -- Use the variation of the chemi-ion current as a 
function of applied voltage to characterize the combustion 
behavior of near-limit lifted flames in a coflow burner and use the 
ion-driven wind to stabilize or reattach these flames.
~~~~

### Pagina 50

Cita: [pdf_ffdb51438f8e427adc7c, p. 50]. Metodo: native.

~~~~text
D.1) Time resolved ion current and luminosity of near 
limit flames
D.2) Images from the flame at near limit conditions 
with an active field
Measured Data End Products 
Objective D
Measurement D.1 uses the same sensors as those for the 
step-response objective (B); measurement D.2 uses 
imaging sensors (e.g., color camera)
~~~~

### Pagina 51

Cita: [pdf_ffdb51438f8e427adc7c, p. 51]. Metodo: native.

~~~~text
D.3) Mean and RMS ion current and luminosity of 
near limit flames with varying electric field
D.4) Liftoff height as a function of voltage and 
inert concentration in the fuel and flow rate 
(coflowing flame)
Extracted Data End Products 
Objective D
The data D.3 use the same sensors as in D.1 
and will indicate whether the electrical 
properties of the flame can act as a stability 
sensor; the data of D.4 show the steady state 
influence of the electric field on liftoff height.
~~~~

### Pagina 52

Cita: [pdf_ffdb51438f8e427adc7c, p. 52]. Metodo: native.

~~~~text
D.5) Ion driven wind velocity near the lifted 
flame base 
Derived Data End Products 
Objective D
Using the ion current it will be possible to assess the 
relative importance of the steady ion wind versus a 
mixing process near the flame edge as the source of 
changes to the liftoff height.
~~~~

### Pagina 53

Cita: [pdf_ffdb51438f8e427adc7c, p. 53]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Req’d Measurements and Operational Constraints
Sensor Measurement Objectives 
Served
Shunt resistor Ion current A, B, C, D
Color camera Flame shape and size A, B, C, D
PMT (unfiltered) Spatially integrated 
luminosity A, B, C, D
PMT (filtered)
Filtered CH* 
integrated light from 
flame
A, B, C, D
LLL-UV Camera + 
filters
Filtered CH* and 
OH* video of flame A, B, C, D
Spatially resolved 
soot volume fraction C only
HiBMS imaging + 
laser illumination Density Imaging 
(desired) A, B, C, D
Thermocouple Burner temperature D only
TFP array 
(or substitute sensor)
Temperature field 
above flame A, B, C, D 
Operational Constraints
Cannot be operated 
simultaneously with laser￾illuminated sensors
(measurement interference)
Cannot be measured 
simultaneously; both 
require same instrument
Filter swaps limited by 
astronaut availability
Found an issue with 
fibers in field space
~~~~

### Pagina 54

Cita: [pdf_ffdb51438f8e427adc7c, p. 54]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, sparse_text_or_visual_only, tiled_ocr_not_manually_verified.

[Imagen de la pagina](../imagenes/pdf_ffdb51438f8e427adc7c/p0054.jpg)

~~~~text
Additional Requirements
Gas phase temperature
Soot accumulation
~~~~

### Pagina 55

Cita: [pdf_ffdb51438f8e427adc7c, p. 55]. Metodo: native.

~~~~text
Operation Sequence
* Time and total reflect correspond to fuel usage, actual runtime will be longer
Voltage Sweep Time
-Prepare Chamber 0 sec.
-Initiate experiment 15 sec.
-Measurements 160 sec.
-Check for system errors
-Proceed to next test condition
Total*: 175 sec.
Voltage Step
-Prepare Chamber 0 sec.
-Initiate experiment 15 sec.
-Measurements 48 sec.
-Check for system errors
-Proceed to next test condition
Total*: 63 sec.
Soot and liftoff control
-Prepare Chamber 0 sec.
-Initiate experiment 15 sec.
-Measurements 38 sec.
-Check for system errors
-Proceed to next test condition
Total*: 53 sec.
~~~~

### Pagina 56

Cita: [pdf_ffdb51438f8e427adc7c, p. 56]. Metodo: native.

~~~~text
Test Matrix
Total (CH4+C2H4): 96/194
Fuel Burner Test type Tests (req/des)
CH4 50/108
Jet Sweep 12/28
Step 12/20
Control 2/2
Total 26/68
Co-flow Sweep 12/20
Step 8/20
Control 4/0
Total 24/40
C2H4 46/86
Jet Sweep 12/28
Step 12/12
Control 2/2
Total 26/42
Co-flow Sweep 8/24
Step 8/20
Control 4/0
Total 20/44
~~~~

### Pagina 57

Cita: [pdf_ffdb51438f8e427adc7c, p. 57]. Metodo: native.

~~~~text
Success Criteria
OBJECTIVE Minimum Criteria Complete Criteria (additional to 
Minimum)
Superior Criteria
(additional to Complete)
A
VI curve for 
undiluted CH4 on a 
single burner. 
Capture color 
images
Obtain VI curve for both fuels with 
varying dilution for one jet diffusion 
and the coflow flame. 
Obtain thermal field 
information for the gas jet 
or coflow flame to visualize 
ion driven wind
B
Obtain step-response VI curve for 
undiluted CH4 on a single burner. 
Capture transient color images
Obtain step-response VI 
curves for both fuels with 
varying dilution for one jet 
diffusion and the coflow 
flame. 
C
Measure soot luminosity 
(radiometer measurement) as a 
function of applied voltage during 
VI sweeps and step changes 
Obtain spatially resolved 
soot volume fraction for 
relevant conditions.
D
Capture flame images from co-flow 
burner during voltage sweep to 
allow measurement of liftoff height 
in relation to electric field strength
Demonstrate control of 
flame near sooting and 
stability limits. Evaluate the 
extent to which stability 
limits can be extended 
using an electric field
~~~~

### Pagina 58

Cita: [pdf_ffdb51438f8e427adc7c, p. 58]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Post Flight Data Analysis
• Evaluate conditions in real-time; select 
appropriate repeat tests
• COMSOL model with idealized 
assumptions
• Simple algebraic expressions
475 K
410 K
315 K
350 K
Position (m)
~~~~

### Pagina 59

Cita: [pdf_ffdb51438f8e427adc7c, p. 59]. Metodo: native.

~~~~text
Summary – Potential Interaction
• Chemistry of chemi-ionization added to 
mechanisms
• Burner overlap (jet and co-flow)
• Soot control
• Combustion control
• Flame analysis (alternative fuels)
~~~~
