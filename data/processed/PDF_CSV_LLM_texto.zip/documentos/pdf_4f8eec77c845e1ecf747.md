# 21216 test sheets

- Identificador: pdf_4f8eec77c845e1ecf747
- Investigaciones: PSI-159
- Tipo de documento: Raw Data
- Estado: processed
- Temas detectados automaticamente: pressure, ignition, hardware, oxygen, soot

## Fuentes

- [PSI-159_Raw Data_21216 test sheets.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-159/Raw%20Data/PSI-159_Raw%20Data_21216%20test%20sheets.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_4f8eec77c845e1ecf747, p. 1]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_4f8eec77c845e1ecf747/p0001.jpg)

~~~~text
ACME / CFI-G (inverse flame) - Science Test Sheet
est date: | 4 zo | CME test#:
Local time: | est of day #:
MT: | Hot flame of day #:
TEST CONDITIONS | Control? | fully automated 'manual'
Test type? ignition a no-flame | tandard other
Fuel | C2H6 c:] C3H8 | n-C4H10 | 02 bottle: | 85% (volume)
Fuel conc. | O % (vol, nominal) | Burner 02 conc.. | % (volume)
Fuel conc. | % (vol, per calc) | 02 flow rate: | slpm (N2 basis)
hamber pressure: | psia (CIR avg) | ow rate: | slpm
ent before? no {yes, to | psia
Iso just before? o fan GC scrub
FP? uno o fixed moving back-n-forth
INSTRUMENTATION | ain: | DataCam | ops camera
QDataCam: | o BG7 c] CH* CH20 | ROI? | reduced | fps
Intensified: filter? clear CH* VCH20 ü none | ROI?Zfull o reduced | 22 fps
-a-HiBMs: backlight filter? no Kyes | CIR backlight? gno yes fps2-a45-&30 p-e
FLAME BEHAVIOR
Flame hot cool maybe cool | Ignited? yes o no yes, but ...*
Flame o hole/opening partially detached | Soot@ignition none little lots
Flame | scillating unsteady o quasi-stead | 00t@middle none little lots
Out | Xt. detect time out o temp. limit | 00t@end | (none little lots o
POST-TEST CONDITIONS
Fuel conc. | % (vol, per calc) | Chamber pressure: | psia (CIR avg)
alve safety timer | sec | Oxidizer bottle pressure: | psia
*GENERAL COMMENTS
haut-
12 July 2021
~~~~

### Pagina 2

Cita: [pdf_4f8eec77c845e1ecf747, p. 2]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_4f8eec77c845e1ecf747/p0002.jpg)

~~~~text
ACME / CFI-G (inverse flame) - Science Test Sheet
est date: | CME test #: 227CAZ—
Local time: | est of day#: Z.—
ot flame of day #:
Rack Officer (RO): | PD (ACME):
DMO (CIR): | Researcher:
TEST CONDITIONS | Control? | ully automated 'manual'
Test type? o ignition c] no-flam | standard o other
Fuel g C2H6 | C3H8 | n-C4H10 | 02 bottle: | 85% (volume)
Fuel conc. | % (vol, nominal) | Burner 02 conc.: | % (volume)
Fuel conc. | o. B % (vol, per calc) | 02 flow rate: | slpm (N2 basis)
Chamber pressure: | psia (CIR avg) | N2 flow rate: | CD | slpm
ent before? po yes, to | psia
Iso just before? g-fan GC scrub
FP?Éno o fixed moving back-n-forth
INSTRUMENTATION | Gain: | DataCam | ops camera
EDataCam: filter? U-€lear BG7 | CH20 | ROI? dfull reduced | fps
Intensified: filter? o clear o CH* | none | ROI? éfull reduced | fps
• backlight filter? no Oes | CIR | yes | typts
FLAME BEHAVIOR
Flame hot cool c] maybe cool | Ignited? Oes no yes, but
.
Flame hole/opening gpartially detached | 00t@ignition none little lots
Flame Y-oscillating Qunsteady quasi-stead | 00t@middle gnone Cl little a lots
Out Gt. detect time out temp. limit | oot@end | none little lots a
POST-TEST CONDITIONS
Fuel conc. | D. | % (vol, per calc) | Chamber pressure: | psia (CIR avg)
alve safety timer | 67 | sec | Oxidizer bottle pressure: | psia
*GENERAL COMMENTS
12 July 2021
~~~~

### Pagina 3

Cita: [pdf_4f8eec77c845e1ecf747, p. 3]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_4f8eec77c845e1ecf747/p0003.jpg)

~~~~text
ACME / CH-G (inverse flame) - Science Test Sheet
est date: | CME test#: 21 ZE 4
Local time: | est of day
GMT: | ot flame of day #:
Rack Officer (RO): | PD (ACME): | 6
DMO (CIR): | Researcher:
TEST CONDITIONS | Control? | Afully automated 'manual'
Test type? ignition o no-flame gstandard other
Fuel | C2H6 üC3H8 on-C4H10 | 02 bottle: | 85% (volume)
Fuel conc. | % (vol, nominal) | Burner 02 conc.. | % (volume)
Fuel conc. | % (vol, per calc) | 02 flow rate: | slpm (N2 basis)
Chamber pressure: -44 psia (CIR avg) | ow rate: | slpm no
2—
before? | ED
ent | kno yes, to | psia
Iso just before? | fan o GC D scrub
FP?Eno ü fixed Cl moving back-n-forth
INSTRUMENTATION | Gain: | DataCam ÄLops camera
ÉDataCam: filter? yclear BG7 CH* CH20 | ROI?Kfull o reduced | fps
Elntensified: filter? clear o CH*kCH20 none | ROI? afull reduced | fps
Z-HiBMs: backlight filter? noß-yes | CIR backlight?zno yes fps?-g-1-5-g-30
FLAME BEHAVIOR
Flame | ot o cool o maybe cool | Ignited? yes c] no o yes, but .
Flame D hole/opening | artially detached | 00t@ignition none o littl | lots
Flame oscillating unsteady quasi-stead | SOOt@middIe none little lots
Out ext. detect time out temp. limit | oot@end | none little lots
POST-TEST CONDITIONS
Fuel conc. | % (vol, per calc) | Chamber pressure: | zpsia (CIR avg)
alve safety timer | sec | Oxidizer bottle pressure: | psia
*GENERAL COMMENTS
5melce_
t,Q'z7
12 July 2021
~~~~

### Pagina 4

Cita: [pdf_4f8eec77c845e1ecf747, p. 4]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_4f8eec77c845e1ecf747/p0004.jpg)

~~~~text
ACME / CFI-G (inverse flame) - Science Test Sheet
est date: | CMEtest#:
Local time: | est of day #:
MT: | ot flame of day #:
Rack Officer (RO): | A | PD (ACME):
DMO (CIR): | Researcher:
TEST CONDITIONS | Control? | Kfully automated c] 'manual'
Test type? ignition no-flame *standard other
Fuel *-C2H6 | C3H8 c] n-C4H10 | 2 bottle: | 85% (volume)
Fuel conc. | % (vol, nominal) | Burner 02 conc.: | % (volume
Fuel conc. | % (vol, per calc) | 02 flow rate: | slpm (N2 basis)
Chamber pressure: | psia (CIR avg) | N 2 flow rate: | slpm
2
ent before? no yes, to | psia
Iso just before? | fan o GC o scrub
no fixed moving back-n-forth
INSTRUMENTATION | ain: 337 DataCam | camera
ADataCam: filter? ßclear D BG7 | CH20 | ROI Wull D reduced | fps
y-Intensified: filter? o clear o | none | full o reduced | fps
æ-HiBMs•: backlight filter? no | es | CIR backlight? Äno yes jps?æ45-g-30
FLAME BEHAVIOR
Flame | ot o cool o maybe cool | Ignited? yes no c] yes, but
..
Flame hole/openin | partially detached | 00t@ignition c] none little lots
Flame oscillating Efunsteady o quasi-stead | Soot@middle none c] little lots
ut ext. detect time out temp. limit | 00t@end | none little lots
POST-TEST CONDITIONS
Fuel conc. | % (vol, per calc) | Chamber pressure: | psia (CIR avg)
eeC_
alve safety timer | sec | Oxidizer bottle pressure: | psia
*GENERAL COMMENTS
hal+-
12 July 2021
~~~~

### Pagina 5

Cita: [pdf_4f8eec77c845e1ecf747, p. 5]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_4f8eec77c845e1ecf747/p0005.jpg)

~~~~text
ACME / CFI-G (inverse flame) - Science Test Sheet
est date: | 74 | CME test #: 2Ä7--lC
Local time: | est of day
GMT: | ot flame of day#:
TEST CONDITIONS | Control ? | kfully automated 'manual'
Test type? ignition o no-flame *tandard c] other
Fuel | 2H6 | C3H8 | n-C4H10 | 02 bottle: | 85% (volume)
Fuel conc. | -v[ü/o (vol, nominal) | Burner 02 conc.. | % (volume
Fuel conc. | /D.3D % (vol, per calc) | 02 flow rate: | O. | slpm (N2 basis)
Chamber pressure: 442-psia (CIR avg) eer N2 flow rate: | slpm
ent before? Eno o yes, to | psia
Iso just before? p-fan GC scrub
fixed moving back-n-forth
INSTRUMENTATION | ain: | Datacam | camera
DataCam: filter? #-clear BG7 | CH20 | ROI? Afull reduced | fps
9-lntensified: filter? clear CH* €-CH2Q none | ROI? •full reduced | 2-3 fps
n-HiBMs.• backlight filter? noxyes | CIR backlight. no yes
FLAME BEHAVIOR
Flame hot cool maybe cool | Ignited? ye | no yes, but ...*
Flame hole/opening partially detached | 00t@ignition none little lots ü
Flame c] oscillating unsteady quasi-stead | 00t@middle none little lots
ut ext. detect time out o temp. limit | oot@end | none little c:] lots
POST-TEST CONDITIONS
Fuel conc. | Z % (vol, per calc) | hamber pressure: | Z psia (CIR avg)
alve safety timer | sec | Oxidizer bottle pressure: i-2>?- psia
*GENERAL COMMENTS
12 July 2021
~~~~

### Pagina 6

Cita: [pdf_4f8eec77c845e1ecf747, p. 6]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_4f8eec77c845e1ecf747/p0006.jpg)

~~~~text
ACME / CFI-G (inverse flame) - Science Test Sheet
est date: | Ze 24 | CME test#:
Local time: | est of day #:
GMT: | 21 Z/ | 74253 | Hot flame of day #:
Rack Officer (RO): | PD (ACME): | 6 -
DMO (CIR): | Researcher:
TEST CONDITIONS | Control? | K.fully automated 'manual'
Test type? ignition o no-flame {standard other
Fuel ÉC2H6 oC3H8 an-C4H10 | 02 bottle: | 85% (volume)
Fuel conc. | % (vol, nominal) | Burner 02 conc.: | % (volume
Fuel conc. | 0 | % (vol, per calc) | 02 flow rate: | slpm (N2 basis)
hamber pressure: | Z- psia (CIR avg) | rate: | slpm
ent before? no yes, to | psia
Iso just before? | fan GC scrub
FP?Æ no fixed moving back-n-forth
INSTRUMENTATION | Gain: | DataCam | ops camera
filter? *clear BG7 CH* CH20 | ROI? Efull o reduced | fps
«p-lntensified: filter? clear c] | CH20 none | ROI? Efull o reduced | Z fps
crHtßMs: backlight filter? no yes | CIR | yes fps?-a45-s-30
FLAME BEHAVIOR
c] cool D maybe cool | Ignited? Kyes no yes, but *
...
Flame hole/opening€partially detached | 00t@ignition none c] littlsé
Flame oscillating | nsteady o quasi-stead | 00t@middle none little c-_1 lots
Out ext. detect | ime out c] temp. limit | 00t@end | (none little lots
POST-TEST CONDITIONS
Fuel conc. | ö Z | 0/0 (vol, per calc) | Chamber pressure: | -2-psia (CIR avg)
alve safety timer | 7 | sec | Oxidizer bottle pressure: | psia
*GENERAL COMMENTS
(/c/es9
A-I
12 July 2021
~~~~

### Pagina 7

Cita: [pdf_4f8eec77c845e1ecf747, p. 7]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_4f8eec77c845e1ecf747/p0007.jpg)

~~~~text
ACME / CFI-G (inverse flame) - Science Test Sheet
est date: | zoa I | CME test#: Z/ ZI'
Local time: | est of day #:
MT: | ot flame of day #:
Rack Officer (RO): | PD (ACME):
DMO (CIR): | Researcher:
TEST CONDITIONS | ontrol? | "fully automated 'manual'
Test type? ignition Cl no-flame standardAother
Fuel | C2H6 | C3H8 | n-C4H10 | 2 bottle: | 85% (volume)
Fuel conc. | % (vol, nominal) | Burner 02 conc.: | •3 | % (volume)
Fuel conc. | % (vol, per calc) | 02 flow rate: | O | slpm (N2 basis)
hamber pressure: | ZZ-psia (CIR avg) | te: | slpm
ent before? | o o yes, to | psia
Iso just before? f-fan GC a scrub
FP? no {fixed o moving o back-n-forth
INSTRUMENTATION | Gain: C) DataCam | ops camera
DataCam: filter? Éclear o BG7 0 CH* o CH20 | ROI?.Å full reduced | fps
Antensified: filter? o clear | none | a reduced | 23 fps
ZHiBMs.• backlight filter? no myes | CIR backlight? ecno yes
FLAME BEHAVIOR
Flame hot cool maybe cool | Ignited? Ayes no c] yes, but
.
Flame hole/opening c] partially detached | 00t@ignition none little"lots
Flame RI-oscillating | quasi-stead | Soot@middle d none little lots
ut $ext. detect time out a temp. limit | 00t@end | Gone little lots
POST-TEST CONDITIONS
psia (CIR avg) 64)
*GENERAL COMMENTS
12 July 2021
~~~~

### Pagina 8

Cita: [pdf_4f8eec77c845e1ecf747, p. 8]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_4f8eec77c845e1ecf747/p0008.jpg)

~~~~text
ACME / CFI-G (inverse flame) - Science Test Sheet
est date: | 202) | CME test#:
Local time: | est of day#:
GMT: | ot flame of day #:
Rack Officer (RO): | PD (ACME):
DMO (CIR): | Researcher:
TEST CONDITIONS | Control? | fully automated 'manual'
Test type? ignition o no-flamed standard other
Fuel 'Q C2H6 | C3H8 | n-C4H10 | 02 bottle: | 85% (volume)
Fuel conc. | % (vol, nominal) | Burner 02 conc.: | D % (volume
Fuel conc. | D, | % (vol, per calc) | 02 flow rate: | slpm (N2 basis)
Chamber pressure: 4 | psia (CIR | N 2 flow rate: | slpm
ent before? n | yes, to | psia
Iso just before? | fan GC scrub
FP?Ano c] fixed moving back-n-forth
INSTRUMENTATION | ain: | DataCam | ops camera
•dDataCam: | BG7 | CH20 | ROI? *full a reduced | fps
#-lntensified: filter? o clear CH | CH20 c] none | ROI?bQ full reduced | fps
e-HiBMs: backlight filter? n | yes | CIR backlight?Eno yes f-ps?-e45-Q30
FLAME BEHAVIOR
Flame hot o cool o maybe cool | Ignited? kyes no yes, but ...*
Flame hole/opening<partially detached | 00t@ignition none little lots
Flame Q oscillating Q unsteady quasi-stead | 00t@middle none a little ü lots
ut ext. detect time out o temp. limit | 00t@end (none c] little lots
POST-TEST CONDITIONS
Chamber pressure: | Z- psia (CIR avg)
*GENERAL COMMENTS
Az
12 July 2021
~~~~

### Pagina 9

Cita: [pdf_4f8eec77c845e1ecf747, p. 9]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_4f8eec77c845e1ecf747/p0009.jpg)

~~~~text
ACME / CFI-G (inverse flame) - Science Test Sheet
est date: | zoa | CME test #: | F/
Local time: | est of day #:
MT: | 2) | I | ot flame of day #:
TEST CONDITIONS | Control? | k fully automated 'manual'
Test type? ignition no-flamezstandard other
Fuel | C2H6 | C3H8 | n-C4H10 | 02 bottle: | 85% (volume)
Fuel conc. | % (vol, nominal) | Burner 02 conc.: | +7—5 % (volume)
Fuel conc. | % (vol, per calc) | 02 flow rate: | D slpm (N2 basis
Chamber pressure:v .i5psia (CIR avg) | N2 flow rate: | D, 91 g slpm
ent before?Åno o yes, to | psia
Iso just before? 4fan o GC scrub
FP? no c] fixed moving back-n-forth
INSTRUMENTATION | ain: —Z Datacam EL ops camera
DataCam: | BG7 | CH20 | ROI? < full reduced | fps
Intensified: filter? clear CH*ACH20 none | ROI? Kfull reduced
æ-HiBMS: backlight filter? n | yes | CIR backlight?kno yes fps?-a-ftS-tr30
FLAME BEHAVIOR
Flame hot o cool maybe cool | Ignited? yes no o yes, but .
Flame o hole/opening partially detached | 00t@ignitio | none little o lots
Flame oscillating unsteady quasi-stead | 00t@middle none little lots c]
Out ext. detec time out o temp. limit | 00t@end | 'Znone little lots
POST-TEST CONDITIONS
44,+psia (CIR avg)
*GENERAL COMMENTS
ECF-
12 July 2021
~~~~

### Pagina 10

Cita: [pdf_4f8eec77c845e1ecf747, p. 10]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_4f8eec77c845e1ecf747/p0010.jpg)

~~~~text
ACME / CFI-G (inverse flame) - Science Test Sheet
est date: | 202-1 | CME test#:
Local time: | est of day#: | D
MT: | 20 | ot flame of day #:
Rack Officer (RO): | PD (ACME):
DMO (CIR): | Researcher:
TEST CONDITIONS | Control? | fully automated 'manual'
Test type? a ignition no-flame | other
Fuel kAC2H6 | C3H8 | n-C4H10 | 02 bottle: | 85% (volume)
Fuel conc. | % (vol, nominal) | Burner 02 conc.: | 8 | % (volume
Fuel conc. | i | % (vol, per calc) | 02 flow rate: | slpm (N2 basis
,
Chamber pressure: | psia (CIR avg) | rate: | slpm
ent before? o n | yes, to | psia
Iso just before? | fan GC scrub
FP?Sno fixed moving o back-n-forth
INSTRUMENTATION | ain: 33 DataCam | ops camera
DataCam: filter? g-clear o BG7 CH* ü CH20 | ROI? | reduced | fps
Wlntensified: filter? clear CH* | none | ROI? é-full o reduced | fps
-g-HiBMs: backlight filter? c] no Eyes | CIR backlight? "no yes fps.?-g45-g30—
FLAME BEHAVIOR
Flame hot cool maybe cool | Ignited? yes no o yes, but ...*
Flame hole/opening | rtially detached | 00t@ignition none little lots
Flam | scillating Wunsteady | 00t@middle k none little o lots
ut ext. detect time out CJ temp. limit | 00t@end | Knone little lots
POST-TEST CONDITIONS
Fuel conc. | % (vol, per calc) | Chamber pressure: | psia (CIR avg)
alve safety timer | sec | Oxidizer bottle pressure: | psia
*GENERAL COMMENTS
12 July 2021
~~~~

### Pagina 11

Cita: [pdf_4f8eec77c845e1ecf747, p. 11]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_4f8eec77c845e1ecf747/p0011.jpg)

~~~~text
ACME / CFI-G (inverse flame) - Science Test Sheet
est date: | CME test#:
Local time: | est of day #:
GMT: | 2-1 | ot flame of day#: D
TEST CONDITIONS | Control? | Åfully automated 'manual'
Test type? ignition no-flame Qstandard o other
Fuel nC2H6 0 C3H8 | n-C4H10 | 02 bottle: | 85% (volume)
Fuel conc. | % (vol, nominal) | Burner 02 conc.: | % (volume
Fuel conc. | O | % (vol, per calc) | 02 flow rate: | slpm (N2 basis)
Chamber pressure: | psia (CIR avg) | N2 flow rate: | slpm
ent | yes, to | psia
ISO just before? Lfan GC c] scrub
o o fixed o moving back-n-forth
INSTRUMENTATION | Gain: | DataCam | ops camera
LDataCam: filter? Kclear o BG7 CH* c] CH20 | ROI?kfull o reduced | fps
*Intensified: filter? clear CH* XCH20 none | ROI? Afull reduced | 2-3 fps
E-HiBM*backlight filter? no.Qes | CIR backlight.
FLAME BEHAVIOR
Flame | cool maybe cool | Ignited Bu yes no c] yes, but ..
Flame c] hole/openingÅpartially detached | 00t@ignition ü none ü little lots
Flame oscillating (unsteady quasi-stead | 00t@middle 'none D little o lots
Out Yæxt. detect time out temp. limit | 00t@end | D little lots
POST-TEST CONDITIONS
psia (CIR avg) fffcD
*GENERAL COMMENTS
12 July 2021
~~~~

### Pagina 12

Cita: [pdf_4f8eec77c845e1ecf747, p. 12]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_4f8eec77c845e1ecf747/p0012.jpg)

~~~~text
ACME / CFI-G (inverse flame) - Science Test Sheet
est date: | zoa | CMEtest#:
Local time: | est of day #: t Z.—
GMT: | ot flame of day#: I
TEST CONDITIONS | Control? | @fully automated o 'manual'
Test type? ignition o no-flame Lstandard o other
Fuel QC2H6 | C3H8 | n-C4H10 | 2 bottle: | 85% (volume)
Fuel conc. | A¯/D0/o (vol, nominal) | Burner 02 conc.: | 'vo 0/0 (volume
Fuel conc. | % (vol, per calc) | 02 flow rate: | slpm (N2 basis)
Chamber pressure: | psia (CIR avg) | N 2 flow rate: | 4 | slpm
ent before? | o yes, to | psia
Iso just before? Afan GC scrub
FP? no o fixed o moving back-n-forth
INSTRUMENTATION | Gain: | DataCam | ops camera
VDataCam: filter? Kclear BG7 | CH20 | ROI? Afull a reduced | fps
$lntensified: filter? clear CH*4CH2-Q-D none | full reduced
backlight filter? noCSyes | CIR | yes fps2æ-æs-e-3@
FLAME BEHAVIOR
Flame hot cool maybe cool | Ignited? Zyes no o yes, but ...*
Flame o hole/openin | partially detached | SOOt@ignition o none little lot
Flame oscillating unsteady quasi-stead | 00t@middIe none c] little lots o
ut ext. detect time out temp. limit | SOOt@end | none little lots o
POST-TEST CONDITIONS
Chamber pressure: | psia (CIR avg)
*GENERAL COMMENTS
12 July 2021
~~~~

### Pagina 13

Cita: [pdf_4f8eec77c845e1ecf747, p. 13]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_4f8eec77c845e1ecf747/p0013.jpg)

~~~~text
ACME / CFI-G (inverse flame) - Science Test Sheet
est date: | CME test #:
Local time: | est of day #:
GMT: | ot flame of day#:
TEST CONDITIONS | Control? | *fully automated 'manual'
Test type? o ignition no-flame "tandard c] other
Fuel *C2H6 | C3H8 | n-C4H10 | 2 bottle: | 85% (volume)
Fuel conc. | % (vol, nominal) | Burner 02 conc.: | % (volume)
Fuel conc. | 'SC) % (vol, per calc) | 02 flow rate: | slpm (N2 basis
hamber pressure: | psia (CIR avg) | N 2 flow rate: | slpm
ent before? Y-no yes, to | psia
Iso just before? | fan GC o scrub
FP? åno fixed a moving back-n-forth
INSTRUMENTATION | Gain: 32— Datacam -Zi—ops camera
filter? R_clear a BG7 CH* CH20 | ROI? (full o reduced | fps
filter? o clear CH* k-CH20 none | ROI? | reduced | Z fps
æ-HißMsæbacklight filter? no *yes | CIR backlight? | yes
FLAME BEHAVIOR
Flame hot o cool maybe cool | Ignited? yes no yes, but .
Flame D hole/opening partially detached | 00t@ignition none little c] lots D
Flame oscillating c] unsteady quasi-stead | 00t@middle none little lots D
Out ext. dete | time out o temp. limit | SOOt@end | Knone D little o lots
POST-TEST CONDITIONS
psia (CIR avg)
/Æel
*GENERAL COMMENTS
Pr—bö/Ls | b +
50
12 July 2021
~~~~
