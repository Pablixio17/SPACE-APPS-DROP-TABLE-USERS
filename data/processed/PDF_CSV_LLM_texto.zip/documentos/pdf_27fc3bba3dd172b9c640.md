# BASS_SysAcceptanceReview.2

- Identificador: pdf_27fc3bba3dd172b9c640
- Investigaciones: PSI-26
- Tipo de documento: Engineering Documents
- Estado: processed
- Temas detectados automaticamente: hardware, operations, solid_materials, pressure, microgravity, extinction, soot, smoke_detection, computational_models

## Fuentes

- [PSI-26_Engineering Documents_BASS_SysAcceptanceReview.2.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-26/Engineering%20Documents/PSI-26_Engineering%20Documents_BASS_SysAcceptanceReview.2.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Pasajes de orientacion (extractivos, no resumen validado)

### conclusion - pagina 35

CONCLUSION
The hardware developed to support the SLICE 
and BASS payloads has been designed, tested, 
and verified using approved processes resulting in 
what is expected to be highly successful 
operations.
6/16/2010 35

### objective - pagina 13

objectives. I have interacted regularly with Dennis
Stocker regarding the hardware and I feel the experiments have a high probability of
success. The SLICE results will enable refinement of the future CLD Flame test matrix
and allow for a preliminary assessment of our numerical codes' ability to characterize
lifted flames in a microgravity environment.
Please let me know ifl can provide additional material conceming your review.
Sincerely,
Marshall B. Long
Professor of Mechanical Engineering
Professor of Applied Physics
6/16/2010 | 13

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_27fc3bba3dd172b9c640, p. 1]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
SLICE/BASS
SYSTEM ACCEPTANCE REVIEW (SAR-2) 
June 18, 2010
Prepared For:
National Aeronautics and Space Administration
John H. Glenn Research Center at Lewis Field
Microgravity Science Division
Cleveland, Ohio 44135
Prepared By:
ZIN Technologies, Incorporated
6745 Engle Road
Middleburg Hts, Ohio 44130
~~~~

### Pagina 2

Cita: [pdf_27fc3bba3dd172b9c640, p. 2]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
SLICE/BASS SAR-2 Agenda
• Introduction
• SLICE Hardware/Science Overview, Requirements, PI Endorsement
• SLICE Verification Testing & Status, and Operations Overview
• SLICE Open Work
• BASS Hardware/Science Overview, Requirements, PI Endorsement
• BASS Verification Testing & Status and Operations Overview
• BASS Open Work
• SAR-1 Board Assessment (Jim Cockrell)
• ZIN Quality Assessment (Debra Lyden)
• GRC S&MA Assessment (Bipin Patel)
• SAR-2 Board Discussion (Pete McCallum)
6/16/2010 2
~~~~

### Pagina 3

Cita: [pdf_27fc3bba3dd172b9c640, p. 3]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
SAR-2 Review Board
Board Member Responsibility
Peter McCallum Board Chair
Glen Horvat Engineering
Bhim Singh Research
Frank Greco Safety/Quality Assurance
6/16/2010 3
~~~~

### Pagina 4

Cita: [pdf_27fc3bba3dd172b9c640, p. 4]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
SLICE/BASS Project Team
Project Manager Responsibility
Robert Hawersaat GRC Project Manager
Paul Ferkul BASS Principal Investigator
Sandra Olson BASS Co-Investigator
James Tien BASS Co-Investigator
Fumi Takahashi BASS/SLICE Co-Investigator
Marshall Long SLICE Principal Investigator
Mitch Smooke SLICE Co-Investigator
Dennis Stocker SLICE Co-Investigator
Jay Owens Imaging/Optics
Mike Johnston Research Assistant
Tibor Lorik ZIN Project Lead
Chuck Bunnell Mechanical/Operations
Chris Bodzioney/Debra Lyden Safety
Chris Dixon Mechanical Designer
Kevin Dendorfer Technician
Jim Bruewer Mechanical Engineer
6/16/2010 4
~~~~

### Pagina 5

Cita: [pdf_27fc3bba3dd172b9c640, p. 5]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
System Acceptance Review Purpose
Obtain Executive Board Assessment on the 
acceptability of the SLICE and BASS hardware to 
proceed with shipment for STS-133/Flight ULF-5 
MPLM scheduled for launch in September 2010.
6/16/2010 5
~~~~

### Pagina 6

Cita: [pdf_27fc3bba3dd172b9c640, p. 6]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
SLICE HARDWARE OVERVIEW
• SLICE will utilize the SPICE hardware currently on ISS.
– Experiment Assembly, Cables, Control Box, Video Camera.
• SLICE will refurbish the SPICE Gas Bottles for re-flight.
• SLICE will design, fab, assemble, test new hardware.
– 2.1 mm and 3.2 mm burner tubes
– Upgraded Nikon Still Camera
– Blue-Green Filter
– Ceramic Pyrometry Fiber
6/16/2010 6
~~~~

### Pagina 7

Cita: [pdf_27fc3bba3dd172b9c640, p. 7]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_27fc3bba3dd172b9c640/p0007.jpg)

~~~~text
Hardware Overview Configuration
ZIN Technologies, Inc.
60054MAFH080
EXPERIMENT
60054EAFH007
ASSEMBLY | J22
CONTROL BOX
60054MAFHOOO
J21
p21
60054EAFH006
P12 | PII
SHUTTER
P31 | PAI | J12 | Jll
J31 | J41
VIDEO | STILL | VIDEO
CAMERA | CAMERA | UNIT | UNIT
60054MAFHIO | 0054MAFH45
MONITOR
J32 | J42 | J16 | J15
CL
P32 | p 42
LINE IN | JIA | J17
p17
04
VIDEO OUT
P303
S-VIDEO (F)
VCR
S-VIDEO | GLOVEBOX
(R)
POWER
SUPPLY
6/16/2010 | 7
~~~~

### Pagina 8

Cita: [pdf_27fc3bba3dd172b9c640, p. 8]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, sparse_text_or_visual_only, tiled_ocr_not_manually_verified.

[Imagen de la pagina](../imagenes/pdf_27fc3bba3dd172b9c640/p0008.jpg)

~~~~text
SPICE ON-ORBIT IN MSG
ZIN Technologies, Inc.
1.1
ISS019E017336
6/16/2010
~~~~

### Pagina 9

Cita: [pdf_27fc3bba3dd172b9c640, p. 9]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
SLICE HARDWARE OVERVIEW
6/16/2010 9
Gas Bottles in Case (1 of 2) Experiment Assembly
Gas Bottle (1 of 12) Control Box
Video Camera
Ignitor/Burner Case
~~~~

### Pagina 10

Cita: [pdf_27fc3bba3dd172b9c640, p. 10]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
SLICE HARDWARE OVERVIEW
(NEW)
6/16/2010 10
Burner Tube (2.1 mm & 3.2 
mm) Ceramic Pyrometry Fiber
D300s Still Camera LEXAN Window
~~~~

### Pagina 11

Cita: [pdf_27fc3bba3dd172b9c640, p. 11]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_27fc3bba3dd172b9c640/p0011.jpg)

~~~~text
SLICE HARDWARE
OVERVIEW
ZIN Technologies, Inc.
Gas Bottle Assemblies
Part #
Full Name | Fuel Bottle Label/FueI Type &
Percentage
(all pressures are at 1 70C)
SPICE Gas Bottle
Assembly 1 | El/Ethylene 100% @210 psia | 60054MAFH090-1
SPICE Gas Bottle
Assembly 2 | E2/Ethylene 20%, Diluent GN2 @ 210 psia | 60054MAFH090-2
SPICE Gas Bottle
Assembly 3 | E3/Ethylene 20%, Diluent GN2 @ 210 psia | 60054MAFH090-3
SPICE Gas Bottle
Assembly 4 | MI/Methane 100% @ 210 psia | 60054MAFH090-4
SPICE Gas Bottle
Assembly 5 | M2/Methane 100% @ 210 psia | 60054MAFH090-5
SPICE Gas Bottle
Assembly 6 | M3/Methane 100% @ 210 psia | 60054MAFH090-6
SPICE Gas Bottle
Assembly 7 | M4/ Methane 70%, Diluent GN2 | 210 | 60054MAFH090-7
@ | psia
SPICE Gas Bottle
Assembly 8 | M5/ Methane 70%, Diluent GN2 | 210 | 60054MAFH090-8
@ | psia
SPICE Gas Bottle
Assembly 9 | M6/ Methane 40%, Diluent GN2 | 210 | 60054MAFH090-9
@ | psia
SPICE Gas Bottle
Assembly 10 | M7/ Methane 40%, Diluent GN2 @ 210 | 60054MAFH090-10
psia
SPICE Gas Bottle
Assembly 1 1 | Pl/Propane 100% @ 110 psia | 60054MAFH090-11
SPICE Gas Bottle
Assembly 12 | Ethane 100% @ 210 psia | 60054MAFH090-12
6/16/2010
11
~~~~

### Pagina 12

Cita: [pdf_27fc3bba3dd172b9c640, p. 12]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
SLICE SUCCESS CRITERIA
• Minimum Success -– Still images are acquired for at least 15 
different lifted flames with different combinations of fuel flow and air 
velocity with a single fuel, or at least 10 different lifted flames each 
of two fuels, or at least 5 different lifted flames each of 3 or more 
fuels. 
• High Success -– Still images are acquired of at least 30 different 
lifted flames total from at least 3 different fuels. The still images are 
acquired with a blackbody characterized camera for soot pyrometry
or liftoff limits are determined for at least one fuel.
• Complete Success -– Testing conducted with all 12 fuel bottles, with 
identification of stability limits and smoke points (within the range of 
the SPICE velocity limits). Still images are taken of lifted flames with 
a blackbody characterized camera.
6/16/2010 12
~~~~

### Pagina 13

Cita: [pdf_27fc3bba3dd172b9c640, p. 13]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_27fc3bba3dd172b9c640/p0013.jpg)

~~~~text
SLICE | Pl | Endorsement
ZIN Technologies, Inc.
Yale University | Mechanical
Department of | Engineering
P.O. Box 208284
New Haven, Connecticut 06520-8284
Phone: (203) 432-4229
FAX: (203) 432-6775
email: marshall.long@yale.edu
May 19, 2010
Robert W. Hawersaat
SLICE Project Manager
NASA Glenn Research Center
Cleveland, Ohio 44135
Dear Bob:
I am writing to confirm that the SLICE flight hardware meets the design specifications
originally posed to achieve the science objectives. I have interacted regularly with Dennis
Stocker regarding the hardware and I feel the experiments have a high probability of
success. The SLICE results will enable refinement of the future CLD Flame test matrix
and allow for a preliminary assessment of our numerical codes' ability to characterize
lifted flames in a microgravity environment.
Please let me know ifl can provide additional material conceming your review.
Sincerely,
Marshall B. Long
Professor of Mechanical Engineering
Professor of Applied Physics
6/16/2010 | 13
~~~~

### Pagina 14

Cita: [pdf_27fc3bba3dd172b9c640, p. 14]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
SLICE PRODUCT VERIFICATION TESTING
• D300s Still Camera
– Functional Test
– Soft Stow Vibration per 60054-TST-007 - Complete
– Radiated Emissions Test – RE02 – Complete
• The original plan was to use similarity of design from the original camera however the EME 
panel on 5/13/10 informed the project that it will be required to perform a radiated emissions 
test.
– Thermal Operating Test per 60054-TST-009 – Complete
• 4 cycles from 10 to 45 ˚C
– Materials Bake-out for 72 hours at 120 ˚F – Complete
• The SPICE off-gas testing using the similar D100 camera as well as all other SPICE hardware 
has a total T value of 0.001152. Using this value for just the new BASS D300s camera will 
provide sufficient margin as well as allow the payload to remain below the 0.5 limit.
– Black Body Calibration and Focus Setup using Replacement Top Window. – 6/17/10
• Burner Tubes
– Perform dimensioning calibration - Complete
• Replacement Top Window
– Soft Stow Vibration per 60054-TST-007 - Complete
– Anneal at 250˚F for 1 hour - Complete
– Materials Bake-out for 72 hours at 120 ˚F - Complete
6/16/2010 14
~~~~

### Pagina 15

Cita: [pdf_27fc3bba3dd172b9c640, p. 15]. Metodo: native.

Calidad: figures_not_digitized, table_structure_not_manually_validated.

~~~~text
SLICE PRODUCT VERIFICATION TESTING
• Ceramic Pyrometry Fiber
– Soft Stow Vibration per 60054-TST-007 – Complete
• Engineering Vibe Test passed
• Gas Bottles
– Soft Stow Vibration per 60054-TST-007 – Complete
– Pre and Post Vibe Helium Leak Test – Complete
– Fill per Table above – Complete
6/16/2010 15
~~~~

### Pagina 16

Cita: [pdf_27fc3bba3dd172b9c640, p. 16]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
SAFETY VERIFICATIONS
• SLICE is designated as a SPICE re-flight.
• Out of Board Approval is expected once 
verifications are closed.
• 77 Safety Verifications
– 59 Closed Verifications
– 14 Crew Procedure Controls – Procedures are being 
developed – 8/10
– 2 EMI TIA Approval for D300s Camera – 7/10
– 1 HFIT Inspection at turnover – 6/23/10
– 1 Stowage Configuration Verification – 7/10/10
6/16/2010 16
~~~~

### Pagina 17

Cita: [pdf_27fc3bba3dd172b9c640, p. 17]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
INTEGRATION VERIFICATIONS
• Utilize SPICE ICD as a baseline for the integration 
requirements with MSG.
• New verifications not addressed in the safety 
verifications include the following:
– Fit Check for D300s Still Camera in MSG EU – Complete
– Still Camera Video Interface Test in MSG EU - Complete
– Labeling – Complete @ KSC
• Physical and Functional Interface testing in the MSG 
EU with the new camera were successful.
• Modified SPICE crew procedures were dry run to 
evaluate their status. Other than minor tweaks the 
procedures are adequate. 
6/16/2010 17
~~~~

### Pagina 18

Cita: [pdf_27fc3bba3dd172b9c640, p. 18]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
SCHEDULE HIGHLIGHTS (Open Work)
• All hardware assembly and test is complete!
• Verification Closures are still in process as noted
• Hardware Turnover @KSC – 6/24/10
• Bench Review – 7/8/10
6/16/2010 18
~~~~

### Pagina 19

Cita: [pdf_27fc3bba3dd172b9c640, p. 19]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
SLICE OPEN NCR Status
• Radiated Emissions Exceedence of the D300s 
Camera.
– NCR will close upon receiving an approved TIA.
• Failure of the D300s camera during thermal 
testing.
– Closure will not occur until hardware is returned to the 
vendor for failure analysis and repair.
6/16/2010 19
~~~~

### Pagina 20

Cita: [pdf_27fc3bba3dd172b9c640, p. 20]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
SAR-1 Concerns & Issues
• As-Built inspections of flight hardware was scheduled after the originally scheduled 
SAR-2 on 6/11/10.
– The as-built inspections have been completed. DD250 is in the process of being generated 
with the planned turnover to GRC at 3 PM today, 6/18/10.
• Stowage Configuration Drawings to close safety verification showing proper stow of 
the hardware will be finalized at the Bench Review scheduled for 7/8/10.
– The PD will obtain the drawings once the updates have been made and include them in a 
memo to close the verification.
• The D300s Camera completed EMI testing with the final results provided to MSG and 
the EME panel. Due to some small exceedances from the requirement the payload 
generated an NCR. MSG is generating a TIA to submit to the EME panel for 
approval. Approval is expected.
• Crew Procedures are in draft form and are not planned to be completed until after 
SAR-2.
– Crew procedures will be reviewed to include required safety controls. Operations will not be 
conducted until these safety verifications have been closed.
6/16/2010 20
~~~~

### Pagina 21

Cita: [pdf_27fc3bba3dd172b9c640, p. 21]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
BASS HARDWARE OVERVIEW
• BASS will utilize the SPICE hardware currently on 
ISS.
– Experiment Assembly, Cables, Video Camera
• BASS will utilize the SLICE Still Camera.
• BASS will design, fab, assemble, test new 
hardware.
– Modified 3.2 mm burner tube
– GN2 Hose Assembly
– Sample Frame Assembly Insert for Experiment Assembly
– 4 different fuel holder designs for a total of 41 fuel samples
– BASS Control Box
– Fan Flow Block Assembly
– Ignitor Wire Extension Assembly
6/16/2010 21
~~~~

### Pagina 22

Cita: [pdf_27fc3bba3dd172b9c640, p. 22]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_27fc3bba3dd172b9c640/p0022.jpg)

~~~~text
BASS HARDWARE OVERVIEW
ZIN Technologies, Inc.
CAMERA ASSEMBLY
eoosaMAFH'00J
Experiment Assembly | Video Camera
BASS Control Box
6/16/2010 | 22
~~~~

### Pagina 23

Cita: [pdf_27fc3bba3dd172b9c640, p. 23]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
BASS HARDWARE OVERVIEW
(NEW)
6/16/2010 23
Burner Tube (3.2 mm 
Modified) Sample Frame Assembly
Ignitor Assembly
GN2 Hose
Assembly
~~~~

### Pagina 24

Cita: [pdf_27fc3bba3dd172b9c640, p. 24]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
BASS HARDWARE OVERVIEW
(NEW)
6/16/2010 24
SPHERE & HEMISPHERE SAMPLE ASSEMBLY 
(1 CM & 2 CM DIAMETER PMMA)
FLAT SAMPLE ASSEMBLY (1 CM 
& 2 CM WIDE)
~~~~

### Pagina 25

Cita: [pdf_27fc3bba3dd172b9c640, p. 25]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
BASS HARDWARE OVERVIEW
(NEW)
THICK FLAT SAMPLE 
ASSEMBLY (PMMA & WAX)
WAX-IMPREGNATED WICK SAMPLE ASSEMBLY
(JAPAN WAX & PARAFFIN)
6/16/2010 25
~~~~

### Pagina 26

Cita: [pdf_27fc3bba3dd172b9c640, p. 26]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, sparse_text_or_visual_only, table_structure_not_manually_validated, tiled_ocr_not_manually_verified.

[Imagen de la pagina](../imagenes/pdf_27fc3bba3dd172b9c640/p0026.jpg)

~~~~text
BASS LAYOUT IN MSG
ZIN Technologies, Inc.
6/16/2010 | 26
~~~~

### Pagina 27

Cita: [pdf_27fc3bba3dd172b9c640, p. 27]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
BASS SUCCESS CRITERIA
• Minimal Success: 20 total tests including: eight tests 
with flat samples (four materials at two different flow 
speeds); four tests with spherical PMMA samples 
(four different flow speeds with nitrogen 
extinguishment); four tests with candles (four 
different flow speeds with nitrogen extinguishment); 
and four tests of PMMA wake flames (four different 
flow speeds with nitrogen extinguishment). 
• Complete Success: 60 flames as indicated in test 
matrix.
6/16/2010 27
~~~~

### Pagina 28

Cita: [pdf_27fc3bba3dd172b9c640, p. 28]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_27fc3bba3dd172b9c640/p0028.jpg)

~~~~text
BASS | PI | Endorsement
ZIN Technologies, Inc.
NATIONAL
CENTER
FOR
SPACE
EXPLORATION
RESEARCH
NCSER
FLUIDS AND
May 18, 2010
Mr. Robert Hawersaat
BASS Project Manager
NASA Glenn Research Center
Cleveland, Ohio 44135
Dear Bob,
This letter is to infonn you that the BASS experimnent apparatus designed and built by the
engineering team meets the science requirements specific to the hardw•are as stated in the SRD.
The hardware relies upon use of the existing SPICE experirnent (already on orbit). There were a
nu.rnber of challenges which the engineering tearn was able to overcorne, and I cornrnend thern
for achieving the objectives while constrained by a very tight schedule. Our weekly rueetings
with Tibor Lorik and the rest Of the engineering tearn have assured that the hardware was built to
the desired specifications to have the best chance of success of rneeti_ng our science objectives.
The flight hardware design has been functionally tested and verified at GRC, vvith the SPICE
engineering hardware being utilized for some Of these tests. The BASS hardware has perforrnecl
within acceptable tolerances specified by the science requirements and, in my opinion will yield
quality science upon cornpletion of the rernain_ing open work.
Sincerely,
Paul Ferkul
Staff Scientist
Phone: 216-433-8107
Ernail: paul.ferkul@masa.gov
National Center for Space Exploration Research on Fluids and Combustion
ncs er. net | N ASA Glenn
g — 312 | A Research Center of the C&7iversities *ace Research Association
Euclid A | 110-3
Clevelmd, Ohio | Ohio 44135
Tel: | 3«-0748 | USRA | T A: (216)
6/16/2010 | Fax: (216) 308-0718 | Fax: (216) 4.30-3;V3 | 28
~~~~

### Pagina 29

Cita: [pdf_27fc3bba3dd172b9c640, p. 29]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
BASS PRODUCT VERIFICATION TESTING
• Sample Frame Assembly
– Fit Check with Engineering Assembly - Complete
– Soft Stow Vibration per 60054-TST-007 - Complete
– Materials Bake-out for 72 hours at 120 ˚F - Complete
– EMI Test for Magnet Strength - Complete
• Fuel Samples Assembly (41 flight units)
– Fit Check with Engineering Assembly - Complete
– Soft Stow Vibration per 60054-TST-007 - Complete
• GN2 Hose Assembly
– Soft Stow Vibration per 60054-TST-007 - Complete
– Pre and Post Vibe Helium Leak Test - Complete
• BASS Control Box
– Functional Test with Engineering Assembly - Complete
– Soft Stow Vibration per 60054-TST-007 - Complete
– Materials Bake-out for 72 hours at 120 ˚F - Complete
• Ignitor Wire Extension Assembly
– Functional Test with Engineering Assembly – Complete
6/16/2010 29
~~~~

### Pagina 30

Cita: [pdf_27fc3bba3dd172b9c640, p. 30]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
SAFETY VERIFICATIONS
• BASS safety package utilizes the SPICE 
package but it is a stand-alone payload.
• 61 Safety Verifications
– 46 Closed Verifications
– 11 Crew Procedure Controls – Procedures are being 
developed – 8/10
– 2 EMI TIA Approval for D300s Camera
– 1 HFIT Inspection at turnover – 6/23/10
– 1 Stowage Configuration Verification – 7/10/10
6/16/2010 30
~~~~

### Pagina 31

Cita: [pdf_27fc3bba3dd172b9c640, p. 31]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
INTEGRATION VERIFICATIONS
• Utilize SPICE ICD as a baseline for the integration requirements with MSG.
• New verifications not addressed in the safety verifications include the 
following:
– Fit Check for BASS Control Box & GN2 Hose in MSG EU – Complete
– Labeling - Complete @ KSC
– Combustion By-products compatibility assessment with MSG Filters – Complete
• Physical and Functional Interface testing in the MSG EU with the new 
Control Box were successful.
• Preliminary BASS crew procedures were dry run to evaluate their status. 
The procedures generally are in good shape with a couple of issues.
– The number of images expected to be acquired may limit the number of runs that can be 
performed in each session. There are eight 4 GB flash disks that will need to be transferred 
to a laptop, down-linked, and verified all were received prior to flash disks being erased to be 
reused.
– The project is still evaluating the various modes available with the new camera of acquiring 
images.
6/16/2010 31
~~~~

### Pagina 32

Cita: [pdf_27fc3bba3dd172b9c640, p. 32]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
SCHEDULE HIGHLIGHTS (Open Work)
• All hardware assembly and test is complete!
• Verification Closures are still in process as 
noted.
• Hardware Turnover @KSC – 6/24/10
• Bench Review – 7/8/10
6/16/2010 32
~~~~

### Pagina 33

Cita: [pdf_27fc3bba3dd172b9c640, p. 33]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
BASS OPEN NCR Status
• Radiated Emissions Exceedence of the D300s 
Camera.
– NCR will close upon receiving an approved TIA.
• Failure of the D300s camera during thermal 
testing.
– Closure will not occur until hardware is returned to the 
vendor for failure analysis and repair.
6/16/2010 33
~~~~

### Pagina 34

Cita: [pdf_27fc3bba3dd172b9c640, p. 34]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
SAR-1 Concerns & Issues
• The completion of the ECLSS Assessment of combustion by-products was 
scheduled after the originally scheduled SAR-2 on 6/11/10.
– ECLSS has provided an assessment that shows the combustion by-products are 
compatible with the ECLSS system.
• Stowage Configuration Drawings to close safety verification showing proper 
stow of the hardware will be finalized at the Bench Review scheduled for 
7/8/10.
– The PD will obtain the drawings once the updates have been made and include them 
in a memo to close the verification.
• Crew Procedures are in draft form and are not planned to be completed 
until after SAR-2.
– Crew procedures will be reviewed to include required safety controls. Operations will 
not be conducted until these safety verifications have been closed.
• The touch temperature report was not approved at the time of SAR-1.
– The report is approved and in CM.
6/16/2010 34
~~~~

### Pagina 35

Cita: [pdf_27fc3bba3dd172b9c640, p. 35]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
PROJECT CONCLUSION
The hardware developed to support the SLICE 
and BASS payloads has been designed, tested, 
and verified using approved processes resulting in 
what is expected to be highly successful 
operations.
6/16/2010 35
~~~~

### Pagina 36

Cita: [pdf_27fc3bba3dd172b9c640, p. 36]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
SAR-1 Board Assessment
• Jim Cockrell will discuss the SLICE BASS 
System Acceptance Review (SAR-1) Board’s 
findings
• The SLICE BASS SAR-1 Chair’s Synopsis letter 
is available on the eRoom
• Each of the open items at SAR-1 for SLICE is 
addressed on chart 20
• Each of the open items at SAR-1 for BASS is 
addressed on chart 34
6/16/2010 36
~~~~

### Pagina 37

Cita: [pdf_27fc3bba3dd172b9c640, p. 37]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
ZIN Quality Assessment
• Quality
– SLICE/BASS followed the ZIN Technology Quality 
Management System for engineering and building flight 
hardware. 
– For this re-flight SLICE/BASS:
• Used Manufacturing Work Orders (MWO) prepared for cleaning 
and assembly operations.
• Use inspection and test documents prepared for in-process and 
final inspection/test activities – all completed plans are nominally 
reviewed/approved by a ZIN Tech Quality representative.
• Will achieve configuration verification through as-built 
inspections performed by a ZIN Tech’s Quality representative as 
part of the MWO process.
6/16/2010 37
~~~~

### Pagina 38

Cita: [pdf_27fc3bba3dd172b9c640, p. 38]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_27fc3bba3dd172b9c640/p0038.jpg)

~~~~text
ZIN Technologies, Inc.
GRC Safety and Mission Assurance
SMAAssessment for SLICE/BASS
Bipin Patel
6-18-2010
6/16/2010 | 38
~~~~

### Pagina 39

Cita: [pdf_27fc3bba3dd172b9c640, p. 39]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Safety
• Flight Phase III Safety Data Package. 
• Safety Verification on going.
– Open:
• Pre Launch Stowage List
• Revise Crew procedures
• EMI Test Report/TIA
6/16/2010 39
~~~~

### Pagina 40

Cita: [pdf_27fc3bba3dd172b9c640, p. 40]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Mission Assurance
• Project Quality Assessment
• Product Assurance Plan (SpaceDOC PAP)
• Conducted Quality, Risks, M&P and Safety Audit.
• Successfully completed the Safety and Mission Assurance 
Organizational Review Board conducted.
• MIUL/MUA – Material certification letter in 
signature loop.
• EEE parts risk assessment
• PACE-2 uses industrial grade COTS parts.
• GIDEP Alert searches: One hit dispositioned.
6/16/2010 40
~~~~

### Pagina 41

Cita: [pdf_27fc3bba3dd172b9c640, p. 41]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_27fc3bba3dd172b9c640/p0041.jpg)

~~~~text
Mission Assurance
ZIN Technologies, Inc.
Risk Management
— Risk assessment team met periodically.
6/16/2010 | 41
~~~~

### Pagina 42

Cita: [pdf_27fc3bba3dd172b9c640, p. 42]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Assessment
The Project should continue to track the Mission 
Assurance risks through the completion of the 
open items, off-line testing, installation, and 
mission operations.
6/16/2010 42
~~~~

### Pagina 43

Cita: [pdf_27fc3bba3dd172b9c640, p. 43]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_27fc3bba3dd172b9c640/p0043.jpg)

~~~~text
SAR-2 Board Discussion
ZIN Technologies, Inc.
Pete McCallum
Glen Horvat
Bhim Singh
Frank Greco
6/16/2010 | 43
~~~~
