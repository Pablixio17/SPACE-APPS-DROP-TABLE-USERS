# ACME_Integrated_Science_Requirements_Definition_Review_20100505

- Identificador: pdf_de4fbf2c4b4a88629b79
- Investigaciones: PSI-20, PSI-22, PSI-23
- Tipo de documento: Science Documents
- Estado: processed
- Temas detectados automaticamente: hardware, oxygen, soot, pressure, electric_fields, ignition, extinction, operations, microgravity, smoke_detection, droplets

## Fuentes

- [PSI-20_Science Documents_ACME_Integrated_Science_Requirements_Definition_Review_20100505.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-20/Science%20Documents/PSI-20_Science%20Documents_ACME_Integrated_Science_Requirements_Definition_Review_20100505.pdf)
- [PSI-22_Science Documents_ACME_Integrated_Science_Requirements_Definition_Review_20100505.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-22/Science%20Documents/PSI-22_Science%20Documents_ACME_Integrated_Science_Requirements_Definition_Review_20100505.pdf)
- [PSI-23_Science Documents_ACME Integrated Science Requirements Definition Review 20100505.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-23/Science%20Documents/PSI-23_Science%20Documents_ACME%20Integrated%20Science%20Requirements%20Definition%20Review%2020100505.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_de4fbf2c4b4a88629b79, p. 1]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
ACME
Advanced Combustion via Microgravity Experiments
Integrated Science Requirements
R i t D fi iti R i Requirements Definition Review
May 10-11, 2010
Cleveland Ohio Cleveland, Ohio
www.nasa.gov 1
~~~~

### Pagina 2

Cita: [pdf_de4fbf2c4b4a88629b79, p. 2]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
Integq rated Science Requirements
• Introduction
– Experiments
– Concept
• Requirements*
– Hd R i t Hardware Requirements
• Experiment Configuration
• Monitoring Measurements
• Science Diagnostics
*Non-hardware requirements will be addressed by each experiment
MDCA insert
hardware requirements will be addressed by each experiment
– Operational Requirements
– Test Matrices
– Success Criteria
www.nasa.gov
Success Criteria
2
~~~~

### Pagina 3

Cita: [pdf_de4fbf2c4b4a88629b79, p. 3]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
4 ACME Experiments
• CLD Flame
– Coflow Laminar Diffusion Flame
– PI M h ll L (Y l U ) Marshall Long (Yale U.)
– Co-I Mitchell Smooke (Yale U.)
• E-FIELD Flames
– Electric Field Effects on Laminar Diffusion Flames
– PI Derek Dunn-Rankin (UC Irvine)
– Co-Is Felix Weinberg (Imperial College) 
Zeng-Guang Yuan (NCSER)
• Flame Design Flame Design - a novel approach to clean efficient diffusion flames a novel approach to clean, efficient diffusion flames
– PI Richard L. Axelbaum (Washington U. in St. Louis)
– Co-Is Beei-Huan Chao (U. Hawaii), 
Peter B. Sunderland (U. Maryland),
D id L U b (NASA Gl ) David L. Urban (NASA Glenn)
• s-Flame
– Structure and Response of Spherical Diffusion Flames
– PI C.K. Law (Princeton U.)
www.nasa.gov
C.K. Law (Princeton U.)
– Co-Is Stephen D. Tse (Rutgers U.)
Kurt R. Sacksteder (NASA Glenn)
3
~~~~

### Pagina 4

Cita: [pdf_de4fbf2c4b4a88629b79, p. 4]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
Laminar Gaseous Diffusion Flames
• 4 previous space experiments
– LSP: Laminar Soot Processes
• PI: G M Faeth (U Michigan) PI: G.M. Faeth (U. Michigan)
• Combustion Module
• STS-83 and STS-94 (1997), STS-107 (2003)
– TGDF: Turbulent Gas-jet Diffusion Flames
• PI: M.Y. Bahadori (SAIC)
• Get Away Special Canister (GAS can)
• STS-87 (1997)
– ELF: Enclosed Laminar Flames ELF: Enclosed Laminar Flames
• PI: L.-D. Chen (U. Iowa)
• Middeck Glovebox (MGBX)
• STS-87 (1997)
– SPICE: Smoke Point In Coflow Experiment
• PI: D.L. Urban (NASA Glenn) - initially G.M. Faeth
• Microgravity Science Glovebox (MSG)
• ISS Expeditions 18-19 (2009)
www.nasa.gov
ISS Expeditions 18 19 (2009)
Roger Crouch with CM-1 on STS-83 (top), Michael Barratt with SPICE (bottom) 4
~~~~

### Pagina 5

Cita: [pdf_de4fbf2c4b4a88629b79, p. 5]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
ACME Concept
• ACME experiments all use laminar gaseous diffusion flames
• Conduct them using a single modular insert for the Combustion 
Integrated Rack (CIR) on the International Space Station (ISS)
– The only currently existing insert is for droplet combustion experiments
Koichi Wakata with MDCA in CIR (left), ISS (right) www.nasa.gov 5
~~~~

### Pagina 6

Cita: [pdf_de4fbf2c4b4a88629b79, p. 6]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
ACME Hardware
• ACME hardware
– single modular insert
– avionics box avionics box
– color camera(s) & optics
– gas bottles, filter cartridges, etc.
Nicole Stott with MDCA (left), CIR (right) www.nasa.gov 6
~~~~

### Pagina 7

Cita: [pdf_de4fbf2c4b4a88629b79, p. 7]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
ACME Insert Concept
Mesh electrode or SiC fiber array for TFP 
(vertically translating) 
Lamp(s) to 
illuminate 
configuration
Mesh electrode
Radiometer
Radiometer
Radiometer
PMT
PMT
PMT
Radiometer
ad o ete
P
Igniter (retracting)
High-voltage 
power supply 
with current 
measurement
Radiometer
Fuel MFC
Inert MFC
Igniter (retracting)
Thermocouples
Mixer
www.nasa.gov 7
Oxidizer MFC
~~~~

### Pagina 8

Cita: [pdf_de4fbf2c4b4a88629b79, p. 8]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
Science Requirements Disallowed
• ACME must be done within resource constraints
• Difficult/costly or desired requirements were not allowed Difficult/costly or desired requirements were not allowed
– Measurements
• CH* imaging
• infrared imaging infrared imaging
• Schlieren and shadowgraph imaging
• PAH limit
• soot inception limit by laser scattering soot inception limit by laser scattering
• soot sampling
• species concentrations (other than via CIR’s GC)
• b rner gas temperat res burner gas temperatures
– Testing
• oxygen concentrations over 40% in the chamber
f
www.nasa.gov 8
• dynamic venting or constant pressure testing
~~~~

### Pagina 9

Cita: [pdf_de4fbf2c4b4a88629b79, p. 9]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
Nominal Opq erational Sequence
• Flow > Ignite > Measure > Extinguish 
– Initiate burner flows at ignition condition 
– Ignite flame
• Wait for flame to stabilize
– If needed adjust flows to initial test condition If needed, adjust flows to initial test condition
• Wait for flame to stabilize
– If needed:
• ramp burner flow(s) ramp burner flow(s)
• activate and adjust electric field
• translate TFP array
– St b fl Stop burner flows
• per extinction detection or test duration
Nicole Stott with CIR www.nasa.gov 9
~~~~

### Pagina 10

Cita: [pdf_de4fbf2c4b4a88629b79, p. 10]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
ACME Hardware Requirements
• Experiment Configuration
– General () 1.1
– Burners (1.2-1.4)
– Electric Field (1.5-1.7)
– Gas Delivery (1 8 Gas Delivery (1.8-1 9) .
– Ignition (1.10)
– Ambient Environment (1.11)
– Data Acquisition (1.12)
• Monitoring Measurements
• Science Diagnostics Science Diagnostics
Frank DeWinne with CIR www.nasa.gov 10
~~~~

### Pagina 11

Cita: [pdf_de4fbf2c4b4a88629b79, p. 11]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
General Req () uirements (1.1)
• Burners all burners accommodated, but only one at a time
exchangeable during spaceflight
one duplicate of each provided to Project Scientist
• Compatibility of burners and gas delivery system
– fuels H2, CH4, C2H6, C3H8, C2H4, C3H6, and mixes
– inerts N2, CO2, He, Ne, Ar, Kr, Xe, and mixes
– fuel/inert mixtures of any fuel(s) and inert(s) above
– oxygen mix ≤85% oxygen with any fuel(s) and/or inerts above
• Chamber contents compatible with ≤40% oxygen
• Simultaneous all configuration requirements apply simultaneously 
unless otherwise specified
www.nasa.gov 11
~~~~

### Pagina 12

Cita: [pdf_de4fbf2c4b4a88629b79, p. 12]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
Burners (1.2-1.4)
• 3 types of exchangeable burners 
– p p () orous spherical burners (3 sizes)
– circular gas-jet burners (6 sizes)
– axisymmetric, coflow burner (1 size)
• capable of inverse flames capable of inverse flames
www.nasa.gov 12
~~~~

### Pagina 13

Cita: [pdf_de4fbf2c4b4a88629b79, p. 13]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
Sp () herical Burners (1.2)
• Porous sphere ODs 6.4, 9.5, 12.7 mm known to ±0.1 mm 
• Burner tube
– inner diameter so pressure drop is ≤20% of that across burner
– outer diameter ≤25% of sphere diameter
– length ≥100 mm
– material stainless steel
• Sphericity 2.2s drop verification of flame with rmin/rmax>0.8
• Positions (1) centered in chamber & windows
or (2) 30 mm ‘below’ window center
• Volume (internal) ≤10 cc from last solenoid valves
• Resistance withstand 0-450 oC
www.nasa.gov 13
~~~~

### Pagina 14

Cita: [pdf_de4fbf2c4b4a88629b79, p. 14]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
Gas-Jet Burners () 1.3
• Shape straight tube with circular cross section
• Length ≥40 inner diameters
• Tube sizes 0.4±0.1 mm ID, 0.8±0.1 mm OD
0.8±0.1 mm ID, 1.2±0.1 mm OD
1.3±0.1 mm ID, 1.6±0.1 mm OD
2.1±0.1 mm ID, 2.4±0.1 mm OD
2.7±0.1 mm ID, 3.1±0.1 mm wall
3.2±0.1 mm ID, 3.6±0.1 mm wall
ID and OD known to ±0.05 mm
• Burner tip smooth, free from burs
• Position on chamber axis either:
(1) 10 mm ‘below’ window center
(2) 30 mm ‘below’ window center
• Material stainless steel
www.nasa.gov 14
• Resistance withstand 0-1000 oC
Soot volume fraction measurement in LSP experiment on STS-83
~~~~

### Pagina 15

Cita: [pdf_de4fbf2c4b4a88629b79, p. 15]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
Coflow Burner () 1.4
• Concentricity within ±0.3 mm
• Outlets orthogonal and flat within ±0.1 mm
• Dimensions
Honeycomb
– inner tube 2.1±0.1 mm ID, 2.4±0.1 mm OD,
length of ≥40 inner diameters
≤10 cc volume from last solenoid valves 10 cc volume from last solenoid valves
0.5 to 1.0 mm downstream of annular outlet
stainless steel
– outer tube 25±0.5 mm ID
0.0 to 0.5 downstream of annular outlet
• Annular flow axisymmetric, plug flow for velocities of ≤50 cm/s
no swirl or turbulence
≤0.75 mm boundary layer at inner tube
well characterized with cold flow for 10-50 cm/s
• Axisymmetry flame axisymmetry demonstrated in 1g and 0g
Position centered 12 mm ‘below’ window center
www.nasa.gov 15
• Position centered, 12 mm below window center
• Resistance withstand 0-1000 oC range
~~~~

### Pagina 16

Cita: [pdf_de4fbf2c4b4a88629b79, p. 16]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
Electric Field (1.5-1.7)
Nozzle Insulator
Mesh Gas supply
HV
electrode
Shunt for current 
measurement, Rs
Gas supply
tubes
H.V.
Ch b
measurement, Rs
www.nasa.gov 16
Chamber Low voltage input, e.g., 0-24VDC
~~~~

### Pagina 17

Cita: [pdf_de4fbf2c4b4a88629b79, p. 17]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
Electrodes: Burner () () 1.5) and Mesh (1.6)
Burner as Electrode (1.5) - doesn’t apply to spherical burners
• Resistance <1 Ohm along/across burner (i.e., same potential)
• Insulation burner insulated from the chamber
Electrode Mesh (1.6)
• Shape flat circle
• Material copper (mesh and ring)
• Mesh 16-22 wires/inch
0.38-0.64 mm diameter wire
• Edge 2-3 mm diameter ring
• Size ≥80 mm diameter (ring OD)
• Orientation orthogonal and on chamber axis
• Position 25 or 40 mm ‘above’ window centers
• Removable during spaceflight
www.nasa.gov 17
gp g
~~~~

### Pagina 18

Cita: [pdf_de4fbf2c4b4a88629b79, p. 18]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
Electric Field () 1.7
• Voltage range -10 to +10 kV set within ±0.1% of set point
• Step change any polarity and magnitude within range
≤5 ms rise time
• Alternating polarity sequence of steps at 0-100 Hz (mimic AC field)
• Uplink voltage, polarity, step changes, timing
• No conductive contact mesh and burner (except for temp. measurement)
• Conductive free zone ≥30 mm more than mesh diameter
from burner to ≥20 mm downstream of mesh
• Current leakage <100 nanoamps (at ±10 kV with a 35-mm spacing)
• Removable high voltage power supplies, associated electronics
www.nasa.gov 18
~~~~

### Pagina 19

Cita: [pdf_de4fbf2c4b4a88629b79, p. 19]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
Gas Supp y ( ) l 1.8
• For required testing
– fuels 100% H2, 100% CH4, 100% C2H4 
H2/CH4 mixes H2/CH4 mixes :* 55 6/44 4 44 4/55 6 66 7/33 3 55.6/44.4, 44.4/55.6, 66.7/33.3
– oxidizers** O2/N2 mixes*: 85/15, 50/50, 30/70, 21/79
40/60 O2/He 
– inerts 100% N2 (available from ISS), 100% He
• For desired testing
– fuels none
– oxidizers** O2/CO2 mixes*: 85/15, 40/60
– inerts 100% CO2 100% CO2
www.nasa.gov 19
*Mixes on a molar (volume) basis
**CIR gas bottles limited to ≤85% O2
~~~~

### Pagina 20

Cita: [pdf_de4fbf2c4b4a88629b79, p. 20]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
Burner Gas Delivery( ) 1.9
• Capability simultaneous flow of fuel, oxidizer, and inert to burner
(coflow burner: each gas to inner or outer tube, not both) 
• Uplink mixture composition, flow rates
• Composition ±0.01 mole fraction, known as function of time
• Flow rate control accuracy of ≤5% (plus shut off capability)
• Flow capacity 60s at maximum flow rates (see below)
• Gas temperature 300±10 K
• Contaminants ≤0.001 mole fraction, dry
• Flow ranges see below (slpm on a N2 basis) 
CLD E-FIELD E-FIELD Flame Flame Flame
Flame Flames Flames Design Design Design s-Flame
coflow gas jt e coflow sphi l er ca coflow* coflow** sphi l er ca
fuel 0.2 0.1 0.1 0.3 0.3 2.0 0.5
oxy 15 n/a 2.0 3.0 20 2.0 n/a
inert 0.1 0.05 0.05 10 2.0 20 1.0
www.nasa.gov 20
inert 0.1 0.05 0.05 10 2.0 20 1.0
*normal **inverse
~~~~

### Pagina 21

Cita: [pdf_de4fbf2c4b4a88629b79, p. 21]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
Ig () nition (1.10)
• Reliable ignite all initial flow conditions
verified to ignite within 1 s in 1g at limiting/extreme conditions
• Disturbance minimize hydrodynamic wakes
• Insertion ≥30 s before igniton
• Retraction ≤0.5 s after ignition
• Energy variable and minimized
• Duration uplinkable and variable between 0-10 s
MDCA ignition www.nasa.gov 21
~~~~

### Pagina 22

Cita: [pdf_de4fbf2c4b4a88629b79, p. 22]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
Ambient Environment () 1.11
• Composition uplinkable and variable to ±0.01 mole fraction
• Contaminants ≤0.01 mole fraction and dry, unless waived
• Atmosphere well mixed
• Quiescent 300 s hold period before ignition
• Pressure 0.1 to 3 bar within ±3% of set point
• Temperature 290-310 K, uniform within ±5 K
• Free volume ≥80 liters, symmetric as possible
• Free zone
– spherical flames ≥200 mm diameter
– non-spherical ≥150 mm diameter cylinder, ≥200 mm up, etc.
• Disturbance limit burner flow, combustion, probe motion, g-jitter
• No test prohibition during thruster firing, docking, or undocking
• ‘Black’ background no reflection or emission in view of sensor
• Emissivity ≥0.5 except for burners, probe tips, igniter, etc.
www.nasa.gov 22
Req’t for dynamic venting was disallowed because of difficulty & cost!
~~~~

### Pagina 23

Cita: [pdf_de4fbf2c4b4a88629b79, p. 23]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
Data Synchronization & Recording (1.12)
• Synchronization common time reference, within 2x response time
• Data acquisition start & stop times can be uplinked
imaging ≤1 min before ignition, ≤1 min after extinction
non-imaging ≤5 min before ignition, ≤5 min after extinction
• Downlink can downlink from only selected imaging systems
can downlink image data for selected time period(s)
• Recording simultaneous for all of the following
monitoring chamber pressure, gas flow rates, burner pressure 
diff ti l ( differential (sph i l fl herical flames) l t i l t ti l ( ), electrical potential (E￾FIELD Flames only), acceleration
diagnostics
imaging color imaging for operations color imaging for data color imaging for operations, color imaging for data
analysis, UV imaging, pyrometry, soot volume fraction
non-imaging burner & far-field temperatures, radiant emission, 
chemiluminescent emission, ion current (E-FIELD
www.nasa.gov 23
chemiluminescent emission, ion current (E FIELD
Flames only)
~~~~

### Pagina 24

Cita: [pdf_de4fbf2c4b4a88629b79, p. 24]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
ACME Hardware Requirements
• Experiment Configuration
• Monitoring Measurements Monitoring Measurements
– Chamber Pressure (2.1)
– Oxygen Concentration (2.2)
– G Fl R t (2 3) Gas Flow Rates (2.3)
– Burner Pressure Differential (2.4)
– Electrical Potential (2.5)
– Acceleration (2.6)
• Science Diagnostics
These measurements are required to 
verify boundary and initial conditions 
www.nasa.gov 24
and thus enable modeling and analysis.
Michael Barratt with MDCA in CIR
~~~~

### Pagina 25

Cita: [pdf_de4fbf2c4b4a88629b79, p. 25]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
Gas Monitoring(2.1-2.3)
Chamber Pressure (2.1)
• Accuracy ±1% of reading
• Range 0.1-4.0 bar absolute
• Frequency ≥1 samples/s
• Response time ≤0.5 s
Chamber Oxygen Concentration (2.2)
• Instrument Gas Chromatograph Instrumentation Package (GCIP)
• Measure when? prior to each test, after filling, scrubbing (if any), & mixing
Gas Flow Rates () 2.3
• Accuracy ±5% of reading
• Frequency ≥10 samples/s
• Response time ≤1 s
www.nasa.gov 25
p
• Measure all supply lines during testing whether or not in use
~~~~

### Pagina 26

Cita: [pdf_de4fbf2c4b4a88629b79, p. 26]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
Other Monitoring(2.4-2.6)
Burner Pressure Differential (2.4) – only required for spherical flames
• Difference across porous spherical burner (i.e., versus chamber)
• Accuracy ±2% of reading
• Range 0.1 to ~1.5x pressure drop at 5 slpm (on N2 basis)
• Frequency ≥10 samples/s
• Response time ≤0.5 s
Electric Potential (2.4) – for E-FIELD Flames only
• Accuracy ±1% of reading
• Range matching range of electric field
• Frequency ≥1 samples/s
• Response time ≤0.5 s
Acceleration (2.6)
www.nasa.gov 26
• Instrument Space Acceleration Measurement System (SAMS)
• Sensor location at or near CIR
~~~~

### Pagina 27

Cita: [pdf_de4fbf2c4b4a88629b79, p. 27]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
ACME Hardware Requirements
• Experiment Configuration
• Monitoring Measurements Monitoring Measurements
• Science Diagnostics
– Color Imaging for Ops (3.1)
– Color Imaging for Data (3.2)
– Ultraviolet (UV) Imaging (3.3)
– Temp (3 ) erature (3.4)
– Soot Volume Fraction (3.5)
– Radiant Emission (3.6)
– Chemiluminescent Emission (3 7) Chemiluminescent Emission (3.7)
– Ion Current (3.8)
– Post-Test Gas Composition (3.9)
MDCA and CIR www.nasa.gov 27
~~~~

### Pagina 28

Cita: [pdf_de4fbf2c4b4a88629b79, p. 28]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
Color Imagg p ( ) ing for Operations (3.1)
• Range, spectral 0.4-0.7 µm
• Focus chamber axis
• FOV include ≥90 mm circle
• Uplink control at least gain or iris
• Framing rate ≥25 fps
• Downlink near-real time
• Exchangeable yes (e.g., because of radiation susceptibility)
• Illumination optional via uplink
Michael Barratt with MDCA and CIR www.nasa.gov 28
~~~~

### Pagina 29

Cita: [pdf_de4fbf2c4b4a88629b79, p. 29]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
Color Imagg y ( ) ing for Data Analysis (3.2)
• Range, spectral 0.4-0.7 µm
• Sensitivity ≥ cameras with Sony ICX285 2/3” CCD
• Lens f-number ≤2.8
• Spatial resolution ≤0.2% FOV dimension
• Bit depth ≥3x12 (i.e., 12 bits each for red, green, blue)
• Focus chamber axis, centered with chamber windows
• FOV: 1D flames ≥90 mm diameter
• FOV: 2D flames 35 mm along axis, ≥20 mm wide 
• Orientation long dimension (if any) with chamber axis
• Views ≥1
• Filter option to image with or without BG-7 filter
• Framing rate ≥20 fps
• Uplink control ≥ bit depth, gain, iris, exposure time, 
framing rate, binning, Region Of Interest (ROI)
www.nasa.gov 29
• Characterization blackbody with 800-1200 oC, etc., etc., etc.
• Exchangeable yes, in spaceflight
~~~~

### Pagina 30

Cita: [pdf_de4fbf2c4b4a88629b79, p. 30]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
Ultraviolet (UV) Imaging (3.3)
• Specifications generally similar to color imaging
• Spectral range OH*, 310 nm, 10 nm FWHM*
• FOV
– 1D flames ≥75 mm diameter
– 2D flames 60±5mm along chamber axis, 
≥30 mm wide
* Full Width at Half Maximum
 r 
-
←→ r +
www.nasa.gov 30
Abel deconvolved OH* 
image from s-Flame
LLL-UV camera (right)
~~~~

### Pagina 31

Cita: [pdf_de4fbf2c4b4a88629b79, p. 31]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
Temp () erature: Burner (3.4.1)
• Position
– Spherical burner 20o to 90o of tube
not visible in ≥1 color view
– 2D burners at/near nozzle tip
• Non-disturbance flame symmetry verified via testing
• Probe size (if any) ≤250 micron
• Range
– Spherical burner 0-700 oC
– 2D burners 0-300 oC
• Precision ±2 oC
• Accuracy ±5 oC
• Frequency ≥10 samples/s 
• Response time ≤0.5 s
Frank DeWinne with CIR www.nasa.gov 31
~~~~

### Pagina 32

Cita: [pdf_de4fbf2c4b4a88629b79, p. 32]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
Temperature: Hot Soot-Containing Regions (3.4.2)
• FOV
– Spherical flames ≥85 mm diameter
– 2D flames 50±5 mm along axis, ≥20 mm wide
• Characterization required for any new instrumentation
• Gain variable
• Frequency ≥0.2 sample/s
• Response time ≤5 s
• Uplink gain, start & stop times
HiBMs camera www.nasa.gov 32
~~~~

### Pagina 33

Cita: [pdf_de4fbf2c4b4a88629b79, p. 33]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
Temperature: Hot Soot-Free Regions (3.4.3)
• Where? orthogonal to chamber axis, in plane including axis
• Multiple lines ≥5 lines spaced 5±0.5 mm apart
position known to position known to ±1 mm
• If fibers… retract to ≥100 mm from burner
partial retraction to burn off soot
15 micron oxidized SiC fibers
≤25o t th l f di i i to orthogonal of corresponding imaging
removable & exchangeable during spaceflight
• FOV
– Spherical flames Spherical flames ≥85 mm diameter 85 mm diameter
– 2D flames 50±5 mm along axis, ≥20 mm wide
• Characterization required for any new instrumentation
• Frequency ≥0 2 sample/s 0.2 sample/s
• Response time ≤5 s
• Uplink gain, start & stop times
www.nasa.gov 33
~~~~

### Pagina 34

Cita: [pdf_de4fbf2c4b4a88629b79, p. 34]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
Temperature: Far-Field () 3.4.4
• Unobstructed open path to burner, avoid ≤20o of burner tube
• Positions (radial)
close or 13 25 50 100 200 200 mm 13, 25, 50, 100, 200, 200 mm
distant 45, 60, 100, 100, 200, 200 mm
• Range 700-1700 oC for r≤40 mm, otherwise 0-1250 oC
• Accuracy ±3 oC for r≤40 mm ±1 Accuracy ±3 C for r≤40 mm, ±1 oC for outer positions C for outer positions
• Frequency ≥10 sample/s
• Response time ≤0.1 s in air at 1 bar at ≤20 m/s
• Free zone Free zone ≥50 mm dia cylinder from center to position & beyond 50 mm dia. cylinder from center to position & beyond
• TC probe, if any within ±10o of parallel to ray from center for r≤100 mm
• TC size ≤0.2 mm OD within 5 mm of tip
≤2 mm OD within 20 mm of tip 2 mm OD within 20 mm of tip
≤3.5 mm OD within 50 mm of tip
• Exchangeable during spaceflight
• E-FIELD Flames not required
www.nasa.gov 34
E FIELD Flames not required
~~~~

### Pagina 35

Cita: [pdf_de4fbf2c4b4a88629b79, p. 35]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
Soot Volume Fraction () 3.5
• FOV: 1D flames ≥45 mm along the chamber axis, ≥45 mm wide
• FOV: 2D flames ≥25 mm along the chamber axis, ≥25 mm wide
• Images illumination flame illumination plus flame illumination, flame, illumination plus flame
• Frequency ≥1 samples/s
• Response time ≤1 s
• Uplink control Uplink control start and stop times start and stop times
Sandra Magnus with CIR (left), CIR illumination package (right) www.nasa.gov 35
~~~~

### Pagina 36

Cita: [pdf_de4fbf2c4b4a88629b79, p. 36]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
Radiant Emission () 3.6
• Accuracy ±10%
• FOV cone ≥120 mm in diameter at the chamber axis
• Linear array Linear array ≥5 sensors spaced 5 sensors spaced ≤30 mm
orthogonal (±3 degrees) to chamber axis
centered with chamber windows
• Angled array ≥1 non-orthogonal sensors extending to ≥60 Angled o array ≥1 non orthogonal sensors extending to ≥60
• Range
– Spectral 0.2-11 microns 
– Irradiance 0.0001-0.1 W/cm2
• Frequency ≥60 samples/s
• Response time ≤0.05 s
Michael Fincke with MDCA www.nasa.gov 36
~~~~

### Pagina 37

Cita: [pdf_de4fbf2c4b4a88629b79, p. 37]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
Chemiluminescent Emission () 3.7
• Range, spectral simultaneous for each
– OH* 310 nm with ≥10 nm or larger FWHM
– CH* 431 nm with 431 nm with ≥10 nm or larger FWHM 10 nm or larger FWHM
– broadband ≤300 to at least ~600 nm 
• FOV 120 mm diameter sphere at window center
• Sensitivity to flame Sensitivity to flame good as human eye verified in 1g good as human eye, verified in 1g
• Frequency ≥120 samples/s
• Response time ≤5 ms
• Exchangeable in spg aceflight
Koichi Wakata with MDCA in CIR www.nasa.gov 37
~~~~

### Pagina 38

Cita: [pdf_de4fbf2c4b4a88629b79, p. 38]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
Other Science Diag( nostics (3.8-3.9)
Ion Current (3.8) – E-FIELD Flames only
• Measure between the burner and mesh 
• Range 0-25 microamps
• Accuracy ≤ larger of (±5% of reading) or (±0.05 microamps)
• Frequency ≥120 samples/s
• Response time ≤1 ms
Post-Test Gas Composition (3.9)
• Instrument Gas Chromatograph Instrumentation Package (GCIP)
• Measure when? (1) immediately after extinction and/or (2) after mixing
• Species at least CO, CO2, CH4, C2H2, C2H4, N2, O2
www.nasa.gov 38
~~~~

### Pagina 39

Cita: [pdf_de4fbf2c4b4a88629b79, p. 39]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
Majo C a ges s ce SC r Changes since SCR
• Added
– Inverse spg herical flame testing (tentative, g y pp assuming safety approval)
– Color imaging for operations (i.e., with near real-time downlink)
• Eliminated (where most items were desired)
– D i ti ynamic venting
– Oxygen measurement (other than via GCIP)
– Burner gas temperature measurement
– CH* imaging
– IR imaging
– Schlieren or shadowgraph imaging Schlieren or shadowgraph imaging
• Other Changes
– Reduced maximum oxygen in chamber from 50% to 40%
www.nasa.gov 39
~~~~

### Pagina 40

Cita: [pdf_de4fbf2c4b4a88629b79, p. 40]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
National Aeronautics and Space Administration
NAS Sc e ce ea A Science Team
• Dennis Stocker, Project Scientist
• Dr Fumiaki Takahashi Dr. Fumiaki Takahashi, Deputy Project Scientist Deputy Project Scientist
• Jay Owens, Imaging Technology
Wile E. Coyote ® www.nasa.gov 40
~~~~
