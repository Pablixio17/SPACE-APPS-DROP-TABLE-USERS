# 21216 daily test point log

- Identificador: pdf_bb2696a0faa138afc124
- Investigaciones: PSI-159
- Tipo de documento: Raw Data
- Estado: processed
- Temas detectados automaticamente: hardware

## Fuentes

- [PSI-159_Raw Data_21216 daily test point log.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-159/Raw%20Data/PSI-159_Raw%20Data_21216%20daily%20test%20point%20log.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_bb2696a0faa138afc124, p. 1]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_bb2696a0faa138afc124/p0001.jpg)

~~~~text
ACME Daily Test Point Log | 8/4/2021
Downlink Data Limit (MB) = 127,000 | Total = | 90,140
Test Point Name Script Aborts | IPSU1/HiBMS | IPSU2/LLL-UV | ACME Camera | Intensified Camera
Downlink
(enter all test | Before IPSUs | Archived | Archived | Archived | Archived
Data (MB)
points) | Open | Images | D/L? | Images | Images | Images | D/L?
21216A1 | 461 | 1555 | 5,796
21216A2 | 1598 | 5,974
21216A3 | 479 | 1534 | 5,785
21216A4 | 686 | 2141 | 8,123
21216A5 | 292 | 1162 | 4,185
21216A6 | 747 | 2155 | 8,334
21216B1 | 297 | 1673 | 5,680
21216C1 | 463 | 1788 | 6,477
21216F1 | 792 | 2553 | 9,614
21216H1 | 478 | 1532 | 5,777
21216H2 | 591 | 1856 | 7,032
21216J1 | 622 | 2094 | 7,809
21216K1 | 792 | 2532 | 9,553
21
PD: | Date:
~~~~
