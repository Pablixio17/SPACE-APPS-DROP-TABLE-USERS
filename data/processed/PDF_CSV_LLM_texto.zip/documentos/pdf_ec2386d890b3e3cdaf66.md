# 21340 test sheets

- Identificador: pdf_ec2386d890b3e3cdaf66
- Investigaciones: PSI-10
- Tipo de documento: Raw Data
- Estado: processed
- Temas detectados automaticamente: pressure, ignition, hardware, soot, oxygen

## Fuentes

- [PSI-10_Raw Data_21340 test sheets.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-10/Raw%20Data/PSI-10_Raw%20Data_21340%20test%20sheets.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_ec2386d890b3e3cdaf66, p. 1]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_ec2386d890b3e3cdaf66/p0001.jpg)

~~~~text
ACME / Flame Design (inverse flame) - Science Test Sheet
est date: | CME test #:
Local time: | est of day #:
GMT: | Flame of day #:
TEST CONDITIONS | Control? | automated 'manual'
Test type? o ignition no-flamewstandard other
Chamber atmosphere | 02 bottle: | 85% (volume)
C2H4 conc. | % (vol, nominal) | Burner 02 conc.. | % (volume
2H4 conc. | ODO/o (vol, per calc) | 02 flow rate: | slpm (N2 basis)
Chamber pressure: | psia (CIR avg per FCU) | N..2-f-10w rate: | slpm | Av
ent before? no 9es, to | psia
Iso just before? | fan GC scrub
FP. no | c] moving o back-n-forth
INSTRUMENTATION | ain: | DataCam 2)_ ops camera
CDataCam: filter? k clear BG7 CH* CH20 | ROI? full reduced | fps
R
Intensified: filter? o clearLCH* CH20 0 none | ROI?y full o reduced | fps
backlight filter? a nou yes | CIR backlight? o no yes fps? 15 30
FLAME BEHAVIOR
o cool maybe cool | Ignited? KY es no yes, but ...*
Flame hole/opening partially detached | 00t@ignition c none little lots
Flame oscillating unsteady quasi-stead | oot@middte none a little lots
Out o ext. detect time out temp. limit | oot@end | one little lots
POST-TEST CONDITIONS
Fuel conc. | % (vol, per calc) | hamber pressure: | psia (CIR avg per FCU)
alve safety timer | sec | Oxidizer bottle pressure: | psia
*GENERAL COMMENTS
•Aqe-
19 Oct. 2021
~~~~

### Pagina 2

Cita: [pdf_ec2386d890b3e3cdaf66, p. 2]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_ec2386d890b3e3cdaf66/p0002.jpg)

~~~~text
ACME / Flame Design (inverse flame) - Science Test Sheet
est date: | 20 | CME test #:
Local time: | e s t Of d a y # :
GMT: | Flame of day #: | 1
TEST CONDITIONS | Control? | æfully automated 'manual'
Test type? ignition ü no-flameætandard other
hamber atmosphere | 02 bottle: | 85% (volume)
C2H4 conc. | % (vol, nominal) | Burner 02 conc.: | % (volume)
C2H4 conc. | % (vol, per calc) | 2 flow rate: | slpm (N2 basis)
Chamber pressure: | psia (CIR avg per FCU | te: | slpm
ent before? no yes, to | psia
Iso just before? | fan GC scrub
FP? c] no | moving D back-n-forth
INSTRUMENTATION | ain: | DataCam _A_ ops camera
g DataCam: filter?éclear BG7 0 CH* CH20 | ROI? Q full reduced | fps
filter? a clear Y-.CH* o CH20 c) none | ROI? U full reduced | ZZ fps
D-H.i-BMs: backlight filter? o no yes | CIR | yes fps?-z-as-a-30
c
FLAME BEHAVIOR
Flame€hot o cool o maybe cool | Ignited? yes no yes, but .
Flame hole/opening partially detached | Soot@ignition none littlé lots
Flame oscillating o unsteady quasi-stead | 00t@middte soone little D lots
Out ext. detect time out temp. limit | 00t@end | E none c.ü little ü lots
POST-TEST CONDITIONS
Fuel conc. | % (vol, per calc) | Chamber pressure: | psia (CIR avg per FCU)
alve safety timer | Z ' | Oxidizer bottle
sec | pressure: | psia
*GENERAL COMMENTS
fff | A)
Z cloSe-s+
19 Oct. 2021
~~~~

### Pagina 3

Cita: [pdf_ec2386d890b3e3cdaf66, p. 3]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_ec2386d890b3e3cdaf66/p0003.jpg)

~~~~text
ACME / Flame Design (inverse flame) - Science Test Sheet
est date: | CME test#: 21
Local time: | est of day #:
GMT: | Zi | 40 | Flame of day #:
TEST CONDITIONS | Control? | fully automated 'manual'
Test type? ignition c] no-flame,estandard o other
Chamber atmosphere | 02 bottle: | 85% (volume)
C2H4 conc. | % (vol, nominal) | Burner 02 conc.. | % (volume)
C2H4 conc. | % (vol, per calc) | 2 flow rate: | slpm (N2 basis)
hamber pressure: | psia (CIR avg per FCU | N 2 flow rate: | 2 | slpm
ent before? | o yes, to | psia
Iso just before? | fan GC o scrub
FP? Kno fixed moving o back-n-forth
INSTRUMENTATION | ain: | DataCam | ops camera
CDataCam: filter? | BG7 | CH20 | ROI? (full o reduced | fps
q Intensified: filter? o clear | o CH20 none | full reduced | fps
HiBMs: backlight filter? nogyes | CIR backlight? no eyes fps?Z15 30
FLAME BEHAVIOR
Flame hot o cool maybe cool | Ignited? yes ü no o yes, but ...*
Flame o hole/opening partially detached | 00t@ignition none c] little lots
Flame ü oscillating unsteady quasi-stead | Soot@middle none ü little lots
Out ext. detectx time out temp. limit | 00t@end | none little lots
POST-TEST CONDITIONS
Fuel conc. | % (vol, per calc) | hamber pressure: | psia (CIR avg per FCU
alve safety timer | sec | Oxidizer bottle pressure: | psia
*GENERAL COMMENTS
aZy/-e
19 Oct. 2021
~~~~

### Pagina 4

Cita: [pdf_ec2386d890b3e3cdaf66, p. 4]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_ec2386d890b3e3cdaf66/p0004.jpg)

~~~~text
ACME / Flame Design (inverse flame) - Science Test Sheet
est date: | zU | CME test #: Z | DB-z—
Local time: | est of day #:
GMT: | Flame of day #:
TEST CONDITIONS | Control? | ully automated o 'manual'
Test type? ignition c] no-flamenstandard other —<-É-e—
hamber atmosphere | 02 bottle: | 85% (volume)
C2H4 conc. | % (vol, nominal) | Burner 02 conc.. | % (volume
C2H4 conc. | % (vol, per calc) | 2 flow rate: | slpm (N2 basis
Chamber pressure: | psia (CIR avg per FCU) | N 2 flow rate: | slpm
ent before? | o yes, to | psia
Iso just before? | fan GC a scrub
FP? no | moving back-n-forth
INSTRUMENTATION | ain: | O DataCam 2' ops camera
ADataCam: | BG7 | CH20 | ROI? k full reduced | fps
Intensified: filter? o clear XCH* o CH20 none | ROI? full reduced | fps
a-HBMst-backlight filter? nogayes | CIR backlight?E no yes fpsæ-±5+30 n,
FLAME BEHAVIOR
Flame hot c] cool maybe cool | Ignited? yes no yes, but *
...
Flame o hole/opening partially detached | SOOt@ignition c] none little( lots
Flame oscillating c] unsteady 'quasi-stead | 00t@middle none little lots
Out ext. detect | ime out o temp. limit | SOOt@end k none little o lots
POST-TEST CONDITIONS
*GENERAL COMMENTS
vay
(f9 Oct. 2021
~~~~

### Pagina 5

Cita: [pdf_ec2386d890b3e3cdaf66, p. 5]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_ec2386d890b3e3cdaf66/p0005.jpg)

~~~~text
ACME / Flame Design (inverse flame) - Science Test Sheet
est date: | zoa. I
Local time: | est of day #:
MT: ZI | Flame of day #:
TEST CONDITIONS | Control? | *fully automated o 'manual'
Test type? | o no-flame—standard other
Chamber atmosphere | 02 bottle: | 85% (volume)
C2H4 conc. | % (vol, nominal) | Burner 02 conc.: | % (volume
C2H4 conc. | 0/0 (vol, per calc) | 2 flow rate: | slpm (N2 basis)
Chamber pressure: | -b psia (CIR avg per FCU) | N2 flow rate: | slpm
ent before? - no o | to | psia
yes,
Iso just before? | fan GC scrub
Xno fixed a moving back-n-forth
INSTRUMENTATION | ain: Z | DataCam | ops camera
ZDataCam: filter?øclear BG7 | CH20 | ROI?R full reduced | fps
Zlntensified: filter? o | CH20 none | ROI | full reduced | fps
HiBMs: backlight filter? no Kyes | CIR backlight? no Ryes fps?Ä15 a 30
FLAME BEHAVIOR
Flame hot o cool maybe cool | Ignited? yes no o yes, but ...*
Flame hole/opening ü partially detached | SOOt@ignition o none c] little Eflots
Flame c] oscillating o unsteadykquasi-stead | 00t@middle Z none little ü lots
Out o ext. detectZtime out o temp. limit | Soot@end | none little c: lots
POST-TEST CONDITIONS
*GENERAL COMMENTS
Very
19 Oct. 2021
~~~~

### Pagina 6

Cita: [pdf_ec2386d890b3e3cdaf66, p. 6]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_ec2386d890b3e3cdaf66/p0006.jpg)

~~~~text
ACME / Flame Design (inverse flame) - Science Test Sheet
est date: | CME test
Local time: | est of day
GMT: | 3 0 | Flame of day #:
TEST CONDITIONS | Control? | €_fully automated 'manual'
Test type? ignition no-flame.standard $other
hamber atmosphere | 02 bottle: | 85% (volume)
C2H4 conc. | % (vol, nominal) | Burner 02 conc.: | % (volume)
C2H4 conc. | % (vol, per calc) | 02 flow rate: | slpm (N2 basis)
Chamber pressure: | psia (CIR avg per FCU) | N2 flow rate: | slpm
ent before? no yes, to | psia
Iso just before? | fan o GC scrub
FP? no fixed moving D back-n-forth
INSTRUMENTATION | ain: | DataCam 2—-1 ops camera
<DataCam: filter? | BG7 | CH20 | ROI? | reduced | fps
filter? clear ZCH* CH20 none | ROI? *full reduced | Efps
E-HiBMs: backlight filter? no yes | CIR backlight? no yes fps2a-1S-aB01te
FLAME BEHAVIOR
Flame hot cool maybe cool | Ignited? yes no yes, but .
Flame hole/opening partially detached | SOOt@ignition ü none little lots
Flame c] oscillating o unsteady K quasi-stead | 00t@middIe none little lots
Out ext. detecty-time out temp. limit | oot@end | none little o lots
POST-TEST CONDITIONS
Fuel conc. | // | % (vol, per calc) | Chamber pressure: | (CIR avg per FCU)
alve safety timer | sec | Oxidizer bottle pressure: | psia
70 ?
*GENERAL COMMENTS
19 Oct. 2021
~~~~

### Pagina 7

Cita: [pdf_ec2386d890b3e3cdaf66, p. 7]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_ec2386d890b3e3cdaf66/p0007.jpg)

~~~~text
ACME / Flame Design (inverse flame) - Science Test Sheet
est date: | é zozl | CME test#:
Local time: | est of day | 7
GMT: | Flame of day #:
TEST CONDITIONS | Control? | Qfully automated 'manual'
Test type? o ignition a no-flame {standard o other
Chamber atmosphere | 02 bottle: | 85% (volume)
C2H4 conc. | % (vol, nominal) | Burner 02 conc.: | % (volume
C2H4 conc. | / | % (vol, per calc) | 2 flow rate: | slpm (N2 basis)
hamber pressure: | psia (CIR avg per FCU) | N 2 flow rate: | slpm
ent before? no yes, to | psia
Iso just before? | fan o GC scrub
moving back-n-forth
INSTRUMENTATION | ain: | DataCam | ops camera
QDataCam: filter? | BG7 0 | CH20 | ROI? full o reduced | fps
A Intensified: filter? clearACH* CH20 none | ROI? g full ü reduced | 22 fps
: backlight filter? | yes | CIR backlight?E no yes fps-?-e45-e-30
0
FLAME BEHAVIOR
Flame hot cool o maybe cool | Ignited? E yes no o yes, but ..
Flame hole/opening c] partially detached | 00t@ignition none little lots
Flame oscillating unsteady quasi-stead | Soot@middle knone little o lots
Out ext. detecta time out temp. limit | Soot@end | none little lots
POST-TEST CONDITIONS
Fuel conc. | % (vol, per calc) | hamber pressure: | psia (CIR avg per FCU
alve safety timer | sec | xidizer bottle pressure: | psia
zib
*GENERAL COMMENTS
19 Oct. 2021
~~~~

### Pagina 8

Cita: [pdf_ec2386d890b3e3cdaf66, p. 8]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_ec2386d890b3e3cdaf66/p0008.jpg)

~~~~text
ACME / Flame Design (inverse flame) - Science Test Sheet
est date: | CME test#:
Local time: | est of day#: g
GMT: | Flame of day #:
Rack Officer (RO): | PD (ACME):
DMO (CIR): | Researcher:
TEST CONDITIONS | Control? | Qfully automated 'manual'
Test type? ignition a no-flame standard a other
Chamber atmosphere | 02 bottle: | 85% (volume)
C2H4 conc. | % (vol, nominal) | Burner 02 conc.: | % (volume)
C2H4 conc. / | % (vol, per calc) | 02 flow rate: | slpm (N2 basis)
hamber pressure: | psia (CIR avg per FCU) | N2 flow rate: | D-Z-7 | slpm
ent before? Ano yes, to | psia
Iso just before? | fan GC scrub
FP? t/no c] fixed o moving back-n-forth
INSTRUMENTATION | ain: | DataCam | ops camera
DataCam: | BG7 | CH20 | ROI?je• full reduced | fps
filter? clear ACH* CH20 none | ROI ? A full reduced | Z fps
cuHiBMs: backlight filter? o n | yes | CIR backlight? yho c] yes fps2-u-J5æ„30
FLAME BEHAVIOR
Flamen hot c] cool o maybe cool | Ignited? yes no o yes, but ...*
Flame o hole/opening o partially detached | 00t@ignition c] none ü little "lots
Flame oscillating o unsteady | Soot@middle none D little lots
Out ext. detect time out temp. limit | 00t@end | none o little lots
POST-TEST CONDITIONS
*GENERAL COMMENTS
42),
/
19 Oct. 2021
~~~~

### Pagina 9

Cita: [pdf_ec2386d890b3e3cdaf66, p. 9]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_ec2386d890b3e3cdaf66/p0009.jpg)

~~~~text
ACME / Flame Design (inverse flame) - Science Test Sheet
est date: | CME test#: 2-1
Local time: | est of day #:
GMT: | Flame of day #:
TEST CONDITIONS | Control? | fully automated 'manual'
Test type? ignition no-flame. standard@ther-G—
hamber atmosphere | 02 bottle: | 85% (volume)
C2H4 conc. | % (vol, nominal) | Burner 02 conc.: | % (volume)
C2H4 conc. | / | % (vol, per calc) | 02 flow rate: | slpm (N2 basis)
Chamber pressure: | ( psia (CIR avg per FCU) | N2 flow rate: | A 19 | slpm
ent | o yes, to | psia
Iso just before? | an GC scrub
fixed moving back-n-forth
INSTRUMENTATION | Gain: | DataCam Zi ops camera
ADataCam: filter? | BG7 | CH20 | ROI?Rfull ü reduced | fps
Intensified: filter? | CH20 none | ROI? Afull reduced | fps
æ44iBMs: backlight filter? nozyes | CIR backlight? Eno yes fps-?æ45-c 30
FLAME BEHAVIOR
Flame hot cool maybe cool | Ignited? eyes c] no yes, but *
...
Flame hole/opening partially detached | 00t@ignition none c] little
Flame oscillating unsteadyÅquasi-stead | 00t@middle none little o lots
Out c] ext. detect time out o temp. limit | 00t@end | 3Cnone little lots
POST-TEST CONDITIONS
*GENERAL COMMENTS
19 Oct. 2021
~~~~

### Pagina 10

Cita: [pdf_ec2386d890b3e3cdaf66, p. 10]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_ec2386d890b3e3cdaf66/p0010.jpg)

~~~~text
ACME / Flame Design (inverse flame) - Science Test Sheet
est date: | CME test #:
Local time: | est of day#: D
GMT: | 4b | -25 | Flame of day #:
Rack Officer (RO): | PD (ACME):
DMO (CIR): | Researcher:
TEST CONDITIONS | Control? | Åfully automated 'manual'
Test type? ignition no-flame éstandard
Chamber atmosphere | 02 bottle: | 85% (volume)
C2H4 conc. | % (vol, nominal) | Burner 02 conc.. | % (volume)
2H4 conc. | % (vol, per calc) | 2 flow rate: | slpm (N2 basis)
Chamber pressure: | psia (CIR avg per FCU | N 2 flow rate: | slpm
ent before? no yes, to | psia
Iso just before? | fan GC scrub
FP? o noßfixed o moving o back-n-forth
INSTRUMENTATION | ain: | DataCam | ops camera
LIDataCam: filter? gclear BG7 | ü CH20 | ROI? A full o reduced | fps
k Intensified: filter? clearÄCH* CH20 none | ROI? R full reduced | fps
æ-Hi-BMs•. backlight filter? no *yes | CIR backlight? *no o yes fps-?-o-1-5ü30
FLAME BEHAVIOR
Flamekhot cool maybe cool | Ignited? yes no yes, but .
Flame o hole/opening o partially detached | oot@ignition none littlek lots
Flame c] oscillating c] unsteady quasi-stead | 00t@middle phone c] little lots
Out o ext. detect time out temp. limit | 00t@end | Z none c little [.3 lots
POST-TEST CONDITIONS
*GENERAL COMMENTS
Vt-tb
19 Oct. 2021
~~~~

### Pagina 11

Cita: [pdf_ec2386d890b3e3cdaf66, p. 11]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_ec2386d890b3e3cdaf66/p0011.jpg)

~~~~text
ACME / Flame Design (inverse flame) - Science Test Sheet
est date: | CME test#:
Local time: | est of day#: /
GMT: | Flame of day #: /
TEST CONDITIONS | Control? | Z fully automated c] 'manual'
Test type? o ignition no-flame<standard Lother —T--É:e———
hamber atmosphere | 02 bottle: | 85% (volume)
C2H4 conc. | % (vol, nominal) | Burner 02 conc.: | % (volume)
C2H4 conc. | % (vol, per calc) | 02 flow rate: | D. | slpm (N2 basis)
hamber pressure: | psia (CIR avg per FCU) | N2 flow rate: | slpm
ent before? | yes, to | psia
Iso just before? Han GC scrub
FP? o noßfixed o moving back-n-forth
INSTRUMENTATION | ain: | DataCam | ops camera
U Datacam: filter? Éclear BG7 | CH20 | ROI? fi full o reduced | fps
Vlntensified: filter? | c] CH20 none | full reduced | Z>fps
R--ÆBM?. backlight filter? no,c yes | CIR | yes
FLAME BEHAVIOR
Flame | ü cool o maybe cool | Ignited? yes o no o yes, but ..
Flame hole/opening o partially detached | 00t@ignition none little <Lots
Flame oscillating | 00t@middle Znone little lots | ash
o | unsteadykquasi-stead
ut D ext. detectÅtime out temp. limit | 00t@end | Znone little lots
POST-TEST CONDITIONS
Fuel conc. | / | % (vol, per calc) | Chamber pressure: | psia (CIR avg per FCU
alve safety timer | sec | Oxidizer bottle pressure: | psia
*GENERAL COMMENTS
19 Oct. 2021
~~~~

### Pagina 12

Cita: [pdf_ec2386d890b3e3cdaf66, p. 12]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_ec2386d890b3e3cdaf66/p0012.jpg)

~~~~text
ACME / Flame Design (inverse flame) - Science Test Sheet
est date: | CME test#: | (
Local time: | est of day#:
GMT: | Flame of day#:
TEST CONDITIONS | Control ? | u fully automated ü 'manual'
Test type? ignition no-flame
Chamber atmosphere | 02 bottle: | 85% (volume)
C2H4 conc. | C 0/0 (vol, nominal) | Burner 02 conc.: | % (volume)
C2H4 conc. | /2//2 | 0/0 (vol, per | 02 flow rate: | slpm (N2 basis
hamber pressure: | psia (CIR avg per FCU) | N 2 flow rate: | slpm | ME)
ent before? o no yes, to | psia
Iso just before? | fan o GC o scrub
FP? no fixed o moving D back-n-forth
INSTRUMENTATION | ain: | O DataCam 2_ ops camera
QataCam: filter?kclear o BG7 CH* CH20 | ROI? k full reduced | fps
Llntensified: filter? clear •CH* CH20 none | ROI? Zfull reduced | E fps
filter? nocyes | CIR backlight? | yes
FLAME BEHAVIOR
Flame Khot cool o maybe cool | Ignited?Üyes no o yes, but
.
Flame hole/opening partially detached | 00t@ignition none o littl | lots
Flame | unsteady o quasi-stead | SOOt@middle Knone little o lots
Out*åext. detect time out temp. limit | oot@end | none little lots
POST-TEST CONDITIONS
Fuel conc. | % (vol, per calc) | Chamber pressure: /4„7psia (CIR avg per FCU
alve safety timer | sec | Oxidizer bottle pressure: 'Z | psia
*GENERAL COMMENTS
—k (dewJ9z_,—
Ipe
19 Oct. 2021
Éj | OSc-i | 46
_LX
~~~~

### Pagina 13

Cita: [pdf_ec2386d890b3e3cdaf66, p. 13]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_ec2386d890b3e3cdaf66/p0013.jpg)

~~~~text
ACME / Flame Design (inverse flame) - Science Test Sheet
est date: | CME test | Zi
Local time: | est of day #:
GMT: | Flame of day #:
TEST CONDITIONS | Control? | Cf'fully automated 'manual'
Test type? o ignition no-flame <-standardß other
Chamber atmosphere | 02 bottle: | 85% (volume)
C2H4 conc. | 0/0 (vol, nominal) | Burner 02 conc.: | % (volume)
C2H4 conc. | / | % (vol, per calc) | 02 flow rate: | slpm (N2 basis)
hamber pressure: ) | psia (CIR avg per FCU) | N2 flow rate: | 02.51 | slpm
ent before? Eno yes, to | psia
Iso just before? Afan GC scrub
FP? o no h4ixed o moving back-n-forth
INSTRUMENTATION | ain: C) DataCam | ops camera
(DataCam: filter?Aclear BG7 CH* CH20 | ROI? k full ü reduced | fps
Llntensified: filter? o clearØ CH* CH20 none | ROI? Kfull o reduced | fps
a-HiBMs: backlight filter? | CIR backlight?kno yes
FLAME BEHAVIOR
Flame hot o cool maybe cool | Ignited? Zyes no yes, but .
Flame o hole/opening •partially detached | 00t@ignition none o little Oots
Flame Q oscillating unsteady quasi-stead | 00t@middle k none o little lots
Out | time out ü temp. limit | oot@end | none c.] little c] lots
POST-TEST CONDITIONS
Fuel conc. | % (vol, per calc) | hamber pressure: | psia (CIR avg per FCU
alve safety timer | sec | Oxidizer bottle pressure: | psia
*GENERAL COMMENTS
¯ -so-yie | A
-ÅJe—19 Oct. 2021
~~~~
