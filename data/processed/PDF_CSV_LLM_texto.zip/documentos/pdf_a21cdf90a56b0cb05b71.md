# 22018 test sheets

- Identificador: pdf_a21cdf90a56b0cb05b71
- Investigaciones: PSI-10
- Tipo de documento: Raw Data
- Estado: processed
- Temas detectados automaticamente: pressure, ignition, hardware, oxygen, soot

## Fuentes

- [PSI-10_Raw Data_22018 test sheets.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-10/Raw%20Data/PSI-10_Raw%20Data_22018%20test%20sheets.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_a21cdf90a56b0cb05b71, p. 1]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_a21cdf90a56b0cb05b71/p0001.jpg)

~~~~text
ACME / Flame Design (inverse flame) - Science Test Sheet
est date: | CME test
Local time: | est of day#:
GMT: 22— D 6 | Flame of day #:
Rack Officer (RO): | PD (ACME):
DMO (CIR): | Researcher:
TEST CONDITIONS | Control? | Efully automated 'manual'
Test type? ignition no-flame<standard other
Chamber atmosphere | 02 bottle: | 85% (volume)
C2H4 conc. | % (vol, nominal) | Burner 02 conc.. | % (volume)
C2H4 conc. | % (vol, per calc) | 02 flow rate: | slpm (N2 basis)
hamber pressure: | psia (CIR avg per FCU) | D | slpm
ent before? o no Ryes, to Ö- Z psia
Iso just before? | fan GC scrub
FP? Kno fixed moving back-n-forth
INSTRUMENTATION | ain: | DataCam [Z ops camera
ZDataCam: filter? zclear o BG7 0 CH* CH20 | ROI? k full reduced | fps
E Intensified: filter? clear QCH* CH20 none | ROI? gfull o reduced | fps
a-HiBMs: backlight filter? o no Elyes | CIR backlight? kno yes
FLAME BEHAVIOR
Flame Zhot a cool maybe cool | Ignited? yes no yes, but *
...
Flame hole/opening partially detached | 00t@ignition o none a little (lots
Flame oscillating a unsteady quasi-stead | 00t@middle D none S(little c] lots
Out ext. detect •time out temp. limit | oot@end | none little lots
POST-TEST CONDITIONS
*GENERAL COMMENTS
19 Oct. 2021
~~~~

### Pagina 2

Cita: [pdf_a21cdf90a56b0cb05b71, p. 2]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_a21cdf90a56b0cb05b71/p0002.jpg)

~~~~text
ACME / Flame Design (inverse flame) - Science Test Sheet
est date: | I | zezz | CME test#.•
Local time: | est of day#:
MT: — 2 ot & | 55 | Flame of day#: Z
( | 5ü«s
TEST CONDITIONS | Control? | fully automated o 'manual'
Test type? ignition no-flame Zstandard
Chamber atmosphere | 2 bottle: | 85% (volume)
C2H4 conc. | % (vol, nominal) | Burner 02 conc.: | % (volume
2H4 conc. | % (vol, per calc) | 02 flow rate: | slpm (N2 basis)
Chamber pressure: | psia (CIR avg per FCU) | slpm
Z—
ent before? uno yes, to | psia
Iso just before? | o GCa scrub
FP? o no | o moving back-n-forth
INSTRUMENTATION | ain: (D DataCam I Z- ops camera
XDataCam: filter? Y-clear o BG7 CH* o CH20 | ROI? Rfull reduced | fps
Intensified: filter? | o CH20 0 none | ROI? k full o reduced | '23fps
: backlight filter? no<yes | CIR | yes
FLAME BEHAVIOR
Flame g-hot o cool maybe cool | Ignited? yes no o yes, but ...*
Flame hole/opening o partially detached | 00t@ignition none ü littleZlots
Flame o oscillating unsteadykquasi-stead | 00t@middle (none c] little c] lots
Out o ext. detectq-time out temp. limit | 00t@end | little lots
POST-TEST CONDITIONS
*GENERAL COMMENTS
19 Oct. 2021
~~~~

### Pagina 3

Cita: [pdf_a21cdf90a56b0cb05b71, p. 3]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_a21cdf90a56b0cb05b71/p0003.jpg)

~~~~text
ACME / Flame Design (inverse flame) - Science Test Sheet
est date: | Ze 22— | CME test
Local time: | est of day
GMT: | Flame of day
TEST CONDITIONS | Control? | A fully automated 'manual'
Test type? ignition no-flame Cstandard Sother
hamber atmosphere | 02 bottle: | 85% (volume)
C2H4 conc. | % (vol, nominal) | Burner 02 conc.: | % (volume
C2H4 conc. | % (vol, per calc) | 02 flow rate: | slpm (N2 basis)
hamber pressure: 14-7 psia (CIR avg per FCU | N2 flow rate: | slpm
ent before? no yes, to | psia
Iso just before? gfan GC scrub
FP? no €fixed o moving a back-n-forth
INSTRUMENTATION | ain: | C) DataCam i 2-- ops camera
Datacam: filter? clear BG7 | CH20 | ROI? < full D reduced | fps
z Intensified: filter? | CH20 0 none | ROI?éfull reduced | 22 fps
a-HiBMs:-backlight filter? no Qyes | CIR backlight? no yes
FLAME BEHAVIOR
Flame ghot o cool maybe cool | Ignited? yes no D yes, but
.
Flame hole/opening partially detached | 00t@ignition none ü little klots
Flame o oscillating ü unsteady quasi-stead | 00t@middle < none little lots
Out o ext. detect time out o temp. limit | SOOt@end | none little lots
POST-TEST CONDITIONS
Fuel conc. | % (vol, per calc) | Chamber pressure: | psia (CIR avg per FCU
alve safety timer | sec | Oxidizer bottle pressure: go psia
*GENERAL COMMENTS
13
19 Oct. 2021
~~~~

### Pagina 4

Cita: [pdf_a21cdf90a56b0cb05b71, p. 4]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_a21cdf90a56b0cb05b71/p0004.jpg)

~~~~text
ACME / Flame Design (inverse flame) - Science Test Sheet
est date: | 2-0 2-2— | CME test
Local time: | est of day #:
GMT: | 22 | Flame of day #:
TEST CONDITIONS | Control? | automated 'manual'
Test type? o ignition no-flame Astandard X-other | I
Chamber atmosphere | 2 bottle: | 85% (volume)
C2H4 conc. | % (vol, nominal) | Burner 02 conc.: | % (volume
2H4 conc. | / | % (vol, per calc) | 2 flow rate: | slpm (N2 basis)
-
Chamber pressure: | psia (CIR avg per FCU) | N2 flow rate: | slpm
ent before? wno yes, to | psia
Iso just before? Zfan o GC o scrub
FP? | moving back-n-forth
INSTRUMENTATION | ain: | C) DataCam _LZ_ ops camera
DataCam: filter? <clear BG7 0 CH* o CH20 | ROI? Q full o reduced | fps
Z Intensified: filter? clear | CH20 none | ROI? gfull o reduced | Z fps
•æ-H.iBMs: backlight filter? no yes | CIR backlight?m no yes
FLAME BEHAVIOR
Flame hot o cool maybe cool | no D yes, but .
Flame hole/opening partially detached | 00t@ignition o none little •tots
Flame oscillating unsteady kquasi-stead | 00t@middIe none little lots
Out o ext. detect | ime out o temp. limit | oot@end | none little o lots
POST-TEST CONDITIONS
Fuel conc. | % (vol, per calc) | Chamber pressure: | psia (CIR avg per FCU
alve safety timer | sec | Oxidizer bottle pressure: | 30 psia
Z 2-1
*GENERAL COMMENTS
ff9be--v--
19 Oct. 2021
~~~~

### Pagina 5

Cita: [pdf_a21cdf90a56b0cb05b71, p. 5]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_a21cdf90a56b0cb05b71/p0005.jpg)

~~~~text
ACME / Flame Design (inverse flame) - Science Test Sheet
est date: | 08 Zejzz— | CME test #:
Local time: | est of day #:
MT: | ZZ | Flame of day #:
TEST CONDITIONS | Control? | Q fully automated 'manual'
Test type? ignition no-flame<standard other
Chamber atmosphere | 02 bottle: | 85% (volume)
C2H4 conc. | % (vol, nominal) | Burner 02 conc.: | C, % (volume)
2H4 conc. | / U 4" 0/0 (vol, per calc) | 02 flow rate: | slpm (N2 basis
Chamber pressure: | psia (CIR avg per FCU | N 2 flow rate: | slpm
ent before? eno yes, to | psia
Iso just before? | an o GC D scrub
FP? no [Xlfixed moving o back-n-forth
INSTRUMENTATION | ain: | DataCam i | ops camera
V-DataCam: filter?ßclear BG7 ü | CH20 | full o reduced | fps
g-lntensified: filter? clear k CH* o CH20 none | ROI?ß full reduced | Z fps
a-HiBMs: backlight filter? no y-yes | CIR backlight? Rno yes fps?-t-1-5a-30
FLAME BEHAVIOR
Flame | 6t o cool maybe cool | no yes, but *
...
Flame hole/opening c] partially detached | 00t@ignition none little lots
Flame oscillating unsteady Zguasi-stead | 00t@middle none little o lots
Out o ext. | out o temp. limit | 00t@end knone c] little lots
POST-TEST CONDITIONS
*GENERAL COMMENTS
19 Oct. 2021
~~~~

### Pagina 6

Cita: [pdf_a21cdf90a56b0cb05b71, p. 6]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_a21cdf90a56b0cb05b71/p0006.jpg)

~~~~text
ACME / Flame Design (inverse flame) - Science Test Sheet
est date: | CME test
Local time: | est of day #:
MT: | / Z | Flame of day #:
TEST CONDITIONS | Control? | V fully automated ü 'manual'
Test type? a ignition no-flameastandar# other
Chamber atmosphere | 2 bottle: | 85% (volume)
C2H4 conc. | % (vol, nominal) | Burner 02 conc.: | % (volume)
Z C2H4 conc. | % | 02 flow
(vol, per calc) | rate: | 0-172— slpm (N2 basis)
hamber pressure: | psia (CIR avg per FCU | te: | Ö | slpm
ent before? a no yes, to | psia
Iso just before? | 'fan o GC scrub
FP? o no fixed o moving a back-n-forth
INSTRUMENTATION | Gain: | C) DataCam _ZA_ ops camera
DataCam: filter? gclear BG7 0 CH* CH20 | ROI?9Q full reduced | fps
Intensified: filter? D | none | ROI?E full o reduced | 2fps
a-HiBMs: backlight filter | es | CIR backlight? Eno yes fps-?-e-æs-s-30
FLAME BEHAVIOR
Flame hot o cool o maybe cool | Ignited? "yes no o yes, but ...*
Flame hole/openingkpartially detached | 00t@ignition o none little Wots
Flame | unsteady | 00t@middle knone little lots
Out Qext. detect time out c] temp. limit | 00t@end | Énone o little lots
POST-TEST CONDITIONS
Fuel conc. | -É | % (vol, per calc) | hamber pressure: / | psia (CIR avg per FCU)
alve safety timer | sec | Oxidizer bottle pressure: 76 psia
*GENERAL COMMENTS
Ash
19 Oct. 2021
~~~~

### Pagina 7

Cita: [pdf_a21cdf90a56b0cb05b71, p. 7]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_a21cdf90a56b0cb05b71/p0007.jpg)

~~~~text
ACME / Flame Design (inverse flame) - Science Test Sheet
TEST CONDITIONS | Control ? | K fully automated o 'manual'
Test type? ignition | other
Chamber atmosphere | 02 bottle: | 85% (volume)
C2H4 conc. | 0/0 (vol, nominal) | Burner 02 conc.: | % (volume
C2H4 conc. | % (vol, per calc) | 02 flow rate: | 6 | slpm (N2 basis)
hamber pressure: | psia (CIR avg per FCU) | Niftowrate: | slpm
ent before? | o yes, to | psia
Iso just before? Q fan GC scrub
FP? o no 'fixed o moving a back-n-forth
INSTRUMENTATION | ain: | D DataCam Z) ops camera
filter? X clear o BG7 0 CH* CH20 | ROI? (full o reduced | fps
ulntensified: filter? clear | CH20 0 none | ROI? R full reduced | z2fps
æ-HiBMs: backlight filter? no *Sles | CIR backlight? •no yes fps2g-.æs-g.30
FLAME BEHAVIOR
Flame | o cool o maybe cool | Ignited? Kyes no yes, but ...*
Flame hole/opening partially detached | 00t@ignition D none o little *Jots
Flame oscillating unsteady o quasi-stead | 00t@middle none o little lots
Out xext. detect time out temp. limit | 00t@end | none o little lots
POST-TEST CONDITIONS
Fuel conc. | % (vol, per calc) | Chamber pressure: | psia (CIR avg per FCU
alve safety timer | q | sec | Oxidizer bottle pressure: | psia
*GENERAL COMMENTS
42 | )
19 Oct. 2021
~~~~

### Pagina 8

Cita: [pdf_a21cdf90a56b0cb05b71, p. 8]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_a21cdf90a56b0cb05b71/p0008.jpg)

~~~~text
ACME / Flame Design (inverse flame) - Science Test Sheet
est date: | CME test#:
Local time: | est of day#: g
MT: | 2-2 Ö | Flame of day #:
TEST CONDITIONS | ontrol? | )Qfully automated a 'manual'
Test type? ignition no-flame <standardkother
Chamber atmosphere | 02 bottle: | 85% (volume)
C2H4 conc. | % (vol, nominal) | Burner 02 conc.: | % (volume
2H4 conc. | % (vol, per calc) | 02 flow rate: | Slpm (N2 basis)
Chamber pressure: | psia (CIR avg per FCU) | ft2-ftuwrate: | slpm
ent before? | yes, to | psia
Iso just before? g_fan GC scrub
FP? no (fixed moving c] back-n-forth
INSTRUMENTATION | ain: | D DataCam | ops camera
DataCam: | clear o BG7 CH* o CH20 | ROI? Oull reduced | fps
glntensified: filter? clear | CH20 0 none | ROI? p full reduced | fps
B-HiBMs: backlight filter? | CIR backlight?tg'no yes
FLAME BEHAVIOR
Flamebt hot o cool maybe cool | Ignited? yes D no D yes, but ..
Flame a hole/openin | artially detached | 00t@ignition CJ none littleb< lots
Flame | 7
oscillating•unsteady quasi-stead | 00t@middle none little lots
Out *Xt. detect time out temp. limit | oot@end | none o little lots
POST-TEST CONDITIONS
*GENERAL COMMENTS
19 Oct. 2021
~~~~

### Pagina 9

Cita: [pdf_a21cdf90a56b0cb05b71, p. 9]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_a21cdf90a56b0cb05b71/p0009.jpg)

~~~~text
ACME / Flame Design (inverse flame) - Science Test Sheet
est date: | 2ezz | CME test #:
Local time: | est of day #:
GMT: | Flame of day#:
TEST CONDITIONS | Control? | Rfully automated 'manual'
Test type? ignition no-flame V-standard L other | É
Chamber atmosphere | 02 bottle: | 85% (volume)
C2H4 conc. | "V IO % (vol, nominal) | Burner 02 conc.: | % (volume
2H4 conc. | % (vol, per calc) | 02 flow rate: | Z- slpm (N2 basis)
Chamber pressure: | "ia (CIR avg per FCU | N 2 flow rate: | slpm
ent before? Eno o yes, to | psia
Iso just before? '(fan GC scrub
FP? no Vfixed a moving back-n-forth
INSTRUMENTATION | ain: | O DataCam _2_L | camera
ops
LDataCam: filter? | BG7 | CH20 | ROI? | o reduced | fps
Afull
Clntensified: filter? clear uTH* CH20 0 none | ROI? 'Zfull o reduced | 2-2 fps
-e-HiBMs: backlight filter? no€-yes | CIR backlight?øno yes | MS
FLAME BEHAVIOR
Flame o hot cool o maybe cool | Ignited? ü yes no o yes, but ...*
Flame hole/opening partially detached | 00t@ignition o none little lots
Flame oscillating unsteady c] quasi-stead | 00t@middle o none little cj lots
ut o ext. detect c] time out c] temp. limit | oot@end | none o little lots
POST-TEST CONDITIONS
*GENERAL COMMENTS
12 G L
19 Oct. 2021
~~~~

### Pagina 10

Cita: [pdf_a21cdf90a56b0cb05b71, p. 10]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_a21cdf90a56b0cb05b71/p0010.jpg)

~~~~text
ACME / Flame Design (inverse flame) - Science Test Sheet
est date: | CME test
Local time: | est of day#: iO
MT: | i | 2 ziz- | Flame of day | '
Rack Officer (RO): | PD (ACME):
DMO (CIR): | Researcher:
TEST CONDITIONS | Control? | L fully automated c] 'manual'
Test type? o ignition no-flame Y-standard
Chamber atmosphere | 02 bottle: | 85% (volume)
C2H4 conc. | % (vol, nominal) | Burner 02 conc.: | % (volume
2H4 conc. | % (vol, per calc) | 02 flow rate: | OVIS Z- slpm (N2 basis)
Chamber pressure: | psia (CIR avg per FCU) | N2 flow rate: | slpm
ent before? | yes, to | psia
Iso just before? | fan o GC ü scrub
FP? no | o moving o back-n-forth
INSTRUMENTATION | Gain: | DataCam | ops camera
LDataCam: filter? | BG7 | CH20 | ROI? full reduced | fps
*Intensified: filter? clear | o CH20 0 none | ROI? afull o reduced | 22 fps
a-Hi.BMs; backlight filter? noSyes | CIR backlight?X no yes 4ps?-tr1-5-0 30
FLAME BEHAVIOR
FlameA hot o cool maybe cool | Ignited? yes no yes, but *
...
Flame hole/opening partially detached | 00t@ignition o none little lots
Flame Oscillating unsteady quasi-stead | 00t@middle N none little lots
Out | detect time out a temp. limit | 00t@end | none little o lots
POST-TEST CONDITIONS
Fuel conc. | % (vol, per calc) | Chamber pressure: | psia (CIR avg per FCU
alve safety timer | 4 | sec | Oxidizer bottle pressure: —z | psia
*GENERAL COMMENTS
19 Oct. 2021
~~~~

### Pagina 11

Cita: [pdf_a21cdf90a56b0cb05b71, p. 11]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_a21cdf90a56b0cb05b71/p0011.jpg)

~~~~text
ACME / Flame Design (inverse flame) - Science Test Sheet
est date: | CME test
Local time: | est of day#: / i
GMT.• | 23 | Flame of day #:D
TEST CONDITIONS | Control? | Afully automated 'manual'
Test type? ignition no-flame NStandard
Chamber atmosphere | 02 bottle: | 85% (volume)
2H4 conc. | % (vol, nominal) | Burner 02 conc.. | 2-9/0 (volume
C2H4 conc. | % (vol, per calc) | 02 flow rate: | 2 | slpm (N2 basis)
hamber pressure: | psia (CIR avg per FCU) | N2 flow rate: | Q | slpm
ent before? gno yes, to | psia
Iso just before? o fan GCo scrub
FP? noZfixed o moving ü back-n-forth
INSTRUMENTATION | ain: | Ö DataCam Zi ops camera
(Datacam: filter? | BG7 | o CH20 | ROI? Rfull reduced | fps
Llntensified: filter? CJ clear RCH* CH20 none | ROI? Efull reduced | &fps
g44iBMs±acklight filter? noæyes | CIR backlight?ano yes
FLAME BEHAVIOR
Flame Zhot o cool maybe cool | Ignited? Q yes o no o yes, but ...*
Flame hole/opening partially detached | 00t@ignition none ? little? lots
Flame goscillating Nunsteady o quasi-stead | 00t@middle enone tittle lots
Out <ext. detect a time out o temp. limit | 00t@end | knone little t] lots
POST-TEST CONDITIONS
Fuel conc. | % (vol, per calc) | Chamber pressure: | psia (CIR avg per FCU
alve safety timer | sec | Oxidizer bottle pressure: CC psia
Z 2-1 | I
*GENERAL COMMENTS
61
19 Oct. 2021
~~~~

### Pagina 12

Cita: [pdf_a21cdf90a56b0cb05b71, p. 12]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_a21cdf90a56b0cb05b71/p0012.jpg)

~~~~text
ACME / Flame Design (inverse flame) - Science Test Sheet
est date: | ZUZ?— | CME test
Local time: | est of day#: I Z—
MT: | 21 | Flame of day#: /
TEST CONDITIONS | Control? | Q fully automated 'manual'
Test type? D ignition o no-flame y-standard* other
hamber atmosphere | 02 bottle: | 85% (volume)
C2H4 conc. | I D % (vol, nominal) | Burner 02 conc.: | % (volume
2H4 conc. | % (vol, per calc) | 02 flow rate: | slpm (N2 basis
Chamber pressure: | psia (CIR avg per FCU) | slpm
ent before? | yes, to | psia
Iso just before? | fan c] GC o scrub
o no<fixed moving o back-n-forth
INSTRUMENTATION | ain: | ö DataCam | ops camera
(DataCam: filter? Gear o BG7 CH* CH20 | ROI? <zfull reduced | fps
Ulntensified: filter? D | CH20 none | ROI? e full o reduced | fps
cæHiBMs•. backlight filter? | yes | CIR backlight?g-no yes fps?-g45a-Sff-
FLAME BEHAVIOR
Flame | D cool maybe cool | Ignited? yes no o yes, but ...*
Flame o hole/opening partially detached | 00t@ignition o none little lots
FlameÅ oscillating unsteady ü quasi-stead | 00t@middle none little lots
Outvext. detect ü time out temp. limit | 00t@end | little c.] lots
POST-TEST CONDITIONS
Fuel
*GENERAL COMMENTS
19 Oct. 2021
~~~~

### Pagina 13

Cita: [pdf_a21cdf90a56b0cb05b71, p. 13]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_a21cdf90a56b0cb05b71/p0013.jpg)

~~~~text
ACME / Flame Design (inverse flame) - Science Test Sheet
est date: | CME test#:
Local time: | est of day#: 13
GMT: | A-zzz3 | Flame of day #: | zzr•e
TEST CONDITIONS | Control? | (W fully automated c] 'manual'
Test type? o ignition o no-flame [XStandard other
Chamber atmosphere | 02 bottle: | 85% (volume)
2H4 conc. | •iD % (vol, nominal) | Burner 02 conc.: | % (volume)
C2H4 conc. | % (vol, per calc) | 02 flow rate:03 | slpm (N2 basis)
Chamber pressure: | psia (CIR avg per FCU) | N2 flow rate: | slpm
ent before? no yes, to | psia
Iso just before? | fan GC o scrub
FP? Yno fixed o moving back-n-forth
INSTRUMENTATION | Gain: 222 DataCam | ops camera
DataCam: filter? yclear BG7 0 CH* o CH20 | ROI? Qfull reduced | fps
Intensified: filter? clear LCH* o CH20 c] none | ROI?L full reduced | fps
a-Hi-BMs: backlight filter? no æ/es | CIR backlight?Jzno yes
FLAME BEHAVIOR | 14
Flame hot o cool ü maybe cool | Ignited? yes p-no o yes, but *
...
Flame hole/opening partially detached | 00t@ignition none CJ littl
Flame o oscillating unsteady o quasi-stead | 00t@middle c] none little lots
Out ext. detect time out temp. limit | 00t@end | o none little lots
POST-TEST CONDITIONS
*GENERAL COMMENTS
be | 4jZce-
&SccI
Cite
19 Oct. 2021
~~~~

### Pagina 14

Cita: [pdf_a21cdf90a56b0cb05b71, p. 14]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_a21cdf90a56b0cb05b71/p0014.jpg)

~~~~text
ACME / Flame Design (inverse flame) - Science Test Sheet
est date: | CME test | 2-2ezg
Local time: | est of day#: I
GMT: | Flame of day#: Z
TEST CONDITIONS | Control? | fully automated c] 'manual'
Test type? ignition no-flame | tandard a other
Chamber atmosphere | 02 bottle: | 85% (volume)
C2H4 conc. | % (vol, nominal) | Burner 02 conc.: | % (volume
2H4 conc. | 4 | % (vol, per calc) | 02 flow rate: DS | lpm (N2 basis)
Chamber pressure: | psia (CIR avg per FCU) | N2 flow rate: | slpm
ent before? | yes, to | psia
Iso just before? o fan GC scrub
FP? 'no o fixed o moving o back-n-forth
INSTRUMENTATION | ain.• 26 DataCam 2-9 ops camera
QDataCam: filter? <clear BG7 D CH* o CH20 | ROI? | o reduced | fps
Ulntensified: filter? o clear | CH20 0 none | ROI? Lfull o reduced | 2.2 fps
g-H.iBMs•. backlight filter? | yes | CIR backlight? | yes
FLAME BEHAVIOR
Flame Khot o cool maybe cool | Ignited? <yes no yes, but *
...
Flame hole/opening El partially detached | 00t@ignition none little (lots
Flame •oscillating Cunsteady ü quasi-stead | 00t@middle none o little lots
Out Åext. detect time out o temp. limit | oot@end | none little o lots
POST-TEST CONDITIONS
Fuel conc. | % (vol, per calc) | Chamber pressure: | psia (CIR avg per FCU
alve safety timer | 6' | sec | Oxidizer bottle pressure: | psia
*GENERAL COMMENTS
~~~~
