# 21291 test parameter notes

- Identificador: pdf_b47b43f7450e4bd55ada
- Investigaciones: PSI-159
- Tipo de documento: Raw Data
- Estado: processed
- Temas detectados automaticamente: ignition, extinction, hardware, operations

## Fuentes

- [PSI-159_Raw Data_21291 test parameter notes.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-159/Raw%20Data/PSI-159_Raw%20Data_21291%20test%20parameter%20notes.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_b47b43f7450e4bd55ada, p. 1]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_b47b43f7450e4bd55ada/p0001.jpg)

~~~~text
testpointName | 21291A1
dataCameraPre'gnitionExposureUs | 1000000
dataCameraTestExposureUs | 1000000
analog CameraShutte | 2
uselntensifiedCamera
intensifierlgniti0nGain | 20000
intensifier TestGain | 80000
prelgnitionlmageTimeSec
postFlamelmagingTimeSe | 5
useDataCameraAut0Gain
autoGainT01erancePercen | 5
autoGainMaxDb | 33
autoGainMinDb
autoGainOutliers
autoGainRatePercent | 100
autoGainTargetPercent | 50
rampDataCameraGain
dataCameraGain1dB
dataCameraGain2dB
dataCameraGain3dB
dataCameraH01dTime1Sec
dataCameraH01dTime2Sec
dataCameraRamp1t02Time
dataCameraRamp2t03TimeSec | 5
dataCameraManualGain | 33
useBracketedExposures
bracketinglmagesPerExposure | 1
bracketingNumberOfExposures
bracketingExposureStartUsec | sooooo
bracketingExposureMultiplierTimes100 | 160
igniterStartPositi0n | 2170
igniterEndPosition | 2290
igniterVelocityCountsPerSe | 80
igniterPreheatPowe
igniterPreheatDurationMs | 1 ooo
igniterlgnitionPowerV
igniterIgniti0nDurationMs | 3000
igniterDelayBeforeRetractMs | 1800
igniterRetractVelocityCountsPerSe | 500
pmt1Gain
pmt2Gain | 6.5
pmt3Gain | 6.5
fiberlgnitionPosition
fiberTestPosition
fiberMoveDuringTest
fiberSegmentDistance | 100
fibervelocity | 3000
fiberH01dDurationSe
fiberCycles | 100
useFoma
flowTimeoutSec | 270
fuelFlowlgnitionDeltaMS | 2000
nitrogenFiowignitionDeltaM
stabilizationTime1S
stabilizationTime2 | 5
fuellgnitionFlowSlpm | 0.233
nitrogenignitionFlowSlpm | 0.000
fuelTestFlow1Slpm | 0.233
nitrogenTeStFlow1Slpm | 0.000
fuelTestFlow2Slpm | 0.000
nitrogenTestFlOw2Slpm | 0.000
fuelTestF10w3Slpm | 0.000
nitrogenTestF10w3Slpm | 0.000
constantFlowTime1Se | 240
constantFlowTime2Se | 0
constantFlowTime3Se
ignitionToTestRampTimeSec
testF10wRamp1T02TimeSec
testFlowRamp2T03TimeSec
postExtinctionDelaySec | 3
postExtincti0nFlowChangeFuelPercen
postExtinctionFlowChangeNitrogenPercen | o
postExtinctionFlowChangeRampTimeSec
postExtinctionFlowChangeHotdSec
~~~~

### Pagina 2

Cita: [pdf_b47b43f7450e4bd55ada, p. 2]. Metodo: windows_ocr_grid_removed.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_b47b43f7450e4bd55ada/p0002.jpg)

~~~~text
testpointNamel | 2129181
data CameraPrelgnitionExposureUsl | 1000000
dataCameraTestExposu reUsl | 1000000
analogCameraShutterl | 2
uselntensifiedCameral
intensifierlgnitionGainl | 20000
intensifierTestGainl | 80000
preignitionlmageTimeSec'
postFtameimagingTimeSec | 5
useDataCameraAutoGain
autoGainTolerancePercent | 5
autoGainMaxDb | 33
autoGainMinDb
autoGainOutliers
autoGainRatePercent | 100
autoGainTargetPercent | 50
rampDataCameraGaini
dataCameraGain1dB
dataCameraGain2dB
dataCameraGain3d8
dataCameraH01dTime1Sec
dataCameraH01dTime2Sec
dataCameraRamp1t02TimeSec | 5
data Camera Ramp2t03TimeSec | 5
dataCameraManualGain | 33
useBracketedExposures | 1
bracketinglmagesPerExposure | 1
bracketingNumberOfExposures | 4
bracketingExposureStartUsec | 500000
bracketingExposureMultiplierTimeSIOO | 160
igniterStartPosition | 2170
igniterEndPosition | 2290
igniterVelocityC0untsPerSec | 80
igniterpreheatPowerV | 3
igniterPreheatDurationMs | 1000
igniterlgnitionP0werV | 4
igniterlgnitionDurationMs | 3000
igniterDelayBeforeRetractMs | 1800
igniterRetractVelocityCou ntsPerSec | 500
pmt1Gain | 6
pmt2Gain | 6.5
pmt3Gain | 6.5
fiberlgnitionPOSition | 10000
fiberTestPosition
fiberMoveDuringTest
fiberSegmentDistance | 100
fiberVelocity | 3000
fiberHoldDurationSec | 1
fi berCycles | 100
useFoma | 1
flowTimeoutSec | 270
fuelFlowlgnitionDeltaMs
nitrogenFlowlgnitionDeltaMs
stabilizationTime1Sec
stabilizationTime2Sec | 5 | 15
fuellgnitionFlowSlpm | 0.233
nitrogenlgnitionFlOwSlpm | 0.000
fuelTestF10w1Slpm | 0.233
nitrogenTestFlow1Slpm | 0.000
fuelTestFlow2Slpm | 0.000
nitrogenTestFlow2Slpm | 0.000
fuelTestFlow3Slpm | 0.000
nitrogenTestFlOw3Slpm | 0.000
constantFlowTime1Sec | 240
constantFlowTime2Sec
constantFlowTime3Sec
ignitionTOTestRampTimeSec
testFlowRamp1T02TimeSec
testFlowRamp2T03TimeSec
postExti nctionDelaySec | 3
postExtinctionFlowChangeFuelPercent
postExtinctionFlowChangeNitrogenPercent
postExtinctionFlowChangeRampTimeSec
postExtinctionF10wChangeH01dSeg
/ 0025
~~~~

### Pagina 3

Cita: [pdf_b47b43f7450e4bd55ada, p. 3]. Metodo: windows_ocr_grid_removed.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_b47b43f7450e4bd55ada/p0003.jpg)

~~~~text
testp0intNamel | 21291C1
dataCameraPrelgnitionExposureUsl | 1000000
dataCameraTestExposureUsl | 1000000
analogCameraShutterl | 2
uselntensifiedCamera\ | 1
intensifierlgnitionGain | 20000
intensifierTestGain | 80000
preignitionlmageTimeSec
postFlamelmagingTimeSec | 5
useDataCameraAutoGain
autoGainTolerancePercent | 5
autOGainMaxDb | 33
autoGainMinDb
autoGainOutliers
autoGainRatePercent | 100
autoGainTargetPercent | 50
rampDataCameraGain
dataCameraGain1dB
dataCameraGain2dB
dataCameraGain3dB
dataCameraH01dTime1Sec
dataCameraH01dTime2Sec
dataCameraRamp1t02TimeSec | 5
dataCameraRamp2t03TimeSec | 5
dataCameraManualGain | 33
useBracketedExposures
bracketingl magesPerExposure | 1
bracketingNumberOfExposures | 4
bracketingExposureStartUset | 500000
bracketingExposureMultiplierTimes100 | 160
igniterStartPosition | 2170
igniterEndPosition | 2290
igniterVelocityCountsPerSec | 80
igniterPreheatPOwerV | 3
igniterPreheatDurationMs | 1000
igniterlgnitionP0werV | 4
igniterlgnitionDurationMs | 3000
igniterDelayBeforeRetractMs | 1800
igniterRetractVelocityC0untsPerSec | 500
pmt1Gain | 6
pmt2Gain | 6.5
pmt3Gain | 6.5
fiberignitionposition
fiberTestPosition
fiberMoveDuringTest
fiberSegmentDistance | 100
fiberVelocity | 3000
fiberHoldDurationSec | 1
fiberCycles | 100
useFoma | 1
flowTimeoutSec | 270
fuelFlowlgnitionDeltaMs
nitrogenFlowlgnitionDeltaMs
stabilizationTime1Sec
stabilizationTime2Sec | 5
fuellgnitionFlowSlpm | 0.155
nitrogenlgnitionFlowSlpm | 0.000
fuelTestFlow1Slpm | 0.155
nitrogen TestFlow1Slpm | 0.000
fuelTestFlow2Slpm | 0.000
nitrogenTestFlow2Slpm | 0.000
fuel TestF10w3Slpm | 0.000
nitrogenTestF10w3Slpm | 0.000
constantFlowTime1Sec | 240
constantFlowTime2Sec
constantF10wTime3Sec
ignitionTOTestRampTimeSec
testFlowRamp1T02TimeSec
testFlowRamp2T03TimeSec
postExtinctionDelaySec | 3
postExtinctionFlowChangeFuelPercent
postExtinctionFlowChangeNitrogenPercent
postExtinctionFlowChangeRampTimeSec
postExtinctionF10wChangeH01dSec
~~~~

### Pagina 4

Cita: [pdf_b47b43f7450e4bd55ada, p. 4]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_b47b43f7450e4bd55ada/p0004.jpg)

~~~~text
testpointName | 21291D1
dataCameraPrelgnitionExposureUs | 1000000
dataCameraTestExposureUs | 1000000
analogCameraShutte | 2
uselntensifiedCamera | 1
intensifierlgnitionGain | 20000
intensifier TestGain | 80000
prelgnitionlmageTimeSec
postFlamelmagingTimeSec | 5
useDataCameraAutoGain
autoGainTolerancePercen
autoGainMaxDb | 33
autoGainMinDb
autoGainOutliers
autoGainRatePercen | 100
autoGainTargetPercen | 50
rampDataCameraGain
dataCameraGain1dB
dataCameraGain2dB
dataCameraGain3dB
dataCameraHoldTime1Sec
dataCameraHoldTime2Sec
dataCameraRamp1t02TimeSec | 5
dataCameraRamp2t03TimeSe | 5
dataCameraManuaiGain | 33
useBracketedExposures
bracketinglmagesperExposure
bracketingNumberOfExposures
bracketingExposureStartUs | 500000
bracketingExposureMultiplierTimes10 | 160
igniterStartPosition | 2170
igniterEndPosition | 2290
igniterVelocityCountsPerSec
igniterPreheatPowerV | 3
igniterPreheatDurationMs | 1000
igniterlgnitionPowerV
igniterlgnitionDurationMs | 3000
igniterDelayBeforeRetractMs | 1800
igniterRetractVelocityCountsPerSec | 500
pmt1Gain
pmt2Gain | 6.5
pmt3Gain | 6.5
fiberlgnitionPosition
fiberTestPosition
fiberM0veDuringTes
fiberSegmentDistanc | 100
fiberveloci | 3000
fiberHoldDurationSec | 1
fiberCycles | 100
useFoma
flowTimeoutSec | 270
fuelFlowlgnitionDeltaMs | 500
nitrogenFlowlgnitionDeltaMs
stabilizationTime1Sec
stabilizationTime2Sec | 5
fuellgnitionFlowSlpm | 0.233
nitrogenlgnitionFlowStpm | 0.000
fuelTestFlow1Slpm | 0.233
nitrogenTestFlow1Slpm | 0.000
fuelTestFlow2Slpm | 0.000
nitrogenTestFlow2Slpm | 0.000
fuelTestFlow3Slpm | 0.000
nitrogen TestFlow3Slpm | 0.000
constantFlowTime1S | 240
constantFlowTime2
constantF10wTime3Sec
ignitionTOTestRampTimeSec
testFlowRamp1T02TimeSec
testFlowRamp2T03TimeSec
postExtinctionDelaySec | 3
postExtincti0nFlowChangeFuelPercen
postExtinctionF10wChangeNitrogenPercent
postExtinctionFlowChangeRampTimeSec
postExtinctionFlowChangeHoldSec
~~~~

### Pagina 5

Cita: [pdf_b47b43f7450e4bd55ada, p. 5]. Metodo: windows_ocr_grid_removed.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_b47b43f7450e4bd55ada/p0005.jpg)

~~~~text
testpointNamel | 21291F1
dataCameraPrelgnitionExposureUsl | 1000000
dataCameraTestExposureUsl | 1000000
analogCameraShutterl | 2
uselntensifiedCameral | 1
intensifierlgnitionGainl | 20000
intensifierTestGainl | 80000
preignitionlmageTimeSecl
postFlamelmagingTimeSecl | 5
useDataCameraAut0Gain
autoGainTolerancePercent | 5
autoGainMaxDb | 33
autoGainMinDb
autoGainOutliers
autOGainRatePercent | 100
autoGainTargetPercent | 50
rampDataCameraGain
dataCameraGain1dB
dataCameraGain2dB
dataCameraGain3dB
dataCameraH01dTime1Sec
dataCameraH01dTime2Sec
dataCameraRamp1t02TimeSec | 5
dataCameraRamp2t03TimeSec | 5
dataCameraManualGain | 33
useBracketedExposures | 1
bracketing] magesPerExposu re | 1
bracketingNumberOfExposures | 4
bracketingExposureStartUsec | 500000
bracketingExposu reMultiplierTimeS100 | 160
igniterStartPosition | 2170
igniterEndPosition | 2290
igniterVelocityCountsPerSec | 80
igniterPreheatPowerV | 3
igniterPreheatDurationMS | 1000
igniterlgnitionPowerV | 4
igniterlgnitionDurationMS | 3000
igniterDelayBef0reRetractMS | 1800
igniterRetractVelocityC0untsPerSec | 500
pmt1Gain | 6
pmt2Gain | 6.5
pmt3Gain | 6.5
fiberlgnitionPosition | 10000
fiberTestPosition
fiberM0veDuringTest
fiberSegmentDistance | 100
fiberVelocity | 3000
fiberH01dDurationSec | 1
fiberCycles | 100
useFoma | 1
flowTimeoutSec | 270
fuelF10wlgniti0nDeltaMs
nitrogenF10wlgnitionDeltaMS
stabilizationTime1Sec
stabilizationTime2Sec | 5
fuellgnitionFlowSlpm | 0.233
nitrogenlgnitionFlowSlpm | 0.000
fuelTestFlow1Slpm | 0.233
nitrogenTestFlow1Slpm | 0.000
fuelTestFlow2Slpm | 0.000
nitrogenTestFlow2Slpm | 0.000
fuelTestFlow3Slpm | 0.000
nitrogenTestFlow3Slpm | 0.000
constantF10wTime1Sec | 240
constantF10wTime2Sec
constantFlowTime3Sec
ignitionToTestRampTimeSec
testFlowRamp1T02TimeSec
testFlowRamp2T03TimeSeg
postExtinctionDelaySee | 3
postExtinctionF10wChangeFuelPercen
postExtinctionFlowChangeNitrogenpercentl
postExtinctionFlowChangeRampTimeSecl
postExtinctionFlowChangeHoldSecl
~~~~

### Pagina 6

Cita: [pdf_b47b43f7450e4bd55ada, p. 6]. Metodo: windows_ocr_grid_removed.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_b47b43f7450e4bd55ada/p0006.jpg)

~~~~text
testp0intNamel | 2129161
dataCameraPrelgnitionExposureUsl | 1000000
dataCameraTestExposureUsl | 1000000
analogCameraShutterl | 2
uselntensifiedCameral | 1
intensifierlgnitionGainl | 20000
intensifierTestGainl | 80000
preignitionlmageTimeSecl
postFlamelmagingTimeSecl | 5
useDataCameraAutoGain
autoGainT0terancePercent | 5
autoGainMaxDb | 33
autoGainMinDb
autoGainOutliers
autoGainRatePercent | 100
autoGainTargetPercent | 50
rampDataCameraGain
dataCameraGain1dB
dataCameraGain2dB
dataCameraGain3dB
dataCameraHoldTime1Sec
dataCameraHoldTime2Sec
dataCameraRamp1t02TimeSec | 5
dataCameraRamp2t03TimeSec: | 5
dataCameraManualGain | 33
useBracketedExposures
bracketinglmagesPerExposure | 1
bracketingNumberOfExposures | 4
bracketingExposureStartUsec | 500000
bracketingExposureMultiplierTimeS100 | 160
igniterStartPosition | 2170
igniterEndPosition | 2290
igniterVelOcityCountsPerSec | 80
igniterPreheatPowerV | 3
igniterPreheatDurationMs | 1000
igniterlgnitionPowerV | 4
igniterlgnitionDurationMs | 3000
igniterDelayBeforeRetractMs | 1800
igniterRetractVelocityC0untsPerSec | 500
pmt1Gain | 6
pmt2Gain | 6.5
pmt3Gain | 6.5
fiberlgnitionPosition | 0
fiberTestPosition
fiberMoveDuringTest
fiberSegmentDistance | 100
fiberVelocity | 3000
fiberHoldDurationSec | 1
fiberCycles | 100
useFoma | 1
flowTimeoutSec | 270
fuelFlowlgnitionDeltaMs
nitrogenFlowlgnitionDeltaMs
stabilizationTime1Sec
stabilizationTime2Sec
fuellgnitionF10wSlpm | r.) 165 | D,Z3 3 | 0.155
nitrogenlgnitionFlowSlpm | 0.000
fuelTestFlow1Sipm | D-233 | 0.155
nitrogen TestFlOw1Slpm | 0.000
fuelTestF10w2Slpm | 0.000
nitrogenTestFlow2Slpm | 0.000
fuelTestFlow3Slpm | 0.000
nitrogenTestFlow3Slpm | 0.000
constantFlowTime1Sec | 240
constantFlowTime2Sec
constantFtowTime3Sec
ignitionTOTestRampTimeSec
testF10wRamp1T02TimeSec
testFlowRamp2T03TimeSec
postExtinctionDelaySec | 3
postExtinctionFlowChangeFuelPercent
postExtinctionFlowChangeNitrogenPercent
postExtinctionFlowChangeRampTimeSec
postExtinctionF10wChangeH01dSec
c | c
250
~~~~
