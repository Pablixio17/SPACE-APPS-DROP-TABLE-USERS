# 21222 test parameter notes

- Identificador: pdf_223addbae280d8fe441a
- Investigaciones: PSI-159
- Tipo de documento: Raw Data
- Estado: processed
- Temas detectados automaticamente: oxygen, ignition, extinction, hardware, operations

## Fuentes

- [PSI-159_Raw Data_21222 test parameter notes.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-159/Raw%20Data/PSI-159_Raw%20Data_21222%20test%20parameter%20notes.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_223addbae280d8fe441a, p. 1]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_223addbae280d8fe441a/p0001.jpg)

~~~~text
testpointName | 21222A1
dataCameraPrelgnitionExposureUs | 1000000
dataCameraTestExposureUs | 100000
analogCameraShutter
uselntensifiedCamera | TRUE
intensifierlgnitionGain | 20000
intensifierTestGain | 60000
prelgnitionlmageTimeSec
postFlamelmagingTimeSec | 5
useDataCameraAutoGain | FALSE
autoGainTolerancePercent | 5
autoGainMaxDb | 33
autoGainMinDb
autoGainOutliers
autoGainRatePercent | 100
autoGainTargetPercent | 50
rampDataCameraGain | FALSE
dataCameraGain1dB
dataCameraGain2dB
dataCameraGain3dB
dataCameraHoldTime1Sec
dataCameraHoldTime2Sec
dataCameraRamp1t02TimeSec
dataCameraRamp2t03TimeSec | 5
dataCameraManualGain | 33
useBracketedExposures | FALSE
bracketinglmagesPerExposure | 1
bracketingNumberOfExposures
bracketingExposureStartUsec | sooo
bracketingExposureMultiplierTimes100 | 1000
igniterStartPosition | 2170
igniterEndPosition | 2290
igniterVelocityCountsPerSec | 80
igniterPreheatPowerV | 3
igniterPreheatDurationMs | 1000
igniterlgnitionPowerV | 4
igniterlgnitionDurationMs | 3000
igniterDelayBeforeRetractMs | 1800
igniterRetractVelocityCountsPerSec | 500
pmt1Gain | 10
pmt2Gain
pmt3Gain | 10
fiberlgnitionPosition
fiber TestPosition
fiberMoveDuringTest | FALSE
fiberSegmentDistance | 100
fiberVelocity | 3000
fiberHoldDurationSec
fiberCycles | 100
useFoma | TRUE
flowTimeoutSec | go
oxidizerFlowlgnitionDeltaMs | 2000
nitrogenFlowlgnitionDeltaMs
stabilizationTime1Sec
stabilizationTime2Sec
oxidizerlgnitionFlowSlpm | 0.299
nitrogenlgnitionFlowSlpm
oxidizerTestFlow1Slpm | 0.299
nitrogenTestFlow1Slpm
oxidizerTestFlow2Slpm
nitrogenTestFlow2Slpm
oxidizerTestFlow3SIpm
nitrogenTestFlow3Slpm
constantFlowTime1Sec | 60
constantFlowTime2Sec
constantFlowTime3Sec
ignitionToTestRampTimeSec
testFlowRamp1T02TimeSec
testFlowRamp2T03TimeSec
postExtinctionDelaySec
postExtinctionFlowChangeOxidizerPercent
postExtinctionFlowChangeNitrogenPercent
postExtinctionFlowChangeRampTimeSec
postExtinctionF10wChangeHoldSec
~~~~

### Pagina 2

Cita: [pdf_223addbae280d8fe441a, p. 2]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_223addbae280d8fe441a/p0002.jpg)

~~~~text
testpointName | 2122281
dataCameraPrelgnitionExposurelJs | 1000000
dataCameraTestExposureUs | 100000
analogCameraShutter | 2
uselntensifiedCamera | TRUE
intensifierlgnitionGain | 20000
intensifierTestGain | 60000
preignitionlmageTimeSec
postFlamelmagingTtmeSec | 5
useDataCameraAut0Gain | FALSE
autoGainTolerancePercent | 5
autoGainMaxDb | 33
autoGainMinDb
autoGainOutliers
autoGainRatePercent | 100
autoGainTargetPercent | 50
rampDataCameraGain | FALSE
dataCameraGain1dB
dataCameraGain2dB
dataCameraGain3dB
dataCameraHoldTime1Sec
dataCameraHoldTime2Sec
dataCameraRamp1t02TimeSec | 5
dataCameraRamp2t03TimeSec | 5
dataCameraManualGain
useBracketedExposures | TRUE
bracketinglmagesPerExposure | 1
bracketingNumberOfExposures
bracketingExposureStartUsec | 50000
bracketingExposureMultiplierTimes100 | 200
igniterStartPosition | 2170
igniterEndPosition | 2290
igniterVelocityCountsPerSec | 80
igniterPreheatPowerV
igniterPreheatDurationMs | 1000
igniterlgnitionPowerV | 4
igniterlgnitionDurationMs | 3000
igniterDelayBeforeRetractMs | 1800
igniterRetractVelocityCountsPerSec | 500
pmt1Gain | 10
pmt2Gain | 8
pmt3Gain | 10
fiberlgnitionPosition | 10000
fiberTestPosition | 17000
fiberMoveDuringTest | FALSE
fiberSegmentDistance | 100
fiberVelocity | 3000
fiberHoldDurationSec | 1
fiberCycles | 100
useFoma | TRUE
flowTimeoutSec | 90
oxidizerFlowlgnitionDeltaMs
nitrogenFlowlgnitionDeltaMs
stabilizationTime1Sec
stabilizationTime2Sec
oxidizerlgnitionFlowSlpm | 0.299
nitrogenlgnitionFlowSlpm
oxidizer TestFlow1Slpm | 0.299
nitrogenTestFlow1Slpm
oxidizerTestFlow2Slpm
nitrogenTestFlow2Slpm
oxidizer TestFlow3Slpm
nitrogenTestFlow3Slpm
constantFlowTime1Sec | 60
constantFlowTime2Sec
constantFlowTime3Sec
ignition ToTestRampTimeSec
testFlowRamp1T02TimeSec
testFlowRamp2T03TimeSec
postExtinctionDelaySeC | 3
postExtinctionFlowChangeOxidizerPercent
postExtinctionFlowChangeNitrogenPercent
postExtinctionFlowChangeRampTtmeSec
postExtinctionFlowChangeHoldSec
~~~~

### Pagina 3

Cita: [pdf_223addbae280d8fe441a, p. 3]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_223addbae280d8fe441a/p0003.jpg)

~~~~text
testpointName | 21222C1
dataCameraPrelgnitionExposureUs | 1000000
dataCameraTestExposureUs | 100000
analogCameraShutter | 2
uselntensifiedCamera | TRUE
intensifierlgnitionGain | 20000
intensifierTestGain | 60000
prelgnitionlmageTimeSec
postFlamelmagingTimeSec | 5
useDataCameraAut0Gain | FALSE
autoGainTolerancePercent | 5
autoGainMaxDb | 33
autoGainMinDb
autoGainOutliers
autoGainRatePercent | 100
autoGainTargetPercent | 50
rampDataCameraGain | FALSE
dataCameraGain1dB
dataCameraGain2dB
dataCameraGain3dB
dataCameraHoldTime1Sec
dataCameraH01dTime2Sec
dataCameraRamp1t02TimeSec
dataCameraRamp2t03TimeSec | 5
dataCameraManuatGain | 33
useBracketedExposures | FALSE
bracketinglmagesPerExposure | 1
bracketingNumberOfExposures | 4
bracketingExposureStartUsec | sooo
bracketingExposureMultiplierTimes100 | 1000
igniterStartPosition | 2170
igniterEndPosition | 2290
igniterVelocityCountsPerSec | 80
igniterPreheatPowerV | 3
igniterPreheatDurationMs | 1000
igniterlgnitionPowerV | 4
igniterlgnitionDurationMs | 3000
igniterDelayBeforeRetractMs | 1800
igniterRetractVelocityCountsPerSec | 500
pmt1Gain | 10
pmt2Gain | 8
pmt3Gain | 10
fiberlgnitionPosition
fiberTestPosition
fiberMoveDuringTest | FALSE
fiberSegmentDistance | 100
fiberVelocity | 3000
fiberHoldDurationSec | 1
fiberCycles | 100
useFoma | TRUE
flowTimeoutSec | 90
oxidizerFlowlgnitionDeltaMs
nitrogenFlowlgnitionDeltaMs | 4500
stabilizationTime1Sec
stabilizationTime2Sec | 5
oxidizerlgnitionFlowSlpm | 0.299
nitrogenlgnitionFlowSlpm | 0.205
oxidizerTestFlow1Slpm | 0.299
nitrogenTestFlow1Slpm | 0.205
oxidizerTestFlow2Slpm
nitrogenTestFlow2Slpm
oxidizer TestFlow3Slpm
nitrogenTestFlow3Slpm
constantFlowTime1Sec | 60
constantFlowTime2Sec
constantFlowTime3Sec
ignitionTOTestRampTimeSec
testFlowRamp1T02TimeSec
testFlowRamp2T03TimeSec
postExtinctionDelaySec | 3
postExtinctionFlowChangeOxidizerPercent
postExtinctionFlowChangeNitrogenPercent
postExtinctionFlowChangeRampTimeSec
postExtinctionFlowChangeHoldSec
~~~~

### Pagina 4

Cita: [pdf_223addbae280d8fe441a, p. 4]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_223addbae280d8fe441a/p0004.jpg)

~~~~text
testpointName | 21222D1
dataCameraPrelgnitionExposureUs | 1000000
dataCameraTestExposureUs | 100000
analogCameraShutter | 2
uselntensifiedCamera | TRUE
intensifierlgnitionGain | 20000
intensifierTestGain | 60000
prelgnitionlmageTimeSec
postFlamelmagingTimeSec | 5
useDataCameraAutoGain | FALSE
autoGainTolerancePercent | 5
autoGainMaxDb | 33
autoGainMinDb
autoGainOutliers
autoGainRatePercent | 100
autoGainTargetPercent | 50
rampDataCameraGain | FALSE
dataCameraGain1dB
dataCameraGain2dB
dataCameraGain3dB
dataCameraHoldTime1Sec
dataCameraH01dTime2Sec
dataCameraRamp1t02TimeSec | 5
dataCameraRamp2t03TimeSec | 5
dataCameraManualGain
useBracketedExposures | TRUE
bracketinglmagesPerExposure | 1
bracketingNumberOfExposures | 4
bracketingExposureStarWsec | 50000
bracketingExposureMultiplierTimes100 | 200
igniterStartPosition | 2170
igniterEndPosition | 2290
igniterVelocityCountsPerSec | 80
igniterPreheatPowerV | 3
igniterPreheatDurationMs | 1000
igniterlgnitionPowerV | 4
igniterlgnitionDurationMs | 3000
igniterDelayBeforeRetractMs | 1800
igniterRetractVetocityCountsPerSec | 500
pmt1Gain | 10
pmt2Gain | 8
pmt3Gain | 10
fiberlgnitionPosition | 10000
fiberTestPosition | 17000
fiberMoveDuringTest | FALSE
fiberSegmentDistance | 100
fiberVelocity | 3000
fiberHoldDurationSec | 1
fiberCycles | 100
useFoma | TRUE
flowTimeoutSec | 90
oxidizerFlowlgnitionDeltaMs
nitrogenFlowlgnitionDeltaMs | 4500
stabilizationTime1Sec
stabilizationTime2Sec | 5
oxidizerlgnitionFlowSlpm | 0.299
nitrogenlgnitionFlowSlpm | 0.205
oxidizerTestFlow1Slpm | 0.299
nitrogenTestFlow1Slpm | 0.205
oxidizerTestFlow2Slpm
nitrogenTestFlow2Slpm
oxidizerTestFlow3Slpm
nitrogenTestFlow3Slpm
constantFlowTime ISec | 60
constantFlowTime2Sec
constantFlowTime3Sec
ignitionTOTestRampTimeSec
testFlowRamp1T02TimeSec
testFlowRamp2T03TimeSec
postExtinctionDelaySec
postExtinctionFlowChangeOxidizerPercent
postExtinctionFlowChangeNitrogenPercent
postExtinctionFlowChangeRampTimeSec
postExtinctionFlowChangeHoldSec
~~~~

### Pagina 5

Cita: [pdf_223addbae280d8fe441a, p. 5]. Metodo: windows_ocr_grid_removed.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_223addbae280d8fe441a/p0005.jpg)

~~~~text
testp0intName! | 21222F1 | fZ-n
dataCameraPrelgnitionExposureUs | 1000000
dataCameraTestExposureUs | 100000
analogCameraShutter | 2
uselntensifiedCamera | TRUE
intensifierlgnitionGain
intensifierTestGain | 60000
preignitionlmageTimeSec
postFlamelmagingTimeSec | 5
useDataCameraAutoGain | FALSE
autoGainTolerancePercent | 5
autoGainMaxDb | 33
autoGainMinDb
autoGainOutliers
autoGainRatePercent | 100
autoGainTargetPercent | 50
rampDataCameraGain | FALSE
dataCameraGain1dB
dataCameraGain2dB
dataCameraGain3dB
dataCameraHoldTime1Sec
dataCameraHoldTime2Sec
dataCameraRamp1t02TimeSec | 5
dataCameraRamp2t03TimeSec | 5
dataCameraManualGain
useBracketedExposures | AFALSE
bracketinglmagesPerExposure | 1
bracketingNumberOfExposures | 4
bracketingExposureStartUsec | sooo
bracketingExposureMultiplierTimes100 | 1000
igniterStartPosition | 2170
igniterEndPosition | 2290
igniterVelocityCountsPerSec | 80
igniterPreheatPowerV | 3
igniterPreheatDurationMs | 1000
igniterlgnitionPowerV | 4
igniterIgnitionDurationMs | 3000
igniterDeIayBeforeRetractMs | 1800
igniterRetractVelocityCountsPerSec | 500
pmt1Gain | 10
pmt2Gain | 8
pmt3Gain | 10
fiberlgnitionPosition
fiberTestPosition
fiberMoveDuringTest | FALSE
fiberSegmentDistance | 100
fiberVelocity | 3000
fiberH01dDurationSec | 1
fiPerCycles | 100
useFoma | TRUE
flowTimeoutSec | 90
oxidize rFlowlgnitionDeltaMs
nitrogenFlowlgnitionDeltaMs | 4500
stabilizationTime1Sec
stabilizationTime2Sec | 5
oxidizerlgnitionFlowSlpm | 0.299
nitrogenlgnitionFlowSlpm | 0.895
oxidizer TestFlow1Slpm | 0.299
nitrogenTestFlow1Slpm | 0.895
oxidizerTestFtow2Slpm
nitrogenTestFlow2Slpm
oxidizerTestFlow3Slpm
nitrogenTestFlow3Slpm
constantFlowTime1Sec | 60
constantFlowTime2Sec
constantFlowTme3Sec
ignitionToTestRampTimeSec
testFlowRamp1T02TimeSec
testFlowRamp2T03TimeSec;
postExtinctionDelaySecl | 3
postExtinctionFlowChangeOxidizerPercentl
postExtinctionFlowChangeNitrogenPercentl
postExtinctionFlowChangeRampTimeSecl
postExtinctionFlowChangeHoldSecl
~~~~

### Pagina 6

Cita: [pdf_223addbae280d8fe441a, p. 6]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_223addbae280d8fe441a/p0006.jpg)

~~~~text
testpointName | 2122261
dataCameraPrelgnitionExposureUs | 1000000
dataCameraTestExposurelJs | 100000
analogCameraShutter | 2
uselntensifiedCamera | TRUE
intensifierlgnitionGain | 20000
intensifierTestGain | 60000
prelgnitionlmageTimeSec
postFlamelmagingTimeSec | 5
useDataCameraAutoGain | FALSE
autoGainT01erancePercent | 5
autoGainMaxDb | 33
autoGainMinDb
autoGainOutliers
autoGainRatePercent | 100
autoGainTargetPercent | 50
rampDataCameraGain | FALSE
dataCameraGain1dB
dataCameraGain2dB
dataCameraGain3dB
dataCameraHoldTime1Sec
dataCameraHoldTime2Sec
dataCameraRamp1t02TimeSec | 5
dataCameraRamp2t03TimeSec
dataCameraManualGain
useBracketedExposures | TRUE
bracketingl magesPerExposure | 1
bracketingNumberOfExposures | 4
bracketingExposureStartUsec | 50000
bracketingExposureMultiplierTimes100 | 200
igniterStartPosition | 2170
igniterEndPosition | 2290
igniterVelocityCountsPerSec | 80
igniterPreheatPowerV
igniterPreheatDurationMs | 1000
igniterlgnitionPowerV | 4
igniterlgnitionDurationMs | 3000
igniterDelayBeforeRetractMs | 1800
igniterRetractVelocityCountsPerSec | 500
pmt1Gain | 10
pmt2Gain
pmt3Gain | 10
fibertgnitionPosition | 10000
fiberTestPosition | 17000
fiberMoveDuringTest | FALSE
fiberSegmentDistance | 100
fiberVelocity | 3000
fiberHoldDurationSec | 1
fi berCycles | 100
useFoma | TRUE
flowTimeoutSec | go
oxidizerFlowlgnitionDeltaMs
nitrogenFlowlgnitionDeltaMs | 4500
stabilizationTime1Sec
stabilizationTime2Sec | 5
oxidizerlgnitionFlowSlpm | 0.299
nitrogenlgnitionFlowSlpm | 0.895
oxidizerTestFlow1Slpm | 0.299
nitrogenTestFlow1Slpm | 0.895
oxidizer TestFlow2Slpm
nitrogenTestFlow2Slpm
oxidizerTestFlow3Slpm
nitrogenTestFlow3Slpm
constantFlowTime1Sec | 60
constantFlowüme2Sec
constantFlowTime3Sec
ignition ToTestRampTimeSec
testFlowRamp1T02TimeSec
testFlowRamp2T03TimeSec
postExtinctionDelaySec | 3
postExtinctionFlowChangeOxidizerPercent
postExtinctionFlowChangeNitrogenPercent
postExtinctionFlowChangeRampTimeSec
postExtin(iionFlowChangeH01dSec
~~~~
