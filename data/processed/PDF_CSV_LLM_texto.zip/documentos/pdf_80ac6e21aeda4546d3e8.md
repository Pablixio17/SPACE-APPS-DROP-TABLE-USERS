# 19123 flow traces etc dps

- Identificador: pdf_80ac6e21aeda4546d3e8
- Investigaciones: PSI-10
- Tipo de documento: Raw Data
- Estado: processed
- Temas detectados automaticamente: ignition, oxygen, pressure, hardware, extinction, operations

## Fuentes

- [PSI-10_Raw Data_19123 flow traces etc dps.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-10/Raw%20Data/PSI-10_Raw%20Data_19123%20flow%20traces%20etc%20dps.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_80ac6e21aeda4546d3e8, p. 1]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
1
IMPORTANT – It is very likely that there are some errors in these notes. There 
were sometimes discrepancies in recorded values, in which case this edited 
version gave priority to the hand-written notes. In the case of possible
omissions in the hand-written notes, priority was given to the raw version of 
this file – despite the possibility of copy & paste errors. At this time, the values
have not been confirmed using the as-run parameter files.
Test 19123A1 – successful test, run with bracketingExposureStartUsec=80000, 
bracketingExposureMultiplierTimes100=500, igniterIgnitionDurationMs=2500, 
igniterDelayBeforeRetractMs=2000
Also set igniter trigger level=2.5 V, igniter off delay=200 ms
After test, 967 on lowest valve safety timer, 1058 psia in oxidizer bottle
~~~~

### Pagina 2

Cita: [pdf_80ac6e21aeda4546d3e8, p. 2]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_80ac6e21aeda4546d3e8/p0002.jpg)

~~~~text
2
Test 19123A2 – successful test, run like A1 except for no fuel flow before igniter 
activation, i.e., with bracketingExposureStartUsec=80000, 
bracketingExposureMultiplierTimes100=500, igniterIgnitionDurationMs=2500, 
igniterDelayBeforeRetractMs=2000, fuelFlowIgnitionDeltaMs=0
After test, 937 on lowest valve safety timer, 1061 psia in oxidizer bottle

[Texto OCR de la imagen]
Test 19123A2 — successful test, run like A1 except for no fuel flow before igniter
activation, i.e., with bracketingExposureStartUsec=80000,
bracketingExposureMultiplierTimes100=500, igniterIgnitionDurationMs=2500,
igniterDelayBeforeRetractMs=2000, fuelFIowIgnitionDeItaMs=O
Gas Flow Charts
Gr aphs
2019-05-03 | GMT
2019-05-03
Systan Temperatures
State | Operate | c | O. 000 | scale | 20,000 | SLPM
cpu | 32.500
Set All Gains
Static Mixer Line (MFCAI) | 34.000
000
abe Sensor 1 | 33.332
ACME FLOW MI MIXER SETPOINT | ACME FLOW MI MIXER FLOW
ooo | 33.313
CA-be Sensor 2
-0005
ooo | 25
Hard Drive
-0.010
20:45 | 20:46 | 20:47 | 20:48 | 20:49
3fri may 2019 | Tirne (s)
TC200A (TCO | 23. 118809 | 0.028
State | Operate | c | 0.000 | SLPM | R | 0.000 | SLPM | F.' scale | 0.500 | SLPM | TC200B crc2) | 22.324650 | -0.004
22.443212 | 0.872 | v
Bypass(MFCA2)
Array
ACME FLOW M2 BYPASS SETPOINT | ACME FLOW | BYPASS FLOW | Rake:
invalid 40w | -154,551 | mV
-le-3 | invalid40w | -148.618 | mV
20:45 | 20:46 | 20:47 | 20:48 | 20:49 | invalid-low | -142.693
3fri nay 2019 | Time (s)
invalid | -148.169 | mV
Vld
State | Operate | c | 0.000 | SLPM | R | -0.000 | SLPM | scale | 0.200 | SLPM
Fuel(MFCA3) | Burner:
Buner | 113.035435 | 3.738 | mV
ACME FLOW | ACME FLOW M3 FUEL_FLOW
0.10
0.05
Comec60n | Connected
20:45 | 20:47 | 20:48 | 20:49
3Fri may 2019 | Time (s)
Time Series Chart #1
Packet | So ft,vare MnemoNc
ACME Teleme ACME DIAG PMT_TI | 0.00
ACME Teleme | 0.00
ACME | 0.00
2.5
2.0
2.]
Select Items | End Plottng
Clear Selections
• | 03 May 2019 | 3Fri nay 2019 | Time
Star
Graph | I
After test, 937 on lowest valve safety timer, 1061 psia in oxidizer bottle
2
~~~~

### Pagina 3

Cita: [pdf_80ac6e21aeda4546d3e8, p. 3]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_80ac6e21aeda4546d3e8/p0003.jpg)

~~~~text
3
Test 19123A3 – successful test, run like A1 except for no fuel flow before igniter 
activation and a different igniter position, i.e., with 
bracketingExposureStartUsec=80000, 
bracketingExposureMultiplierTimes100=500, igniterIgnitionPosition=2250,
igniterIgnitionDurationMs=2500, igniterDelayBeforeRetractMs=2000, 
fuelFlowIgnitionDeltaMs=0
After test, __ on lowest valve safety timer, __ psia in oxidizer bottle

[Texto OCR de la imagen]
Test 19123A3 — successful test, run like A1 except for no fuel flow before igniter
activation and a different igniter position, i.e., with
bracketingExposureStartUsec=80000,
bracketingExposureMuItiplierTimes100=500, igniterlgnitionPosition=2250,
igniterIgnitionDurationMs=2500, igniterDelayBeforeRetractMs=2000,
fuelFlowIgnitionDeltaMs=O
Gas flow Charts
File Graphs
2019-05-03 21:05:08
2019-05-03
System Tenpera tures
State | Operate | c | 0.000 | QPM | R | -0.009 | Fu/ scale | 20.000 | SLPM
32.600
Set AI Gains
Static Mixer Line (MFCAI) | CPU | 34.000
ooo
Cube Sensor 1 | 33.447
ooo | 33.492
Cube Sensor 2
-0.01
ooo | 25
Drive
-0.02
21:01 | 21:02 | 21:03 | 21:04 | 21:05
3fri may2019 | Tine (s)
TC200A (TCI) | 23.094)00 | 0.027 | mV
Sute | Operate | c | 0.000 | SLPM | R | -0.000 | SLPM | scale | 0.500 | SLPM | TC200B CTC2) | 0.001 | mV
22.443212 | 0.872 | v
Bypass(MFCA2)
ACME FLOW | BYPASS SETPOINT | ACME FLOW | BYPASS FLOW | Rake Remo
"vabd40w | -154.068 | mV
o
invabd-low | -148, 147 | mV
21:01 | 21:02 | 21:03 | 21:04 | 21:05 | "vabd-/ow | -142.239
mV
3fri may 2019 | Time (s)
invabd-low | -147,675 | mV
Operate | c | 0.000 | R | -0.000 | SLPM | sue | 0.200
Fuel(MFCA3) | Burner | (1/4)
Burner TC | 730748 | 3.561 | mV
0.10
0.05
Cube
21:01 | 21:02 | 21:03 | 21:04 | 21:05
3 Fri May 2019 | Time (s)
Time Series Chart #1
Softaare
ACME | 1 | 0.00
ACME Telen-,e ACME DIAG PMT T2 | 0.00
ACME Teleme ACME_DLAG | 0.00
> 2.0
a-,d Plotting
Clear Selections | Restart
¯ | 03May 2019 | 3fri may2019 | Tine
Star'
After test, | on lowest valve safety timer, | psia in oxidizer bottle
3
~~~~

### Pagina 4

Cita: [pdf_80ac6e21aeda4546d3e8, p. 4]. Metodo: native.

~~~~text
4
Test 19123A4 – successful test, run like A3 except for igniter position and igniter 
detection threshold , i.e., with bracketingExposureStartUsec=80000, 
bracketingExposureMultiplierTimes100=500, igniterIgnitionPosition=2200,
igniterIgnitionDurationMs=2500, igniterDelayBeforeRetractMs=2000 
fuelFlowIgnitionDeltaMs=0
Also ignition detection trigger=2 V
Lost telemetry data on science console; had to reboot.
After test, __ on lowest valve safety timer, __ psia in oxidizer bottle
Test 19123C1 – successful test, run with bracketingExposureStartUsec=80000, 
bracketingExposureMultiplierTimes100=500, igniterIgnitionPosition=2200,
igniterIgnitionDurationMs=2500, igniterDelayBeforeRetractMs=2000 
Also ACME camera zoom and focus like in A1, i.e., dataCamera Focus=12700, 
dataCamera Zoom=35000.
Also set igniter trigger level= 2.0 V, Igniter Off Delay= 200 ms 
Lost display on science computer except for video.
After test, 836 on lowest valve safety timer, 1064 psia in oxidizer bottle
~~~~

### Pagina 5

Cita: [pdf_80ac6e21aeda4546d3e8, p. 5]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_80ac6e21aeda4546d3e8/p0005.jpg)

~~~~text
5
Test 19123F1 – successful test, run with bracketingExposureStartUsec=80000, 
bracketingExposureMultiplierTimes100=500, igniterIgnitionPosition=2200,
igniterIgnitionDurationMs=2500, igniterDelayBeforeRetractMs=2000 
Also ACME camera zoom and focus like in A1, i.e., dataCamera Focus=12700, 
dataCamera Zoom=35000.
Also set igniter trigger level= 2.0 V, Igniter Off Delay= 200 ms 
After test, 796 on lowest valve safety timer, 1064 psia in oxidizer bottle

[Texto OCR de la imagen]
Test 19123F1 — successful test, run with bracketingExposureStartUsec=80000,
bracketingExposureMuItiplierTimes100=500, igniterIgnitionPosition=2200,
igniterIgnitionDurationMs=2500, igniterDelayBeforeRetractMs=2000
Also ACME camera zoom and focus like in A1, i.e., dataCamera Focus=12700,
dataCamera Zoom-35000.
Also set igniter trigger level= 2.0 V, Igniter Off Delay= 200 ms
.2 Gas Flow Charts
2019-05-03 22: 11:53 | GMT
state | 2019-05-03 | GMT
system | System Temperatures
cpu | 32.700
Operate | c | 0.000 | SLPM | R | -0.011 | SLPM | scale | 20.000 | SLPM | A" Gains
cpu Board | 35.000
Static Mixer Line (MFCAI) | set
Cube Sensor 1 | 33.986
Set
Cube Sensor 2
Hard Drive | 25
22:07 | 22:08 | 22:09 | 22: 10 | 22:11
3Fri May 2019 | Time (s)
23.781139 | 0.041 | mV
22.664854 | -0.004 | mV
State | Operate | c | 0.000 | SLPM | R | -0.001 | SLPM | scale | 0.500 | (TC2)
22.782211 | 0.873
Bypass(MFCA2)
ACME FLOW | BYPASS SETPOINT | ACME FLOW | BYPASS FLOW | Rake: Removed
oso | invalid-low | -152.416
0.025
invalid-low | -1%.477
22:07 | 22:08 | 22:09 | 22:10 | 22:11
3fri may 2019 | Tirne (s) | invalid-low | -142.606
invalid-low | -146.064 | mV
State | Operate | C | 0.000 | SLPM | R | -0.000 | SLPM | scale | 0.200
Fuel(MFCA3)
Burns-: Spheeal (1/4)
105.107764 | 3.398
0.10
0.05
22:08 | 22:09 | 22:10 | 22:11 | CLbe Cnnection
3Fri May 2019 | Time (s)
—IOS 13
Low
0.00
0.00
0.00
2.] | 0.5
End Plotting
Restart
3 Fri May 2019 | Tine
After test, 796 on lowest valve safety timer, 1064 psia in oxidizer bottle
5
~~~~

### Pagina 6

Cita: [pdf_80ac6e21aeda4546d3e8, p. 6]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
6
Test 19123F2 – successful test, run exactly like F1 to check repeatability, i.e., run 
with bracketingExposureStartUsec=80000, 
bracketingExposureMultiplierTimes100=500, igniterIgnitionPosition=2200,
igniterIgnitionDurationMs=2500, igniterDelayBeforeRetractMs=2000 
Also ACME camera zoom and focus like in A1, i.e., dataCamera Focus=12700, 
dataCamera Zoom=35000.
Also set igniter trigger level= 2.0 V, Igniter Off Delay= 200 ms
After test, 753 on lowest valve safety timer, 1066 psia in oxidizer bottle
~~~~

### Pagina 7

Cita: [pdf_80ac6e21aeda4546d3e8, p. 7]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
7
Test 19123F3 – successful test, run with F1-F2 parameters except for igniter 
position, i.e., run with bracketingExposureStartUsec=80000, 
bracketingExposureMultiplierTimes100=500, igniterIgnitionPosition=2250,
igniterIgnitionDurationMs=2500, igniterDelayBeforeRetractMs=2000 
Also ACME camera zoom and focus like in A1, i.e., dataCamera Focus=12700, 
dataCamera Zoom=35000.
Also set igniter trigger level= 2.0 V, Igniter Off Delay= 200 ms
After test, 724 on lowest valve safety timer, 1066 psia in oxidizer bottle
~~~~

### Pagina 8

Cita: [pdf_80ac6e21aeda4546d3e8, p. 8]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_80ac6e21aeda4546d3e8/p0008.jpg)

~~~~text
8
Test 19123H1 – failed ignition, run with bracketingExposureStartUsec=80000, 
bracketingExposureMultiplierTimes100=500, igniterIgnitionPosition=2200,
igniterIgnitionDurationMs=2500, igniterDelayBeforeRetractMs=2000
Also ACME camera zoom and focus as in plan, i.e., dataCamera Focus=10025, 
dataCamera Zoom=45000.
Also set igniter trigger level= 2.0 V, Igniter Off Delay= 200 ms
After test, 703 on lowest valve safety timer, 1066 psia in oxidizer bottle

[Texto OCR de la imagen]
Test 19123H1- failed ignition, run with bracketingExposureStartUsec=80000,
bracketingExposureMuItiplierTimes100=500, igniterIgnitionPosition=2200,
igniterIgnitionDurationMs=2500, igniterDelayBeforeRetractMs=2000
Also ACME camera zoom and focus as in plan, i.e., dataCamera Focus=10025,
dataCamera Zoom-45000.
Also set igniter trigger level= 2.0 V, Igniter Off Delay= 200 ms
_ t. Gas flow Charts
-IOIS
File Graphs
2019-05-03 23:33: 59 | GMT
2019-05-03
System Ternpera tures
State | Operate | c | 0.000 | QPM | R | -0.020 | FL" scale | 20.000 | SLPM | cpu | 32.700
t All Gains
Board | 35
Static Mixer Line (MFCAI)
set
Cut* Sensor 1 | 34.340
ACME FLOW MI MIXER SETPOINT | ACME_FLOW
Cube Sensor 2 | 34.387
Hard Drive | 26
23:30 | 23:31 | 23:32 | 23:33
3fri May 2019 | Tine (s)
23.922577 | 0.033
State | Operate | c | 0.000 | SLPM | R | -0.000 | SLPM | scale | 0.500 | SLPM | 22905793 | -0.008
Bypass(MFCA2) | 23. 121190 | 0.874
Array
ACME FLOW | BYPASS SETPOINT | ACME FLOW | BYPASS FLOW
Rake:
0.25
-151.184 | mV
23:30 | 23:31 | 23:32 | 23:33 | "v aid-low | -145.223 | mV
3fri May 2019 | Time (s)
invaEd-lovv' | 344 | mV
invabd-lcv,'.' | -144 , | mV
state | Operate | c | 0.000 | R | -0.000 | scale | 0.200
Fuel(MFCA3)
ACME FLOW '43 FUEL SETPOINT | ACME FLOW M3 FUEL FLOW
27.190125 | o. 165
23:30 | 23:31 | 23:32 | 23:33 | Cube
Correction
3Fri May 2019 | Time (s)
v.rne Series Chart #1
Packet | So ftv•are Fhernonic
ACME Teleme ACME DIAG PMT Tl | 0.00
ACME Teleme | 0.00
ACME Teleme | 0.00
> -OSe-3
-o.7e-3
-OSe-3
-I.oe-3
Select Items | End Plotting
03May 2019 | 3fri may 2019 | Time
startT,me | Restart
After test, 703 on lowest valve safety timer, 1066 psia in oxidizer bottle
8
~~~~

### Pagina 9

Cita: [pdf_80ac6e21aeda4546d3e8, p. 9]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
9
Test 19123K1 – successful test, run with bracketingExposureStartUsec=80000, 
bracketingExposureMultiplierTimes100=500, igniterIgnitionPosition=2200,
igniterIgnitionDurationMs=2500, igniterDelayBeforeRetractMs=2000, 
constantPostExtinctionDelaySec=rampPostExtinctionDelaySec=0
Also ACME camera zoom and focus as in plan, i.e., dataCamera Focus=10025, 
dataCamera Zoom=45000.
Also set igniter trigger level= 2.0 V, Igniter Off Delay= 200 ms
After test, 674 on lowest valve safety timer, 1066 psia in oxidizer bottle
~~~~

### Pagina 10

Cita: [pdf_80ac6e21aeda4546d3e8, p. 10]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
10
Test 19123B1 – successful test, run with bracketingExposureStartUsec=80000, 
bracketingExposureMultiplierTimes100=500, igniterIgnitionPosition=2250,
igniterIgnitionDurationMs=2500, igniterDelayBeforeRetractMs=2000, 
constantPostExtinctionDelaySec=rampPostExtinctionDelaySec=0
Also ACME camera zoom and focus as in plan, i.e., dataCamera Focus=10025, 
dataCamera Zoom=45000.
Also set igniter trigger level= 2.0 V, Igniter Off Delay= 200 ms
After test, 647 on lowest valve safety timer, 1066 psia in oxidizer bottle
~~~~

### Pagina 11

Cita: [pdf_80ac6e21aeda4546d3e8, p. 11]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
11
Test 19123D1 – successful test, run with bracketingExposureStartUsec=80000, 
bracketingExposureMultiplierTimes100=500, igniterIgnitionPosition=2250,
igniterIgnitionDurationMs=2500, igniterDelayBeforeRetractMs=2000, 
constantPostExtinctionDelaySec=rampPostExtinctionDelaySec=0
Also ACME camera zoom and focus as in plan, i.e., dataCamera Focus=10025, 
dataCamera Zoom=45000.
Also set igniter trigger level= 2.0 V, Igniter Off Delay= 200 ms
After test, 622 on lowest valve safety timer, 1067 psia in oxidizer bottle
~~~~

### Pagina 12

Cita: [pdf_80ac6e21aeda4546d3e8, p. 12]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
12
Test 19123J1 – successful test, run with bracketingExposureStartUsec=80000, 
bracketingExposureMultiplierTimes100=500, igniterIgnitionPosition=2250,
igniterIgnitionDurationMs=2500, igniterDelayBeforeRetractMs=2000, 
constantPostExtinctionDelaySec=rampPostExtinctionDelaySec=0
Also ACME camera zoom and focus as in plan, i.e., dataCamera Focus=10025, 
dataCamera Zoom=45000.
Also set igniter trigger level= 2.0 V, Igniter Off Delay= 200 ms
After test, 594 on lowest valve safety timer, 1067 psia in oxidizer bottle
~~~~

### Pagina 13

Cita: [pdf_80ac6e21aeda4546d3e8, p. 13]. Metodo: native.

~~~~text
13
Test 19123 L1 – successful test, run with bracketingExposureStartUsec=80000, 
bracketingExposureMultiplierTimes100=500, igniterIgnitionPosition=2250,
igniterIgnitionDurationMs=2500, igniterDelayBeforeRetractMs=2000,
stabilizationTime2Sec=1,
fuelBottleIgnitionFlowRateN2Slpm=fuelBottleTestFlowRateN2Slpm=0.2,
constantPostExtinctionDelaySec=0, Ramp PostExtinctionDelaySec=0
Also ACME camera zoom and focus as in plan, i.e., dataCamera Focus=10025, 
dataCamera Zoom=45000.
Also set igniter trigger level= 2.0 V, Igniter Off Delay= 200 ms
After test, __ on lowest valve safety timer, __ psia in oxidizer bottle
~~~~

### Pagina 14

Cita: [pdf_80ac6e21aeda4546d3e8, p. 14]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
14
Test 19123L2 – successful test, run with bracketingExposureStartUsec=80000, 
bracketingExposureMultiplierTimes100=500, igniterIgnitionPosition=2250,
igniterIgnitionDurationMs=2500, igniterDelayBeforeRetractMs=2000,
stabilizationTime2Sec=1, rampFlowToZeroSec=30, 
constantPostExtinctionDelaySec=0, Ramp PostExtinctionDelaySec=0
Also ACME camera zoom and focus as in plan, i.e., dataCamera Focus=10025, 
dataCamera Zoom=45000.
Also set igniter trigger level= 2.0 V, Igniter Off Delay= 200 ms
After test, 523 on lowest valve safety timer, 1067 psia in oxidizer bottle
~~~~

### Pagina 15

Cita: [pdf_80ac6e21aeda4546d3e8, p. 15]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
15
Test 19123L3 – successful test, run with bracketingExposureStartUsec=80000, 
bracketingExposureMultiplierTimes100=500, igniterIgnitionPosition=2200,
igniterIgnitionDurationMs=2500, igniterDelayBeforeRetractMs=2000,
fiberIgnitionPosition=fiberTestPosition=0, stabilizationTime2Sec=0,
constantFlowTimeSec=3, rampFlowToZeroSec=30, 
constantPostExtinctionDelaySec=0, Ramp PostExtinctionDelaySec=0
Also ACME camera zoom and focus as in plan, i.e., dataCamera Focus=10025, 
dataCamera Zoom=45000.
Also set igniter trigger level= 2.0 V, Igniter Off Delay= 200 ms
After test, 491 on lowest valve safety timer, 1067 psia in oxidizer bottle
~~~~

### Pagina 16

Cita: [pdf_80ac6e21aeda4546d3e8, p. 16]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
16
Test 19123L4 – successful test, conducted with as-planned fuel flow, run with 
bracketingExposureStartUsec=80000, 
bracketingExposureMultiplierTimes100=500, igniterIgnitionPosition=2200,
igniterIgnitionDurationMs=2500, igniterDelayBeforeRetractMs=2000,
constantFlowTimeSec=3, rampFlowToZeroSec=15, 
constantPostExtinctionDelaySec=0, Ramp PostExtinctionDelaySec=0
Also ACME camera zoom and focus as in plan, i.e., dataCamera Focus=10025, 
dataCamera Zoom=45000.
Also set igniter trigger level= 2.0 V, Igniter Off Delay= 200 ms
After test, 455 on lowest valve safety timer, 1320 psia in oxidizer bottle
~~~~

### Pagina 17

Cita: [pdf_80ac6e21aeda4546d3e8, p. 17]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
17
Test 19123L5 – successful test, the same as L4 except for the reduced ramp time 
to zero flow, run with bracketingExposureStartUsec=80000, 
bracketingExposureMultiplierTimes100=500, igniterIgnitionPosition=2200,
igniterIgnitionDurationMs=2500, igniterDelayBeforeRetractMs=2000,
constantFlowTimeSec=3, rampFlowToZeroSec=5, 
constantPostExtinctionDelaySec=0, Ramp PostExtinctionDelaySec=0
Also ACME camera zoom and focus as in plan, i.e., dataCamera Focus=10025, 
dataCamera Zoom=45000.
Also set igniter trigger level= 2.0 V, Igniter Off Delay= 200 ms
After test, 421 on lowest valve safety timer, 1067 psia in oxidizer bottle
~~~~

### Pagina 18

Cita: [pdf_80ac6e21aeda4546d3e8, p. 18]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
18
Test 19123L6 – successful test, the same as L5 except for the increased ramp 
time to zero flow, run with bracketingExposureStartUsec=80000, 
bracketingExposureMultiplierTimes100=500, igniterIgnitionPosition=2200,
igniterIgnitionDurationMs=2500, igniterDelayBeforeRetractMs=2000,
constantFlowTimeSec=3, rampFlowToZeroSec=10, 
constantPostExtinctionDelaySec=0, Ramp PostExtinctionDelaySec=0
Also ACME camera zoom and focus as in plan, i.e., dataCamera Focus=10025, 
dataCamera Zoom=45000.
Also set igniter trigger level= 2.0 V, Igniter Off Delay= 200 ms
After test, 385 on lowest valve safety timer, 1320 psia in oxidizer bottle
~~~~

### Pagina 19

Cita: [pdf_80ac6e21aeda4546d3e8, p. 19]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
19
Test 19123L7 – successful test, the same as L6 for the halved fuel flow, extended 
igniter durations, and apparently a longer ramp duration to zero flow, run with 
bracketingExposureStartUsec=80000, 
bracketingExposureMultiplierTimes100=500, igniterIgnitionPosition=2200,
igniterIgnitionDurationMs=3000, igniterDelayBeforeRetractMs=2500,
fuelBottleIgnitionFlowRateN2Slpm=fuelBottleTestFlowRateN2Slpm=0.052,
constantFlowTimeSec=3, rampFlowToZeroSec=15, 
constantPostExtinctionDelaySec=0, Ramp PostExtinctionDelaySec=0
Also ACME camera zoom and focus as in plan, i.e., dataCamera Focus=10025, 
dataCamera Zoom=45000.
Also set igniter trigger level= 2.0 V, Igniter Off Delay= 200 ms
~~~~

### Pagina 20

Cita: [pdf_80ac6e21aeda4546d3e8, p. 20]. Metodo: native.

~~~~text
20
Test 19123L8 – failed ignition with burnt-out igniter, test was with the same 
conditions as L6 except for the halved fuel flow, extended igniter durations, and 
increased PMT gains, run with bracketingExposureStartUsec=80000, 
bracketingExposureMultiplierTimes100=500, igniterIgnitionPosition=2200,
igniterIgnitionDurationMs=3000, igniterDelayBeforeRetractMs=2500,
pmt1Gain=5.5, pmt2Gain=pmt3Gain=5.75, 
fuelBottleIgnitionFlowRateN2Slpm=fuelBottleTestFlowRateN2Slpm=0.052,
constantFlowTimeSec=3, rampFlowToZeroSec=10, 
constantPostExtinctionDelaySec=0, Ramp PostExtinctionDelaySec=0
Also ACME camera zoom and focus as in plan, i.e., dataCamera Focus=10025, 
dataCamera Zoom=45000.
Also set igniter trigger level= 2.0 V, Igniter Off Delay= 200 ms
~~~~
