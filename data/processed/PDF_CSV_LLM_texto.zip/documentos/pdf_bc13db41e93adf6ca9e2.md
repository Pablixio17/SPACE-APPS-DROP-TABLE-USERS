# 19171 test sheets

- Identificador: pdf_bc13db41e93adf6ca9e2
- Investigaciones: PSI-10
- Tipo de documento: Raw Data
- Estado: processed
- Temas detectados automaticamente: pressure, ignition, hardware, oxygen

## Fuentes

- [PSI-10_Raw Data_19171 test sheets.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-10/Raw%20Data/PSI-10_Raw%20Data_19171%20test%20sheets.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_bc13db41e93adf6ca9e2, p. 1]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_bc13db41e93adf6ca9e2/p0001.jpg)

~~~~text
ACME / Flame Design (normal flame) - Science Test Sheet
est date: | CME test #:
Local time: | est of day #:
MT: | 171 | Flame of day #:
CONDITIONS | ontrol? | k fully automated o 'manual'
TEST
Test type? o ignition o no-flame Wtandard o other
Oxygen conc. | % (volume) | Burner type: | K 1/4" sphere jet
hamber | psia | Fuel Bottle: | CH4 | 96 *C2H4
pressure:
ent before? | to | psia | Burner fuel conc.: | [000/0 (volume)
o no | es,
Air' added? | to | Fuel flow rate: 42-slpm (N2 basis)
o no Myes, | psia
Iso just before? o fan GC o scrub | slpm
INSTRUMENTATION | FP?Vno o fixed o moving o back-n-forth
BG7 CH* CH20 | ROI? &full reduced | fps
*DataCam: | o | 0
Intensified: filter? | CH20 0 none | ROI? | o reduced | z fps
o
HiBMs: backlight filter? no | CIR backlight? no | fps? (15 D 30
o Mes
FLAME BEHAVIOR | Ignited? Ayes o no o yes, but .
Fla | 00tQnone o ignition only Klittle Aots
me A-asymmetric
Flame | out | oot@end znone o ignition little lots
Aoscillating unsteady *blew
POST-TEST CONDITIONS | Oxidizer bottle pressure: I Zopsia
alve safety timer | "D sec
*GENERAL COMMENTS
3 ? .43 Z
6 Feb. 2019
~~~~

### Pagina 2

Cita: [pdf_bc13db41e93adf6ca9e2, p. 2]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_bc13db41e93adf6ca9e2/p0002.jpg)

~~~~text
ACME / Flame Design (normal flame) - Science Test Sheet
ontrol? | fully automated 'manual'
TEST CONDITIONS
Test type? o ignition o no-flameØtandard other
% (volume) | Burner type: | sphere jet
xygen conc. | -t/ O
hamber | psia | Fuel Bottle: CH4 | % o C2H4
pressure: | 4K
Burner fuel conc.: | % (volume)
ent before? Eno o yes, to | psia
Fuel flow rate: az-slpm (N2 basis)
Air' added? | o yes, to | psia
Iso | before? | o GC o scrub | N2-ftow-ra-te; | p slpm
just | yifan
FP? | fixed o moving back-n-forth
INSTRUMENTATION
eDataCam: filter? | BG7 CH* CH20 | ROI? *full o reduced | fps
«clear o | 0 | a
filter? | CH20 0 none | ROI? efull o reduced | fps
Intensified: | o clear qCH* o
filter? | CIR backlight? no yes fps?N5 0 30
YHiBMs: backlight | no q_yes
FLAME BEHAVIOR | Ignited? yes a no o yes, but ..
00t o none D ignition only o little o lots
Flame o asymmetric o hole/opening(s)
oot@end none o ignition a little o lots
Flame o oscillating a unsteady o blew out
CONDITIONS | xidizer bottle pressure: | psia
POST-TEST
% (volume) | alve safety timer | sec
xygen conc. 37. I
*GENERAL COMMENTS
+ | -D | F
4.4
AJAX
6 Feb. 2019
~~~~

### Pagina 3

Cita: [pdf_bc13db41e93adf6ca9e2, p. 3]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_bc13db41e93adf6ca9e2/p0003.jpg)

~~~~text
ACME / Flame Design (normal flame) - Science Test Sheet
est date: | CME test
Local time: | est of day #:
MT: | I r7 | Flame of day #:
TEST CONDITIONS | ontrol? | fully automated o 'manual'
Test type? o ignition D no-flame (standard o other
Oxygen conc. | % (volume) | Burner type: | 1/4" sphere o jet
Chamber | psia OR Fuel Bottle: o CH4 | % C2H4
pressure:
ent before? | to | psia | Burner fuel conc.: | % (volume)
Kno o yes,
Air' added? | to | psia | Fuel flow rate: | slpm (N2 basis)
no D yes,
Iso just before? | an o GC o scrub
INSTRUMENTATION | FP? no o fixed moving o back-n-forth
filter? | BG7 a CH* CH20 | ROI? Q full reduced | fps
LDataCam:
Intensified: filter? clear KCH* o CH20 0 none | ROI?Pfull o reduced | 23 fps
o
OliBMs: backlight filter? o no *yes | CIR backlight? no (yes fps?R15 0 30
FLAME BEHAVIOR | Ignited? | no 0 yes, but ...*
Flame | hole/opening(s) | oot o none o ignition only a little D lots
a asymmetric
Flame | blew out | oot@end Xnone o ignition a little o lots
o oscillating o unsteady o
POST-TEST CONDITIONS | Oxidizer bottle pressure: IZ$ | psia
conc. | 72—0/0 (volume) | alve safety timer | Z.— sec
xygen
*GENERAL COMMENTS
c/7-Jer-
/-zs+—F.r-
Öz_
e.gc-e-pk
6 Feb. 2019
~~~~

### Pagina 4

Cita: [pdf_bc13db41e93adf6ca9e2, p. 4]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_bc13db41e93adf6ca9e2/p0004.jpg)

~~~~text
ACME / Flame Design (normal flame) - Science Test Sheet
est date: | 20 201 | CME test#: / /
Local time: | est of day #:
MT: | Flame of day #:
Rack Officer (RO): | PD (ACME):
DMO (CIR): | Researcher: | vts
TEST CONDITIONS | ontrol? | Kfully automated o 'manual'
Test type? o ignition o no-flame•ß$tandard o other
conc. | % (volume) | Burner type: | sphere o jet
xygen
hamber | psia | Fuel Bottle: a CH4 | % o C2H4 | %
pressure:
ent before? | to | psia | Burner fuel conc.: | % (volume)
Q no o yes,
Air' added? | to | psia | Fuel flow rate: | slpm (N2 basis)
n no o yes,
Iso just before? (fan o GC o scrub | N-240w-rate: | slpm
INSTRUMENTATION | FP? o no o fixed moving D back-n-forth
DataCam: filter? | BG7 0 | CH20 | ROI? Y-full o reduced | fps
Éclear o
Intensified: filter? | o CH20 0 none | ROI? g full reduced | fps
o | o
HiBMs: backlight filter? o no Ryes CIR backlight? o no | fps? (15 0 30
o
POST-TEST CONDITIONS | xidizer bottle pressure: | psia
conc. 3592-— % (volume) | alve safety timer | D sec
xygen
*GENERAL COMMENTS
347 ZL Oz-
6 Feb. 2019
~~~~

### Pagina 5

Cita: [pdf_bc13db41e93adf6ca9e2, p. 5]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_bc13db41e93adf6ca9e2/p0005.jpg)

~~~~text
ACME / Flame Design (normal flame) - Science Test Sheet
est date: | CME test#: f 7/
Local time: | 251 | est of day #:
MT: | / | Flame of day #:
TEST CONDITIONS | Control? | fully automated o 'manual'
Test type? D ignition o no-flame(standard o other
conc. | % (volume) | Burner type: | sphere o jet
xygen
Chamber | psia OR Fuel Bottle: CH4 | % o C2H4 | %
pressure:
ent before? Eno o | to | psia | Burner fuel conc.: | % (volume)
yes,
Air' added? | to | psia | Fuel flow rate: | slpm (N2 basis)
no yes,
Iso just before? | fan o GC o scrub | N2 flow rate: | slpm
INSTRUMENTATION | FP? Yno o fixed o moving o back-n-forth
DataCam: filter? Aclear o BG7 0 CH* CH20 | ROI? Q full reduced | fps
Intensified: filter? o | o CH20 0 none | ROI? V full o reduced | 2.} fps
*HiBMs: backlight filter? o no *yes | CIR backlight? no uyes fps? R 15 0 30
FLAME BEHAVIOR | Ignited? Zyes o no o yes, but .
Flame | o hole/opening(s) | 00t none o ignition only o little D lots
o asymmetric
Flame | unsteady o blew out | oot@end a none o ignition a little o lots
o oscillating o
POST-TEST CONDITIONS | xidizer bottle pressure: | psia
conc. 35 | % (volume) | alve safety timer | S | sec
xygen
*GENERAL COMMENTS
* 359 Z
6 Feb. 2019
~~~~

### Pagina 6

Cita: [pdf_bc13db41e93adf6ca9e2, p. 6]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_bc13db41e93adf6ca9e2/p0006.jpg)

~~~~text
ACME / Flame Design (normal flame) - Science Test Sheet
ontrol? | fully automated o 'manual'
TEST CONDITIONS
Test type? D ignition o no-flame Estandard o other
D % (volume) | Burner type: | k 1/4" sphere o jet
xygen conc.
Fuel Bottle: o CH4 | %AC2H4 /'2>0/0
hamber pressure: | psia
before? | to | psia | Burner fuel conc.: | % (volume)
ent | 0 yes,
Fuel flow rate: åÅ.)7C slpm (N2 basis)
Air' added? A-no o yes, to | psia
Iso just before? Wan o GC o scrub | N2 flow rate: 0/17 slpm
INSTRUMENTATION | FP? o no fixedkoving o back-n-forth
DataCam: filter? | BG7 | CH20 | ROI? E full o reduced | fps
o | 0
Intensified: filter? clear X-CH* CH20 0 none | ROI? gfull o reduced | fps
o | o
filter? | CIR backlight? o no gyes fps? (15 0 30
rHiBMs: backlight | o no Kyes
FLAME BEHAVIOR | Ignited? | no yes, but
00t D none D ignition only o little o lots
Flame o asymmetric o hole/opening(s)
blew | oot@end o none D ignition little D lots
Flame o oscillating D unsteady o | out
POST-TEST CONDITIONS | xidizer bottle pressure: / 300 psia
347B | % (volume) | alve safety timer | sec
xygen conc.
*GENERAL COMMENTS
-häe
6 Feb. 2019
~~~~

### Pagina 7

Cita: [pdf_bc13db41e93adf6ca9e2, p. 7]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_bc13db41e93adf6ca9e2/p0007.jpg)

~~~~text
ACME / Flame Design (normal flame) - Science Test Sheet
est date: | 201 | CME test
Local time: | est of day #:
MT: | Flame of day #:
Rack Officer (RO): -T | PD (ACME):
DMO (CIR): | Researcher:
TEST CONDITIONS | ontrol? | Nully automated c] 'manual'
Test type? o ignition o no-flame standard o other
conc. | D % (volume) | Burner type: | (1/4" sphere o jet
xygen
hamber | psia | Fuel Bottle: CH4 | % D C2H4
pressure:
ent before? | to | psia | Burner fuel conc. : | % (volume)
o no o yes,
Air' added? | to | psia | Fuel flow rate: 0-1Mslpm (N2 basis)
o no D yes,
Iso just before? Uan a GC crub | N2 flow rate: | slpm
INSTRUMENTATION | FP? D no o fixed moving o back-n-forth
filter? B-clear o BG7 0 CH* o CH20 | ROI? Xfull o reduced | fps
DataCam:
[Antensified: filter? clear LCH* o CH20 0 none | ROI? g full o reduced | fps
o
backlight filter? o no Eyes | CIR backlight? o no | fps? | 30
ÜiBMs:
FLAME | Ignited? | but .
Ze-tb
Flame | hole/opening(s) | 00t a none o ignition only o little o lots
symmetric o
Flame | blew out | oot@end o none o ignition a little o lots
oscillating o unsteady o
POST-TEST CONDITIONS | Oxidizer bottle pressure: 1300 psia
conc. 35.- Z % (volume) | alve safety timer | sec
xygen
*GENERAL COMMENTS
% | bet4-z-
* | az__
6 Feb. 2019
~~~~

### Pagina 8

Cita: [pdf_bc13db41e93adf6ca9e2, p. 8]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_bc13db41e93adf6ca9e2/p0008.jpg)

~~~~text
ACME / Flame Design (normal flame) - Science Test Sheet
est date: | -20 z. | CME test #:
Local time: | est of day #:
MT: | 7 | 2t•.4s | Flame of day #:
Rack Officer (RO): | PD (ACME):
DMO (CIR): | Researcher:
CONDITIONS | ontrol? | fully automated o 'manual'
TEST
Test type? ignition no-flame..(standard o other
conc. | % (volume) | Burner type: | €1/4" sphere a jet
xygen
hamber | psia OR Fuel Bottle: o CH4 | % ZC2H4
pressure:
ent before? | to | psia | Burner fuel conc.: | % (volume)
D no o yes,
Air' added? | to | psia | Fuel flow rate: O.Iæ4 slpm (N2 basis)
o no o yes,
Iso just before? u fan o GC o scrub | N2 flow rate: | slpm
INSTRUMENTATION | FP? o no c] | a back-n-forth
DataCam: filter? clear BG7 0 CH* a CH20 | ROI? o full o reduced | fps
o
Intensified: filter? clear CH* o CH20 0 none | ROI? o full o reduced | fps
o
backlight filter? o no | CIR backlight? o no | 15 0 30
*HiBMs: | Wes
POST-TEST CONDITIONS | Oxidizer bottle pressure: | psia
35<7 % (volume) | alve safety timer | t g sec
xygen conc.
*GENERAL COMMENTS
35-732/0
* | a
•au2J
6 Feb. 2019
~~~~

### Pagina 9

Cita: [pdf_bc13db41e93adf6ca9e2, p. 9]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_bc13db41e93adf6ca9e2/p0009.jpg)

~~~~text
ACME / Flame Design (normal flame) - Science Test Sheet
TEST CONDITIONS | ontrol? | A fully automated o 'manual'
Test type? o ignition a no-flame@standard o other
conc. | D % (volume) | Burner type: | •QI/4" sphere o jet
xygen
hamber | psia | Fuel Bottle: CH4 | 96a-C2H4 1000/0
pressure:
ent before? no o | to | psia 40 Burner fuel conc.: | % (volume)
yes,
Air' | to | psia | Fuel flow rate: o,/A-slpm (N2 basis)
no o yes,
Iso | before? | fan GC scrub | N2 flow rate: 0243 slpm
just | a | o
INSTRUMENTATION | FP? o no o fixed moving back-n-forth
Datacam: filter? g-clear o BG7 0 CH* CH20 | ROI? Z full reduced | fps
Intensified: filter? o clearcCH* o CH20 0 none | ROI? *full o reduced | fps
HiBMs: backlight filter? no Kyes | CIR backlight? o no ayes fps? ZJ5 0 30
FLAME BEHAVIOR | Ignited? | Dyes, but .
Flame Kasymmetric hole/opening(s) | oot o nonedunition only o
Flame | blew out | oot@end none D ignition D little o lots
o oscillating o unsteady o
POST-TEST CONDITIONS | Oxidizer bottle pressure: 3 DI psia
87 % (volume) | alve safety timer | 304 sec
xygen conc.
*GENERAL COMMENTS
beßc 7Lzs+-
357270
6 Feb. 2019
~~~~

### Pagina 10

Cita: [pdf_bc13db41e93adf6ca9e2, p. 10]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_bc13db41e93adf6ca9e2/p0010.jpg)

~~~~text
ACME / Flame Design (normal flame) - Science Test Sheet
est date: | CME test#: I I
Local time: | est of day | Ö
MT: | Flame of day
TEST CONDITIONS | ontrol? | (fully automated 'manual'
Test type? o ignition no-flameAEtandard o other
Oxygen conc. | 4 | % (volume) C | Burner type: | 1/4" sphere o jet
hamber pressure: | psia | Fuel Bottle: D CH4
ent before? | o | to | psia | Burner fuel conc.: | % (volume)
zno yes,
Air' added? | to | psia | Fuel flow rate: o, | slpm (N2 basis)
éno o yes,
Iso just before? | fan o GC o scrub | N2 flow rate: | Ö slpm | .332-
INSTRUMENTATION | F P? no o fixed D moving o back-n-forth
Datacam: filter? | o BG7 | CH20 | ROI? full o reduced | fps
*Intensified: filter? o clear YCH* o CH20 none | ROI? gfull o reduced | Z fps
dHiBMs: backlight filter? no | CIR backlight? o noZyes fps?É45 0 30
Ignited? | o no o yes, but *
FLAME BEHAVIOR | yes | ...
Flame | hole/opening(s) | 00t o none o ignition only a little ßJots
o asymmetric a
Flame | unsteady o blew out | oot@end none D ignition o little o lots
o oscillating
POST-TEST CONDITIONS | Oxidizer bottle pressure: I DI psia
conc. | % (volume) | alve safety timer | -ZZ | sec
xygen
*GENERAL COMMENTS
CA
ze._t—
6 Feb. 2019
~~~~

### Pagina 11

Cita: [pdf_bc13db41e93adf6ca9e2, p. 11]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_bc13db41e93adf6ca9e2/p0011.jpg)

~~~~text
ACME / Flame Design (normal flame) - Science Test Sheet
CONDITIONS | ontrol? | fully automated o 'manual'
TEST
Test type? D ignition o no-flame | other
conc. | % (volume) | Burner type: | sphere jet
xygen
Chamber | psia | Fuel Bottle: o CH4 | % AC2H4
pressure:
before? | to | psia | Burner fuel conc.: | % (volume)
ent | qno o yes,
Air' added? | psia | Fuel flow rate: | slpm (N2 basis)
o yes, to
Iso just before? | fan o GC o scrub | Slpm
INSTRUMENTATION | FP? no D fixed o moving o back-n-forth
Datacam: | BG7 0 | CH20 | ROI? K full a reduced | fps
o
Intensified: filter? clearg-CH* CH20 0 none | ROI? Efull o reduced | Z fps
o
HiBMs: backlight filter? no | CIR backlight? o noßyes fps? | D 30
y-yes
Ignited? | o no o | but *
FLAME BEHAVIOR | ayes | yes, | ...
Flame | 00t o none o ignition only o little lots
o asymmetric o hole/opening(s)
Flame | blew out | oot@end o none o ignition a little (lots
o oscillating o unsteady o
POST-TEST CONDITIONS | Oxidizer bottle pressure: 30' psia
3+25 % (volume) | alve safety timer | / 7 Z sec
xygen conc.
*GENERAL COMMENTS
6 Feb. 2019
~~~~

### Pagina 12

Cita: [pdf_bc13db41e93adf6ca9e2, p. 12]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_bc13db41e93adf6ca9e2/p0012.jpg)

~~~~text
ACME / Flame Design (normal flame) - Science Test Sheet
est date: | Ze 1 | CME test #:
Local time: | est of day #:
MT: | Flame of day #:
TEST CONDITIONS | ontrol? | automated o 'manual'
Test type? o ignition o no-flame | o other
conc. | w4•D % (volume) | Burner type: | X1/4" sphere o jet
xygen
hamber | psia | Fuel Bottle: D CH4 | % o C2H41220/0
pressure:
ent before? | to | psia | Burner fuel conc.: | % (volume)
Xno o yes,
Air' added? | to | psia | Fuel flow rate: | slpm (N2 basis)
nno o yes,
Iso just before? Xfan o GC o scrub | N2 flow rate: O | slpm b—33Z-
INSTRUMENTATION | o fixed o moving o back-n-forth
filter? *clear o BG7 0 CH* a CH20 | ROI? Oull o reduced | fps
Intensified: filter? o | o CH20 0 none | ROI? full o reduced | ZZ fps
d-HiBMs: backlight filter? o no | CIR backlight? o no *yes | D 30
ß-yes
Ignited? | o no o | but *
FLAME BEHAVIOR | yes | yes, | ...
Flame | hole/opening(s) | 00t none o ignition only a little o lots
o asymmetric o
Flame | unsteady blew out | oot@end none o ignition a little o lots
o oscillating o | o
POST-TEST CONDITIONS | xidizer bottle pressure: /3D psia
conc. 33 9 g % (volume) | alve safety timer | 11 | sec
xygen
*GENERAL COMMENTS
% Öz_
34.25
6 Feb. 2019
~~~~

### Pagina 13

Cita: [pdf_bc13db41e93adf6ca9e2, p. 13]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_bc13db41e93adf6ca9e2/p0013.jpg)

~~~~text
ACME / Flame Design (normal flame) - Science Test Sheet
ontrol? | fully automated o 'manual'
TEST CONDITIONS
Test type? D ignition no-flame ktandard other
4 D % (volume) -k | Burner type: | V-1/4" sphere jet
xygen conc.
psia | Fuel Bottle: o CH4 | % a C2H4
Chamber pressure: | D
Burner fuel conc.: | % (volume)
ent before? o no o yes, to | psia
Fuel flow rate: | slpm (N2 basis)
Air' added? o no o yes, to | psia
Iso | before? o fan o GC o scrub | N2 flow rate: | slpm
just
FP? no o fixed o moving o back-n-forth
INSTRUMENTATION
YDataCam: filter? | BG7 | CH20 | ROI? | o reduced | fps
0
filter? clear8CH* CH20 0 none | ROI? g full o reduced | fps
Intensified: | o
filter? | CIR backlight? no eyes fps?B-a5 0 30
HiBMs: backlight | D nou_yes
Ignited? o yes o no o yes, but ...*
FLAME BEHAVIOR
00t o none ignition only o little o lots
Flame o asymmetric o hole/opening(s)
oot@end o none o ignition a little o lots
Flame o oscillating o unsteady o blew out
CONDITIONS | Oxidizer bottle pressure: | psia
POST-TEST
% (volume) | alve safety timer | sec
xygen conc.
*GENERAL COMMENTS
f94t¯
6 Feb. 2019
~~~~
