# PS-02788_ACME_info_sheet

- Identificador: pdf_2b6c470b544ab2b7cc8b
- Investigaciones: PSI-20, PSI-22, PSI-23
- Tipo de documento: Presentations, Reports, Science Documents
- Estado: processed
- Temas detectados automaticamente: microgravity, electric_fields, hardware, oxygen, ignition, soot, operations

## Fuentes

- [PSI-20_Science Documents_PS-02788_ACME_info_sheet.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-20/Science%20Documents/PSI-20_Science%20Documents_PS-02788_ACME_info_sheet.pdf)
- [PSI-22_Reports_PS-02788 ACME info sheet.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-22/Reports/PSI-22_Reports_PS-02788%20ACME%20info%20sheet.pdf)
- [PSI-23_Presentations_PS-02788 ACME info sheet.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-23/Presentations/PSI-23_Presentations_PS-02788%20ACME%20info%20sheet.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Pasajes de orientacion (extractivos, no resumen validado)

### objective - pagina 1

objective is fire prevention, especially for spacecraft.
German astronaut Alex Gerst exchanging the nitrogen mass flow 
controller on the ACME chamber insert within the CIR facility.
RESEARCH: ACME includes six independent experiments 
investigating laminar, nonpremixed flames of gaseous 
fuels. The experiments are being conducted with a single 
set of modular hardware in the Combustion Integrated 
Rack (CIR) on the International Space Station (ISS). 
While the ISS astronauts set up the experimental hardware, 
the ACME tests are remotely commanded from NASA’s 
Glenn ISS Payload Operations Center.
Example flame from the Burning Rate Emulator (BRE) experiment 
led by Prof. Jim Quintiere (University of Maryland).
U.S. astronaut Joe Acaba and Russian cosmonaut Alexander 
Misurkin exchanging the CIR oxidizer bottle.
STATUS: ACME was setup by the ISS crew in Sept.-Oct. 
2017 where thus far sixteen astronauts from Canada, 
Germany, Italy, Japan, Russia, and the United States have 
supported the research. Since November 2017, over 550 
flames have been ignited for the Coflow Laminar Diffusion 
Flame (CLD Flame), Electric-Field Effects on Laminar 
Diffusion Flames (E-FIELD Flames), and Burning Rate 
Emulator (BRE) experiments. They are respectively led by 
Profs. Marshall Long (Yale University), Derek Dunn-Rankin 
(University of California, Irvine), and Jim Quintiere 
(University of Maryland). Russian collaborators on those 
experiments are with the Far Eastern Federal University 
and Peter the Great St. Petersburg Polytechnic University.
U.S. astronaut Ricky Arnold carrying out CIR maintenance tasks 
during CLD Flame experiment operations.
Advanced Combustion via Microgravity Experiments (ACME)
National Aeronautics and
Space Administration
NASA GLENN RESEARCH CENTER
www.nasa.go

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_2b6c470b544ab2b7cc8b, p. 1]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
PURPOSE: ACME is focused on advanced combustion 
technology via fundamental microgravity research. The 
primary goal is to improve efficiency and reduce pollutant 
emission in practical terrestrial combustion. A secondary 
objective is fire prevention, especially for spacecraft.
German astronaut Alex Gerst exchanging the nitrogen mass flow 
controller on the ACME chamber insert within the CIR facility.
RESEARCH: ACME includes six independent experiments 
investigating laminar, nonpremixed flames of gaseous 
fuels. The experiments are being conducted with a single 
set of modular hardware in the Combustion Integrated 
Rack (CIR) on the International Space Station (ISS). 
While the ISS astronauts set up the experimental hardware, 
the ACME tests are remotely commanded from NASA’s 
Glenn ISS Payload Operations Center.
Example flame from the Burning Rate Emulator (BRE) experiment 
led by Prof. Jim Quintiere (University of Maryland).
U.S. astronaut Joe Acaba and Russian cosmonaut Alexander 
Misurkin exchanging the CIR oxidizer bottle.
STATUS: ACME was setup by the ISS crew in Sept.-Oct. 
2017 where thus far sixteen astronauts from Canada, 
Germany, Italy, Japan, Russia, and the United States have 
supported the research. Since November 2017, over 550 
flames have been ignited for the Coflow Laminar Diffusion 
Flame (CLD Flame), Electric-Field Effects on Laminar 
Diffusion Flames (E-FIELD Flames), and Burning Rate 
Emulator (BRE) experiments. They are respectively led by 
Profs. Marshall Long (Yale University), Derek Dunn-Rankin 
(University of California, Irvine), and Jim Quintiere 
(University of Maryland). Russian collaborators on those 
experiments are with the Far Eastern Federal University 
and Peter the Great St. Petersburg Polytechnic University.
U.S. astronaut Ricky Arnold carrying out CIR maintenance tasks 
during CLD Flame experiment operations.
Advanced Combustion via Microgravity Experiments (ACME)
National Aeronautics and
Space Administration
NASA GLENN RESEARCH CENTER
www.nasa.gov
~~~~

### Pagina 2

Cita: [pdf_2b6c470b544ab2b7cc8b, p. 2]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
PS–02788–0319
Advanced Combustion via Microgravity Experiments
Diffusion flames with a weak air coflow as a function of the electric field strength, where an open copper mesh above the 
flame is negatively and positively charged in the top and bottom rows, respectively. Flames naturally include ions which can 
be affected by a powerful electric or magnetic field. In ACME’s E-FIELD Flames experiment, the copper mesh is energized 
up to 10,000 volts. This technology could be used to stabilize fuel-lean flames under conditions which are less polluting.
Canadian astronaut David Saint-Jacques preparing the 
ACME chamber insert for the BRE experiment.
ACME chamber insert within the CIR facility (above left) and two 
examples (above middle and right) of lifted flames that are 
detached from CLD Flame’s coflow burner, as a function of the 
fuel and air velocities. The false color in the image to the right 
indicates the CH* concentration as function of the radius and 
height above the burner. CH* is an excited species and emits blue 
light as it drops to a lower energy level in a process known as 
chemiluminescence. It is the primary source of the blue that is the 
natural color of hydrocarbon flames (neglecting the broadband 
thermal radiation from the soot).
WEB SITE: http://spaceflightsystems.grc.nasa.gov/acme/
UPDATES: www.facebook.com/space.flames 
PHOTOGRAPHS: www.flickr.com/photos/space-flames
EDUCATION: https://tinyurl.com/space-flames 
CONTACT: Dennis Stocker, ACME Project Scientist, NASA Glenn, 216-433-2166, dennis.p.stocker@nasa.gov
~~~~
