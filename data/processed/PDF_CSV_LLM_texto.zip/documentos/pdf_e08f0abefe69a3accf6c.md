# 21174 daily test point log

- Identificador: pdf_e08f0abefe69a3accf6c
- Investigaciones: PSI-159
- Tipo de documento: Raw Data
- Estado: processed
- Temas detectados automaticamente: hardware

## Fuentes

- [PSI-159_Raw Data_21174 daily test point log.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-159/Raw%20Data/PSI-159_Raw%20Data_21174%20daily%20test%20point%20log.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_e08f0abefe69a3accf6c, p. 1]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_e08f0abefe69a3accf6c/p0001.jpg)

~~~~text
ACME Daily Test Point Log | 6/23/2021
Downlink Data Limit (MB) = 127,000 | Total = | 126,561
Test Point Name Script Aborts | IPSU1/HiBMS | IPSU2/LLL-UV | ACME Camera | Intensified Camera
Downlink
(enter all test | Before I PSUs | Archived | Archived | Archived | Archived
Data (MB)
points) | Open | Images | D/L? | Images | D/L? | Images | D/L? | Images | D/L?
21174A1 | 478 | 1532 | 5,777
21174A2 | 560 | 1784 | 6,737
21174A3 | 769 | 2207 | 8,547
21174M | 2347 | 5895 | 23,646
2117481 | 726 | 3529 | 2,027
21174C1 | 519 | 1647 | 6,225
21174C2 | 520 | 1692 | 6,358
21174C3 | 579 | 1828 | 6,917
21174C4 | 1130 | 3107 | 12,164
21174D1 | C] | 586 | 2925 | 1,636
21174F1 | 743 | 2147 | 8,300
21174C5 | 381 | 1369 | 1,064
21174C6 | 2740 | 6808 | 27,391
21174F2 | 456 | 1521 | 1,273
21174F3 | 476 | 1588 | 1,329
21174F4 | 606 | 1890 | 7,172
Date:
~~~~
