# 21209 daily test point log

- Identificador: pdf_b00e4c6bfa1b230208fe
- Investigaciones: PSI-159
- Tipo de documento: Raw Data
- Estado: processed
- Temas detectados automaticamente: hardware

## Fuentes

- [PSI-159_Raw Data_21209 daily test point log.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-159/Raw%20Data/PSI-159_Raw%20Data_21209%20daily%20test%20point%20log.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_b00e4c6bfa1b230208fe, p. 1]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_b00e4c6bfa1b230208fe/p0001.jpg)

~~~~text
ACME Daily Test Point Log | 7/28/2021
Downlink Data Limit (MB) = 127,000 | Total = | 91,751
Test Point Name Script Aborts | IPSUI/HiBMS | IPSU2/LLL-UV | ACME Camera | Intensified Camera
Downlink
(enter all test | Before IPSUs | Archived | Archived | Archived | Archived
Data (MB)
points) | Open | Images | D/L? | Images | D/L? | Images | D/L? | Images | D/L?
21209A1 | 75 | 615 | 1,993
21209A2
21209A3 | 753 | 2232 | 8,574
21209B1 | 790 | 3877 | 13,448
21209A4 | 749 | 2202 | 8,476
21209H1 | 794 | 2558 | 9,634
21209J1 | 793 | 2557 | 9,629
21209F1 | 789 | 2484 | 9,406
21209F2 | 796 | 2603 | 9,770
21209F3 | 790 | 2465 | 9,353
2120982 | 286 | 1624 | 5,508
21209K1 | 396 | 1674 | 5,960
It
Date:
~~~~
