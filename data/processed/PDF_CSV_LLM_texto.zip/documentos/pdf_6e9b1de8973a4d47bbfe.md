# 21349 test sheets

- Identificador: pdf_6e9b1de8973a4d47bbfe
- Investigaciones: PSI-10
- Tipo de documento: Raw Data
- Estado: processed
- Temas detectados automaticamente: pressure, ignition, hardware, oxygen, soot

## Fuentes

- [PSI-10_Raw Data_21349 test sheets.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-10/Raw%20Data/PSI-10_Raw%20Data_21349%20test%20sheets.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_6e9b1de8973a4d47bbfe, p. 1]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_6e9b1de8973a4d47bbfe/p0001.jpg)

~~~~text
ACME / Flame Design (inverse flame) - Science Test Sheet
est date: | 2-C2— | CME test#: 2-)3
Local time: | est of day#: | (
GMT: | Flame of day #:
Rack Officer (RO): | PD (ACME):
DMO (CIR): | Researcher:
TEST CONDITIONS | ontrol? | automated ü 'manual'
Test type? o ignition o no-flame Gandard other
Chamber atmosphere | 2 bottle: | 85% (volume)
C2H4 conc. | % (vol, nominal) | Burner 02 conc.: | % (volume
2H4 conc. | % (vol, per calc) | 02 flow rate: | slpm (N2 basis
Chamber pressure: | psia (CIR avg per FCU) | N2 flow rate: | slpm
ent before? no *yes, to 0.2— psia
Iso just before? | fan GC scrub
F P? no o fixed moving back-n-forth
INSTRUMENTATION | ain: | DataCam 2-1 ops camera
QataCam: filter? | BG7 | CH20 | ROI? Afull reduced | fps
untensified: filter? clear (CH* CH20 none | ROI?qfull reduced | fps
HiBMs: backlight filter? a no Oes | CIR backlight | 94ye
FLAME BEHAVIOR
Flame Khot o cool maybe cool | Ignited? o yes no o yes, but ...*
Flame hole/opening partially detached | 00t@ignition none little lots
Flame oscillating unsteady quasi-stead | 00t@middIe D none little lots
Out ext. detect ü time out temp. limit | 00t@end | c] none little Zlots
POST-TEST CONDITIONS
Fuel conc. | % (vol, per calc) | Chamber pressure: | psia (CIR | FCU)
avg per
alve safety timer | sec | Oxidizer bottle pressure: | 45' psia
*GENERAL COMMENTS
19 Oct. 2021
~~~~

### Pagina 2

Cita: [pdf_6e9b1de8973a4d47bbfe, p. 2]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_6e9b1de8973a4d47bbfe/p0002.jpg)

~~~~text
ACME / Flame Design (inverse flame) - Science Test Sheet
est date: | CME test#.•
Local time: | est of day#:
MT: | Flame of day#:
TEST CONDITIONS | ontrol? | (fully automated o 'manual'
Test type? o ignition no-flame standard o other
hamber atmosphere | 02 bottle: | 85% (volume)
C2H4 conc. | % (vol, nominal) | Burner 02 conc.: | g 5 % (volume)
C2H4 conc. | % (vol, per calc) | 2 flow rate: | slpm (N2 basis)
Chamber pressure: | Z—psia (CIR avg per FCU | N2 flow rate: | O | slpm
ent before? no yes, to | psia
Iso just before? | fan GC scrub
Fpwl() c] fixed ü moving back-n-forth
INSTRUMENTATION | ain: | DataCam | ops camera
XDataCam: filter?zclear BG7 | CH20 | ROI? e full reduced | fps
Intensified: filter? clear | o CH20 0 none | ROI? •full reduced | fps
backlight filter? no Wyes | CIR backlight? no Ryes | 30
FLAME BEHAVIOR
Flame hot D cool maybe cool | Ignited? (yes no o yes, but
Flame c] hole/opening partially detached | 00t@ignition none little lots
Flame oscillating unstead | quasi-stead | SOOt@middle a none little.a lots
Out o ext. detect a time out | limit | 00t@end | none little Ots
POST-TEST CONDITIONS
Fuel conc. | % (vol, per calc) | hamber pressure: | 3psia (CIR avg per FCU
alve safety timer | 7-38 | sec | Oxidizer bottle pressure: | 3 psia
*GENERAL COMMENTS
19 Oct. 2021
~~~~

### Pagina 3

Cita: [pdf_6e9b1de8973a4d47bbfe, p. 3]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_6e9b1de8973a4d47bbfe/p0003.jpg)

~~~~text
ACME / Flame Design (inverse flame) - Science Test Sheet
est date: | CME test | 13
Local time: | est of day #:
MT: | 2) | Flame of day #:
Rack Officer (RO): | PD (ACME):
DMO (CIR): | Researcher:
TEST CONDITIONS | Control? | fully automated 'manual'
Test type? ignition o no-flam | standard other
Chamber atmosphere | 02 bottle: | 85% (volume)
C2H4 conc. | % (vol, nominal) | Burner 02 conc.. | % (volume
C2H4 conc. | % (vol, per calc) | 02 flow rate: | slpm (N2 basis
hamber pressure: | psia (CIR avg per FCU | N 2 flow rate: | O. 4) > slpm
ent before? zno yes, to | psia
Iso just before? e fan GC scrub
FP? no fixed o moving back-n-forth
INSTRUMENTATION | ain: 2 | DataCam | ops camera
DataCam: filter? Eclear BG7 CH* CH20 | ROI? (full o reduced | fps
Intensified: filter? | CH20 none | ROI? Sfull reduced | Bfps
light filter? no Ayes | CIR backlight? Kno yes fps2-a-1S&30
„.zc
FLAME BEHAVIOR
Flame hot o cool maybe cool | Ignited? o yestÅno o | but ...*
yes,
Flame D hole/opening c] partially detached | Soot@ignition none a little c] lots
Flame oscillating unsteady quasi-stead | 00t@middle a none little c] lots
ut ext. detect time out temp. limit | 00t@end | o none little c] lots
POST-TEST CONDITIONS
Fuel conc. | % (vol, per calc) | hamber pressure: | psia (CIR | FCU
avg per
alve safety timer | ZZ— sec | xidizer bottle pressure: | 3 psia
*GENERAL COMMENTS
19 Oct. 2021
~~~~

### Pagina 4

Cita: [pdf_6e9b1de8973a4d47bbfe, p. 4]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_6e9b1de8973a4d47bbfe/p0004.jpg)

~~~~text
ACME / Flame Design (inverse flame) - Science Test Sheet
est date: | CME test#:
Local time: | 2-.20 | est of day #:
GMT: | Flame of day #:
Rack Officer (RO): | PD (ACME): | G-
DMO (CIR): | Researcher:
TEST CONDITIONS | Control? | (fully automated o 'manual'
Test type? ignition no-flame A standard other
hamber atmosphere | 02 bottle: | 85% (volume)
C2H4 conc. | % (vol, nominal) | Burner 02 conc.: | % (volume
C2H4 conc. | % (vol, per calc) | 2 flow rate: | slpm (N2 basis)
hamber pressure: | sia (CIR avg per FCU) | N2 flow rate: | slpm
ent before? no yes, to | psia
Iso just before? L fan GC scrub
FP?Q no fixed moving back-n-forth
INSTRUMENTATION | ain: 24- DataCam _2L ops camera
filter?gclear BG7 | CH20 | ROI? < full reduced | fps
Intensified: filter? clear d-CH* CH20 none | ROI?yfull reduced | 23 fps
U-HiBMs: backlight filter? no eyes | CIR backlight? Sno yes
FLAME BEHAVIOR
cool o maybe cool | Ignited? | o no yes, but .
Flame Xhole/opening partially detached | 00t@ignition none little *lots
Flame oscillating unsteady quasi-stead | 00t@middle noneklittle LI lots
Out ext. detect time out o temp. limit | 00t@end | none little lots
POST-TEST CONDITIONS
Fuel conc. | % (vol, per catc) | Chamber pressure: | psia (CIR avg per FCU)
alve safety timer | Oxidizer bottle pressure: 43 | psia
*GENERAL COMMENTS
Piet
+ztbe
74
19 Oct. 2021
~~~~

### Pagina 5

Cita: [pdf_6e9b1de8973a4d47bbfe, p. 5]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_6e9b1de8973a4d47bbfe/p0005.jpg)

~~~~text
ACME / Flame Design (inverse flame) - Science Test Sheet
est date: | CME test#: 2134 D
Local time: | est of day #:
GMT: | Flame of day
TEST CONDITIONS | Control? | ully automated 'manual'
Test type? ignition no-flameÄ standard CJ other
hamber atmosphere | 02 bottle: | 85% (volume)
C2H4 conc. | 0/0 (vol, nominal) | Burner 02 | % (volume
C2H4 conc. | % (vol, per calc) | 2 flow rate: | slpm (N2 basis)
Chamber pressure: | psia (CIR avg per FCU | N2 flow rate: D,} | slpm
ent before? Q no yes, to | psia
Iso just before? | fan o GC scrub
FP? no fixed moving back-n-forth
INSTRUMENTATION | Gain: —24.- DataCam 2-1 ops camera
DataCam: filter? Vclear BG7 0 CH* CH20 | ROI? {full reduced | fps
filter? o clear g-CH* CH20 none | ROI?øfull o reduced | fps
: backlight filter? nozyes | CIR | yes fps?-t-1-5-o-30
FLAME BEHAVIOR
Flame Éhot o cool c) maybe cool | Ignited? | no yes, but ...*
Flame hole/opening ü partially detached | Soot@ignition o none little lots
Flame oscillating c] unsteadyequasi-stead | 00t@middle o none little lots
Out ext. detect time out temp. limit | oot@end | none littl | lots
POST-TEST CONDITIONS
i6e
*GENERAL COMMENTS
19 Oct. 2021
~~~~

### Pagina 6

Cita: [pdf_6e9b1de8973a4d47bbfe, p. 6]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_6e9b1de8973a4d47bbfe/p0006.jpg)

~~~~text
ACME / Flame Design (inverse flame) - Science Test Sheet
est date: | ec— 5 zez-) | CME test#: Z 4 'V? I
Local time: | est of day #:
MT: | Flame of day #:
TEST CONDITIONS | Control? | fully automated 'manual'
Test type? ignition no-flame | other
hamber atmosphere | 02 bottle: | 85% (volume)
C2H4 conc. | % (vol, nominal) | Burner 02 conc.: | % (volume
C2H4 conc. | % (vol, per calc) | 02 flow rate: | O. | slpm (N2 basis)
hamber pressure: | psia (CIR avg per FCU) | N 2 flow rate: | O? | slpm
ent before? | o yes, to | psia
ISO just before? | fan GC ü scrub
FP?Å_no fixed moving o back-n-forth
INSTRUMENTATION | ain: | DataCam | ops camera
Datacam: filter? | BG7 | CH20 | ROI? Ä full reduced | fps
Untensified: filter? o clear CCH* o CH20 0 none | ROI? *full c] reduced | -Cfps
backlight filter? non yes | CIR backlight?
FLAME BEHAVIOR
Flame hot cool o maybe cool | Ignited? eyes no o yes, but
..
Flame hole/opening partially detached | SOOt@ignition none little lots
Flame o oscillating Cl unsteady | uasi-stead | SOOt@middle none little€ lots
Out ext. detect time out temp. limit | oot@end | none CJ littlek lots
POST-TEST CONDITIONS
Fuel conc. | % (vol, per calc) | Chamber pressure: 47 psia (CIR avg per FCU)
alve safety timer | sec | Oxidizer bottle pressure: | 40 psia
oei
*GENERAL COMMENTS
>4Doe
19 Oct. 2021
~~~~

### Pagina 7

Cita: [pdf_6e9b1de8973a4d47bbfe, p. 7]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_6e9b1de8973a4d47bbfe/p0007.jpg)

~~~~text
ACME / Flame Design (inverse flame) - Science Test Sheet
est date: | CME test
Local time: | est of day
MT: | Flame of day #:
TEST CONDITIONS | Control? | fully automated 'manual'
Test type? ignition no-flamekstandard other
Chamber atmosphere | 2 bottle: | 85% (volume)
C2H4 conc. | % (vol, nominal) | Burner 02 conc.: | % (volume)
2H4 conc. | % (vol, per calc) | 02 flow rate: | slpm (N2 basis)
Chamber pressure: | psia (CIR avg per FCU | N2 flow rate: | slpm
ent before? no yes, to | psia
Iso just before? | fan GC scrub
FP? Kno o fixed moving back-n-forth
INSTRUMENTATION | ain: —4— Datacam | ops camera
<DataCam: filter? Qclear BG7 CH* CH20 | ROI? e full reduced | fps
< Intensified: filter? a clear RCH* CH20 ü none | ROI | full reduced
ßHiBMs:-backlight filter? c] no y yes | CIR backlight? Q no yes
FLAME BEHAVIOR
Flame Øhot cool maybe cool | Ignited? yes o no o yes, but ...*
Flame hole/opening o partially detached | SOOt@ignition none littledlots
Flame oscillating c] unsteady, quasi-stead | 00t@middle none o little lots
Out ext. detect | ime out temp. limit | Soot@end | c.] none o littl | lots
POST-TEST CONDITIONS
Fuel conc. | % (vol, per calc) | hamber pressure: | psia (CIR avg per FCU)
alve safety timer | sec | Oxidizer bottle pressure: | psia
*GENERAL COMMENTS
19 Oct. 2021
~~~~

### Pagina 8

Cita: [pdf_6e9b1de8973a4d47bbfe, p. 8]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_6e9b1de8973a4d47bbfe/p0008.jpg)

~~~~text
ACME / Flame Design (inverse flame) - Science Test Sheet
est date: | 15 2--e'2- | CME test | 21
Local time: | est of day #:
MT: | Flame of day #:
TEST CONDITIONS | ontrol? | fully automated 'manual'
Test type? D ignition no-flame | other
Chamber atmosphere | 02 bottle: | 85% (volume)
C2H4 conc. | A2.-7f20/o (vol, nominal) | Burner 02 conc.: | % (volume)
C2H4 conc. | % (vol, per calc) | 2 flow rate: | slpm (N2 basis)
Chamber pressure: | psia (CIR avg per FCU | N 2 flow rate: | slpm
ent before? no a yes, to | psia
Iso just before? gfan GC scrub
FP? 0±no fixed o moving back-n-forth
INSTRUMENTATION | ain: 24 DataCam 2 ops camera
d Datacam: filter? pclear BG7 | CH20 | ROI? Q full o reduced | fps
Intensified: filter? | CH* ü CH20 none | ROI?øfull o reduced | ups
e-HiBMs: backlight filter? noeyes | CIR backlight?q no yes fes-.?-a4Se30
FLAME BEHAVIOR
Flame Thot ü cool maybe cool | no o yes, but
.
Flame c] hole/opening partially detached | 00t@ignition o none little <lots
Flame o oscillating unsteady | 00t@middle o none ittl | lots
Out ext. detect time out D temp. limit | 00t@end | none little lots
POST-TEST CONDITIONS
Fuel conc. | % (vol, per calc) | Chamber pressure: 4, psia (CIR avg per FCU)
alve safety timer | sec | Oxidizer bottle pressure: | psia
Ze-I | z'C>i
*GENERAL COMMENTS
19 Oct. 2021
~~~~

### Pagina 9

Cita: [pdf_6e9b1de8973a4d47bbfe, p. 9]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_6e9b1de8973a4d47bbfe/p0009.jpg)

~~~~text
ACME / Flame Design (inverse flame) - Science Test Sheet
est date: | CME test
Local time: | est of day#:
GMT: | Flame of day #:
TEST CONDITIONS | Control? | •dfully automated 'manual'
Test type? o ignition o no-flame *standard other
Chamber atmosphere | 02 bottle: | 85% (volume)
C2H4 conc. | % (vol, nominal) | Burner 02 conc.: | % (volume)
C2H4 conc. | % (vol, per calc) | 02 flow rate: | i | slpm (N2 basis)
hamber pressure: | psia (CIR avg per FCU) | N2 flow rate:0Å15 20715 slpm
ent before? no yes, to | psia
Iso just before? | GC scrub
FP? Zno a fixed moving c] back-n-forth
INSTRUMENTATION | ain: 24¯DataCam | ops camera
ZDataCam: filter? {clear BG7 | CH20 | ROI? Q full o reduced | fps
plntensified: filter? | CH20 a none | ROI? pfull reduced | Bps
G-HiBMs: backlight filter? no q yes | CIR backlight? Kno yes
FLAME BEHAVIOR
Flame | ot c] cool maybe cool | Ignited? | es no yes, but .
Flame hole/opening o partially detached | 00t@ignition none little (lots
Flame oscillating o unsteady Ikquasi-stead | 00t@middle o none little lots
Out o ext. detect<time out temp. limit | 00t@end | none o littlek lots
POST-TEST CONDITIONS
Fuel conc. | % (vol, per calc) | hamber pressure: | psia (CIR avg per FCU
alve safety timer | d | sec | Oxidizer bottle pressure: | psia
(Zee)
*GENERAL COMMENTS
;/czy
19 Oct. 2021
~~~~

### Pagina 10

Cita: [pdf_6e9b1de8973a4d47bbfe, p. 10]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_6e9b1de8973a4d47bbfe/p0010.jpg)

~~~~text
ACME / Flame Design (inverse flame) - Science Test Sheet
est date: | CME test#: 21
Local time: | est of day#: ID
MT: | 34 | Flame of day #:
TEST CONDITIONS | Control? | (fully automated 'manual'
Test type? o ignition ü no-flameÆstandard o other
Chamber atmosphere | 02 bottle: | 85% (volume)
C2H4 conc. | % (vol, nominal) | Burner 02 conc.:æ | % (volume
C2H4 conc. | % (vol, per calc) | 02 flow rate: | O, i g | slpm (N2 basis)
Chamber pressure: ifDpsia (CIR avg per FCU) | N2 flow rate: | slpm
ent before? | o yes, to | psia
Iso just before? | fan GC scrub
FP? ano fixed c] moving back-n-forth
INSTRUMENTATION | ain: 2" | DataCam _Z_ ops camera
DataCam: filter? | a BG7 | CH20 | ROI? (full a reduced | fps
'C Intensified: filter? clear XCH* o CH20 none | ROI? Øfull o reduced
z„HiBMs: backlight filter? no,pyes | CIR | no yes fps-?-æ4s--e-30
FLAME BEHAVIOR
Flame Lhot o cool a maybe cool | Ignited? k yes no o yes, but
Flame hole/opening c] partially detached | 00t@ignition D none c] little (lots
Flame o oscillating unsteady quasi-stead | 00t@middle o none little Ots
Out o ext. detect time out a temp. limit | oot@end | none little c] lots
POST-TEST CONDITIONS
Fuel conc. | % (vol, per calc) | Chamber pressure: 5-1 psia (CIR | FCU
avg per
alve safety timer | DS | sec | Oxidizer bottle pressure: | psia
*GENERAL COMMENTS
19 Oct. 2021
~~~~

### Pagina 11

Cita: [pdf_6e9b1de8973a4d47bbfe, p. 11]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_6e9b1de8973a4d47bbfe/p0011.jpg)

~~~~text
ACME / Flame Design (inverse flame) - Science Test Sheet
est date: | CME test | 3
Local time: | est of day#: /
GMT: | Flame of day#: D
Rack Officer (RO): | 34 | PD (ACME):
DMO (CIR): | Researcher:
TEST CONDITIONS | Control? | < fully automated c] 'manual'
Test type? c] ignition no-flamepstandard other
Chamber atmosphere | 2 bottle: | 85% (volume)
C2H4 conc. | % (vol, nominal) | Burner 02 conc.: | % (volume
-
C2H4 conc. | % (vol, per calc) | 02 flow rate: | slpm (N2 basis)
hamber pressure: | psia (CIR avg per FCU) | N 2 flow rate: | Z+slpm
ent before? | o yes, to | psia
ISO just before? Zfan GC scrub
FP? Kno fixed moving back-n-forth
INSTRUMENTATION | ain: | -DataCam | ops camera
atacam: filter? eclear BG7 | CH20 | ROI? Afull o reduced | fps
(Intensified: filter? clear RCH* CH20 none | full reduced | ZEfps
z-HiBMs: backlight filter? no kyes | CIR backlight?A no yes fps?a-1ST-30
FLAME BEHAVIOR
Flame ±hot cool maybe cool | Ignited? | no yes, but ...*
Flame hole/opening partially detached | 00t@ignition D none ü little"..lots
Flame oscillating c] unsteadyAquasi-stead | 00t@middle none little lots
ut ext. detectøtime out temp. limit | SOOt@end | little o lots
POST-TEST CONDITIONS
Fuel conc. | % (vol, per calc) | hamber pressure: 53psia (CIR avg per FCU)
alve safety timer | 2— sec | Oxidizer bottle pressure: | psia
*GENERAL COMMENTS
Very 59
AJZ | 19 Oct. 2021
~~~~

### Pagina 12

Cita: [pdf_6e9b1de8973a4d47bbfe, p. 12]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_6e9b1de8973a4d47bbfe/p0012.jpg)

~~~~text
ACME / Flame Design (inverse flame) - Science Test Sheet
est date: | 15 202 | | CME test #:
Local time: | est of day#: I-Z-
GMT: | Flame of day#: | I
Rack Officer (RO): | PD (ACME):
DMO (CIR): | Researcher:
TEST CONDITIONS | Control? | åfully automated 'manual'
Test type? ignition no-flame ustandard other
Chamber atmosphere | 02 bottle: | 85% (volume)
2H4 conc. | % (vol, nominal) | Burner 02 conc.: | % (volume
2H4 conc. | % (vol, per calc) | 02 flow rate: | slpm (N2 basis
Chamber pressure: I "psia (CIR avg per FCU) | N 2 flow rate: | slpm
ent before? eno yes, to | psia
Iso just before? | fan GC scrub
FP? no fixed moving a back-n-forth
INSTRUMENTATION | ain: | DataCam Z) ops camera
€DataCam: filter? (clear BG7 | CH20 | full reduced | fps
filter? clear | CH20 none | ROI? R full reduced | 22fps
g-HiBMs: backlight filter? no g:yes | CIR backlight? | yes fps-?-tH-5-tT30
FLAME BEHAVIOR
Flame | o cool maybe cool | Ignited? | no yes, but *
...
Flame o hole/opening partially detached | SOOt@ignition c] none c] little lots
Flame o oscillating unsteady | uasi-stead | 00t@middle c] none a little lots
Out o ext. detect V.time out temp. limit | oot@end | none o little(lots
POST-TEST CONDITIONS
Fuel conc. | % (vol, per calc) | hamber pressure: | psia (CIR avg per FCU)
alve safety timer | Oxidizer bottle pressure: | psia
*GENERAL COMMENTS
ere
19 Oct. 2021
~~~~

### Pagina 13

Cita: [pdf_6e9b1de8973a4d47bbfe, p. 13]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_6e9b1de8973a4d47bbfe/p0013.jpg)

~~~~text
ACME / Flame Design (inverse flame) - Science Test Sheet
est date: | CME test#:
Local time: | 5742- | est of day #:
MT: | Flame of day#: Z
TEST CONDITIONS | Control? | fully automated o 'manual'
Test type? c] ignition o no-flamekstandard other
Chamber atmosphere | 02 bottle: | 85% (volume)
C2H4 conc. | % (vol, nominal) | Burner 02 conc.. | % (volume)
C2H4 conc. | % (vol, per calc) | 02 flow rate: | slpm (N2 basis)
hamber pressure: | psia (CIR avg per FCU) | N2 flow rate: | O, | slpm
ent before? Kno yes, to | psia
Iso just before? | fan GC scrub
FP?Z no o fixed moving back-n-forth
INSTRUMENTATION | ain: / | DataCam | ops camera
Datacam: filter? Aclear a BG7 | CH20 | ROI? efull c] reduced | fps
AJntensified: filter? o clear LCH* CH20 none | ROI? full reduced | Z fps
LLHiBM%backlight filter? no *yes | CIR backlight? E-no yes $-ps?-a-as.a 30
FLAME BEHAVIOR
Flame SZhot cool a maybe cool | Ignited? å-yes no yes, but ...*
Flame hole/opening o partially detached | SOOt@ignition c.i none little lots
Flame oscillating o unsteady squasi-stead | Soot@middle none little lots
Out c] ext. detect time out temp. limit | 00t@end | c none little lots
POST-TEST CONDITIONS
iol
*GENERAL COMMENTS
cÅrorezck
19 Oct. 2021
~~~~

### Pagina 14

Cita: [pdf_6e9b1de8973a4d47bbfe, p. 14]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_6e9b1de8973a4d47bbfe/p0014.jpg)

~~~~text
ACME / Flame Design (inverse flame) - Science Test Sheet
est date: | 202-1 | CME test#:
Local time: | 5757 | est of day #:
GMT: | Zi | zz=5 | Flame of day #: (3
TEST CONDITIONS | Control? | •fully automated 'manual'
Test type? ignition o no-flame Xstandard other
Chamber atmosphere | 02 bottle: | 85% (volume)
C2H4 conc. | % (vol, nominal) | Burner 02 conc.: | Z— % (volume)
C2H4 conc. | % (vol, per calc) | 02 flow rate: | 2-2-7 | slpm (N2 basis)
Chamber pressure: | psia (CIR avg per FCU) | N2 flow rate: | 037 | slpm
ent before? g-no yes, to | psia
ISO just before? kfan GC scrub
fixed moving back-n-forth
INSTRUMENTATION | ain: 20 DataCam 2_ ops camera
Datacam: filter? | BG7 | CH20 | ROI? Rfull reduced | fps
Intensified: filter? o cleawCH* CH20 none | ROI? V full o reduced | fps
crHiBMs: backlight filter? no yes | CIR backlight?p no yes fps?--t-1-5-a-3C
FLAME BEHAVIOR
Flame | o cool maybe cool | Ignited? Z yes no yes, but *
...
Flame hole/opening partially detached | 00t@ignition none little {Vlots
Flame Cl oscillating unsteady quasi-stead | 00t@middle o none little lots
Out ext. detect o time out temp. limit | oot@end | c] none little lots
POST-TEST CONDITIONS
Fuel conc. | % (vol, per calc) | Chamber pressure: | psia (CIR avg per FCU)
alve safety timer | sec | Oxidizer bottle pressure: Z | psia
*GENERAL COMMENTS
all
19 Oct. 2021
~~~~

### Pagina 15

Cita: [pdf_6e9b1de8973a4d47bbfe, p. 15]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_6e9b1de8973a4d47bbfe/p0015.jpg)

~~~~text
ACME / Flame Design (inverse flame) - Science Test Sheet
est date: | 15 Zoa | CME test #: Z? 34
Local time: | est of day #:
GMT: | Flame of day #:
TEST CONDITIONS | Control? | fully automated c] 'manual'
Test type? ignition o no-flame Astandard other
Chamber atmosphere | 02 bottle: | 85% (volume)
C2H4 conc. | % (vol, nominal) | Burner 02 conc.: | % (volume)
C2H4 conc. | % (vol, per calc) | 02 flow rate: | slpm (N2 basis)
Chamber pressure: | psia (CIR avg per FCU) | N2 flow | slpm
ent before? Ano yes, to | psia
Iso just before? | fan o GC scrub
FP?Åno ü fixed moving back-n-forth
INSTRUMENTATION | ain: —ZI--— DataCam | ops camera
(Datacam: | BG7 | CH20 | ROI? Qfull reduced | fps
g-lntensified: filter? o clear [RCH* CH20 none | reduced | Qfps
z-H-iBMsr backlight filter? no Oes | CIR backlight?y no yes
FLAME BEHAVIOR
Flame hot cool maybe cool | Ignited? yes no yes, but *
...
Flame D hole/opening partially detached | 00t@ignition o none o little R'lots
Flame oscillating unsteady kquasi-stead | SOOt@middle none little lots
Out o ext. detect time | limit | Soot@end | e "little lots
—he-II
POST-TEST CONDITIONS
Fuel conc. | % (vol, per calc) | Chamber pressure: | psia (CIR avg per FCU)
alve safety timer | sec | Oxidizer bottle pressure: Z) | psia
*GENERAL COMMENTS
19 Oct. 2021
~~~~

### Pagina 16

Cita: [pdf_6e9b1de8973a4d47bbfe, p. 16]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_6e9b1de8973a4d47bbfe/p0016.jpg)

~~~~text
ACME / Flame Design (inverse flame) - Science Test Sheet
est date: | 15 | CME test #: 2) 3
Local time: | est of day#:
MT: | Flame of day #:
TEST CONDITIONS | Control? | fully automated 'manual'
Test type? ignition | other
Chamber atmosphere | 02 bottle: | 85% (volume)
C2H4 conc. | % (vol, nominal) | Burner 02 conc.:o | >-c2 % (volume)
-
2H4 conc. | % (vol, per calc) | 02 flow rate: | Zi | slpm (N2 basis)
hamber pressure: •7.8épsia (CIR avg per FCU | N 2 flow rate: 0.3? > Ö-+eslpm
ent before? h-no yes, to | psia
Iso just before? Q fan GC scrub
FP?b6 no o fixed o moving back-n-forth
INSTRUMENTATION | ain: 2-7 DataCam | ops camera
OataCam: filter? Kclear o BG7 CH* CH20 | full c] reduced | fps
4 Intensified: filter? o clear | CH20 none | ROI? Afull c] reduced | 22 fps
g-Hi-BMs: backlight filter? no€yes | CIR backlight? A-no yes fps?-z-15z30
FLAME BEHAVIOR
Flameuhot cool maybe cool | Ignited? Lyes o no yes, but ..
Flame hole/opening partially detached | 00t@ignition none littleklots
7
Flame o oscillating unsteadyuquasi-stead | 00t@middle none little lots
Out ext. detect | ime out o temp. limit | 00t@end | o none X little D lots
POST-TEST CONDITIONS
Fuel conc. | % (vol, per calc) | Chamber pressure: | psia (CIR avg per FCU)
alve safety timer | sec | Oxidizer bottle pressure: | psia
*GENERAL COMMENTS | t
701
48
19 Oct. 2021
~~~~
