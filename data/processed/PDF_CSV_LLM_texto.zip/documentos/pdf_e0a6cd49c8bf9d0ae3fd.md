# CoolFlameImage

- Identificador: pdf_e0a6cd49c8bf9d0ae3fd
- Investigaciones: PSI-39
- Tipo de documento: Raw Data
- Estado: processed
- Temas detectados automaticamente: 

## Fuentes

- [PSI-39_Raw Data_CoolFlameImage.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-39/Raw%20Data/PSI-39_Raw%20Data_CoolFlameImage.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_e0a6cd49c8bf9d0ae3fd, p. 1]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_e0a6cd49c8bf9d0ae3fd/p0001.jpg)

~~~~text
65 60 55 50 45 40 35 30 25 20 15 10 5 0
mm
0
5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90
mm

[Complemento OCR de elementos visuales]
mm
10 | 15 | 20 | 25 | 30 | 35 | 45 | 55 | 60 | 65 | 70 | 75 | 85 | 90
~~~~
