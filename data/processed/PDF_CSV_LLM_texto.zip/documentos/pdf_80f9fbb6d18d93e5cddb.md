# 21162 daily test point log

- Identificador: pdf_80f9fbb6d18d93e5cddb
- Investigaciones: PSI-159
- Tipo de documento: Raw Data
- Estado: processed
- Temas detectados automaticamente: hardware

## Fuentes

- [PSI-159_Raw Data_21162 daily test point log.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-159/Raw%20Data/PSI-159_Raw%20Data_21162%20daily%20test%20point%20log.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_80f9fbb6d18d93e5cddb, p. 1]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_80f9fbb6d18d93e5cddb/p0001.jpg)

~~~~text
ACME Daily Test Point Log | 6/11/2021
Downlink Data Limit (MB) = 127,000 | Total = | 116,247
Test Point Name Script Aborts | IPSU1/HiBMS | ACME Camera | Intensified Camera
Downlink
(enter all test | Before IPSUs | Archived | Archived | Archived
Data (MB)
points) | Open | Images | Images | Images
21162A1 | 681 | 2086 | 7,950
21162A2 | 929 | 2642 | 10,255
21162A3 | 2571 | 6455 | 25,895
21162B1 | 1011 | 4790 | 2,822
21162A4 | 3329 | 8176 | 33,002
21162C1 | 431 | 1485 | 5,509
21162C2 | 348 | 1228 | 4,532
211620 | 341 | 1296 | 4,710
21162C4 | 340 | 1273 | 4,641
21162C5 | 328 | 1182 | 4,343
21162D1 | 311 | 1761 | 868
21162F1 | 435 | 1514 | 5,605
21162F2 | 495 | 1632 | 6,114
Date:
~~~~
