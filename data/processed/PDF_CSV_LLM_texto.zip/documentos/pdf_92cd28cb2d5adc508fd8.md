# E-FIELD_Flames_benefits_20200518

- Identificador: pdf_92cd28cb2d5adc508fd8
- Investigaciones: PSI-22
- Tipo de documento: Science Documents
- Estado: processed
- Temas detectados automaticamente: microgravity, electric_fields

## Fuentes

- [PSI-22_Science Documents_E-FIELD_Flames_benefits_20200518.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-22/Science%20Documents/PSI-22_Science%20Documents_E-FIELD_Flames_benefits_20200518.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Pasajes de orientacion (extractivos, no resumen validado)

### objective - pagina 1

objectives identified, the delivery of a unique data set of chemi￾ion behavior in flames under sufficiently stable and symmetric conditions that models and theories can 
be evaluated against the results. As an example, the very distinctive shape of the V-I curve in microgravity, 
when matched in models, will give a very good indication that the feedback between ion driven wind and 
changes in flame shape and burning behavior that then further change the ion current is captured 
accurately.
These results have already garnered the interest of other groups working on electric field effects on 
flames. 
The use of electric field effects on flames can be as sensor (variations of ion current as associated with 
combustion behavior) or actuator (ion-driven wind changes the flame shape and characteristics). This 
work, as was originally planned, provides quantitative evaluation of the sensing and response potential of 
electric fields in combustion. The applications can include the control of flames.
Patents
Thus far, no patents have resulted from the E-FIELD Flames research.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_92cd28cb2d5adc508fd8, p. 1]. Metodo: native.

~~~~text
18 May 2020
Advanced Combustion via Microgravity Experiments (ACME)
Electric-Field Effects on Laminar Diffusion Flames (E-FIELD Flames)
ACME/E-FIELD Flames - Impacts, Benefits, and Products
Prepared by Dennis Stocker, ACME Project Scientist, dennis.p.stocker@nasa.gov, 216-433-2166
Impacts, Benefits, and Products
This text is the ‘Impacts, Benefits, and Products’ section from the 2019 version of the final report.
The impact of this work is, as the original objectives identified, the delivery of a unique data set of chemi￾ion behavior in flames under sufficiently stable and symmetric conditions that models and theories can 
be evaluated against the results. As an example, the very distinctive shape of the V-I curve in microgravity, 
when matched in models, will give a very good indication that the feedback between ion driven wind and 
changes in flame shape and burning behavior that then further change the ion current is captured 
accurately.
These results have already garnered the interest of other groups working on electric field effects on 
flames. 
The use of electric field effects on flames can be as sensor (variations of ion current as associated with 
combustion behavior) or actuator (ion-driven wind changes the flame shape and characteristics). This 
work, as was originally planned, provides quantitative evaluation of the sensing and response potential of 
electric fields in combustion. The applications can include the control of flames.
Patents
Thus far, no patents have resulted from the E-FIELD Flames research.
~~~~
