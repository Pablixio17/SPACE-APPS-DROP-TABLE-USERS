# 21137 flow traces etc

- Identificador: pdf_eeec420ae845e1bb4027
- Investigaciones: PSI-159
- Tipo de documento: Raw Data
- Estado: processed
- Temas detectados automaticamente: oxygen, pressure, ignition, hardware, cool_flames, extinction

## Fuentes

- [PSI-159_Raw Data_21137 flow traces etc.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-159/Raw%20Data/PSI-159_Raw%20Data_21137%20flow%20traces%20etc.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_eeec420ae845e1bb4027, p. 1]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_eeec420ae845e1bb4027/p0001.jpg)

~~~~text
CFI-G Round 1, day 7, with 30% propane (C3H8)
Chamber filled to 1 atm with ~40% O2 (balance N2)
Extinction detection effectively turned off so tests were ended ‘manually’
Test 21137A1 (test 1 of 12, hot flame 1 of 12) – sustained ignition, run with 
igniterPreheatDurationMs=1000, fuelIgnitionFlowSlpm=0.499, 
nitrogenIgnitionFlowSlpm=0, fuelTestFlow1Slpm=0.499, 
nitrogenTestFlow1Slpm=0
1

[Texto OCR de la imagen]
CFI-G Round 1, day 7, with 30% | (C3H8)
propane
Chamber filled to 1 atm with 'v40% 02 (balance N2)
Extinction detection effectively turned off so tests were ended 'manually'
Test 21137A1 (test 1 of 12, hot flame 1 of 12) — sustained ignition, run with
igniterPreheatDurationMs=1000, fuellgnitionFIowSlpm=O.499,
nitrogenlgnitionFIowSIpm- -O, fuelTestFlow1Slpm=O.499,
nitrogenTestFIow1SIpm=O
Gas Flow Charts | x
Graphs
2021-05-17 | GMT
State | Operate | c | SLPM | R | -0.006 | SLPM | FIN Scale | 20.000
Static Mixer Line (MFCAI)
0.010
13:35 | 13:36 | 13:37 | 13:38 | 13:39
17 non | 2021 | Time (s)
State | Operate | c | 0.000 | SLPM | R | -0.003 | SLPM | Ful scale | 2.000
Bypass(MFCA2)
-OSe-3
-I.oe-3
-ISe-3
2.0+3
-2.5e-3
-3.oe-3
-3se-3
-4.oe-3
13:35 | 13:36 | 13:37 | 13:38 | 13:39
17 non may 2021 | Tine (s)
State | Operate | c | 0.000 | SLPM | R | 0.002 | SLPM | scale | 0.500
Fuel(MFCA3)
0.4
13:35 | 13:36 | 13:37 | 13:38 | 13:39
17 non may 2021 | Time (s)
1
~~~~

### Pagina 2

Cita: [pdf_eeec420ae845e1bb4027, p. 2]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_eeec420ae845e1bb4027/p0002.jpg)

~~~~text
Test 21137A1, continued
• VLC media player | Diagnostic Cool Flame Sensors | x
system state | 2021425-17
pMTS | System Ternperaües
5.000 | 33.000
pov.
set All
cpu Board | 35.000
PMT 1 | 0.000 | -0.001 | 0.000
CLbe Sensor 1 | 34.231
PMT 2 | 0.000 | 0.000 | 34,220
CLbe Sensor 2
PMT 3 | 0.000 | -0.000 | 0.000 | 25
Hard
W/an 2
-0.003074 | -0.125 | TC200A (TCI) | 23.%3572 | 0.029
-10 mm Lo Gan
-0.000936 | •O. 565 | TC200B (TC2) | 22.193200 | -O • 023 | mV
-10 mm Hi Gain
-o. 000810 | 0.013 | TCCJ | 22.782211 | 0.873
+30 nm Lo Gain
+30 | -0.000029 | 0.138 | Array
mm
Rake: Far
+60 rrrn Lo Gain | -0.000794 | 0.028
36.498880 | 0.557
+60 rnm H Gü | 0.000214 | 0.314
"v aid40w | -0.001
60 Deg Offset | 0.000208 | 1.399
maid-low | 0.005
38.970662 | 0.658
Cold inctjon
60 Deg Offset | 24.565383 | 1.579
Burner: | (1/4)
Burner | 126.202979 | 4.263 | mV
Comecåm
Series Chart
Packet | Soffvar e themonic
Teleme ACME DIAG | Tl | 0.00
ACME Teleme ACYE | 0.00
ACME | 0.00
2.5
Select Items | End plotting
Clear Selections
Graph Properties
13:36:45 | 13:37:15 | 13:37:30
17 May 2021 13.•37A9.ooo | 17 Hon May 2021 | Time
Start Tune
2
~~~~

### Pagina 3

Cita: [pdf_eeec420ae845e1bb4027, p. 3]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Test 21137A1, continued
After test: 947 on lowest valve safety timer, 188 psia in oxidizer bottle, 125 psia 
in fuel bottle
3
~~~~

### Pagina 4

Cita: [pdf_eeec420ae845e1bb4027, p. 4]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_eeec420ae845e1bb4027/p0004.jpg)

~~~~text
Test 21137A2 (test 2 of 12, hot flame 2 of 12) – sustained ignition, run with 
igniterPreheatDurationMs=1000, fuelFlowIgnitionDeltaMs=0,
fuelIgnitionFlowSlpm=0.259, nitrogenIgnitionFlowSlpm=0,
fuelTestFlow1Slpm=0.259, nitrogenTestFlow1Slpm=0
4

[Texto OCR de la imagen]
Test 21137A2 (test 2 of 12, hot flame 2 of 12) — sustained ignition, run with
igniterPreheatDurationMs=1000, fuelFIowIgnitionDeItaMs=O,
fuellgnitionFlowSlpm=O.259, nitrogenlgnitionFlowSlpm=O,
fuelTestFlow1Slpm=O.259, nitrogenTestFIow1SIpm=O
Gas Flow Charts
Graphs
state | 2021-05-17
State | Operate | c | 0•000 | SLPM | R | -0.005 | SLPM | FL-A Scale | 20.000
Static Mixer Line (MFCAI)
ACME FLOW MI MIXER SETPOINT | ACME FLOW MI MIXER FLOW
-0.010
-0.015
13:54 | 13:55 | 13:56 | 13:57 | 13:58 | 13:59
17 Mon May 2021 | Time (s)
State | Ocxate | c | 0.000 | SLPM | -0.002 | SLPM | scale | 2.000 | SLPM
Bypass(MFCA2)
ACME FLOW | BYPASS SETPOINT | ACME FLOW | BYPASS FLOW
le-3
-le-3
-Ze-3
-3e-3
-se-3
13:54 | 13:55 | 13:56 | 13:57 | 13:58 | 13:59
17 Mon May 2021 | Time (s)
State | Operate | c | 0.000 | SLPM | R | 0.001 | SLPM | scale | 0.500 | SLPM
Fuel(MFCA3)
ACME FLOW "3 FUEL SETPOINT | ACME FLOW r-•13 FUEL FLOW
0.15
0.10
13:54 | 13:55 | 13:56 | 13:57 | 13:58 | 13:59
17 Mon May 2021 | Time (s)
4
~~~~

### Pagina 5

Cita: [pdf_eeec420ae845e1bb4027, p. 5]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_eeec420ae845e1bb4027/p0005.jpg)

~~~~text
Test 21137A2, continued
- VLC media player | Diagnostic Cool Flame Sensors | x
system state | 2021-05-17
PMTs | System Temgzatures
5.000 | 33.100
Power
Set Al Gans
Wlcrn2 | v | cpu | 35, 000
0.000 | 0.000
Cube Sensor 1 | 34.234
PMT 2 | 0.000 | -0.000 | Gan | 0.000 | set | 34.259
Cube Sensor 2
3 | 0.000 | -0.000 | Gan | 0.000 | Set | 25
Drive
Radorneters
w,'cmz | Volts
-0.003056 | -0.124 | TC200A CTCI) | 23.979471 | 0.049 | mV
-10 nm-n Lo
-0.000951 | TC200B (TC2) | 22019383 | -0.03) | mV
-IO mrn H Gah
-0.000778 | 0.015 | 22.782211 | 0.873
+30 nn LO Gah
+30 | H Gan | -o. 000003 | 0.158
nun
Rake: Far
+60 rrn LO Gah | -0.000794 | 0.028
40.265560 | 0.711 | mV
+60 nn Hi Gain | 0.000200 | 0.305
hvaEd-bw | 0.004 | mV
60 Deg Of€et | 0.000185 | 1.386
maid-low | 0.000 | mV
45.990089 | 0.946 | mV
Radometer Cold indon
60 Deg Ofret | 24.650913 | 1.578
CJ | Burner: Sphe•ea/ (l/"
Burner | 199.233940 | 7.198
Cube
Tlme Series Chart
packet | Software Mnernoric
ACME Teleme | 0.00
ACME Telerne ACME DIAG PMT T2 | 0.00
ACME Teleme ACFIE DIAG | T3 | 0.00
Select Items | End Plotting
Clear Selections | Restart
Graph Properties
13:58:00 | 13:58:15
17 May 2021 | 17 Mon May 2021 | Time
Start Tme
5
~~~~

### Pagina 6

Cita: [pdf_eeec420ae845e1bb4027, p. 6]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Test 21137A2, continued
After test: 876 on lowest valve safety timer, 188 psia in oxidizer bottle, 122 psia 
in fuel bottle
6
~~~~

### Pagina 7

Cita: [pdf_eeec420ae845e1bb4027, p. 7]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_eeec420ae845e1bb4027/p0007.jpg)

~~~~text
Test 21137A3 (test 3 of 12, hot flame 3 of 12) – sustained ignition, run with 
igniterPreheatDurationMs=1000, flowTimeoutSec=330,
fuelFlowIgnitionDeltaMs=0, fuelIgnitionFlowSlpm=0.173, 
nitrogenIgnitionFlowSlpm=0, fuelTestFlow1Slpm=0.173, 
nitrogenTestFlow1Slpm=0, constantFlowTime1Sec=300
7

[Texto OCR de la imagen]
Test 21137A3 (test 3 of 12, hot flame 3 of 12) — sustained ignition, run with
igniterPreheatDurationMs=1000, flowTimeoutSec=330,
fuelFlowIgnitionDeltaMs=O, fuellgnitionFIowSIpm=O.173,
nitrogenlgnitionFlowSlpm=O, fuelTestFlow1Slpm=O.173,
nitrogenTestFlow1Slpm=O, constantFlowTime1Sec=300
Gas Flow Charts
Graphs
2021-05-17 14•.12.'33 | GMT
State | Operate | c | 0.000 | SLPM | -0.002 | SLPM | Fun Scale | 20.000
Static Mixer Line (MFCAI)
ACME FLOW
0.010
14:08 | 14:09 | 14:10 | 14:11 | 14:12
17 Mon May 2021 | Tine (s)
State | Operate | c | 0.000 | SLPM | R | 0.000 | scale | 2.000 | SLPM
Bypass(MFCA2)
Ze-3
le-3
-Ie-3
-Ze-3
-3e-3
14:08 | 14:09 | 14:10 | 14:11 | 14:12
17 non may 2021 | Tine (s)
State | Operate | c | 0.000 | SLPM | R | -0.001 | SLPT•-I | scale | 0.500 | SLPM
Fuel(MFCA3)
ACME FLOW "3 FUEL SETPOINT
0.15
0.10
14:08 | 14:09 | 14:10 | 14:11 | 14:12
17 Mon May 2021 | Tüne (s)
7
~~~~

### Pagina 8

Cita: [pdf_eeec420ae845e1bb4027, p. 8]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_eeec420ae845e1bb4027/p0008.jpg)

~~~~text
Test 21137A3, continued
udpW:7300 - VLC media player | Diagnostic Ccol Flame Sensors | x
2021-05-17 14: 10:50 | GMT
PMTs | Syste•n Temperatures
5.000 | CPU | 33.000
Power
Set AI Gans
Board | 35.000
-58.000 | -0.000 | 5.500
CL-& Sensor 1 | 34.272
0.000 | 0.002 | Gain | 6.750 | 34.269
Sensor 2
0.000 | -0.000 | Gain | 5.500 | 25
Hard Drive
W /crn2
-0.002862 | 0113 | TC200A (TCI) | 24.871526 | 0.085
-10 run Lo Gah
-0.000911 | -0.547 | 22292512 | -0.019
-10 rrrn H Gain
-0.000462 | 0.035 | 22.782211 | 0.873
+30 mm Lo Gain
+30 | Hi | 0.000292 | 0.386
rrg-n
Rake: Far
+60 mm LO Gain | -0.000435 | 0.049
50.406210 | 1.128
+60 rm Gan | 0.000560 | 0.542
hvabd-low | 0.017
60 Deg 0%et | 0.000386 | 1.498
hvabd-lcwv | 0.002
TCD | 51.399186 | 1.169
Radorneter Cold Jl-nction
60 Deg Offret | 24.736427 | 1.577
Butner Sphere-a/
Burner | 286.405048 | 10.735
a-be Comecfion
Tame Senes Chan #1
So ftw are Phernonic
ACME Telerne | 0.00
ACtæ Telerne ACME DIAG | T2 | 0.00
ACME | ACME DIAG | T3 | 0.00
2.0
Select Items | End Plotüng
Clear Selections | Restart
Graph Properties
17May | 2021
start Trne
8
~~~~

### Pagina 9

Cita: [pdf_eeec420ae845e1bb4027, p. 9]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Test 21137A3, continued
After test: 718 on lowest valve safety timer, 187 psia in oxidizer bottle, 118 psia 
in fuel bottle
9
~~~~

### Pagina 10

Cita: [pdf_eeec420ae845e1bb4027, p. 10]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_eeec420ae845e1bb4027/p0010.jpg)

~~~~text
Test 21137B1 (test 4 of 12, hot flame 4 of 12) – sustained ignition, run with 
igniterPreheatDurationMs=1000, flowTimeoutSec=150,
fuelFlowIgnitionDeltaMs=0, fuelIgnitionFlowSlpm=0.499, 
nitrogenIgnitionFlowSlpm=0.320, fuelTestFlow1Slpm=0.499, 
nitrogenTestFlow1Slpm=0.320, constantFlowTime1Sec=120
10

[Texto OCR de la imagen]
Test 21137B1 (test 4 of 12, hot flame 4 of 12) — sustained ignition, run with
igniterPreheatDurationMs=1000, flowTimeoutSec=150,
fuelFlowIgnitionDeltaMs=O, fuellgnitionFIowSIpm=O.499,
nitrogenlgnitionFIowSIpm=O.320, fuelTestFIow1SIpm=O.499,
nitrogenTestFIow1SIpm=O.320, constantFlowTime1Sec=120
Gas Flow Charts | o | X
Graphs
2021-05-17 | GMT
State | Operate | c | 0.000 | SLPM | 0.000 | SLPM | Fu" scale | 20.000
Static Mixer Line (MFCAI)
ACME FLOW MI MIXER SETPOINT | ACME FLOW MI MIXER FLOW
-0.010
14:26 | 14:27 | 14:28 | 14:29 | 14:30
may 2021 | Time (s)
State | Operate | c | 0.000 | SLPM | R | -0.001 | SLPM | scale | 2.000 | SLPM
Bypass(MFCA2)
0.4
14:26 | 14:27 | 14:28 | 14:29 | 14:30
may 2021 | Time (s)
State | Operate | c | 0.000 | R | 0.000 | scale | 0.500 | SLPM
Fuel(MFCA3)
0.2
0.1
14:26 | 14:27 | 14:28 | 14:29 | 14:30
17 Mon May 2021 | Time (s)
10
~~~~

### Pagina 11

Cita: [pdf_eeec420ae845e1bb4027, p. 11]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_eeec420ae845e1bb4027/p0011.jpg)

~~~~text
Test 21137B1, continued
VLC media player | Diagnostic Cool Flame Sensors | x
2021-05-17 14:30: 10 | GMT
PMTS | System Terroeratures
5.000 | set | 32.700
Power
Set AI Gans
Wlan2 | CPU Board | 35.0m
0.000 | -0.000 | 0.000 | Set
Gan | Cube | 34.455
Sensor 1
0.000 | 0.000 | 0.000 | Set | 34486
Cube Sensor 2
0.000 | -0.001 | 0.000 | set
Drive
Radiorreters
W/crn 2
-0.002756 | -0.107 | TC200A (TCI) | 33.449388 | 0.419
-10 nn Lo Gain
-0.000912 | -o. 548 | TC200B CTC2) | 22.732086 | -0.015 | mV
-10 nn H Gah
-0.000081 | 0.059 | 23.121190 | 0.874
+30 mm Lo Gah
+30 | H Gan | 0.000635 | 0.651 | Array
nn
Rake:
+60 | LO Gah | 0.000300 | 0.092
97.913195 | 3.087
+60 nn Hi Gdn | 0.001286 | 1.021
invalid-low | 0.150
60 Deg Ofret | 0.000775 | 1.714
*wdid40w | 0.085
76.439144 | z 195
Radometer Cold inction
60 Deg Offset | 25.249453 | 1.571
Burner. Sphe•ea/
Burner | 172.035405 | 6.097
CLbe Connection
Time Series Chart
packet | So Raare Mnernonic | Low
ACME Telerr,e | 0.00
ACME Telerr,e | 0.00
ACME Teleme ACME DIAG PMT T3 | 0.00
2.5
Select Items | End Plotting
Clear Selections
Graph properties
17 May 2021 1+30:10.OOO | 17 Mon May 2021 | Tine
Start Tme
11
~~~~

### Pagina 12

Cita: [pdf_eeec420ae845e1bb4027, p. 12]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Test 21137B1, continued
After test: 579 on lowest valve safety timer, 188 psia in oxidizer bottle, 107 psia 
in fuel bottle
12
~~~~

### Pagina 13

Cita: [pdf_eeec420ae845e1bb4027, p. 13]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_eeec420ae845e1bb4027/p0013.jpg)

~~~~text
Test 21137B2 (test 5 of 12, hot flame 5 of 12) – sustained ignition, run with 
igniterPreheatDurationMs=1000, pmt2Gain=6, flowTimeoutSec=330, 
fuelFlowIgnitionDeltaMs=0, fuelIgnitionFlowSlpm=0.259, 
nitrogenIgnitionFlowSlpm=0.457, fuelTestFlow1Slpm=0.259, 
nitrogenTestFlow1Slpm=0.457, constantFlowTime1Sec=300
13

[Texto OCR de la imagen]
Test 21137B2 (test 5 of 12, hot flame 5 of 12) — sustained ignition, run with
igniterPreheatDurationMs=1000, pmt2Gain=6, flowTimeoutSec=330,
fuelFlowIgnitionDeltaMs=O, fuellgnitionFIowSIpm=O.259,
nitrogenlgnitionFIowSlpm=O.457, fuelTestFIow1SIpm=O.259,
nitrogenTestFIow1SIpm=O.457, constantFlowTime1Sec=300
Gas Flow Charts
Graphs
state | 2021-05-17
system
State | Operate | c | 0.000 | SLPM | R | -0.002 | SLPM | Fun Scale | 20.000
Static Mixer Line (MFCAI)
ACME FLOW MI MIXER SETPOINT | ACME FLOW MI MIXER FLOW
8e-3
6e-3
4e-3
Ze-3
-Ze-3
-6e-3
14:46 | 14:47 | 14:48 | 14:49 | 14:50
17 mon may 2021 | Tine (s)
State | Operate | c | 0.000 | SLPM | -0.000 | SLPM | scale | 2.000 | SLPM
Bypass(MFCA2)
0.2
14:46 | 14:47 | 14:48 | 14:49 | 14:50
17 Mon Hay 2021 | Tine (s)
State | Operate | c | 0.000 | R | 0.000 | scale | 0.500
Fuel(MFCA3)
14:46 | 14:47 | 14:48 | 14:49 | 14:50
17 Mon May 2021 | Tine (s)
13
~~~~

### Pagina 14

Cita: [pdf_eeec420ae845e1bb4027, p. 14]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_eeec420ae845e1bb4027/p0014.jpg)

~~~~text
Test 21137B2, continued
VLC media player | Diagnostic Cool Flame Sensors | x
2021-05-17
pMTS | Systern Temperatres
5,000 | 32.800
Power
Set Al Gans
W /crn2 | cpu | 35.000
0.000 | -0.001 | 0.000
Cube Sensor 1
0.000 | -0.000 | 0.000 | 34.579
Cube Sensor 2
0.000 | -0.000 | Gan | 0.000 | 25
Hard Drive
w,'crnz
-0.003074 | -0.125 | TC200A CTCI) | 30.620063 | 0.304
-10 | Lo Gah
-0.000915 | -0.550 | TC200B (TC2) | 22.533531 | -0.023
-10 n-rn H Gan
-0.000683 | 0.021 | TCCJ | 23.121190 | 0.874
+30 rnm LO Gan
+30 | Hi | 0.000081 | 0.223 | Array
Rake: Far
+60 mm LO Gah | -0.000554 | 0.042
74.637272 | 2.120
+60 mm Gdn
nvabd-low | 0.069
60 Deg Offet | 0.000374 | 1.491
hvabd-low | 0.033
TCD | 59.267090 | 1.481
Radon-veter Cold Junction
Volts
60 Deg Offret | 25.078467 | 1,573
Burner | 153.554293 | 5.356
be Comecim
Time Series Chart—I
So ftv•e Mnemonic
ACME Teleme | 0.00
ACME Teleme | 0.00
ACME | ACME DIAG PMT T3 | 0.00
1.0
Select Items | End PIO tting
Clear Selections
Graph Properties
14:48:45 | 14:49:00 | 14:49:15 | 14:49:30
17 May 2021 1450:OO.OOO | 17 mon may 2021 | Tune
start Time
14
~~~~

### Pagina 15

Cita: [pdf_eeec420ae845e1bb4027, p. 15]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Test 21137B2, continued
After test: 418 on lowest valve safety timer, 188 psia in oxidizer bottle, 101 psia 
in fuel bottle
15
~~~~

### Pagina 16

Cita: [pdf_eeec420ae845e1bb4027, p. 16]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_eeec420ae845e1bb4027/p0016.jpg)

~~~~text
Test 21137A4 (test 6 of 12, hot flame 6 of 12) – sustained ignition, run with 
igniterPreheatDurationMs=1000, pmt2Gain=6, flowTimeoutSec=330,
fuelFlowIgnitionDeltaMs=0, fuelIgnitionFlowSlpm=0.216, 
nitrogenIgnitionFlowSlpm=0, fuelTestFlow1Slpm=0.216, 
nitrogenTestFlow1Slpm=0, constantFlowTime1Sec=300
16

[Texto OCR de la imagen]
Test 21137A4 (test 6 of 12, hot flame 6 of 12) — sustained ignition, run with
igniterPreheatDurationMs=1000, pmt2Gain=6, flowTimeoutSec=330,
fuelFlowIgnitionDeltaMs=O, fuellgnitionFIowSIpm=O.216,
nitrogenlgnitionFIowSIpm=O, fuelTestFIow1SIpm=O.216,
nitrogenTestFIow1SIpm=O, constantFlowTime1Sec=300
Gas Flow Charts | x
Graphs
state | 2021-05-17
system
State | Operate | c | 0.000 | SLPM | R | -0.000 | SLPM | FUISde | 20.000
Static Mixer Line (MFCAI)
6e-3
4e-3
ze-3
-Ze-3
15:37 | 15:38 | 15:39 | 15:40 | 15:41
17 mon nay 2021 | Time (s)
State | Operate | c | 0.000 | SLP&I | R | -0.000 | SLPM | scale | 2.000
Bypass(MFCA2)
ACME FLOW "2 BYPASS SETPOINT | ACME FLOW | BYPASS FLOW
3e-3
ze-3
le-3
-le-3
-Ze-3
-3e-3
15:37 | 15:38 | 15:39 | 15:40 | 15:41
17 Mon Hay 2021 | Time (s)
State | Operate | c | 0.000 | R | 0.001 | scale | 0.500
Fuel(MFCA3)
ACME FLOW | FUEL SETPOINT | ACME FLOW "3 FUEL FLOW
0.6
0.4
15:37 | 15:38 | 15:39 | 15:40 | 15:41
17 Mon May 2021 | Time (s)
16
~~~~

### Pagina 17

Cita: [pdf_eeec420ae845e1bb4027, p. 17]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_eeec420ae845e1bb4027/p0017.jpg)

~~~~text
Test 21137A4, continued
- VLC media player | Diagnostic Cool Flame Sensors
systemstate EXPERIMENT | 2021-05-17
System TenperatLres
5.000 | set | cpu | 32.800
Power
Set Al Gans
W/crn2 | cpu Board | 35.000
PMT 1 | o. ooo | 0.000
Cube Sensor 1 | 34.368
0.000 | -0.001 | Gan | 0.000 | 34.402
Cube Sensor 2
0.000 | -0.000 | Gain | 0.000 | 25
Hard Drive
W/cm 2 | Volts
-0.003091 | -0.126 | TC200A CTCI) | 24.326468 | 0.063
-10 mm Lo Gain
-0.000947 | -0.573 | TC200E CTC2) | 22.093879 | -0.027
-IO mm Hi Gan
-0.000810 | 0.013 | TCCJ | 22.782211 | 0.873 | v
+32 mm | Gan
+30 | Gan | -0.000033 | 0.135 | Array
Rake.- Far
+60 mm Lo Gül | -0.000845 | 0.025
38.212581 | 0.627
+60 mm H Gah | 0.000158 | 0.277
hvabd-/ow | 0.011
60 Deg Offret | 0.000172 | 1.379
nvabd-low | -0.004
TCD | 40.289978 | 0.712
Cold Junctim
Vets
60 Deg Chet | 24, 736427 | 1.577
Burner Sphere-a/ (1/4)
Burr,er | 200.008889 | 7.229 | mV
Cube Conrectjon
Time Series Chart
Packet | Software Mnemmic
ACFE-Teleme | 0.00
Teleme | 0.00
ACNE | 0.00
2.5
Select Iterns | End PIO tång
Clear Selections | Restart
Gr sph Properties
15:39:30 | 15:39:45
17May | 17 Mon May 2021 | Time
Start Tme
17
~~~~

### Pagina 18

Cita: [pdf_eeec420ae845e1bb4027, p. 18]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Test 21137A4, continued
After test: 351 on lowest valve safety timer, 188 psia in oxidizer bottle, 98 psia 
in fuel bottle
18
~~~~

### Pagina 19

Cita: [pdf_eeec420ae845e1bb4027, p. 19]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_eeec420ae845e1bb4027/p0019.jpg)

~~~~text
Test 21137A5 (test 7 of 12, hot flame 7 of 12) – sustained ignition, run with 
igniterPreheatDurationMs=1000, pmt2Gain=6, flowTimeoutSec=320, 
fuelFlowIgnitionDeltaMs=0, fuelIgnitionFlowSlpm=0.190, 
nitrogenIgnitionFlowSlpm=0, fuelTestFlow1Slpm=0.190, 
nitrogenTestFlow1Slpm=0, constantFlowTime1Sec=290
19

[Texto OCR de la imagen]
Test 21137A5 (test 7 of 12, hot flame 7 of 12) — sustained ignition, run with
igniterPreheatDurationMs=1000, pmt2Gain=6, flowTimeoutSec=320,
fuelFlowIgnitionDeltaMs=O, fuellgnitionFIowSIpm=O.190,
nitrogenlgnitionFlowSlpm=O, fuelTestFlow1Slpm=O.190,
nitrogenTestFlow1Slpm=O, constantFlowTime1Sec=290
Gas Flow Charts | x
Graphs
state | 2021-05-17 | GMT
system
State | Operate | c | 0.000 | SLPM | R | 0.008 | SLPM | FUlSca1e | 20.000
Static Mixer Line (MFCAI)
ACME FLOW MI MIXER SETPOINT | ACME FLOW MI MIXER FLOW
8e-3
6e-3
4e-3
-Ze-3
-6e-3
15:55 | 15:56 | 15:57 | 15:58 | 15:59
17 Mon Hay 2021 | Tirne (s)
State | Operate | c | 0.000 | SLPM | R | -0.002 | SLPM | scale | 2.000
Bypass(MFCA2)
ACME FLOW "2 BYPASS SETPOINT | ACME FLOW "2 BYPASS FLOW
-ose-3
-I.oe-3
-Ise-3
-2.0+3
-2.5e-3
-3.oe-3
15:55 | 15:56 | 15:57 | 15:58 | 15:59
17 Mon May 2021 | Time (s)
State | Operate | c | 0.000 | SLPM | R | 0.000 | scale | 0.500 | SLPM
Fuel(MFCA3)
15:55 | 15:56 | 15:57 | 15:58 | 15:59
17 mon may 2021 | Tirne (s)
19
~~~~

### Pagina 20

Cita: [pdf_eeec420ae845e1bb4027, p. 20]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_eeec420ae845e1bb4027/p0020.jpg)

~~~~text
Test 21137A5, continued
VLC media player | Diagnostic Cocl Flame Sensors | x
2021435-17
PMTs | System Temperatures
5.000 | cpu | 32.800
Power
Set Al Gans
W/crn2 | v | Board | 35.000
-58.000 | -0.001 | 5.500 | Set
Gan | Cube | 34.349
Sensor 1
PMT 2 | 71.000 | -0.000 | 6.000 | Set | 34
Cube Sensor 2
PMT 3 | 0.000 | -0.001 | 5.500 | set | 25
Hard Drive
Radome ters
W Ian 2
-0.002668 | -0.102 | TC200A (TCI) | 24.400810 | 0.066 | mV
-10 nn Lo Gan
-0.000946 | -0.572 | TC200B (TQ) | 22.093879 | -0.027 | mV
-IO mm H Gain
-0.000129 | 0.056 | 22.782211 | 0.873
+30 mm Lo Gain
+30 | H Gah | 0.000586 | 0.613
nn
Rake: Far
+60 | LO Gain | -0.000127 | 0.067
41.315066 | 0.754 | mV
+60 nn Hi Gah | 0.000860 | 0.740
invalid-low | 0.016 | mV
60 Deg Ofret | 0.000431 | 1.523
invalid-low | 0.000 | mV
46.233104 | 0.956 | mV
Raciometer Cold Junction
60 Deg Offset | 24.736427 | 1.577
Burner. Sphere—I
Burner | 255.770231 | 9.478
Cube Cmnection
Time Series Chart
Packet | Software Mnernonic | Low
ACME Telemve | 0.00
ACME Telerne | 0.00
ACME Telerne ACME DIAG | T3 | 0.00
Select Items | End | ttjng
Clear Selections
Graph Properties
15:58:15 | 15:58:30 | 15:58:45 | 15:59:00
17 May 2021 | 17 mon may 2021 | Time
start Time
20
~~~~

### Pagina 21

Cita: [pdf_eeec420ae845e1bb4027, p. 21]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Test 21137A5, continued
After test: 277 on lowest valve safety timer, 188 psia in oxidizer bottle, 96 psia 
in fuel bottle
21
~~~~

### Pagina 22

Cita: [pdf_eeec420ae845e1bb4027, p. 22]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_eeec420ae845e1bb4027/p0022.jpg)

~~~~text
Test 21137A6 (test 8 of 12, hot flame 8 of 12) – sustained ignition, run with 
igniterPreheatDurationMs=1000, pmt2Gain=6, flowTimeoutSec=120, 
fuelFlowIgnitionDeltaMs=0, fuelIgnitionFlowSlpm=0.242, 
nitrogenIgnitionFlowSlpm=0, fuelTestFlow1Slpm=0.242, 
nitrogenTestFlow1Slpm=0, constantFlowTime1Sec=90
22

[Texto OCR de la imagen]
Test 21137A6 (test 8 of 12, hot flame 8 of 12) — sustained ignition, run with
igniterPreheatDurationMs=1000, pmt2Gain=6, flowTimeoutSec=120,
fuelFlowIgnitionDeltaMs=O, fuellgnitionFIowSIpm=O.242,
nitrogenlgnitionFlowSlpm=O, fuelTestFlow1Slpm=O.242,
nitrogenTestFlow1Slpm=O, constantFlowTime1Sec=90
Gas Flow Charts
Graphs
2021-05-17 16: 1204
State | Operate | c | 0.000 | SLPM | -0.003 | SLPM | FuUScale | 20.000
Static Mixer Line (MFCAI)
ACME FLOW MI MIXER SETPOINT | ACME FLOW MI MIXER FLOW
0.010
-omo
-OJ15
16:08 | 16:09 | 16:10 | 16:11 | 16:12
17 Mon May 2021 | Time (s)
State | Operate | c | 0.000 | SLPM | -0.003 | SLPM | scale | 2.000
Bypass(MFCA2)
-OSe-3
-loe-3
Ise-3
-2.Oe-3
-2.5e-3
-3.0e-3
16:08 | 16:09 | 16:10 | 16:11 | 16:12
17'•ton may 2021 | Tine (s)
State | Operate | c | 0.000 | SLPM | R | 0.001 | SLPM | scale | 0.500 | SLPM
Fuel(MFCA3)
0.15
0.10
16:08 | 16:09 | 16:10 | 16:11 | 16:12
17 Hon May 2021 | Time (s)
22
~~~~

### Pagina 23

Cita: [pdf_eeec420ae845e1bb4027, p. 23]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_eeec420ae845e1bb4027/p0023.jpg)

~~~~text
Test 21137A6, continued
- VLC media player | Diagnostic Cool Flame Sensors
EXPERIMENT | 2021-05-17
System Temperatures
5.000 | set | CPI_J | 32.800
power
set All Gans
W/crn2 | cpu Board | 35.000
PMT 1 | -58.000 | -0.001 | Gain | 5.500
Cube Sensor 1 | 34.297
PMT 2 | 71.000 | -0.000 | 6.000 | 34.267
Cube Sensor 2
PMT 3 | 0.000 | -0.001 | 5.500 | 25
Hard Drive
W/cm2
0002950 | • 118 | TC200A act) | 23.830725 | 0.043
-10 mm Lo Gan
-0.000964 | -0.585 | TC200B | 22.069047 | -0.028
-10 mm GSn | (TC2)
0000652 | 0.023 | 22.782211 | 0.373
+30 mrn Lo G.Sn
+30 | H Gan | 0.000114 | 0.249
mm
Rake: Far
+60 rnm Lo | -0.000674 | 0.035
35.959736 | 0.535
+60 mrn H Gah | 0.000316 | 0.381
invü40w | 0.008
60 | Ofret | 0.000208 | 1.399
invdid40w | -0.005 | mV
TCD | 43.557397 | 0.846
Radiorneter Cold Junction
60 | Offset | 24.650913 | 1.578
Burner TC | 163.451578 | 5.767 | mV
Cube Connection
Time Senes Chart
Software themonic | Low
Teleme | 0.00
Teleme | 0.00
ACME Teleme | 0.00
2.5
Select Items | End Plotting
Clear Selections
Graph Properties
17May | 17 mon may 2021
start Tme
23
~~~~

### Pagina 24

Cita: [pdf_eeec420ae845e1bb4027, p. 24]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Test 21137A6, continued
After test: 220 on lowest valve safety timer, 188 psia in oxidizer bottle, 94 psia 
in fuel bottle
24
~~~~

### Pagina 25

Cita: [pdf_eeec420ae845e1bb4027, p. 25]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_eeec420ae845e1bb4027/p0025.jpg)

~~~~text
Test 21137A7 (test 9 of 12, hot flame 9 of 12) – sustained ignition, run with 
igniterPreheatDurationMs=1000, pmt2Gain=6, flowTimeoutSec=120,
fuelFlowIgnitionDeltaMs=0, fuelIgnitionFlowSlpm=0.207, 
nitrogenIgnitionFlowSlpm=0, fuelTestFlow1Slpm=0.207, 
nitrogenTestFlow1Slpm=0, constantFlowTime1Sec=90
25

[Texto OCR de la imagen]
Test 21137A7 (test 9 of 12, hot flame 9 of 12) — sustained ignition, run with
igniterPreheatDurationMs=1000, pmt2Gain=6, flowTimeoutSec=120,
fuelFlowIgnitionDeltaMs=O, fuellgnitionFIowSIpm=O.207,
nitrogenlgnitionFlowSlpm=O, fuelTestFlow1Slpm=O.207,
nitrogenTestFlow1Slpm=O, constantFIowTime1Sec=90
Gas Flow Charts
Graphs
2021-05-17 | GMT
State | Operate | c | 0.000 | SLPM | R | -0.004 | SLPM | Fun scale | 20.000 | SLPM
Static Mixer Line (MFCAI)
0.010
16:28 | 16:29 | 16:30 | 16:31 | 16:32
17 Hon | 2021 | Time (s)
Sbte | Operate | c | 0.000 | R | -0.002 | SLPM | ft-a scale | 2.000
Bypass(MFCA2)
-OSe-3
-I.Oe-3
-Ise-3
-2.0e-3
-2.5e-3
-3.oe-3
-3.5e-3
16:28 | 16:29 | 16:30 | 16-31 | 16:32
17 | 2021 | Time (s)
State | Operate | c | 0.000 | -0.000 | SLPM | Ft-Ascale | 0.500
Fuel(MFCA3)
0.20
16:28 | 16:29 | 16:30 | 16:31 | 16:32
17 mon nay 2021 | Time (s)
25
~~~~

### Pagina 26

Cita: [pdf_eeec420ae845e1bb4027, p. 26]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_eeec420ae845e1bb4027/p0026.jpg)

~~~~text
Test 21137A7, continued
- VLC media player | Diagnostic Cool Flame Sensors | o | x
system state | 2021-05-17
pMTS | System Ternperatures
5.000 | 32.800
power
Set All (Äns
w,'crn2 | v | CPU Board | 34,
PMT 1 | -58,000 | -0.000 | 5,500
Cube Senscr 1 | 34, 365
71. ooo | -0.000 | 6. ooo | 34,323
CLbe Sensor 2
PMT 3 | 0.000 | -0.001 | 5.500 | 25
Radometers
W/crn 2
-0.002862 | -0.113 | TC200A (TCI) | 24.252121 | 0.060 | mV
-10 | Lo Gan
-0.000948 | -0.574 | TC2008 (TC2) | 21.870376 | -0.036 | mV
-10 mm H Gan
-0.000462 | 0.035 | 22.782211 | 0.873
+30 | Lo Gan
+3) | H Gan | 0.000287 | 0.382 | Array
Rake: Far
+60 rrrn Lo Gah | -0.000486 | 0.046
38.775077 | 0.650
+60 n-rn H Gain | 0.000514 | 0.512
in vdid40w | 0.014 | mV
60 Deg Of€et | 0.000291 | 1.445
in vdid-low | 0.006
42, 972844 | 0.822 | mV
Radometer Cold indon
60 Deg Of-fret | 24, 736427 | 1.577
CJ | Burner: | (1/4)
Burner | 210.223051 | 7.638
Cube Ccnnectixn
Time Series Chartsl
packet | Software Mnemonic | Low
ACMETeleme ACME DIAG | 0.00
ACME Teleme | 0.00
ACME Teleme | 0.00
2.5
Select Items | End Ph tting
Clear Selections
Graph Properties
17 May 2021 | 17 Mon May 2021 | Tine
Start Tme
26
~~~~

### Pagina 27

Cita: [pdf_eeec420ae845e1bb4027, p. 27]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Test 21137A7, continued
After test: 154 on lowest valve safety timer, 188 psia in oxidizer bottle, 92 psia 
in fuel bottle
27
~~~~

### Pagina 28

Cita: [pdf_eeec420ae845e1bb4027, p. 28]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_eeec420ae845e1bb4027/p0028.jpg)

~~~~text
Diluted to ~21% O2 (balance N2) and vented back to 1 atm
Test 21137D1 (test 10 of 12, hot flame 10 of 12) – sustained ignition, run with 
igniterPreheatDurationMs=1000, pmt2Gain=6, flowTimeoutSec=150, 
fuelFlowIgnitionDeltaMs=500, fuelIgnitionFlowSlpm=0.499, 
nitrogenIgnitionFlowSlpm=0, fuelTestFlow1Slpm=0.499, 
nitrogenTestFlow1Slpm=0, constantFlowTime1Sec=120
28

[Texto OCR de la imagen]
Diluted to '"21% 02 (balance N2) and vented back to 1 atm
Test 21137D1 (test 10 of 12, hot flame 10 of 12) - sustained ignition, run with
igniterPreheatDurationMs=1000, pmt2Gain=6, flowTimeoutSec=150,
fuelFIowIgnitionDeltaMs=500, fuellgnitionFIowSIpm=O.499,
nitrogenlgnitionFlowSlpm=O, fuelTestFlow1Slpm=O.499,
nitrogenTestFlow1SIpm=O, constantFlowTime1Sec=120
Gas Flow Charts
Graphs
state | 2021-05-17 | GMT
system
State | c | 0.000 | R | 0.006 | SLPM | scale | 20.000 | SLPM
Static Mixer Line (MFCAI)
0.010
-0.005
-0.010
-0.015
17:28 | 17:29 | 17:30 | 1701 | 17:32
17 Mon May 2021 | Time (s)
State | Operate | c | 0.000 | R | -0.003 | SLPM | scale | 2.000
Bypass(MFCA2)
ACME FLOW | BYPASS SETPOINT | ACME FLOW "2 BYPASS FLOW
ze-3
le-3
- Ie-3
-ze-3
-3e-3
-4e-3
17:28 | 17:29 | 17:30 | 17:31 | 17:32
17 Mon May 2021 | Tine (s)
State | Operate | c | 0.000 | SLPM | R | 0.001 | SLPM | scale | 0.500 | SLPM
Fuel(MFCA3)
ACME FLOW r-•13 FUEL SETPOINT | ACME FLOW "3 FUEL FLOW
0.6
17:28 | 17:29 | 17:30 | 17:31 | 17:32
17 Mon May 2021 | Tine (s)
28
~~~~

### Pagina 29

Cita: [pdf_eeec420ae845e1bb4027, p. 29]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_eeec420ae845e1bb4027/p0029.jpg)

~~~~text
Test 21137D1, continued
- VuC media player | Diagnostic Cool Flame Sensors
2021-05-17
PMTs | System Temperatures
5.000 | cpu | 32.300
Power
Set Al CÄns
WIT, 2 | Board | 35.000
-58.000 | 0001 | Gain | 5.500
Cabe Sensor 1 | 34 188
PMT 2 | 71.000 | -0.001 | Gain | 6.000 | 34.157
sensor 2
PMT 3 | 0.000 | 0.000 | Gain | 5.500 | 25
Hard Drive
w,'crnz
-0.003162 | -o. 130 | TC200A act) | 23.330725 | 0.043
-10 mm Lo Gail
-0.000967 | -0.587 | CTC2) | 22.416642 | -0.014
-10 | Gan
-0.001016 | 0.000 | 22.782211 | 0.873
+3) mm Lo Gah
+30 | Hi Gan | -0.000212 | -0.003
rnm
Far
+60 mm Lo Gah | -0.001084 | 0.011
31.981322 | 0.373
+60 mm Gan | -0.000074 | 0.124
maid-low | -0.006 | mV
60 Deg Offset | 0.000068 | 1.321
maid -low | •O •004 | mV
TCD | 28.703901 | 0.240
Radiometer Cold
60 Degoffset | 24.479849 | 1.580
Burner | 64.788973 | 1.724
Time Series Chan —1
Packet | Sofr.vare Plnemonic | Low
Telerne | 0.00
ACME Telerne | 0.00
ACME Teleme | 0.00
2-5
Select Items | End Plotting
Clear 3elections
Graph Properties
17May 2021 | 17 | 2021 | Time
Start Trne
29
~~~~

### Pagina 30

Cita: [pdf_eeec420ae845e1bb4027, p. 30]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Test 21137D1, continued
After test: 116 on lowest valve safety timer, 188 psia in oxidizer bottle, 89 psia 
in fuel bottle
30
~~~~

### Pagina 31

Cita: [pdf_eeec420ae845e1bb4027, p. 31]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_eeec420ae845e1bb4027/p0031.jpg)

~~~~text
Test 21137D2 (test 11 of 12, hot flame 11 of 12) – sustained ignition, run with 
igniterPreheatDurationMs=1000, pmt2Gain=6, flowTimeoutSec=90, 
fuelFlowIgnitionDeltaMs=0, fuelIgnitionFlowSlpm=0.086, 
nitrogenIgnitionFlowSlpm=0, fuelTestFlow1Slpm=0.086, 
nitrogenTestFlow1Slpm=0, constantFlowTime1Sec=60
31

[Texto OCR de la imagen]
Test 21137D2 (test 11 of 12, hot flame 11 of 12) - sustained ignition, run with
igniterPreheatDurationMs=1000, pmt2Gain=6, flowTimeoutSec=90,
fuelFIowIgnitionDeltaMs=O, fuellgnitionFIowSIpm=O.086,
nitrogenlgnitionFlowSlpm=O, fuelTestFlow1Slpm=O.086,
nitrogenTestFlow1Slpm=O, constantFlowTime1Sec=60
Gas Flow Charts | o | x
Graphs
2021-05-17 | GMT
State | Operate | c | 0.000 | SLPM | R | 0.007 | SLPM | uscale | 20.000
Static Mixer Line (MFCAI)
0.010
17:44 | 17:45 | 17:46 | 17:47 | 17:48
17 mon may 2021 | Time (s)
State | Operate | c | 0.000 | QPM | R | -0.003 | SLPM | scale | 2.000
Bypass(MFCA2)
ACME FLOW | BYPASS SETPOINT | ACME FLOW "2 BYPASS FLOW
-le-3
-Ze-3
-5e-3
—6e—3
17:44 | 17:45 | 17:46 | 17:47 | 17:48
17 Mon May 2021 | Tine (s)
State | Operate | c | 0.000 | SLPM | R | 0.001 | scale | 0.500
Fuel(MFCA3)
0.04
0.02
17:44 | 17:45 | 17:46 | 17:47 | 17:48
17 mon nay 2021 | Tine (s)
31
~~~~

### Pagina 32

Cita: [pdf_eeec420ae845e1bb4027, p. 32]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_eeec420ae845e1bb4027/p0032.jpg)

~~~~text
Test 21137D2, continued
- VLC media player | Diagnostic Cool Flame Sensors | o | x
system state | 2021-05-17 17:47:39 | GMT
PMTS | System Temper atv-res
5.000 | 32.700
Power
set
W /an2 | Board | 35.000
PMT 1 | -58. ooo | -0.000 | 5.500
Cube Sensor 1 | 34.158
PMT 2 | 71.000 | -0.001 | 6.000 | Set | 34.158
Cube Sensor 2
PMT 3 | 0.000 | -0.000 | Gain | 5.500 | set | 25
Hard Drive
W/an | Volts
0003356 | -o. 141 | TC200A (TCI) | 23.458772 | 0.028
-10 mm LO Gah
-0.000944 | -0.571 | TC200B | 21.920047 | -0.034 | mV
-10 nn Hi Gain
-0.001301 | -0.018 | 22.782211 | 0.873
+3) mm Lo Gain
+30 | Gdn | -0.000467 | -0.200
mm
Rake: Far
+60 mm LO Gain | -0.001460 | -0.011
z. 185483 | 0.219
+60 mm Gdn | -0.000448 | -0.123
invalid-low | -0.005
60 Deg Offet | -0.000068 | 1.245
invalid-low | -0.011 | mV
27.592694 | 0.195
Radiorneter Cold Junction
Volts
60 | Offset | 24.4B849 | 1.580
Burner: | (7/4)
Burner | 122208115 | 4, 100
Cube Correction
Time Series Chatt$l
Packet | Soft,vare Mnemonic | Low
ACME Teleme ACME DIAG PMT Tl | 0.00
ACME Teleme ACME DIAG | T2 | 0.00
ACME Teleme | 0.00
2-5
Select Items | End plotthg
Clear Selections
Graph Properties
17 May 2021 | 17 mon | 2021
start Tiffk
32
~~~~

### Pagina 33

Cita: [pdf_eeec420ae845e1bb4027, p. 33]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Test 21137D2, continued
After test: 66 on lowest valve safety timer, 188 psia in oxidizer bottle, 189 psia 
in fuel bottle
33
~~~~

### Pagina 34

Cita: [pdf_eeec420ae845e1bb4027, p. 34]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_eeec420ae845e1bb4027/p0034.jpg)

~~~~text
Test 21137C1 (test 12 of 12, hot flame 12 of 12) – sustained ignition, run with 
igniterPreheatDurationMs=1000, pmt2Gain=6, flowTimeoutSec=40, 
fuelFlowIgnitionDeltaMs=0, fuelIgnitionFlowSlpm=0.086, 
nitrogenIgnitionFlowSlpm=0.055, fuelTestFlow1Slpm=0.086,
nitrogenTestFlow1Slpm=0.055, constantFlowTime1Sec=25
34

[Texto OCR de la imagen]
Test 21137C1 (test 12 of 12, hot flame 12 of 12) — sustained ignition, run with
igniterPreheatDurationMs=1000, pmt2Gain=6, flowTimeoutSec=40,
fuelFlowIgnitionDeltaMs=O, fuellgnitionFlowSlpm=O.086,
nitrogenlgnitionFIowSIpm=O.055, fuelTestFlow1Slpm=O.086,
nitrogenTestFlow1SIpm=O.055, constantFlowTime1Sec=25
Gas Flow Charts | o | x
Graphs
state | 2021-05-1718: 14:12 | GMT
system
State | Operate | c | 0.000 | SLPM | R | -0.000 | SLPM | Fun scale | 20.000 | SLPM
Static Mixer Line (MFCAI)
ACME FLOW MI MIXER SETPOINT | ACME FLOW MI MIXER FLOW
-0.010
-0.015
18:10 | 18:11 | 18:12 | 18:13 | 18:14
17 Mon May 2021 | Tine (s)
State | Operate | c | 0.000 | R | -0.001 | SLPM | scale | 2.000
Bypass(MFCA2)
0.03
18:10 | 18:11 | 18:12 | 18:13 | 18:14
17 mon may 2021 | Time (s)
State | Operate | c | 0.000 | R | 0.000 | scale | 0.500
Fuel(MFCA3)
SETPOINT | ACME FLOW '43 FUEL FLOW
18:10 | 18:11 | 18:12 | 18:13 | 18:14
17 mon may 2021 | Time (s)
34
~~~~

### Pagina 35

Cita: [pdf_eeec420ae845e1bb4027, p. 35]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_eeec420ae845e1bb4027/p0035.jpg)

~~~~text
Test 21137C1, continued
VLC media player | Diagnostic Cool Flame Sensors | x
system state | 2021-05-17
PMTs | System Tenperatures
5.000 | Set | cpu | 32,
Set All Gains
w larv2 | Board | 35.000
0.000 | -0.001 | 0.000 | set
PMT 1 | Cube | 34.293
Sensor 1
PMT 2 | 0.000 | -0.000 | 0.000 | Set | 34.314
Cube Sensor 2
PMT 3 | 0.000 | -0.000 | 0.000 | set | 25
Hard Drive
Radometers
Volts
-0.003391 | -0.143 | TC200A CTCI) | 23.359563 | 0.024
-10 nm Lo Gah
0000947 | -0.573 | TC200B (TQ) | 22.044215 | -0.029 | mV
-10 mm H Gan
-0.001365 | -0.022 | 22.782211 | 0.373 | v
+30 | Gan
+30 | H Gan | -0.000523 | -0.243
Rake: Far
+60 rm-n Lo Gah | -0.001528 | -0.015
28.333628 | 0.225
+60 nn Hi Gain | 0000509 | -0.163
nvabd-low | -0.001
60 Deg Ofret | -0.000083 | 1.237
maid-low | -0.016 | mV
26.603977 | 0.155 | mV
Radiorneter Cold Jtnction
Vdts
60 Deg Offset | 24.394320 | 1.581
94.492142 | 2.959
Cube
Time Series Chart $1
Soft',vare Mnemonic
ACME Teleme | 0.00
ACB-E Teleme | _T2 | 0.00
ACME Teleme ACME DIAG | T3 | 0.00
Select Items | End Plottng
Clear Selections | Restart
Graph Properties
17 May 2021 18: 13:06.OOO | 17 Mon | 2021 | Tine
St&t Tme
35
~~~~

### Pagina 36

Cita: [pdf_eeec420ae845e1bb4027, p. 36]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Test 21137C1, continued
After test: 29 on lowest valve safety timer, 14.71 psia in oxidizer bottle, 88 psia 
in fuel bottle
36
~~~~
