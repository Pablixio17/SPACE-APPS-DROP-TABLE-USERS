# 21162 flow traces etc

- Identificador: pdf_af6ea0fe11bcb245ea43
- Investigaciones: PSI-159
- Tipo de documento: Raw Data
- Estado: processed
- Temas detectados automaticamente: hardware, oxygen, pressure, ignition, cool_flames, extinction

## Fuentes

- [PSI-159_Raw Data_21162 flow traces etc.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-159/Raw%20Data/PSI-159_Raw%20Data_21162%20flow%20traces%20etc.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_af6ea0fe11bcb245ea43, p. 1]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_af6ea0fe11bcb245ea43/p0001.jpg)

~~~~text
CFI-G Round 1, day 9, with 30% ethane (C2H6)
Chamber filled to 1 atm with ~40% O2 (balance N2)
Extinction detection effectively turned off so tests were ended ‘manually’
Test 21162A1 (test 1 of 13, hot flame 1 of 12) – sustained ignition, run as 
planned 
1

[Texto OCR de la imagen]
CFI-G Round 1, day 9, with 30% ethane (C2H6)
Chamber filled to 1 atm with N40% 02 (balance N2)
Extinction detection effectively turned off so tests were ended 'manually'
Test 21162A1 (test 1 of 13, hot flame 1 of 12) — sustained ignition, run as
planned
Gas Flow Charts | o | x
Graphs
state | 2021-06-11 | G..IT
system
State | Operate | c | 0•000 | SLPM | -0.002 | SLPM | FL] Scale | 20.000 | SLPM
Static Mixer Line (MFCAI)
ACME FLOW MI MIXER SETPOINT | ACME FLOW MI MIXER FLOW
0.010
0.000
-0.010
-0.015
15:22 | 15:23 | 15:24 | 15:25 | 15:26
11 Fri Jun 2021 | Time (s)
State | Operate | c | 0.000 | SLPM | R | 0.000 | SLPM | scale | 2.000
Bypass(MFCA2)
3e-3
ze-3
le-3
-le-3
-ze-3
-3e-3
15:22 | 15:23 | 15:24 | 15:25 | 15:26
11 | Jun 2021 | Time (s)
State | Operate | c | 0.000 | SLPM | R | 0.003 | SLPM | scale | 0.500 | SLPM
Fuel(MFCA3)
0.1
15:22 | 15:23 | 15:24 | 15:25 | 15:26
11 Fri Jun 2021 | Time (s)
1
~~~~

### Pagina 2

Cita: [pdf_af6ea0fe11bcb245ea43, p. 2]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_af6ea0fe11bcb245ea43/p0002.jpg)

~~~~text
Test 21162A1, continued
- VLC media player | Cool Flame Sensors | o | x
Diagnostic
t,ledie | P ld'. back | Audio
2021-06-11
PMTs | Systern Temperatures
5.000 | CPU | 32.800
power
Set AI
CPU Board | 34000
-58.000 | -0.000 | s. soo | Set
PMT 1 | 33.915
Sensor 1
PMT 2 | 71.000 | -0.001 | Gain | 6.000 | Set | 33.908
Cube Senscr 2
PMT 3 | 0.000 | -0.001 | Gain | 5.500 | Set | 25
Hard Drive
W/crn2 | Vdts
-0.002368 | -0.085 | TC200A CTCI) | 23.771076 | 0.061 | mV
-10 mm Lo Gah
-0.000953 | -0.577 | TC200B CTC2) | 22.058970 | -0.015 | mV
-10 mm Hi Gain
0.090 | 22.104234 | 0.871
+30 mm LO
+30 | Hi | 0.001188 | 0.993 | Array
mm
Rake: Far
+60 mm Lo Gah | 0.000727 | 0.110
55.910668 | 1.374 | mV
+60 mm H Gan | 0.001701 | 1.211
invabd-low | 0.067
60 Deg (het | 0.000800 | 1.723
invabd-low | 0.022 | mV
69.684630 | 1.914 | mV
Radiorneter Cold inctim
Vets
60 Deg Offset | 24.223237 | 1.583
48: 15 | B-u•ne-: Sphe•eal (1/4'
Burner | 170.907847 | 6.039
Cube
11 | $101
Packet | Software tvhernonic | Low
0.00
0.00
ACME Tela-ne | 0.00
Select Items | End PIO tting
Clear Selections
Gr aph Properties
192930 | 15:25
11 | 11 fri Jun 2021 | Time
2
~~~~

### Pagina 3

Cita: [pdf_af6ea0fe11bcb245ea43, p. 3]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Test 21162A1, continued
After test: 923 on lowest valve safety timer, 1213 psia in oxidizer bottle, 123 
psia in fuel bottle
3
~~~~

### Pagina 4

Cita: [pdf_af6ea0fe11bcb245ea43, p. 4]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_af6ea0fe11bcb245ea43/p0004.jpg)

~~~~text
Test 21162A2 (test 2 of 13, hot flame 2 of 12) – sustained ignition, run with
flowTimeoutSec=300, fuelFlowIgnitionDeltaMs=0, fuelIgnitionFlowSlpm=0.317,
fuelTestFlow1Slpm=0.317, constantFlowTime1Sec=270
4

[Texto OCR de la imagen]
Test 21162A2 (test 2 of 13, hot flame 2 of 12) — sustained ignition, run with
flowTimeoutSec=300, fuelFIowIgnitionDeItaMs=O, fuellgnitionFIowSIpm=O.317,
fuelTestFlow1Slpm=O.317, constantFlowTime1Sec=270
Gas Flow Charts | x
Graphs
2021-06-11 | GMT
State | Operate | c | 0.000 | SLPM | R | -0.002 | QPM | Fu" Scale | 20.000
Static Mixer Line (MFCAI)
ACME FLOW MI MIXER SETPOINT | ACME FLOW MI MIXER FLOW
0.010
15:50 | 15:51 | 15:52 | 15:53 | 15:54
11 fri Jun 2021 | Time (s)
State | Operate | c | 0.000 | R | -0.004 | SLPM | scale | 2.000
Bypass(MFCA2)
ACME FLOW r•12 BYPASS SETPOINT | ACME FLOW r•12 BYPASS FLOW
o
-le-3
-Ze-3
ill'
-3e-3
-4e-3
-5e-3
15:50 | 15:51 | 15:52 | 15:53 | 15:54
11 Fri Jun2021 | Time (s)
State | Operate | c | 0.000 | SLPM | R | 0.001 | SLPM | scale | 0.500 | SLPM
Fuel(MFCA3)
0.10
15:50 | 15:51 | 15:52 | 15:53 | 15:54
11 Fri Jun 2021 | Tune (s)
4
~~~~

### Pagina 5

Cita: [pdf_af6ea0fe11bcb245ea43, p. 5]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_af6ea0fe11bcb245ea43/p0005.jpg)

~~~~text
Test 21162A2, continued
- VLC media player | Cool Flame Sensors | c:] | x
Diagnostic
system state | 2021-06-11 | GMT
System
5.000 | CPU | 32.800
power
Set AI Gans
W/crr,2 | 34,000
-58.000 | 5.500 | Set
Cube Sensw 1 | 33.910
PMT 2 | 71.000 | -0.000 | 6.000 | Set | 33.905
Cube Sensor 2
PMT 3 | 0.000 | 0.000 | Gain | 5.500 | set | 25
Hard Drive
Radometers
'Man 2
-0.002474 | -0.091 | TC200A (TCI) | 24.606327 | 0.088
-10 mm Lo Gah
-0.000882 | -0.527 | CTC2) | 21.852854 | -0.023
-10 mm H Gän
0.000251 | 0.080 | 22.443212 | 0.872
+30
+30 mm H | 0.000934 | 0.882 | Array
Rake:
+60 nn LO Gdn | 0.000420 | 0.099
55.734393 | 1.362
+60 | H Gail | 0.001395 | 1.093
TCB | invü-/ow
60 Deg Offset | 0.000692 | I. 668
hvü-/ow | 0.021
60.148931 | 1.545
Radorneter Cold Ju-tcbon
60 Deg Offset | 24.308776 | 1.582
Burner: | (1/4'
Burner | 236.813905 | 8.722
Cube Comecåm
packet | So ftvvare Mnernonic | Low
ACME Teleme ACME DIAG | Tl | 0.00
ACB•IE Telen-,e ACME DIAG | T2 | 0.00
ACME Teleme ACME DIAG | T3 | 0.00
Select Items | End plotting
Clear Selections | Restart
Graph Properties
11 Jl_n 202115:53: 17.000 | 11 | Jun 2021
start Tme
5
~~~~

### Pagina 6

Cita: [pdf_af6ea0fe11bcb245ea43, p. 6]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Test 21162A2, continued
After test: 822 on lowest valve safety timer, 1218 psia in oxidizer bottle, 118 
psia in fuel bottle
6
~~~~

### Pagina 7

Cita: [pdf_af6ea0fe11bcb245ea43, p. 7]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_af6ea0fe11bcb245ea43/p0007.jpg)

~~~~text
Test 21162A3 (test 3 of 13, hot flame 3 of 12) – sustained ignition, run with 
flowTimeoutSec=360, fuelFlowIgnitionDeltaMs=0, fuelIgnitionFlowSlpm=0.211,
fuelTestFlow1Slpm=0.211, constantFlowTime1Sec=330
dataCamera Zoom=25000, dataCamera Focus=14600
7

[Texto OCR de la imagen]
Test 21162A3 (test 3 of 13, hot flame 3 of 12) — sustained ignition, run with
flowTimeoutSec=360, fuelFIowIgnitionDeltaMs=O, fuellgnitionFlowSlpm=O.211,
fuelTestFlow1SIpm=O.211, constantFlowTime1Sec=330
dataCamera Zoom=25000, dataCamera Focus-14600
Gas Flow Charts
Graphs
system state | 2021-06-11
Operate | c | 0.000 | SLPM | R | -0.005 | SLPM | Fu" scale | 20.000
Static Mixer Line (MFCAI)
SETPOINT
-0.010
-0.015
16:18 | 16:19 | 16:20 | 16:21 | 16:22
11 Fri Jun 2021 | Tirne (s)
State | Operate | c | 0.000 | QPM | R | 0.000 | FLAIsca1e | 2.000
Bypass(MFCA2)
I.Oe-3
0.5e-3
-I.oe-3 | {Ill'li'n•
-1.5e-3
-2.Oe-3
-2.5e-3
-3.Oe-3
16:18 | 16:19 | 16:20 | 16:21 | 16:22
11 Fri Jun 2021 | Time (s)
State | Operate | c | 0.000 | SLPM | R | 0.000 | ELA scale | 0.500
Fuel(MFCA3)
0•10
16:18 | 16:19 | 16:20 | 16:21 | 16:22
11 Fri Jun 2021 | Time (s)
7
~~~~

### Pagina 8

Cita: [pdf_af6ea0fe11bcb245ea43, p. 8]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_af6ea0fe11bcb245ea43/p0008.jpg)

~~~~text
Test 21162A3, continued
- VLC media player | Cool Flame Sensors | x
Diagnostic
system state | 2021-06-11
System Temperatures
5.000 | set | 33.000
Set AI Gans
W /a•n2 | Boa-d | 34.000
PMT I | -58.000 | -0.000 | 5.500
a-be sensor | | 34.241
PMT 2 | 71.000 | -0.000 | Gain | 6.000 | Set | 34.259
a-be sensor 2
PMT 3 | 0.000 | -0.000 | 5.500 | set | 25
H&dDnve
vv,'anz
-0.002650 | -o, 101 | TC200A (TCI) | 26.257710 | o. 141 | mV
-10 mm Lo Gan
-0.000859 | -0.510 | TC200E (TC2) | 22416640 | -0.014 | mV
-10 mm Hi
-0.000066 | 0.060 | 22782211 | 0.873 | v
+30 rrrn Lo
+3) | H Gan | 0.000638 | 0.653 | Array
mm
Rake: Far
+60 mrn Lo Gain | 0.000095 | 0.080
59.081234 | 1.487
+60 | H Gan | 0.001071 | 0.879
"valid-low | 0.040
60 Deg Offet | 0.000615 | 1.625
0.015
59.683906 | 1.512 | mV
Radiorneter Cold Jl_nctjon
60 Deg Offset | 24.736427 | 1.577
Burner: | (1/4'
Burner | 283.035765 | 10.596 | mV
Connection
Packet | Softvv•are Mnemonic
ACME Teleme | 0.00
ACME Teleme | 0.00
ACME | ACME DIAG | T3 | 0.00
1.0
Select Items | End Pio ting
Clear Selections | Restart
Graph Properties
11 Jun | 11 | Jun 2021
startrrne
8
~~~~

### Pagina 9

Cita: [pdf_af6ea0fe11bcb245ea43, p. 9]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Test 21162A3, continued
After test: 559 on lowest valve safety timer, 1224 psia in oxidizer bottle, 107 
psia in fuel bottle
9
~~~~

### Pagina 10

Cita: [pdf_af6ea0fe11bcb245ea43, p. 10]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_af6ea0fe11bcb245ea43/p0010.jpg)

~~~~text
Test 21162B1 (test 4 of 13, hot flame 4 of 12) – sustained ignition, run with
flowTimeoutSec=360, fuelFlowIgnitionDeltaMs=0, fuelIgnitionFlowSlpm=0.211,
fuelTestFlow1Slpm=0.211, constantFlowTime1Sec=330
dataCamera Zoom=45000, dataCamera Focus=10025
10

[Texto OCR de la imagen]
Test 21162B1 (test 4 of 13, hot flame 4 of 12) — sustained ignition, run with
flowTimeoutSec=360, fuelFlowIgnitionDeltaMs=O, fuellgnitionFIowSIpm=O.211,
fuelTestFlow1Slpm=O.211, constantFlowTime1Sec=330
dataCamera Zoom=45000, dataCamera Focus-10025
Gas Flow Charts
Graphs
2021G-1116:44:23 | GMT
State | Operate | c | 0.000 | SLPM | -0.004 | SLPM | Fun scale | 20.000
Static Mixer Line (MFCAI)
ACME FLOW MI MIXER SETPOINT | ACME FLOW MI MIXER FLOW
6e-3
4e-3
ze-3
-Ze-3
-6e-3
-Be-3
16:40 | 16:41 | 16:42 | 16:43 | 16:44
11 | Jun 2021 | Time (s)
State | Operate | c | 0.000 | SLPM | R | -0.003 | SLPM | scale | 2.000 | SLPM
Bypass(MFCA2)
-OSe-3
-I.oe-3
Ise-3
-2.0e-3
-2.5e-3
-3.oe-3
16:40 | 16:41 | 16:42 | 16:43 | 16:44
11 Fri Jun 2021 | Tüne (s)
State | Operate | c | 0.000 | R | 0.001 | scale | 0.500 | SLPM
Fuel(MFCA3)
ACME FLOW | FUEL SETPOINT | ACME FLOW "3 FUEL FLOW
0.20
0.15
0.10
16:40 | 16:41 | 16:42 | 16:43 | 16:44
11 | Jun 2021 | Time (s)
10
~~~~

### Pagina 11

Cita: [pdf_af6ea0fe11bcb245ea43, p. 11]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_af6ea0fe11bcb245ea43/p0011.jpg)

~~~~text
Test 21162B1, continued
VLC media player | Cool Flame Sensors | x
Diagnostic
system state | 2021-06-11
PMTS | System
5.000 | CPU | 33.000
power
Set AI Gains
W /crn2 | Board | 35. om
-58.000 | -o. ooo | Gan | 5.500
Cube Sensor 1 | 34.286
PMT 2 | 71.000 | A).ooo | 6.000 | 34.283
Cube Sensor 2
PMT 3 | 0.000 | A).001 | 5.500 | 25
Hard Drive
w,'cmz | Vdts
-0.002597 | -0.098 | TC200A CTCI) | 25.886586 | 0.126
-10 nm Lo Gah
-o. 000856 | -0.508 | TC200B CTC2) | 22.366990 | -0.016 | mV
-10 mm H Gan
0.000014 | 0.065 | 22.782211 | 0.873 | v
+30 | Lo Gan
+30 | H Gdn | 0.000706 | 0.706 | Array
'Mn
Rake:
+60 nn Lo Gain | 0.000112 | 0.081
56.741291 | 1.390
+60 | Hi Gü | 0.001102 | 0.900
"va5d40w | 0.037
60 Deg Ofret | 0.000593 | 1.613
nvabd-low | 0.009
52.367331 | 1.209
Radiometer Cold Junction
vets
60 Deg Offset | 24.736427 | 1.577
Burner | (1/4)
Burner | 287.180136 | 10.767 | mV
Cube Correction
Packet | Software Mnemonic | Low
ACME Teleme | 0.00
ACME Telerne | 0.00
ACME Teleme ACYE DIAG PMT T3 | 0.00
Select Items | End plotting
Clear Selections | Restart
Graph Properties | Jiuuvmmwmwm——
11 Jun 2021 | lifti Jun 2021 | Time
start
11
~~~~

### Pagina 12

Cita: [pdf_af6ea0fe11bcb245ea43, p. 12]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Test 21162B1, continued
After test: 368 on lowest valve safety timer, 1225 psia in oxidizer bottle, 99 psia 
in fuel bottle
12
~~~~

### Pagina 13

Cita: [pdf_af6ea0fe11bcb245ea43, p. 13]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_af6ea0fe11bcb245ea43/p0013.jpg)

~~~~text
Test 21162A4 (test 5 of 13, hot flame 5 of 12) – sustained ignition, run with 
flowTimeoutSec=350, fuelFlowIgnitionDeltaMs=0, fuelIgnitionFlowSlpm=0.180,
fuelTestFlow1Slpm=0.180, constantFlowTime1Sec=330
dataCamera Zoom=25000, dataCamera Focus=14600
13

[Texto OCR de la imagen]
Test 21162A4 (test 5 of 13, hot flame 5 of 12) — sustained ignition, run with
flowTimeoutSec=350, fuelFlowIgnitionDeltaMs=O, fuellgnitionFlowSIpm=O.180,
fuelTestFlow1Slpm=O.180, constantFlowTime1Sec=330
dataCamera Zoom=25000, dataCamera Focus-14600
Gas Flow Charts | o | X
Graphs
2021-06-11 17:06:36
State | c | 0.000 | SLPM | R | -0.004 | SLPM | Fun Scale | 20.000 | SLPM
Static Mixer Line (MFCAI)
0.010
-0.010
17:02 | 17:03 | 17:04 | 17:05 | 17:06
11 Fri Jun 2021 | Time (s)
State | Operate | c | 0.000 | SLPM | R | -0.004 | Full scale | 2.000 | SLPM
Bypass(MFCA2)
-0.5e-3
-I.oe-3
-ISe-3
-zse-3
-3.Oe-3
-3.5e-3
17:02 | 17:03 | 17:04 | 17:05 | 17:06
11 Fri Jun 2021 | Time (s)
State | Operate | c | 0.000 | SLPM | R | 0.001 | SLPM | scale | 0.500 | SLPM
Fuel(MFCA3)
17:02 | 17:03 | 17:04 | 17:05 | 17:06
11 Fri Jun 2021 | Tine (s)
13
~~~~

### Pagina 14

Cita: [pdf_af6ea0fe11bcb245ea43, p. 14]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_af6ea0fe11bcb245ea43/p0014.jpg)

~~~~text
Test 21162A4, continued
• VLC media player | Cocl Flame Sensors
Diagnostic
System state | 2021-06-11 | GMT
*ITS | Systern Te-ngeratures
5.000 | 32.700
power
Set AJI Gains
cpu Board | 35.000
-58.000 | -0.000 | 5.500
34.424
71.000 | -0.000 | 6.000 | 34.444
Cube Senscr 2
0.000 | -0.001 | Gain | 5.500 | 25
Hard Mve
Radiometers
W Ian 2 | Volts
-0.002827 | -o. 111 | TC200A (TCI) | 25.985564 | 0.130
-10 nn Lo
-0.000854 | -0.507 | TC200B CC2) | 22.292512 | -0.019 | mV
-10 nm H Gail
-0.000382 | 0.040 | 22.782211 | 0.873
+30 r-nm LO Gah
+30 | H Gah | 0.000350 | 0.431
rm-n
Rake Far
+60 | Lo Gah | 4).000281 | 0.058
55.147603 | 1.324
+60 | Hi Gah | 0.000708 | 0.640
hvabd-low | 0.03)
60 Deg Offset | 0.000475 | 1.547
invabd40w | 0.009
54.930178 | 1.315
Radometer Cold Junction
60 Deg Offret | 25.073467 | 1.573
CJ | Burner: | (1/4)
Burner TC | 279.273624 | 10.441 | mV
Cube Cmnecbon
Packet | Softvgare Mnemonc | Low
ACME-Teleme ACME DIAG PMT Tl | 0.00
ACME Teleme ACME DIAG PMT T2 | 0.00
ACME Teleme ACME DIAG PMT T3 | 0.00
Select Items | End Plotting
Clear Sel*ctions
Graph Properties
17:os:,
11 Jun 2021 | 11 Fri Jun 2021
start
14
~~~~

### Pagina 15

Cita: [pdf_af6ea0fe11bcb245ea43, p. 15]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Test 21162A4, continued
After test: 32 on lowest valve safety timer, 1226 psia in oxidizer bottle, 87 psia 
in fuel bottle
15
~~~~

### Pagina 16

Cita: [pdf_af6ea0fe11bcb245ea43, p. 16]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_af6ea0fe11bcb245ea43/p0016.jpg)

~~~~text
Chamber vented, resetting valve safety timers, and refilled to 
1 atm with ~21% O2 (balance N2)
Test 21162C1 (test 6 of 13, hot flame 6 of 12) – run with sustained ignition, 
flowTimeoutSec=300, fuelFlowIgnitionDeltaMs=500, 
fuelIgnitionFlowSlpm=fuelTestFlow1Slpm=0.106, constantFlowTime1Sec=270
dataCamera Zoom=25000, dataCamera Focus=14600
16

[Texto OCR de la imagen]
Chamber vented, resetting valve safety timers, and refilled to
1 atm with 'v21% 02 (balance N2)
Test 21162C1 (test 6 of 13, hot flame 6 of 12) — run with sustained ignition,
flowTimeoutSec=300, fuelFlowIgnitionDeItaMs=500,
fuellgnitionFlowSlpm=fueITestFIow1SIpm=O.106, constantFlowTime1Sec=270
dataCamera Zoom=25000, dataCamera Focus=14600
Gas Flow Charts | o | x
Graphs
2021-06-11 18:14:41 | GMT
State | Cperate | C | 0.000 | SLPM | R | •001 | Fl-a Scale | 20.000 | SLPM
Static Mixer Line (MFCAI)
0.010
18:10 | 18:11 | 18:12 | 18:13 | 18:14
11 Fri Jun 2021 | Time (s)
State | c | 0.000 | SLPM | R | -0.001 | SLPM | scale | 2.000 | SLPM
Bypass(MFCA2)
ACME FLOW | BYPASS SETPOINT | ACME FLOW | BYPASS FLOW
-le-3
-Ze-3
-3e-3
-4e-3
-5e-3
18:10 | 18:11 | 18:12 | 18:13 | 18:14
11 Fri Jun 2021 | Time (s)
State | c | 0.000 | R | 0.001 | SLPM | scale | 0.500 | SLPM
Fuel(MFCA3)
ACME FLOW "3 FUEL SETPOINT | ACME FLOW "3 FUEL FLOW
0.3
18:10 | 18:11 | 18:12 | 18:13 | 18:14
11 fri Jun 2021 | Time (s)
16
~~~~

### Pagina 17

Cita: [pdf_af6ea0fe11bcb245ea43, p. 17]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_af6ea0fe11bcb245ea43/p0017.jpg)

~~~~text
Test 21162C1, continued
- VLC media player | Cool Flame Sensors
Diagnostic
Tn DIG
system state | 2021-06-11 18: 1405 | GMT
System Temperatures
5.000 | set | 32.600
power
Set Al Gans
Board | 34.000
-58.000 | -0.001 | 5.500
Cube Sensor 1 | 34.132
71.000 | -0.001 | 6.000 | 34.186
Cube Sensor 2
0.000 | 0.000 | 5.500 | 25
Hard Drive
Radiometers
Wlan
-0.003285 | -0.137 | TC200A a: 1) | 23.483572 | 0.029
-IO rm-n Lo
-0.000850 | -0.504 | TC20æ crc2) | 21.895211 | -0.035
-IO rnm H G.Sn
-0.001127 | -0.007 | TCCJ | 22.782211 | 0.873
+30 rm Lo Gan
+30 | H Gail | -0.000314 | -0.082 | Array
nn
Rake: Far
+60 ryn LO | -0.001306 | -0.002
27.987923 | 0.211
+60 rrn H Gan | -0.000292 | -0.020
fwdid-/ow | 0.001
60 Deg Ofret | -0.000006 | 1.280
invü40w | -O • 008 | mV
25.143952 | 0.096
Radometer Cold Juncton
60 Deg Ofret | 24.394320 | 1.581
Burner | 157.219872 | 5.517
Cube Connection
Packet | So ftvwe Mnemonic
ACMETe1eme ACME DIAG PMT Tl | 0.00
ACME Teleme ACME DIAG | T2 | 0.00
ACME Teleme ACME DIAG PMT T3 | 0.00
Select [terns | End plotting
Clear Selections | Restart
Graph Properties
18:13:45
11 Jun 2021 | 11 | Jun 2021
start Time
17
~~~~

### Pagina 18

Cita: [pdf_af6ea0fe11bcb245ea43, p. 18]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Test 21162C1, continued
After test: 949 on lowest valve safety timer, 891 psia in oxidizer bottle, 86 psia 
in fuel bottle
18
~~~~

### Pagina 19

Cita: [pdf_af6ea0fe11bcb245ea43, p. 19]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_af6ea0fe11bcb245ea43/p0019.jpg)

~~~~text
Test 21162C2 (test 7 of 13, hot flame 7 of 12) – run with sustained ignition, 
flowTimeoutSec=300, fuelFlowIgnitionDeltaMs=0, fuelIgnitionFlowSlpm=0.159, 
fuelTestFlow1Slpm=0.159, constantFlowTime1Sec=270
dataCamera Zoom=25000, dataCamera Focus=14600
19

[Texto OCR de la imagen]
Test 21162C2 (test 7 of 13, hot flame 7 of 12) - run with sustained ignition,
flowTimeoutSec=300, fuelFIowIgnitionDeItaMs=O, fuellgnitionFIowSIpm=O.159,
fuelTestFlow1Slpm=O.159, constantFlowTime1Sec=270
dataCamera Zoom=25000, dataCamera Focus=14600
Gas Flow Charts | x
Graphs
202106-11
State | Operate | c | 0.000 | SLPM | R | 0.010 | SLPM | Fun Scale | 20.000 | SLPM
Static Mixer Line (MFCAI)
0.010
18:29 | 18:30 | 18:31 | 18:32 | 18:33 | 18:34
11 | Jun 2021 | Tune (s)
State | Cperate | c | 0.000 | SLPM | R | -0.002 | SLPM | scale | 2000 | SLPB•I
Bypass(MFCA2)
ACME FLOW "2 BYPASS SETPOINT | ACME FLOW r•12 BYPASS FLOW
-ose-3
-I.Oe-3
Ise-3
-2.oe-3
-ase-3
-3.oe-3
18:29 | 18:30 | 18:31 | 18:32 | 18:33 | 18:34
11 Fri Jun 2021 | Time (s)
State | Operate | c | 0.000 | SLPM | 0.001 | SLPM | scale | 0.500 | SLPM
Fuel(MFCA3)
ACME FLOW '-.13 FUEL SETPOINT | ACHE FLOW 1-13 FUEL FLOW
0.16
0.14
0.12
0.10
008
0.02
18:29 | 18:30 | 18:31 | 18:32 | 18:33 | 18:34
11 Fri Jun 2021 | Tine (s)
19
~~~~

### Pagina 20

Cita: [pdf_af6ea0fe11bcb245ea43, p. 20]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_af6ea0fe11bcb245ea43/p0020.jpg)

~~~~text
Test 21162C2, continued
- VLC media player | Cocl Flame Sensors | x
Diagnostic
system state | 2021-06-11 | GMT
Systern Tnpera tures
5.000 | CPU | 32.600
Set AI
W/a•n2 | v | CPL' Board | 35.000
-58.000 | Gain | 5.500
Cube Senscr 1 | 33.888
71.000 | -0.000 | 6.000 | Set | 33.884
Cube Senscr 2
0.000 | 0.000 | Gain, | 5.500 | set | 25
CYive
Radiometers
w,'crn2
-0.003303 | -0, 138 | TC200A (TCI) | 23.309955 | 0.022
-10 rrrn Lo
-0.000849 | -0.503 | TC200B crc2) | 22.044215 | -0.029
-10 rrrn H Gü
-0.001190 | -0.011 | 22.782211 | 0.873
+30 mm Lo Gan
+30 | -0.000374 | -0.128
Rake:
+60 rm Lo Gain | -0.001340 | -0.004
27.938528 | 0.209
+60 rm Hi Gah | -0.000332 | -0, 046
invabd-low | 0.000
60 Deg Of€et | -0.000033 | 1.265
invaEd-low | 4).006
28.432381 | 0.229
Radometer Cold Junction
60 Deg Offret | 24.308776 | 1.582
CJ | Butner Sphe+a/ (1/4'
Burner | 94.347399 | 2953
Cube Connecbon
So R.æare Mnernonic
0.00
ACtvE Teleme | 0.00
ACME | 0.00
2-5
Select Items | End Plotthg
Clear Selections | Restart
Graph Properties
18:33: oo | 18B3230
11 Jun 2021 | 11 Fri Jun 2021 | Time
start Tme
20
~~~~

### Pagina 21

Cita: [pdf_af6ea0fe11bcb245ea43, p. 21]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Test 21162C2, continued
After test: 907 on lowest valve safety timer, 900 psia in oxidizer bottle, 85 psia 
in fuel bottle
21
~~~~

### Pagina 22

Cita: [pdf_af6ea0fe11bcb245ea43, p. 22]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_af6ea0fe11bcb245ea43/p0022.jpg)

~~~~text
Test 21162C3 (test 8 of 13, hot flame 8 of 12) – run with sustained ignition, 
flowTimeoutSec=300, fuelFlowIgnitionDeltaMs=0, fuelIgnitionFlowSlpm=0.211, 
fuelTestFlow1Slpm=0.211, constantFlowTime1Sec=270
dataCamera Zoom=25000, dataCamera Focus=14600
22

[Texto OCR de la imagen]
Test 21162C3 (test 8 of 13, hot flame 8 of 12) — run with sustained ignition,
flowTimeoutSec=300, fuelFlowIgnitionDeltaMs=O, fuellgnitionFlowSIpm=O.211,
fuelTestFlow1Slpm=O.211, constantFlowTime1Sec=270
dataCamera Zoom=25000, dataCamera Focus=14600
Gas Flow Charts
Graphs
2021-06-11 18:45:45
State | c | 0•000 | SLPM | R | 0.001 | SLPM | Ft] Scale | 20.000 | SLPM
Static Mixer Line (MFCAI)
ACME FLOW MI MIXER SETPOINT | ACME FLOW MI MIXER FLOW
0.010
18:41 | 18:42 | 1843 | 1844 | 18:45
11 fri Jun 2021 | Time (s)
State | Operate | c | 0.000 | SLPM | R | -0.003 | SLPM | scale | 2.000
Bypass(MFCA2)
I.Oe-3
OSe-3
-1.5e-3
-2.0e-3
-2.5e-3
-3.0e-3
18:41 | 18:42 | 18:43 | 1844 | 18:45
11 fri Jun 2021 | Time (s)
State | Operate | c | 0.000 | SLPM | R | 0.001 | SLPt•1 | scale | 0.500 | SLPM
Fuel(MFCA3)
0.10
18:41 | 18:42 | 18:43 | 18:44 | 18:45
11 fri Jun 2021 | Tine (s)
22
~~~~

### Pagina 23

Cita: [pdf_af6ea0fe11bcb245ea43, p. 23]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_af6ea0fe11bcb245ea43/p0023.jpg)

~~~~text
Test 21162C3, continued
- VLC media player | Cool Flame Sensors | x
Diagnostic
System state | 2021-06-11 18:45:06 | GMT
System
5.000 | Set | cpu | 32.500
Power
Set AI GSns
W/crn2 | CPU Board | 35.000
0.000 | -0.000 | 0.000 | Set
Cut* Sensor 1 | 33.894
0.000 | -0.000 | Gain | 0.000 | Set | 33.887
CL.& Senscr 2
0.000 | -0.001 | Gain | 0.000 | 25
Hard
Radorneters
W /crn2
-0.003356 | TC200A (TCI) | 23.458772 | 0.028
-10 | Lo Gan
-0.000852 | -0.505 | TC200B (TC2) | 22.143541 | -0.025
-10 mrn H Gan
-0.001301 | -0.018 | 22.782211 | 0.873
+30
+30 | H Gah | -0.000476 | -0.207
nn
Rake: Far
+60 | LO Gain | -0.001443 | -0.010
29.074045 | 0.255
+60 | Gah | -0.000432 | -0.112
invabd-low | -0.007 | mV
60 Deg Offret | -0.000067
invabd-low | -0.010
32.817530 | o. 427 | mV
Radometer Cold Junction
60 Deg Offret | 24.308776 | 1.582
Bu•ne—: | (I/"
71.881238 | 2.019
CLbe Connection
Packet | So ftware Mnemonic | Low
ACME Teleme | 0.00
0.00
ACME Teleme | 0.00
2.5
Select Items | End Plotthg
Clear Selections | Restart
Graph Properties
18:44:00
11 | 2021 | 11 | Jun 2021 | Time
Tme
23
~~~~

### Pagina 24

Cita: [pdf_af6ea0fe11bcb245ea43, p. 24]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Test 21162C3, continued
After test: 866 on lowest valve safety timer, 902 psia in oxidizer bottle, 84 psia 
in fuel bottle
24
~~~~

### Pagina 25

Cita: [pdf_af6ea0fe11bcb245ea43, p. 25]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_af6ea0fe11bcb245ea43/p0025.jpg)

~~~~text
Test 21162C4 (test 9 of 13, hot flame 9 of 12) – run with sustained ignition, 
flowTimeoutSec=300, fuelFlowIgnitionDeltaMs=0, fuelIgnitionFlowSlpm=0.317, 
fuelTestFlow1Slpm=0.317, constantFlowTime1Sec=270
dataCamera Zoom=35000, dataCamera Focus=12700
25

[Texto OCR de la imagen]
Test 21162C4 (test 9 of 13, hot flame 9 of 12) — run with sustained ignition,
flowTimeoutSec=300, fuelFlowIgnitionDeltaMs=O, fuellgnitionFlowSlpm=O.317,
fuelTestFlow1Slpm=O.317, constantFlowTime1Sec=270
dataCamera Zoom=35000, dataCamera Focus-12700
Gas Flow Charts | o | x
Graphs
2021-06-11
State | Operate | c | 0•000 | SLPtvl | R | 0.000 | SLPM | F-UISde | 20.000
Static Mixer Line (MFCAI)
-0.002
-0.006
-0.008
-0.010
-0.012
-0.014
19:03 | 19:04 | 19:05 | 19:06 | 19:07
11 Fri Jun 2021 | Time (s)
State | Operate | c | 0.000 | SLPM | 0.001 | scale | 2.000
Bypass(MFCA2)
ACME FLOW | BYPASS SETPOINT | ACME FLOW | BYPASS FLOW
Ze-3
le-3
-le-3
-Ze-3
-3e-3
-se-3
-6e-3
19:03 | 19:04 | 19:05 | 19:06 | 19:07
11 Fri Jun 2021 | Time (s)
State | Operate | c | 0.000 | SLPM | R | 0.001 | scale | 0.500
Fuel(MFCA3)
ACME FLOW "3 FUEL SETPOINT | ACME FLOW "3 FUEL FLOW
0.25
0.10
19:03 | 19:04 | 19:05 | 19:06 | 19:07
11 Fri Jun 2021 | Time (s)
25
~~~~

### Pagina 26

Cita: [pdf_af6ea0fe11bcb245ea43, p. 26]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_af6ea0fe11bcb245ea43/p0026.jpg)

~~~~text
Test 21162C4, continued
- VuC media player | Cool Flame Sensors | x
Diagnostic
ViHe,-,
system state | 2021-06-11 | GMT
System Temperatures
5.000 | 32.500
power
set All
W/crn2 | Board | 34.000
PMT I | 0.000 | -0.001 | 0.000
CLbe Sensor 1 | 33.941
PMT 2 | 0.000 | 0.000 | 0.000 | 33.932
CLbe Sensor 2
PMT 3 | 0.000 | -0.000 | Gain | 0.000 | 25
Hard Drive
Radome ters
w,'cmz | Vdts
-0.003585 | -0.154 | TC200A CTCI) | 23.433970 | 0.027
-IO nm•n Lo
-0.000849 | -0.503 | TC2008 crc2) | 22.764125 | 0.000
-10 mm GSn
-0.001460 | -0.028 | TCCJ | 22.782211 | 0.873
+30 rm-n Lo Gan
+30 | -0.000620 | -0.318 | Array
Rake: Far
+60 | -0.001563 | -0.017
28.432381 | 0.229
+60 | -0.000549 | -o. 189
maid-bw | -0.017 | mV
60 Deg Offret | -0.000092 | 1.232
maid-low | -0.002 | mV
TCD | 26.059793 | 0.133
Radometer Cold Junction
Volts
60 Deg Offset | 24.308776 | 1.582
Butner: | (1/4)
Burner | 62. 165355 | 1.615
Cube Connection
Software Mnernoric | Low
0.00
0.00
ACE- | 0.00
Select Items | End plotting
Clear Selections
Gr aph Properties
11 In 2021 | Jun 2021 | Tüne
Tme
26
~~~~

### Pagina 27

Cita: [pdf_af6ea0fe11bcb245ea43, p. 27]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Test 21162C4, continued
After test: 825 on lowest valve safety timer, 904 psia in oxidizer bottle, 82 psia 
in fuel bottle
27
~~~~

### Pagina 28

Cita: [pdf_af6ea0fe11bcb245ea43, p. 28]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_af6ea0fe11bcb245ea43/p0028.jpg)

~~~~text
Test 21162C5 (test 10 of 13, hot flame 10 of 12) – sustained ignition, run with 
flowTimeoutSec=300, fuelFlowIgnitionDeltaMs=0, fuelIgnitionFlowSlpm=0.499, 
fuelTestFlow1Slpm=0.499, constantFlowTime1Sec=270
dataCamera Zoom=35000, dataCamera Focus=12700
28

[Texto OCR de la imagen]
Test 21162C5 (test 10 of 13, hot flame 10 of 12) — sustained ignition, run with
flowTimeoutSec=300, fuelFlowIgnitionDeltaMs=O, fuellgnitionFlowSIpm=O.499,
fuelTestFlow1Slpm=O.499, constantFlowTime1Sec=270
dataCamera Zoom=35000, dataCamera Focus=12700
Gas Flow Charts
Graphs
2021-06-11 | GMT
State | Operate | c | 0•000 | SLPM | R | -0.004 | SLPM | Fl] Scale | 20.000 | SLPM
Static Mixer Line (MFCAI)
ACME FLOW MI MIXER SETPOINT | ACME FLOW MI MIXER FLOW
0.010
19:25 | 19:26 | 19:27 | 19:28 | 19:29 | 19:30
11 | Jun 2021 | Tirne (s)
State | Operate | c | 0.000 | SLPM | R | -0.002 | SLPM | Fun scale | 2.000 | SLPM
Bypass(MFCA2)
ACHE FLOW | BYPASS SETPOINT | ACME FLOW "2 BYPASS FLOW
Ine-3
OSe-3
-OSe-3
-I.Oe-3
-ISe-3
-2.0e-3
19:25 | 19:26 | 19:27 | 19:28 | 19:29 | 19:30
11 | Jun 2021 | Tine (s)
Operate | c | 0.000 | SLPM | R | -0.000 | SLPM | Fun scale | 0.500 | SLPM
Fuel(MFCA3)
ACME FLOW "3 FUEL SETPOINT | ACME FLOW "3 FUEL FLOW
0.1
19:25 | 19:26 | 19:27 | 19:28 | 19:29 | 19:30
11 | Jun 2021 | Time (s)
28
~~~~

### Pagina 29

Cita: [pdf_af6ea0fe11bcb245ea43, p. 29]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_af6ea0fe11bcb245ea43/p0029.jpg)

~~~~text
Test 21162C5, continued
udp://233.1 | - VLC media player | Cool Flame Sensors | x
Diagnostic
Systan State | 2021-06-11
PMTs | System Tenper atLres
5.000 | cpu | 32.600
power
Set AI (Äns
Board | 35.000
-58.000 | -omo | 5.500 | Set
CLbe Sensor 1 | 34.189
71.000 | -0.000 | 6.000 | Set | 3-4.149
CLbe Sensor 2
3 | 0.000 | -0.000 | Gain | s. 500 | 25
Hard Drive
ters
W/crn2 | Volts
-0.003127 | -0.128 | TC200A (TCI) | 23.582770 | 0.033
-10 nm Lo Gain
-0.000852 | -0.535 | TC200B (TC2) | 22.019383 | -0.030
-10 mm Gdn
-0.000905 | 0.007 | 22.782211 | 0.873
+30 | Lo
+30 | -0.000108 | 0.077 | Array
Rake- FU
+60 rmn Lo Gan | -0.000981 | 0.017
32.301127 | 0.386
+60 nn H Gah | 0.000025 | 0.189
nvabd-bw | 0.005
60 Deg Ofret | 0.000093 | 1.335
hvabd-bw | -O •007
37.527420 | 0.599
Radometer Cold JLnction
Vdts
60 Deg Ofret | 24.394320 | 1.581
62.237596 | 1.618 | mV
Cube Connecåon
11 | Oiiil
packet | Sofraare | Low
Teleme ACME DIAG PMT Tl | 0.00
ACYE Teleme ACME DIAG PMT T2 | 0.00
ACME Teleme ACME DIAG PMT T3 | 0.00
Select [terns | End Plotthg
Clear Selections | Restart
Graph Properties
11 | 2021 | 11 Fri Jun 2021 | Tine
Start
29
~~~~

### Pagina 30

Cita: [pdf_af6ea0fe11bcb245ea43, p. 30]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Test 21162C5, continued
After test: 785 on lowest valve safety timer, 903 psia in oxidizer bottle, 80 psia 
in fuel bottle
30
~~~~

### Pagina 31

Cita: [pdf_af6ea0fe11bcb245ea43, p. 31]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_af6ea0fe11bcb245ea43/p0031.jpg)

~~~~text
Test 21162D1 (test 11 of 13, hot flame 11 of 12) – sustained ignition, run with 
fiberTestPosition=17200, flowTimeoutSec=300, fuelFlowIgnitionDeltaMs=0,
fuelIgnitionFlowSlpm=fuelTestFlow1Slpm=0.106, constantFlowTime1Sec=270
dataCamera Zoom=45000, dataCamera Focus=10025
31

[Texto OCR de la imagen]
Test 21162D1 (test 11 of 13, hot flame 11 of 12) - sustained ignition, run with
fiberTestPosition=17200, flowTimeoutSec=300, fuelFlowIgnitionDeltaMs=O,
fuellgnitionFlowSlpm=fueITestFIow1SIpm=O.106, constantFlowTime1Sec=270
dataCamera Zoom=45000, dataCamera Focus-10025
Gas Flow Charts
Graphs
state | 2021-06-1119:57:44
State | Operate | c | 0•000 | SLPM | R | -0.004 | SLPM | Fu Scale | 20.000 | SLPM
Static Mixer Line (MFCAI)
ACME FLOW MI MIXER SETPOINT | ACME FLOW MI MIXER FLOW
-0005
-0.010
-0.015
19:53 | 19:54 | 19:55 | 19:56 | 19:57
11 Fri Jun 2021 | Time (s)
State | Operate | c | 0.000 | SLPM | -0.002 | SLPM | scale | 2.000
Bypass(MFCA2)
-le-3
-Ze-3
-3e-3
-4e-3
-5e-3
19:53 | 19:54 | 19:55 | 19:56 | 19:57
11 | Jun 2021 | Time (s)
State | Operate | c | 0.000 | SLPM | R | -0.000 | SLPM | scale | 0.500 | SLPM
Fuel(MFCA3)
0.10
0.02
19:53 | 19:54 | 19:55 | 19:56 | 19:57
11 | Jun 2021 | Time (s)
31
~~~~

### Pagina 32

Cita: [pdf_af6ea0fe11bcb245ea43, p. 32]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_af6ea0fe11bcb245ea43/p0032.jpg)

~~~~text
Test 21162D1, continued
VLC media player | Cool Flame Sensors | ><
Diagnostic
system state | 2021-06-11
System Tempera bores
5.000 | 32.600
Power
Set All GSns
WIT, 2 | Board | 35.000
PMT 1 | -58.000 | 0.000 | Gain | 5.500
Cube Sensor 1 | 34.157
PMT 2 | 71.000 | -0.000 | 6.000 | 34.202
Cube Sensor 2
PMT 3 | 0.000 | -0.001 | 5.500 | Set | 25
Hard Drive
W/cm2
-0.003374 | 142 | TC200A act) | 23.210733 | 0.018
-10 mm Lo
4).000852 | -0.505 | TC2008 CC2) | 22.044215 | -0.029
-IO mm G.Sn
0001269 | -0.016 | 22.782211 | 0.873
+30 rnrn Lo
+30 | H Gül | 182
mm
Rake: Far
+60 mrn Lo | 0001443 | -0.010
29.222066 | 0.261
+60 mrn H Gah | -0.000436 | -o. 115
invdid40w | 0.001
60 Deg Of-fret | -0.000052 | 1.254
invdid40w | -0.014 | mV
TCD | 26.702890 | 0.159
Radiorneter Cold Junction
60 Deg Offset | 24.394320 | 1.581
Burner TC | 131.314057 | 4.471
Cube Connection
11 | O[i$
Software Fhemonic | Low
ACNE Teleme | 0.00
Teleme | 0.00
ACNE Teleme | 0.00
Select [terns | End Plotting
Clear Selections
Graph Properties
11 Jun 2021 | 11 | Jun 2021
start Tme
32
~~~~

### Pagina 33

Cita: [pdf_af6ea0fe11bcb245ea43, p. 33]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Test 21162D1, continued
After test: 721 on lowest valve safety timer, 904 psia in oxidizer bottle, 79 psia 
in fuel bottle
33
~~~~

### Pagina 34

Cita: [pdf_af6ea0fe11bcb245ea43, p. 34]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_af6ea0fe11bcb245ea43/p0034.jpg)

~~~~text
Test 21162F1 (test 12 of 13) – no apparent ignition, run with 
igniterPreheatPowerV=2.8, igniterPreheatDurationMs=10000, 
igniterIgnitionPowerV=3, igniterIgnitionDurationMs=10000, 
igniterDelayBeforeRetractMs=8200, fiberTestPosition=0, flowTimeoutSec=300, 
fuelFlowIgnitionDeltaMs=0, fuelIgnitionFlowSlpm=fuelTestFlow1Slpm=0.317, 
constantFlowTime1Sec=270
dataCamera Zoom=35000, dataCamera Focus=12700
34

[Texto OCR de la imagen]
Test 21162F1 (test 12 of 13) - no apparent ignition, run with
igniterPreheatPowerV=2.8, igniterPreheatDurationMs=10000,
igniterIgnitionPowerV=3, igniterIgnitionDurationMs=10000,
igniterDelayBeforeRetractMs=8200, fiberTestPosition=O, flowTimeoutSec=300,
fuelFlowIgnitionDeltaMs=O, fuellgnitionFIowSIpm=fuelTestFIow1SIpm=O.317,
constantFlowTime1Sec=270
dataCamera Zoom=35000, dataCamera Focus-12700
Gas Flow Charts
Graphs
2021-06-1120: 19:59
State | Operate | c | 0.000 | SLPM | R | 0005 | SLPB•I | Ft] Scale | 20.000
Static Mixer Line (MFCAI)
ACME FLOW MI MIXER SETPOINT | ACME FLOW MI MIXER FLOW
0.010
20:16 | 20:17 | 20:18 | 20:19
11 Fri Jun 2021 | Time (s)
Sute | Operate | c | 0.000 | SLPM | R | •001 | SLPM | scale | 2.000 | SLPM
Bypass(MFCA2)
4e-3
3e-3
Ze-3
le-3
-le-3
-Ze-3
20:16 | 20:17 | 20:18 | 20:19
11 fri Jun 2021 | Time (s)
State | Operate | c | 0.000 | R | 0.000 | scale | 0.500
Fuel(MFCA3)
ACME FLOW "3 FUEL SETPOINT | ACME FLOW "3 FUEL FLOW
v, 0.2
0.1
20:16 | 20:17 | 20:18 | 20:19
11 Fri Jun 2021 | Time (s)
34
~~~~

### Pagina 35

Cita: [pdf_af6ea0fe11bcb245ea43, p. 35]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_af6ea0fe11bcb245ea43/p0035.jpg)

~~~~text
Test 21162F1, continued
media player | Cool Flame Sensors | x
Diagnostic
System state | 2021-06-11 20: 19:02 | GMT
PMTs | Systern Ternperatures
5.000 | CPU | 32.700
power
Set All Gains
v | 34.000
PMT 1 | 0.000 | -0.000 | 0.000
Cube Sensor 1 | 34.266
PMT 2 | 0.000 | -0.000 | 0.000 | 34.293
Cube Sensor 2
PMT 3 | 0.000 | 0.000 | Gain | 0.000 | 25
Hard Drive
W /crn2
-0.003462 | -o. 147 | TC200A (TCI) | 23.260345 | 0.020
-10 mm Lo Gah
-0.000852 | -0.505 | TC20E (TC2) | 21.994550 | -0.031 | mV
-10 ryn Hi Gain
-0.001491 | -0.030 | 22.782211 | 0.873
+3) mm | Gan
+30 mm Gan | -0.000643 | -0.336 | Array
Rake: FU
+60 mm Lo Gain | -0.001682 | -0.024
26.777069 | 0.162
+60 mm H | -0.000662 | -0.264
invalid-low | -0.010
60 Deg Offset | -0.000146 | 1.202
invalid-low | -0.018
23.235540 | 0.019
Radiornet& Cold Junction
60 Deg 0%et | 24.479849 | 1.580
5:41: 15 | Burner: Sphere-a/ 7/4'
Burner | 26.381390 | 0.146
CLbe Cornection
packet | So ftvyare rehemonic | Low
ACME Telerne ACME DIAG PMT Tl | 0.00
ACFE Telerne ACME | 0.00
ACME Tee | 0.00
Select Items | End plo tong
Gr aph properties
20:18
11 Ju-1 2021 | 11 Fri Jun 2021 | Tüne
Start Trne
35
~~~~

### Pagina 36

Cita: [pdf_af6ea0fe11bcb245ea43, p. 36]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Test 21162F1, continued
After test: 669 on lowest valve safety timer, 905 psia in oxidizer bottle, 77 psia 
in fuel bottle
36
~~~~

### Pagina 37

Cita: [pdf_af6ea0fe11bcb245ea43, p. 37]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_af6ea0fe11bcb245ea43/p0037.jpg)

~~~~text
Test 21162F2 (test 13 of 13, hot flame 12 of 12) – sustained ignition, run with 
igniterPreheatPowerV=3, igniterPreheatDurationMs=10000,
igniterIgnitionPowerV=3.2, igniterIgnitionDurationMs=10000, 
igniterDelayBeforeRetractMs=8200, fiberTestPosition=0, flowTimeoutSec=300, 
fuelFlowIgnitionDeltaMs=0, fuelIgnitionFlowSlpm=fuelTestFlow1Slpm=0.317, 
constantFlowTime1Sec=270
dataCamera Zoom=35000, dataCamera Focus=12700
37

[Texto OCR de la imagen]
Test 21162F2 (test 13 of 13, hot flame 12 of 12) - sustained ignition, run with
igniterPreheatPowerV=3, igniterPreheatDurationMs=10000,
igniterIgnitionPowerV=3.2, igniterIgnitionDurationMs=10000,
igniterDelayBeforeRetractMs=8200, fiberTestPosition=O, flowTimeoutSec=300,
fuelFlowIgnitionDeltaMs=O, fuellgnitionFlowSlpm=fuelTestFIow1Slpm=O.317,
constantFlowTime1Sec=270
dataCamera Zoom=35000, dataCamera Focus=12700
Gas Flow Charts
Graphs
State | Operate | c | 0.000 | SLPM | -0.000 | SLPM | FLASca1e | 20.000
Static Mixer Line (MFCAI)
0.010
-0.010
-0.015
20:29 | 20:30 | 20:31 | 20:32 | 20:33
11 Fri Jun 2021 | Time (s)
State | Operate | c | 0.000 | SLPM | R | -0.001 | SLPM | scale | 2.000 | SLPM
Bypass(MFCA2)
Ze-3
-Ze-3
-6e-3
20:29 | 20:30 | 20:31 | 20:32 | 20:33
11 Fri Jun 2021 | Time (s)
Operate | c | 0.000 | SLPM | R | 0.001 | SLPM | scale | 0.500 | SLPM
Fuel(MFCA3)
ACME FLOW "3 FUEL SETPOINT | ACME FLOW M3 FUEL FLOW
0.10
20:29 | 20:30 | 20:31 | 20:32 | 20:33
11 fri Jun 2021 | Tine (s)
37
~~~~

### Pagina 38

Cita: [pdf_af6ea0fe11bcb245ea43, p. 38]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_af6ea0fe11bcb245ea43/p0038.jpg)

~~~~text
Test 21162F2, continued
VLC media player | Cool Flame Sensors
Diagnostic
system state | 2021-06-11
PMTS | Systern | es
5.000 | cpu | 32.700
power
Set Al (Äns
w lcm2 | cpu Board | 35."
0.000 | -0.000 | 0.000 | Set
PMT 1 | Gan | Cube | 34043
Sensor 1
PMT 2 | 0.000 | -0.000 | Gain | 0.000 | Set | 34.071
cube sensor 2
PMT 3 | 0.000 | 0.000 | Gain | 0.000 | Set | 25
Hard Crive
W/cm2 | vets
-0.003303 | -0.138 | TC200A CTCI) | 23.458772 | 0.028 | mV
-10 mm Lo Gan
-0.000853 | -0.506 | TC200E (TQ) | 22.466287 | -0.012
-10
-0.001222 | -0.013 | 22.782211 | 0.873
+30 nn Lo Gain
+30 | H | -o. 151 | Array
mm
Rake:
+60 mm Lo Gah | -0.001255 | 0.001
30.159051 | 0.299 | mV
+60 rnm H Gan | -o. 000244 | 0.012
invabd-low | -0•004 | mV
60 Deg Offset | -0.000009 | 1.278
invabd-low | -0.009 | mV
37.625326 | 0.603
Radiometer Cold inctjcn
Volts
60 Deg Offset | 24.479849 | 1.580
Butne Spheeal (1/4'
Burner | 66.112047 | 1.779
Cube
11 | [$0
Packet | Software Phemonic | Low
0.00
ACME Telene | 0.00
ACME | 0.00
Select Items | End Ph tting
Clear Selections
Gr sph Properties
20:32
11 In 2021 | 11 Fri Jun 2021 | Tune
Tme
38
~~~~

### Pagina 39

Cita: [pdf_af6ea0fe11bcb245ea43, p. 39]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Test 21162F2, continued
After test: 611 on lowest valve safety timer, 905 psia in oxidizer bottle, 75 psia 
in fuel bottle
39
~~~~
