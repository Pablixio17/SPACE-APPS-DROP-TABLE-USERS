# CFI Operational Requirements and Protocols

- Identificador: pdf_4e6dc66cb2a4bac01829
- Investigaciones: PSI-39
- Tipo de documento: Engineering Documents
- Estado: processed
- Temas detectados automaticamente: oxygen, pressure, ignition, cool_flames, droplets, hardware

## Fuentes

- [PSI-39_Engineering Documents_CFI Operational Requirements and Protocols.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-39/Engineering%20Documents/PSI-39_Engineering%20Documents_CFI%20Operational%20Requirements%20and%20Protocols.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_4e6dc66cb2a4bac01829, p. 1]. Metodo: native.

~~~~text
Cool Flames Investigation (CFI) Operational Requirements and Protocols
Operational Requirements:
Droplets must be deployed free floating without any residual momentum in the center of the field of view of the CIR 
diagnostics. Diagnostics must be capable of recording the radiant emissions of both hot and cool flames. CIR must 
store be able to store digital imagery data from a full day of test point (approx. 8 burns) for later downlink.
Operational Protocols:
Following setup and initialization of the CIR rack and MDCA, the chamber is filled with the appropriate atmosphere for 
the day’s test points. Conditions vary in pressure (0.5 atm to 5.0 atm) and oxygen concentration (10 to 30%). A 
settling time of approximately 2 minutes elapses prior to initiating the test in order to ensure that the temperature and 
pressure of the chamber gases have stabilized. This settling time is followed by the dispensing of a predetermined 
amount of fuel (based on the target droplet size) onto a support fiber. When sufficient fuel has been dispensed the 
dispensing needles are retracted and a dwell period of at least 10 seconds is allowed for the droplet internal fluid 
motion induced by deployment to subside. This is then be followed by initiating power to an igniter pair for a 
selectable amount of time ranging from 1 second to 5 seconds after which the igniter will be retracted from the field of 
view. A near real-time download of the color camera video is required in order to verify successful droplet 
deployment, ignition, and overall progress of the experiment. Pressure and temperature data of the chamber 
environment is also required in near real time.
~~~~
