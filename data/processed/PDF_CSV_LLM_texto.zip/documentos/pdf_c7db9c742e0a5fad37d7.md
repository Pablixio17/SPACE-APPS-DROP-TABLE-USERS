# 19137 daily test point log

- Identificador: pdf_c7db9c742e0a5fad37d7
- Investigaciones: PSI-10
- Tipo de documento: Raw Data
- Estado: processed
- Temas detectados automaticamente: hardware

## Fuentes

- [PSI-10_Raw Data_19137 daily test point log.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-10/Raw%20Data/PSI-10_Raw%20Data_19137%20daily%20test%20point%20log.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_c7db9c742e0a5fad37d7, p. 1]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_c7db9c742e0a5fad37d7/p0001.jpg)

~~~~text
ACME Daily Test Point Log | 5/18/2019
Downlink Data Limit (MB) = 127,000 | Total = | 86,676
Test Point Name Script Aborts | IPSU1/HiBMS | ACME Camera | Intensified Camera
Downlink
(enter all test | Before IPSUs | Archived | Archived | Archived
Data (MB)
points) | Open | Images | Images | D/L? | Images
19137A1 | 583 | 193 | 901 | 4,298
1913781 | 657 | 199 | 1017 | 4, 794
19137C1 | 553 | 193 | 856 | 4,109
19137D1 | 506 | 162 | 783 | 3,717
19137F1 | 476 | 160 | 737 | 3,520
19137F2 | 521 | 171 | 807 | 3,841
19137F3 | 522 | 163 | 809 | 3,826
19137G1 | 630 | 199 | 975 | 4,620
19137H1 | 554 | 157 | 857 | 4,009
19137J1 | 565 | 164 | 875 | 4,103
191371<1 | 568 | 166 | 878 | 4,124
19137K2 | 551 | 165 | 854 | 4,018
1913711 | 614 | 170 | 951 | 4,435
19137L2 | 672 | 184 | 1040 | 4,846
19137L3 | 687 | 202 | 1064 | 4,997
19137L4 | 672 | 191 | 1040 | 4,866
1913715 | 627 | 172 | 972 | 4,527
19137L6 | 674 | 176 | 1043 | 4,835
1913717 | 628 | 172 | 972 | 4,529
19137L8 | 630 | 173 | 1017 | 4, 662
Date:
~~~~
