# 19115 flow traces etc

- Identificador: pdf_b3c949dcd13ecf4d6682
- Investigaciones: PSI-10
- Tipo de documento: Raw Data
- Estado: processed
- Temas detectados automaticamente: oxygen, pressure, ignition, hardware, operations

## Fuentes

- [PSI-10_Raw Data_19115 flow traces etc.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-10/Raw%20Data/PSI-10_Raw%20Data_19115%20flow%20traces%20etc.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_b3c949dcd13ecf4d6682, p. 1]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_b3c949dcd13ecf4d6682/p0001.jpg)

~~~~text
1
Test 19115A1 – successful test, run with no changes to planned parameters
After test, 941 on lowest valve safety timer, 1447 psia in oxidizer bottle

[Texto OCR de la imagen]
Test 19115A1 — successful test, run with no changes to planned parameters
. t. Gas Flow Charts
—IOS
2019-04-25 | GMT
state | 2019-04-25
system
System Temper atues
Operate | c | 0.000 | QPM | R | -O .008 | SLPM | scale | 20,000 | SLPM | 33.100
cpu
AJI Gains
Static Mixer Line (MFCAI) | Board | 35.000
Cube Sensor 1 | 34.512
ACME FLOW MI MIXER FLOW
Cube Sensor 2 | 34, 523
_0.025
Hard Drive | 26
v. -0.050
19:17 | 19:18 | 19:19 | 19:20 | 19:21 | 19:22
25 Thu Apr 2019 | Tune (s)
200A (TCI) | 26.441302 | 0.121
Operate | 0.000 | -0.000 | scale | 0.500 | 23.345234 | -0.004
State | c | SLPM | R | SLPM | SLPM
TCCJ | 23.460169 | 0.875
Bypass(MFCA2)
ACME FLOW | BYPASS SETPOINT | ACME FLOW | BYPASS FLOW | Rake: Reumoved
in valid -IWI | -150.758 | mV
-ose-3
in valid-lcv,v | -144. | mV
- I.Oe-3
19:17 | 19:18 | 19:19 | 19:20 | 19:21 | 19:22 | invalid-low | -138.931
25 Thu Apr 2019 | Time (s)
TCD | in valid -10" | mV
State | Operate | c | 0.000 | SLPM | R | 0.000 | SLPM | scale | 0.200 | SLPM
Fuel(MFCA3)
Burner | 227.801047 | 8.317
Cube
19:17 | 19:18 | 19:19 | 19:20 | 19:21 | 19:22
25 Thu Apr 2019 | Tune (s)
Time Series Chart #1
Packet | Softvv•are
ACME Teleme | 0.00
ACME Teleme | 0.00
ACME Teleme | 0.00
2.5
> 2.0
Select Items | End plotbng
Clear Selections | 19:21:45
25 Apr 2019 | 25 Thu Apr 2019 | Time
Graph
After test, 941 on lowest valve safety timer, 1447 psia in oxidizer bottle
1
~~~~

### Pagina 2

Cita: [pdf_b3c949dcd13ecf4d6682, p. 2]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_b3c949dcd13ecf4d6682/p0002.jpg)

~~~~text
2
Test 19115 D1 – unsuccessful ignition, just flash(es), run with no changes to 
planned parameters
Run with 0.05-s PMT1 integration time for ignition detection as planned.
After test, 920 on lowest valve safety timer, 1446 psia in oxidizer bottle

[Texto OCR de la imagen]
Test 19115 DI — unsuccessful ignition, just flash(es), run with no changes to
planned parameters
Run with 0.05-s PMTI integration time for ignition detection as planned.
Flow Cherts
2019-04-25 | GMT
state | 2019-04-25
system
System Temperatures
State | Operate | c | 0.000 | SLPM | R | -0.009 | SLPM | h] scale | 20.000 | SLPM | 33.000
All Gains
Static Mixer Line (MFCAI) | Board | 35.000
Cube Sensor 1 | 34,
Cube Sensor 2 | 34.469
-0.005
Hard Drive | 26
-0.010
19:37 | 19238 | 19B9 | 19:40 | 19:41
25 Thu Apr 2019 | Time (s)
200A (TCI) | 24, 726365 | 0.038 | mV
Opera te | 0.000 | 0.000 | scale | o. 500 | 200B (TC2) | 23.710222 | -0.003
State | c | SLPM | R | SLPM | SLPM
TCCJ | 23.799147 | 0.876
Bypass(MFCA2)
Array
Rake: Removed
0.075
invalid-low | -150.7% | mV
0.050
0.025
TCB | invalid-low | -144.810 | mV
19:37 | 19:38 | 19:39 | 19:40 | 19:41 | in valid -lwe | -138,922
mV
25 Thu Apr 2019 | Tine (s)
TCD | invalid-low | -144.374 | mV
Opera te | c | 0.000 | SLPM | R | -0.000 | SLPM | scale | 0.200 | SLPM
Fuel(MFCA3) | Eume-: Sp.•Se+a/ (1/4)
Burner | 37, 114647 | 0.541
0.075
0.050
0.025 | Connected
Cube
19:37 | 19:38 | 19:39 | 19:40 | 19:41
25 Thu Apr 2019 | Tine (s)
Time Series Chart #1
Software Phernoric
ACME Teleme | 0.00
ACME Teleme | 0.00
ACME Teleme | 0.00 | 2.5
Select Items | End Plotting
Clear Selections | Restart
19:40:45 | 1941 | 19:41:15
25 Apr 2019 | 25 Thu Apr 2019 | Time
Graph | 1
After test, 920 on lowest valve safety timer, 1446 psia in oxidizer bottle
2
~~~~

### Pagina 3

Cita: [pdf_b3c949dcd13ecf4d6682, p. 3]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_b3c949dcd13ecf4d6682/p0003.jpg)

~~~~text
3
Test 19115 D2 – successful test, run with fuelFlowIgnitionDeltaMs=2000
After test, 885 on lowest valve safety timer, 1447 psia in oxidizer bottle

[Texto OCR de la imagen]
Test 19115 D2 - successful test, run with fuelFIowIgnitionDeItaMs=2000
. t. Gas How Charts
2019-04-25 m: 17:01
state | 2019-04-25 m: 17:01
system
System Tenperaües
Operate | c | 0.000 | scale | 20.000 | SLPM | 33, 100
cpu
t AI Gains
Static Mixer Line (MFCAI) | Board | 35.000
Set
Cube Sensor 1 | 34.545
set | 34.548
Cube Sensor 2
-0.005
set | Hard trive | 26
-0.010
20:11 | 20:12 | 20:13 | 20:14 | 20:15 | 20:16 | aon
25 Thu Apr 2019 | Tine (s)
OA CTCI) | 24.857216 | 0.057 | mV
Operate | 0.000 | 0.000 | scale | 0.500 | 23. 196402 | -0.010 | mV
State | C | SLPM | R | SLPM | SLPM
23.460169 | 0.875
Bypass(MFCA2)
Array
Rake: Re.•noved
0.10
hvaIid40w | -150.631 | mV
0•05
maid-low | -144.662 | mV
20:11 | 20:12 | 20:13 | 20:14 | 20:15 | 20:16 | 20:1 | hvaid40w | -138.811
mV
25 Thu Apr 2019 | Time (s)
maid-low | -144.295 | mV
State | Operate | c | 0.000 | SLPtv1 | R | -0.000 | SLPM | scale | 0.200 | SLPM
Fuel(MFCA3) | Burne-: Spheea/ (1/4'
Burner | 129.799395 | 4.382
ACME FLOW | FUEL SETPOINT | ACME FLOW | NEL FLOW
0.075
0.050
0.025 | Connected
Cube &nection
20:11 | 20:12 | 20:13 | 20:14 | 20:15 | 20: 16 | 20:1
25 Thu Apr 2019 | Time (s)
Time Series Chart #1
Packet | Softw•are Mnernonic | Low
ACME Teleme | 0.00
ACME Teleme ACME DIAG | T2 | 0.00
ACME Teleme ACME DIAG | T3 | 0.00
2.5
> 2.0
Select Items | End Plotting
Clear Selections | Restart
20:16
25 Apr 2019 | 25 Thu Apr 2019 | Time
Graph | I
After test, 885 on lowest valve safety timer, 1447 psia in oxidizer bottle
3
~~~~

### Pagina 4

Cita: [pdf_b3c949dcd13ecf4d6682, p. 4]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_b3c949dcd13ecf4d6682/p0004.jpg)

~~~~text
4
Test 19115B1 – successful test, run with fuelFlowIgnitionDeltaMs=2000
ACME dataCamera zoom=45000, ACME camera focus=10025 (as in the 
preceding tests, but contrary to the B1 plan).
After test, 818 on lowest valve safety timer, 1446 psia in oxidizer bottle

[Texto OCR de la imagen]
Test 19115B1 — successful test, run with fuelFIowIgnitionDeltaMs=2000
ACME dataCamera zoom=45000, ACME camera focus=10025 (as in the
preceding tests, but contrary to the Bl plan).
. t. Gas Flow Charts
2019-04-25 20:3430
state | 2019-04-25
System' Ten-veratres
State | Operate | c | 0.000 | SLPM | R | -0.008 | SLPM | FLAscale | 20.000 | SLPM | 33.100
cpu
t AI Gans
Static Mixer Line (MFCAI) | Board | 35.000
set
Cube Sensor 1 | 34.545
Cube Sensor 2 | 34.556
-0.005
Hard Drive | 26
-0.010
20:30 | 20:31 | 20:32 | 20:33 | 20234
25 Thu Apr 2019 | Tirne (s)
200A (TCI) | 24.924527 | 0.046
Operate | 0.000 | -0.001 | sue | 0.500 | 200B CC2) | 23.561440 | -0.009 | mV
State | c | SLPM | R | SLPM | SLPM
23.799147 | 0.876
Bypass(MFCA2)
Array
Rake: Removed
"v ü-low | -150.513 | mV
m • alid-lcv,v | 566
20:30 | 20:31 | 20:32 | 20:33 | 20:34 | nvü-low | -138.688
mV
25 Thu Apr 2019 | Time (s)
"valid -lcv,v | mV
State | Operate | 0.000 | SLPM | R | -0.000 | SLPM | scale | 0.200 | SLPM
Fuel(MFCA3) | Burnet Sphere—I
286.650690 | 10.704 | mV
ACME FLOW "3 FUEL SETPOINT | ACME FLOW "3 FUEL FLOW
Cube Connection
20:30 | 20:31 | 20:32 | 20:33 | 20:34
25 Thu Apr 2019 | Time (s)
Time Series Chart #1 | —IOS
packet | Software Mnemonic
ACME Teleme | 0.00
ACME Teleme | 0.00
ACME Teleme | 0.00
2.5
> 2.0
Select Items | End Plotting | I
Clear Se!ections
25 Apr 2019 20:3430.000 | 25 Thu Apr 2019
Graph | I
After test, 818 on lowest valve safety timer, 1446 psia in oxidizer bottle
4
~~~~

### Pagina 5

Cita: [pdf_b3c949dcd13ecf4d6682, p. 5]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_b3c949dcd13ecf4d6682/p0005.jpg)

~~~~text
5
Test 19115 C1 – unsuccessful ignition, just flash(es), run with pmt1Gain=5.75, 
pmt2Gain=pmt3Gain=6.0, fuelFlowIgnitionDeltaMs=5000
ACME dataCamera zoom and focus as planned.
After test, 792 on lowest valve safety timer, 1447 psia in oxidizer bottle

[Texto OCR de la imagen]
Test 19115 Cl — unsuccessful ignition, just flash(es), run with pmt1Gain=5.75
pmt2Gain=pmt3Gain=6.O, fuelFIowIgnitionDeItaMs=5000
ACME dataCamera zoom and focus as planned.
Gas | Charts
File Graphs
2019-04-25 | GMT
system state | 2019-04-25
System Tenperab-res
0.000 | -0.010 | FLAScale | 20.000 | cpu | 33.200
State | SLPM | R | SLPM
Set Al Gains
cpu Board | 35.000
Static Mixer Line (MFCAI)
set
Cube Sensor 1
set | 34.685
Cube Sensor 2
Set | Hard Drive | 26
20:52 | 20:53 | 20:54 | 20:55 | 20:56 | 20:57
25 Thu Apr 2019 | Time (s)
200A (TCI) | 24.998828 | 0.049
200B (TQ) | 23.536641 | -0.010
Operate | C | 0.000 | SLPM | R | 0.000 | SLPM | scale | 0.500 | SLPM
23.799147 | 0.876
Bypass(MFCA2)
Array
Rake: Removed
ACME FLOW | BYPASS SETPOINT | ACME FLOW M2 BYPASS FLOW
invalid-low | -150.119 | mV
-ose-3
nvdid40w | _ 144. 169 | mV
-I.oe-3
20:52 | 20:53 | 20:54 | 20:55 | 20:56 | 20:57 | TCC | invalid40w | 308 | mV
25 Thu Apr 2019 | Time (s)
TCD | invü40w | -143.745 | mV
Operate | c | 0.000 | SLPM | R | 0.000 | SLPM | scale | 0.200
BLrner
Burnet | (1/4)
Fuel(MFCA3)
Burner | 42.756971 | 0.772
ACME FLOW M3 FUEL SETPOINT | ACME FLOW '43 FUEL FLOW
Cube Comecbon
20:52 | 20:53 | 20:54 | 20:55 | 20:56 | 20:57
25 Thu Apr 2019 | Time (s)
Time Series Chart | —IOS
Packet | Software Mnernoric
ACME Tele-ne | 0.00
AC'Æ Telerne | 0.00
AC&IE Teleme ACME DIAG PMT T3 | 0.00
2.5
> 2.0
Select Items | Er,d Plotting
Clear Selections | 20:56:15
25 Apr 2019 | 25 Thu Apr 2019 | Tine
Graph
After test, 792 on lowest valve safety timer, 1447 psia in oxidizer bottle
5
~~~~

### Pagina 6

Cita: [pdf_b3c949dcd13ecf4d6682, p. 6]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_b3c949dcd13ecf4d6682/p0006.jpg)

~~~~text
6
Test 19115B2 – successful test, run with pmt1Gain=5.25, 
pmt2Gain=pmt3Gain=5.5, fuelFlowIgnitionDeltaMs=2000, 
constantFlowTimeSec=5
ACME dataCamera zoom and focus as planned for C1 (not B).
After test, 730 on lowest valve safety timer, 1447 psia in oxidizer bottle

[Texto OCR de la imagen]
Test 19115B2 — successful test, run with pmt1Gain=5.25,
pmt2Gain=pmt3Gain=5.5, fuelFIowIgnitionDeItaMs=2000,
constantFIowTimeSec=5
ACME dataCamera zoom and focus as planned for Cl (not B).
Gas Flow Charts
File Graphs
2019-0+25
2019-04-25
Systern Temperatures
Overate | 0.000 | -0.010 | scale | 20.000 | CPU | 33.300
State | c | R | SLPM | SLPM
set All
Board | 35.000
Static Mixer Line (MFCAI)
Set
Cube Sensor 1 | 34.644
ACME FLOW MI MIXER SETPOINT | ACME FLOW MI MIXER FLOW | Set
Cube Sensor 2 | 34, 646
Hard Drive | 26
-0.02
21:17 | 21:18 | 21:19 | 21:20 | 21:21 | 21:22 | 21:23
25 Thu Apr 2019 | Time (s)
200A trcl) | 25.023594 | 0.050
2008 CTC2) | 23.611036 | -0.007
State | Operate | c | 0.000 | SLPM | R | -0.001 | SLPM | scale | 0.500 | SLPM
TCCJ | 23, 799147 | 0.876 | v
Bypass(MFCA2)
Array
Rake:
le-3
invalid 40'" | -150' 196
TCE | invalid-low | -144.277 | mV
-le-3
21:17 | 21:18 | 21:19 | 21:20 | 21:21 | 21:22 | 21:23 | TCC | invdid40w | -138.391 | mV
25 Thu Apr 2019 | Time (s)
invü40w | -143.884 | mV
Operate | c | 0.000 | SLPM | R | -0.000 | SLPM | scale | 0.200 | SLPM
Burner Sphe±ä/ (1/4
Fuel(MFCA3)
Burner | 288.733021 | 10.790
0•04
0.02 | Cube Connector'
21:17 | 21:18 | 21:19 | 21:20 | 21:21 | 21:22 | 21:23
25 Thu Apr 2019 | Time (s)
Time Series Chart *1
Packet | So ftveare Mnemonic
ACME | ACME DIAG PMT Tl | 0.00
ACME Teleme ACME DIAG | T2 | 0.00
ACME Teleme ACME DIAG | T3 | 0.00 | 0
2.5
> 2.0
Select [terns | End Plotting
Clær Selections
• ¯ | 25 | 2019 | 25 Thu Apr 2019
Star
After test, 730 on lowest valve safety timer, 1447 psia in oxidizer bottle
6
~~~~

### Pagina 7

Cita: [pdf_b3c949dcd13ecf4d6682, p. 7]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_b3c949dcd13ecf4d6682/p0007.jpg)

~~~~text
7
Test 19115F1 – successful test, run with pmt1Gain=5.5, 
pmt2Gain=pmt3Gain=5.75, fuelFlowIgnitionDeltaMs=1500, 
fuelBottleIgnitionFlowRateN2Slpm=0.052, 
nitrogenIgnitionFlowRateN2Slpm=0.078,
fuelBottleTestFlowRateN2Slpm=0.052, nitrogenTestFlowRateN2Slpm=0.078
After test, 683 on lowest valve safety timer, 1447 psia in oxidizer bottle

[Texto OCR de la imagen]
Test 19115F1 — successful test, run with pmt1Gain=5.5,
pmt2Gain=pmt3Gain=5.75, fuelFIowIgnitionDeItaMs=1500,
fuelBottIelgnitionFIowRateN2Slpm=O.052,
nitrogenlgnitionFIowRateN2SIpm=O.078,
fuelBottleTestFlowRateN2Slpm=O.052, nitrogenTestFlowRateN2Slpm=O.078
Gas Flow Charts
File Graphs
m 19-04-25
2019-04-25
System
Operate | 0.000 | -0.010 | Fu' Scale | 20.000 | 33, 300
State | c | SLPt•1 | R
Set All Gains
CPU Board | 35,000
Static Mixer Line (MFCAI)
Cube Sensor 1 | 34,575
Cube Sensor 2 | 34,570
-0005 | Hard | 26
Drive
-0.010
21:40 | 21:41 | 21:42 | 21:43 | 21:44
25 Thu Apr 2019 | Time (s)
200A (TCI) | 24.974061 | 0.048
2008 (TC2) | 23.735017 | -0.002
state | Operate | c | 0.000 | R | -0.000 | scale | 0.500
TCCJ | 23.799147 | 0.876
Bypass(MFCA2)
Array
Rake: Removed
ACME FLOW | BYPASS SETPOINT | ACME FLOW | BYPASS FLOW
0.10 | hvaid40w
-150.406 | mV
maid-low | mV
21:40 | 21:41 | 21:42 | 2143 | 2144 | hvahd-low | -138.571
25 Thu Apr 2019 | Time (s)
hvabd-low | -144.026 | mV
State | Opera te | c | 0.000 | SLPM | R | -0.000 | SLPM | scale | 0.200 | SLPM
Burner
Burner: Sphe±ä/ (V"
Fuel(MFCA3)
Burner | 142.671500 | 4.890 | mV
0.025 | Cube Connection | Connected
21:40 | 21:41 | 21:42 | 21:43 | 21:44
25 Thu Apr 2019 | Time (s)
Time Series Chart $1
1.1
Packet | Soft'*'are Mnemonc | I Low
ACMETeleme ACME DIAG PMT Tl | 0.00
ACME Teleme ACME DIAG PMT T2 | 0.00
0.7
ACME Teleme ACME DIAG PMT T3 | 0.00
0.6
> 0.5
0.2
0.1
Select Items | End Plotthg
Ciear Selections | Restart
21:43:45
25 Apr 2019 21*424.OOO | 25 Thu Apr 2019 | Time
Graph | I
After test, 683 on lowest valve safety timer, 1447 psia in oxidizer bottle
7
~~~~

### Pagina 8

Cita: [pdf_b3c949dcd13ecf4d6682, p. 8]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
8
Test 19115G1 – successful test, run with pmt1Gain=5.5, 
pmt2Gain=pmt3Gain=5.75, fiberIgnitionPosition=fiberTestPosition=0, 
fiberMoveDuringTest=FALSE, fuelFlowIgnitionDeltaMs=1500, 
stabilizationTime1Sec=0, fuelBottleIgnitionFlowRateN2Slpm=0.052, 
nitrogenIgnitionFlowRateN2Slpm=0.078,
fuelBottleTestFlowRateN2Slpm=0.052, nitrogenTestFlowRateN2Slpm=0.078, 
ignitionToTestRampTimeSec=0, constantFlowTimeSec=2, 
rampFlowToZeroSec=20
After test, 640 on lowest valve safety timer, 1447 psia in oxidizer bottle
~~~~

### Pagina 9

Cita: [pdf_b3c949dcd13ecf4d6682, p. 9]. Metodo: native.

~~~~text
9
Test 19115H1 – unsuccessful ignition, just flash(es), run with pmt1Gain=5.5, 
pmt2Gain=pmt3Gain=5.75, fiberIgnitionPosition=fiberTestPosition=0, 
fiberMoveDuringTest=FALSE, fuelFlowIgnitionDeltaMs=1500, 
fuelBottleIgnitionFlowRateN2Slpm=0.052, 
nitrogenIgnitionFlowRateN2Slpm=0.208,
fuelBottleTestFlowRateN2Slpm=0.052, nitrogenTestFlowRateN2Slpm=0.208
ACME dataCamera zoom and focus as planned for C1 (not H).
TOO LATE TO GET A SNAPSHOT OF CONSOLE DATA FOR THIS TEST
After test, 621 on lowest valve safety timer, 1447 psia in oxidizer bottle
~~~~

### Pagina 10

Cita: [pdf_b3c949dcd13ecf4d6682, p. 10]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_b3c949dcd13ecf4d6682/p0010.jpg)

~~~~text
10
Test 19115K1 – successful test, run with pmt1Gain=5.25, 
pmt2Gain=pmt3Gain=5.5, fiberIgnitionPosition=fiberTestPosition=0, 
fiberMoveDuringTest=FALSE, fuelFlowIgnitionDeltaMs=500, 
stabilizationTime1Sec=0, fuelBottleIgnitionFlowRateN2Slpm=0.2, 
nitrogenIgnitionFlowRateN2Slpm=0.3,
ignitionToTestRampTimeSec=0
After test, 589 on lowest valve safety timer, 1447 psia in oxidizer bottle

[Texto OCR de la imagen]
Test 19115K1 — successful test, run with pmt1Gain=5.25,
pmt2Gain=pmt3Gain=5.5, fiberIgnitionPosition=fiberTestPosition=O,
fiberMoveDuringTest=FALSE, fuelFIowlgnitionDeltaMs=500,
stabilizationTime1Sec=O, fuelBottIeIgnitionFIowRateN2SIpm=O.2,
nitrogenlgnitionFIowRateN2SIpm=O.3,
ignitionToTestRampTimeSec=O
.t Gas Flow Charts
—IOS
2019-04-25
2019-04-25 232925
System Temperatures
Opera te | 0.000 | scale | 20.000 | 33.200
State | c | SLF'•4 | R | SLPM | SLPM
set All Gains
CPU Board | 35.000
Static Mixer Line (MFCAI)
Cube Sensor 1 | 34.710
ACME FLOW MI MIXER SETPOINT | ACME FLOW MI MIXER FLOW
Cube Sensor 2 | 34.689
-0.01 | Drive | 26
23:25 | 23: 26 | 23:27 | 23:28 | 23:29
25 Thu Apr 2019 | Tune (s)
200A (TCI) | 25.196940 | 0.057
2008 (TC2) | 23.487041 | -0.012
Opera te | c | 0.000 | SLPM | R | -0.001 | SLPM | scale | 0.500 | SLPM
TCCJ | 23.799147 | 0.876
Bypass(MFCA2)
Array
Rake:
ACME
hvabd -low | mV
0.2
0.1 | maid-low | -144, 116
mV
23:25 | 23:26 | 23:27 | 23:28 | 23:29 | hvabd-low | 276 | mV
25 Thu Apr 2019 | Tirne (s)
nvaEd-low | -143.701
state | Operate | c | 0.000 | R | -0.001 | SLPM | scale | 0.200 | SLPM
Burner
Burn.: | (1/4
Fuel(MFCA3)
55.295919 | 1.289 | mV
ACME FLOW M3 FUEL SETPOINT | ACME FLOW M3 FUEL FLOW
Cube Cmnectjon | Connected
23:25 | 23:26 | 23:27 | 23:28 | 23:29
25 Thu Apr 2019 | Time (s)
Time Series Chart #1
t•lnemoric
ACME Teleme | 0.00
ACME Teleme | 0.00
ACME Teleme ACME DIAG PMT T3 | 0.00 | 2.5
> 2.0
Select Items | End plotthg
Ciear Selections | Restart
25 | 2019 23:29t24.ooo | 25Thu Apr 2019 | Time
Graph | I
After test, 589 on lowest valve safety timer, 1447 psia in oxidizer bottle
10
~~~~

### Pagina 11

Cita: [pdf_b3c949dcd13ecf4d6682, p. 11]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_b3c949dcd13ecf4d6682/p0011.jpg)

~~~~text
11
Test 19115L1 – successful test, run with pmt1Gain=4.75, 
pmt2Gain=pmt3Gain=5.0, fiberIgnitionPosition=fiberTestPosition=0, 
fiberMoveDuringTest=FALSE, fuelFlowIgnitionDeltaMs=5000, 
stabilizationTime1Sec=0, fuelBottleIgnitionFlowRateN2Slpm=0.2, 
ignitionToTestRampTimeSec=0
After test, __ on lowest valve safety timer, __ psia in oxidizer bottle

[Texto OCR de la imagen]
Test 19115L1 — successful test, run with pmt1Gain=4.75,
pmt2Gain=pmt3Gain=5.O, fiberIgnitionPosition=fiberTestPosition=O,
fiberMoveDuringTest=FALSE, fuelFIowlgnitionDeltaMs=5000,
stabilizationTime1Sec=O, fuelBottleIgnitionFlowRateN2Slpm=O.2,
ignitionToTestRampTimeSec=O
.2 Gas Flow Charts
File Gr aphs
2019-04-25 | GMT
state | 2019-04-25
system
Systan Tempera tures
Operate | 0.000 | -0.010 | Ft-iScale | 20.000 | 33, 100
State | SLPM | R | SLPM | SLPM
Set AI Gains
cpu Board | 35,000
Static Mixer Line (MFCAI)
set
Cube Sensor 1 | 34,575
set | 34.599
0.00 | Cube Sensor 2
-0.01 | Set | Hard | 26
Drive
23:38 | 23:39 | 23:40 | 23:41 | 23:42 | 23:43
25 Thu Apr 2019 | Tine (s)
200A (TCI) | 25.345500 | 0.063
200B CTC2) | 24.032516 | 0.010
State | Operate | c | 0.000 | SLPM | R | -0.000 | SLPM | scale | 0.500 | SLPM
23.799147 | 0.876
Bypass(MFCA2)
Array
Rake: Removed
BYPASS SETPOINT
le-3
invalid40w | -150.374 | mV
TCE | invalid-low | _ 144.435 | mV
-le-3
23:38 | 23:39 | 23:40 | 23:41 | 23:42 | 23:43 | invalid-low | -138•575 | mV
25 Thu Apr 2019 | Tine (s)
invalid-low | -143.986 | mV
State | Operate | C | 0.000 | SLPM | R | -0.001 | scale | 0.200 | SLPM
Bl.rrer
Burner | (1/4)
Fuel(MFCA3)
Burner | 97.029889 | 3.023
ACME FLOW "3 FUEL SETPOINT | ACME FLOW | HJEL FLOW
Cube Cornectim
23:38 | 23:39 | 23:41 | 23:42 | 2343
25 Thu Apr 2019 | Time (s)
Time Series Chart #1
Packet | Soft',vare | Low
Teleme ACME DIAG | Tl | 0.00
ACME Telen-,e ACME DIAG | T2 | 0.00
ACME | ACME DIAG | T3 | 0.00
2.5
> 2.0
Select Items | End plotting
Restart
25 Apr 2019 | 25 Thu Apr 2019 | Time
After test, | on lowest valve safety timer, | psia in oxidizer bottle
11
~~~~

### Pagina 12

Cita: [pdf_b3c949dcd13ecf4d6682, p. 12]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
12
Test 19115M1 – no ignition, where igniter didn’t energize (later determined as 
caused by specificity of fuelFlowIgnitionDeltaMs), run with pmt1Gain=5.25, 
pmt2Gain=pmt3Gain=5.5, fiberIgnitionPosition=fiberTestPosition=0, 
fiberMoveDuringTest=FALSE, fuelFlowIgnitionDeltaMs=1750, 
fuelBottleIgnitionFlowRateN2Slpm=0.052, 
nitrogenIgnitionFlowRateN2Slpm=0.035,
fuelBottleTestFlowRateN2Slpm=0.052, nitrogenTestFlowRateN2Slpm=0.035
ACME dataCamera zoom and focus as planned for C1 (not M).
After test, 530 on lowest valve safety timer, 1447 psia in oxidizer bottle
~~~~

### Pagina 13

Cita: [pdf_b3c949dcd13ecf4d6682, p. 13]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
13
Test 19115M2 – no ignition, where igniter didn’t energize (later determined as 
caused by specificity of fuelFlowIgnitionDeltaMs), run identically to test M1 
with pmt1Gain=5.25, pmt2Gain=pmt3Gain=5.5, 
fiberIgnitionPosition=fiberTestPosition=0, fiberMoveDuringTest=FALSE, 
fuelFlowIgnitionDeltaMs=1750, fuelBottleIgnitionFlowRateN2Slpm=0.052, 
nitrogenIgnitionFlowRateN2Slpm=0.035,
fuelBottleTestFlowRateN2Slpm=0.052, nitrogenTestFlowRateN2Slpm=0.035
ACME dataCamera zoom and focus as planned for C1 (not M).
After test, __ on lowest valve safety timer, __ psia in oxidizer bottle
~~~~

### Pagina 14

Cita: [pdf_b3c949dcd13ecf4d6682, p. 14]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_b3c949dcd13ecf4d6682/p0014.jpg)

~~~~text
14
Test 19115N1 – successful test, run with pmt1Gain=5.0, 
pmt2Gain=pmt3Gain=5.25, fiberIgnitionPosition=fiberTestPosition=0, 
fiberMoveDuringTest=FALSE, fuelFlowIgnitionDeltaMs=500, 
stabilizationTime1Sec=0, fuelBottleIgnitionFlowRateN2Slpm=0.2, 
nitrogenIgnitionFlowRateN2Slpm=0.133
ACME dataCamera zoom and focus as planned.
After test, 489 on lowest valve safety timer, 1447 psia in oxidizer bottle

[Texto OCR de la imagen]
Test 19115N1 — successful test, run with pmt1Gain=5.O,
pmt2Gain=pmt3Gain=5.25, fiberIgnitionPosition=fiberTestPosition=O,
fiberMoveDuringTest=FALSE, fuelFIowlgnitionDeltaMs=500,
stabilizationTime1Sec=O, fuelBottIeIgnitionFIowRateN2SIpm=O.2,
nitrogenlgnitionFIowRateN2SIpm=O.133
ACME dataCamera zoom and focus as planned.
Gas Flow Charts
File Graphs
2019-04-26 | GMT
state | 2019-04-26
system
System Temperatures
Operate | 0.000 | -0.010 | 20.000 | 32.800
State | c | SLPM | R | SLPM | scale | SLPM
set All
Board | 34000
Static Mixer Line (MFCAI)
Cube Sensor 1 | 34096
Cube Sensor 2 | 34 135
-0.01 | Hard Drive | 26
1:02 | 1:03 | 1:04 | 1:05 | 1:06
26 Hi Apr 2019 | Time (s)
200A (TCI) | 25.005823 | 0.063
200B (TC2) | 23.246015 | -0.008
Operate | c | 0.000 | SLPM | R | -0.000 | SLPM | scale | 0.500 | SLPM
TCCJ | 23.460169 | 0.875
Bypass(MFCA2)
Array
Rake:
hvabd | -152.224 | mV
-146.205 | mV
1:02 | 1:03 | 1:04 | 1:05 | 1:06 | maid -IWI' | -140.331 | mV
26fri Apr 2019 | Time (s)
maid -IWI' | -145.774 | mV
Operate | c | 0.000 | SLPM | R | 0.000 | SLPM | scale | 0.200 | SLPM
Bunz
Burne-: Spheea/ (1/4,'
Fuel(MFCA3)
64.197580 | 1.672
ACME FLOW M3 FUEL SETPOINT | ACME FLOW M3 FUEL FLOW
Cube Connection
1:02 | 1:03 | 1:04 | 1:05 | 1:06
26 Fri Apr 2019 | Tine (s)
Time Series Chart #1
Packet | Softvvare Mnemonic
ACME Teleme | 0.00
ACME | 0.00
ACME Teleme | 0.00
2.5
> 2.0
Se!ect Items | End PIO tting
Clear Se'ections | Restart
• ¯ | 26 Apr 2019 | 26 fri Apr 2019 | Tine
Star
Graph | 1
After test, 489 on lowest valve safety timer, 1447 psia in oxidizer bottle
14
~~~~

### Pagina 15

Cita: [pdf_b3c949dcd13ecf4d6682, p. 15]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
15
Test 19115M3 – no ignition, where igniter didn’t energize (later determined as 
caused by specificity of fuelFlowIgnitionDeltaMs), run identically to test M1-M2
with pmt1Gain=5.25, pmt2Gain=pmt3Gain=5.5, 
fiberIgnitionPosition=fiberTestPosition=0, fiberMoveDuringTest=FALSE, 
fuelFlowIgnitionDeltaMs=1750, fuelBottleIgnitionFlowRateN2Slpm=0.052, 
nitrogenIgnitionFlowRateN2Slpm=0.035,
fuelBottleTestFlowRateN2Slpm=0.052, nitrogenTestFlowRateN2Slpm=0.035
ACME dataCamera zoom and focus as planned for C1 (not M).
After test, 469 on lowest valve safety timer, 1447 psia in oxidizer bottle
~~~~

### Pagina 16

Cita: [pdf_b3c949dcd13ecf4d6682, p. 16]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_b3c949dcd13ecf4d6682/p0016.jpg)

~~~~text
16
Test 19115M4 – successful test, run with pmt1Gain=5.25, 
pmt2Gain=pmt3Gain=5.5, fiberIgnitionPosition=fiberTestPosition=0, 
fiberMoveDuringTest=FALSE, fuelFlowIgnitionDeltaMs=2000, 
fuelBottleIgnitionFlowRateN2Slpm=0.052, 
nitrogenIgnitionFlowRateN2Slpm=0.035,
fuelBottleTestFlowRateN2Slpm=0.052, nitrogenTestFlowRateN2Slpm=0.035
ACME dataCamera zoom and focus as planned for C1 (not M).
After test, 417 on lowest valve safety timer, 1446 psia in oxidizer bottle

[Texto OCR de la imagen]
Test 19115M4 — successful test, run with pmt1Gain=5.25,
pmt2Gain=pmt3Gain=5.5, fiberIgnitionPosition=fiberTestPosition=O,
fiberMoveDuringTest=FALSE, fuelFIowlgnitionDeItaMs=2000,
fuelBottleIgnitionFlowRateN2Slpm=O.052,
nitrogenlgnitionFIowRateN2Slpm=O.035,
fuelBottleTestFlowRateN2Slpm=O.052, nitrogenTestFlowRateN2Slpm=O.035
ACME dataCamera zoom and focus as planned for Cl (not M).
Gas Flow Charts
File Graphs
2019-04-26 01:34: 17 | GMT
state | 2019-0+26 01:34: 17
system
System Temßrabures
(>erate | 0.000 | -O. 011 | scale | 20.000 | cpu | 33.000
State | c | SLPM | R | SLpM | SLPM
Set Al CÄns
CPU Board | 35.000
Static Mixer Line (MFCAI)
Set
Cube Senstx 1 | 34.531
ACME FLOW MI MIXER SETPOINT | ACME FLOW MI MIXER FLOW | set
0.000 | Cube | 2 | 34.539
-0.005 | set | Hæd | 26
Drive
-0.010
1230 | 1231 | 1:32 | 1:33 | 1:34
26 Fri Apr 2019 | Time (s)
200A (TCI) | 25.048359 | 0.051
200B (TC2) | 23.858985 | 0.003
State | c>erate | c | 0.000 | SLPM | R | -0.000 | SLPM | scale | 0.500 | SLPM
23.799147 | 0.876
Bypass(MFCA2)
Rake: Removed
ACME FLOW | BYPASS SETPOINT | ACME FLOW | BYPASS FLOW
invalid40w | -150•580 | mV
invalid 40" | -144.618 | mV
1:30 | 1:31 | 1:32 | 1:33 | 1234 | invalid -In' | -138.713 | mV
26 | Apr 2019 | Time (s)
invalid -lwe | -144 , 169 | mV
state | Operate | c | 0.000 | R | 0.000 | SLPM | scale | 0.200 | SLPM
Buner
Fuel(MFCA3)
Burner TC | 196.411951 | 7.044
ACME FLOW M3 FUEL SETPOINT | ACME FLOW "3 FUEL FLOW
Comected
1:30 | 1:31 | 1:32 | 1:33
26 Fri Apr 2019 | Time (s)
Time Series Chart
Packet | Softvvare Mrerronic
ACME Telerr,e | 0.00
ACME Teleme | 0.00
ACME | ACME DIAG | T3 | 0.00
2.5
> 2.0
2.]
Select Items | End Plotthg
Ciea:• Se!ectior.e.. | Restart
1233:15 | 1233:45 | 1234:oo
26 Apr 2019 | 26 Hi Apr 2019 | Time
Graph | 1
After test, 417 on lowest valve safety timer, 1446 psia in oxidizer bottle
16
~~~~

### Pagina 17

Cita: [pdf_b3c949dcd13ecf4d6682, p. 17]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_b3c949dcd13ecf4d6682/p0017.jpg)

~~~~text
17
Test 19115P1 – unsuccessful ignition, just flash(es), variation of B1 run with
pmt1Gain=5.5, pmt2Gain=pmt3Gain=5.75, 
fiberIgnitionPosition=fiberTestPosition=0, fiberMoveDuringTest=FALSE,
fuelFlowIgnitionDeltaMs=2500, 
fuelBottleIgnitionFlowRateN2Slpm=fuelBottleTestFlowRateN2Slpm=0.039,
constantFlowTimeSec=115 (as planned for B1, but not used for B2)
After test, 398 on lowest valve safety timer, 1447 psia in oxidizer bottle

[Texto OCR de la imagen]
Test 19115P1 — unsuccessful ignition, just flash(es), variation of Bl run with
pmt1Gain=5.5,
fiberIgnitionPosition=fiberTestPosition=O, fiberMoveDuringTest=FALSE,
fuelFIowIgnitionDeItaMs=2500,
fuelBottIelgnitionFIowRateN2SIpm=fueIBottIeTestFIowRateN2SIpm=O.039,
constantFIowTimeSec=115 (as planned for Bl, but not used for B2)
.t Gas Flow Charts | —IOS
—IOS
2019-04-2601: 47:05
system state | 2019-04-26
System Tempera bures
Operate | 0.000 | -0.009 | F.J scale | 20.000 | cpu | 33.000
c | QPM | R | SLPM
Set All Gains
Board | 35.000
Static Mixer Line (MFCAI)
Cube Sensor 1 | 34.503
ACME FLOW MI MIXER SETPOINT | ACME FLOW MI MIXER FLOW
0.000 | Cube Sensor 2 | 34.503
Hard Drive | 26
-0.010
1:43 | 1:44 | 1:45 | 1:46 | 1:47
26 Fri Apr 2019 | Time (s)
200A act) | 24.751137 | 0.039
2008 (TC2) | 23.735017 | -0.002 | mV
State | Operate | c | 0.000 | SLPM | R | 0.000 | SLPM | scale | 0.500 | SLPM
23.799147 | 0.376
Bypass(MFCA2)
Rake: Removed
ACME FLOW ma_BYPASS SETPOINT | ACME_FLOW | BYPASS_FLOW
invalid-low | -150.610 | mV
-ose-3
invdid40w
-I.oe-3
1:43 | 1:44 | 1:45 | 1:46 | 1:47 | invalid-low | -138,751 | mV
26 fri Apr 2019 | Time (s)
invalid-low | -144.169
State | CEate | 0.000 | SLPM | R | -0.000 | SLPM | u Sde | 0.200 | SLPM
Burner
Burner | (1/4)
Fuel(MFCA3)
Burner | 39.047416 | 0.620
Q.be Cot-nectim | Connected
1:43 | 1:44 | 1:45 | 1:46 | 1:47
26 Fri Apr 2019 | Time (s)
Time Series Chart #1
Softwvare Nhemonic | Low
Actereleme ACME DIAG | Tl | 0.00
ACME Teleme ACME DIAG | T2 | 0.00
ACME | 0.00 | 0 2.5
> 2.0
Select [terns | End Plotting | I
Ciear Selections | 1:46:30 | 1:46:45
26 Apr 2019 01A"04.ooo | 26 Fri Apr 2019 | Time
Graph
After test, 398 on lowest valve safety timer, 1447 psia in oxidizer bottle
17
~~~~

### Pagina 18

Cita: [pdf_b3c949dcd13ecf4d6682, p. 18]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_b3c949dcd13ecf4d6682/p0018.jpg)

~~~~text
18
Test 19115Q1 – successful test, variation of B1 run with pmt1Gain=5.5, 
pmt2Gain=pmt3Gain=5.75, fiberIgnitionPosition=fiberTestPosition=0, 
fiberMoveDuringTest=FALSE, fuelFlowIgnitionDeltaMs=2000, 
fuelBottleIgnitionFlowRateN2Slpm=fuelBottleTestFlowRateN2Slpm=0.065,
constantFlowTimeSec=115 (as planned for B1 and used for P1)
After test, 351 on lowest valve safety timer, 1447 psia in oxidizer bottle

[Texto OCR de la imagen]
Test 19115Q1 — successful test, variation of Bl run with pmt1Gain=5.5,
pmt2Gain=pmt3Gain=5.75, fiberIgnitionPosition=fiberTestPosition=O,
fiberMoveDuringTest=FALSE, fuelFIowIgnitionDeItaMs=2000,
fuelBottIelgnitionFIowRateN2SIpm=fuelBottIeTestFIowRateN2SIpm=O.065,
constantFlowTimeSec=115 (as planned for Bl and used for Pl)
Gas Flow Charts
File Graphs
2019-04-26 02: 10:36 | GMT
state | 2019-04-26 02: 10:36
system
System Temperatur
Operate | 0.000 | -0.009 | FLAScü | 20.000 | 33.200
R | SLPM | SLPM
Set AI Gains
Board | 35.000
Static Mixer Line (MFCAI)
set
Cube Sensor 1 | 34.792
Set | 34.
Cube Sensor 2
Set | Hard Drive | 26
-0.010
1:55 | z:oo | 2:05 | 2:10
26fri Apr 2019 | Time (s)
200A CTCI) | 24.974061 | 0.048
200B (TQ) | 23.710222 | -0.003
State | Operate | c | 0.000 | SLPM | R | -0.001 | SLPM | scale | 0.500 | SLPM
23.799147 | 0.876
Bypass(MFCA2)
Array
Rake: Removed
ACME FLOW | BYPASS SETPOINT | ACME FLOW | BYPASS FLOW
invalid-low | -149.8 IO | mV
-ose-3
TCE | invalid 40 w | -143.876 | mV
-I.oe-3
1:55 | 2:00 | 2:05 | 2:10 | hvü40w | -138•045 | mV
26 Fri Apr 2019 | Time (s)
TCD | invalid-low | -143.460 | mV
c | 0.000 | SLPM | R | -0.000 | SLPM | scale | 0.200 | SLPM
Buner
Burner. | (1/4)
Fuel(MFCA3)
Burner | 178.047584 | 6.310
0.075
E 0.050
0.025 | Connection
1255 | 2:00 | a:os | z: 10
26 Hi Apr 2019 | Time (s)
Vime Series Chart
packet | Softaare Mnemcnc
ACME Teleme ACME DIAG PMT Tl | 0.00
ACME Telen-,e ACME DIAG | 0.00
ACME Teleme | 0.00 | 2.5
> 2.0
Se!ect Items | End Plotting
Clear Se!ections
26 Apr 2019 | 26 fri Apr 2019 | Tine
Graph | I
VLC media player
After test, 351 on lowest valve safety timer, 1447 psia in oxidizer bottle
18
~~~~
