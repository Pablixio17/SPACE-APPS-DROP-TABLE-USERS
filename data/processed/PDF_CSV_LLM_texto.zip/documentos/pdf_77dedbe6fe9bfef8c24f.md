# 19175 test sheets

- Identificador: pdf_77dedbe6fe9bfef8c24f
- Investigaciones: PSI-10
- Tipo de documento: Raw Data
- Estado: processed
- Temas detectados automaticamente: pressure, ignition, hardware, oxygen

## Fuentes

- [PSI-10_Raw Data_19175 test sheets.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-10/Raw%20Data/PSI-10_Raw%20Data_19175%20test%20sheets.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_77dedbe6fe9bfef8c24f, p. 1]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_77dedbe6fe9bfef8c24f/p0001.jpg)

~~~~text
ACME / Flame Design (normal flame) - Science Test Sheet
est date: | CME test | / 1 5
Local time: | est of day#: I
MT: | 7 | Flame of day#:
TEST CONDITIONS | ontrol? | Q fully automated o 'manual'
Test type? o ignition no-flame D4tandard o other
conc. | b % (volume) | Burner type: | 1/4" sphere o jet
xygen
hamber | psia | Fuel Bottle: | CH4 | C2H4 Vo 0/0
pressure:
ent before? | to | psia | Burner fuel conc.: | % (volume)
a no zyes,
Air' added? | to | psia | Fuel flow rate: | slpm (N2 basis)
o no g yes,
Iso just before? o fan a GCa scrub | N2 flow rate: | slpm
INSTRUMENTATION | FP? no o fixed o moving o back-n-forth
Datacam: | o BG7 0 | a CH20 | ROI? M full a reduced | fps
filter? clear RCH* D CH20 0 none | ROI? & full o reduced | fps
o
backlight filter? o no | CIR backlight? no < yes fps? q 15 0 30
eyes
Ignited? o | KLO o | but *
FLAME BEHAVIOR | yes | yes, | ...
Flame | hole/opening(s) | 00t D none o ignition only a little D lots
o asymmetric o
Flame | unsteady blew out | oot@end Q none ignition D little o lots
oscillating o | o
POST-TEST CONDITIONS | xidizer bottle pressure: 513 psia
conc. | % (volume) | alve safety timer | O sec
xygen
3+3
*GENERAL COMMENTS
7L5F
sk | g 6 | Öz-
6 Feb. 2019
~~~~

### Pagina 2

Cita: [pdf_77dedbe6fe9bfef8c24f, p. 2]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_77dedbe6fe9bfef8c24f/p0002.jpg)

~~~~text
ACME / Flame Design (normal flame) - Science Test Sheet
est date: | 2 | 2b ( | 19t-5A
Local time: | 55 | est of day#:
MT: | 1? 175 | SSS | Flame of day #:
TEST CONDITIONS | Control? | fully automated 'manual'
Test type? D ignition o no-flame | o other
xygen conc. | % (volume) | Burner type: | o 1/4" sphere jet
hamber pressure: | psia | Fuel Bottle: CH4 | % o C2H4 | %
ent before? (no o yes, to | psia | Burner fuel conc.. | % (volume)
Air' added? ø no o yes, to | psia | Fuel flow rate: | slpm (N2 basis)
Iso just before? (fan o GC scrub | N2 flow rate: | slpm
INSTRUMENTATION | FP? o no fixed moving o back-n-forth
Datacam: filter? | BG7 | CH20 | ROI? & full reduced | fps
Intensified: filter? a | CH20 none | ROI? 8 full reduced | Z fps
HiBMs: backlight filter? o no | CIR backlight? noa yes fps? 15 0 30
FLAME BEHAVIOR | Ignited? yes no D yes, but
Flame ü asymmetric a hole/opening(s) | 00t o none ignition only o little o lots
Flame D oscillating unsteady blew out | oot@end a none o ignition little o lots
POST-TEST CONDITIONS | Oxidizer bottle pressure: 5S psia
alve safety timer | sec
*GENERAL COMMENTS
6 Feb. 2019
~~~~

### Pagina 3

Cita: [pdf_77dedbe6fe9bfef8c24f, p. 3]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_77dedbe6fe9bfef8c24f/p0003.jpg)

~~~~text
ACME / Flame Design (normal flame) - Science Test Sheet
est date: Onne-? | 201 | CME test | ? I S
Local time: | est of day #:
MT: | / | 175 | "54 | Flame of day | Z
TEST CONDITIONS | ontrol? | R fully automated o 'manual'
Test type? D ignition no-flame xstandard a other
Oxygen conc. | % (volume) * | Burner type: | L 1/4" sphere o jet
hamber pressure: | psia Cerf Fuel Bottle: üCH4 | 0/6 E-C2H4
ent before? Kno o yes, to | psia | Burner fuel conc.: | % (volume)
Air' added? no o yes, to | psia | Fuel flow rate: | slpm (N2 basis)
Iso just before? | fan o GC D scrub
INSTRUMENTATION | FP? Kno fixed o moving back-n-forth
DataCam: filter? E clear o BG7 c] CH* c] CH20 | ROI? e full o reduced | fps
g-lntensified: filter? o clear RCH* o CH20 0 none | ROI? V full o reduced | ZZ fps
HiBMs: backlight filter? noqyes | CIR backlight? no €yes | 15 30
FLAME BEHAVIOR | Ignited? yes o no o yes, but ..
Flame *asymmetric | 00t a none o ignition only o little o lots
Flame E-oscillating & unsteady %lew out | oot@end o none o ignition little a lots
57
*GENERAL COMMENTS
beze
6 Feb. 2019
~~~~

### Pagina 4

Cita: [pdf_77dedbe6fe9bfef8c24f, p. 4]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_77dedbe6fe9bfef8c24f/p0004.jpg)

~~~~text
ACME / Flame Design (normal flame) - Science Test Sheet
Rack Officer (RO): FT | PD (ACME):
DMO (CIR): | Researcher:
CONDITIONS | Control? | &fully automated o 'manual'
TEST
Test type? o ignition no-flame standard a other
conc. | % (volume) | * Burner type: | &1/4" sphere o jet
xygen
hamber | psia | Fuel Bottle: | CH4 | 960 C2H4ic.2.> %
pressure:
ent before? | to | psia | Burner fuel conc.: | % (volume)
Qo o yes,
Air' added? | Fuel flow rate: | slpm (N2 basis)
gno o yes, to | psia
Iso just before? Qfan GC o scrub | N2 flow rate: | slpm
INSTRUMENTATION | F P? o no o fixed imoving o back-n-forth
filter? | BG7 CH* o CH20 | ROI? Rfull o reduced | fps
kDataCam: | o | 0
Clntensified: filter? clear | o CH20 0 none | ROI? *full o reduced | fps
g-HiBMs: backlight filter? | CIR backlight? no Ryes fps? 15 0 30
o no Elyes
Ignited? ß'es | o | but *
FLAME BEHAVIOR | no yes, | ...
Flame | 00t o none o ignition only o little o lots
o asymmetric o hole/opening(s)
Flame | blew out | oot@end o none ignition o little o lots
o oscillating o unsteady o
POST-TEST CONDITIONS | Oxidizer bottle pressure: | psia
33, z % (volume) | alve safety timer | sec
xygen conc.
*GENERAL COMMENTS
6 Feb. 2019
~~~~

### Pagina 5

Cita: [pdf_77dedbe6fe9bfef8c24f, p. 5]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_77dedbe6fe9bfef8c24f/p0005.jpg)

~~~~text
ACME / Flame Design (normal flame) - Science Test Sheet
est date: | CME test
Local time: | 3.•22 | est of day #:
GMT: | 7/7 | 'Z 2— d | Flame of day#: 4
TEST CONDITIONS | ontrol? | fully automated o •manual'
Test type? o ignition no-flamedstandard o other
xygen conc. | v H o % (volume) | Burner type: | 1/4" sphere jet
hamber pressure: | // •S psia | Fuel Bottle: a CH4 | % | 2H4
ent before? gno o yes, to | psia | Burner fuel conc.: | % (volume)
Air' added?Äno o yes, to | psia | Fuel flow rate.•ö. | slpm (N2 basis)
Iso just before? | fan o GC o scrub | N2 flow rate: o.) | slpm
INSTRUMENTATION | F P? no o fixed o moving o back-n-forth
DataCam: filter? clear BG7 a CH* o CH20 | ROI?zffi full o reduced | fps
Intensified: filter? o clear o CH* o CH20 0 none | ROI? & full o reduced | fps
o HiBMs: backlight filter? no yes | CIR backlight? o no o yes fps? 0 15 D 30
FLAME BEHAVIOR | u, | Ignited? yes o no o yes, but .
Flame o asymmetric o hole/opening(s) | 00t o none o ignition only | lots
Flame o oscillating a unsteady c blew out | oot@end none o ignition little o lots
POST-TEST CONDITIONS | Oxidizer bottle pressure: 5/ | psia
alve safety timer | sec
*GENERAL COMMENTS
6 Feb. 2019
~~~~

### Pagina 6

Cita: [pdf_77dedbe6fe9bfef8c24f, p. 6]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_77dedbe6fe9bfef8c24f/p0006.jpg)

~~~~text
ACME / Flame Design (normal flame) Science Test Sheet
date: | CME test #: | -vgz-
est
oca' time: | est of day #:
MT: | Flame of day | 5
Control? | &fully automated o 'manual'
TEST CONDITIONS
Test type? o ignition no-flame standard o other
conc. | Y o % (volume) | Burner type: | /4" sphere jet
xygen
Fuel Bottle: | CH4 | 96ÄC2H4 | %
hamber pressure: | psia
before?Kno | to | psia | Burner fuel conc.: | % (volume)
ent | o yes,
Air' added? | Fuel flow rate: | slpm (N2 basis)
no o yes, to | psia
Iso just before? | fan o GC o scrub | N2 flow rate: | slpm
INSTRUMENTATION | FP? no o fixed moving o back-n-forth
filter? clear BG7 CH* CH20 | ROI? o full ü reduced | fps
"Datacam:
filter? clear CH* CH20 0 none | ROI? o full o reduced | fps
Plntensified: | o | o
iBMs: backlight filter? no | CIR backlight? no yes fps? 0 15 0 30
yes
FLAME BEHAVIOR | Ignited? yes o no yes, but ...*
Flame | 00t none o ignition only o little o lots
asymmetric o hole/opening(s)
blew out | oot@end none a ignition a tittle lots
Flame o oscillating a unsteady c
POST-TEST CONDITIONS | Oxidizer bottle pressure: | psia
% (volume) | alve safety timer | Z..+ sec
xygen conc. | os
*GENERAL COMMENTS
6 Feb. 2019
~~~~

### Pagina 7

Cita: [pdf_77dedbe6fe9bfef8c24f, p. 7]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_77dedbe6fe9bfef8c24f/p0007.jpg)

~~~~text
ACME / Flame Design (normal flame) - Science Test Sheet
est date: f | CME test
Local time: | est of day #:
MT: | Flame of day #:
Rack Officer (RO): | PD (ACME):
DMO (CIR): | Researcher:
TEST CONDITIONS | Control? | z-fülly automated 'manual'
Test type? ignition no-flame o standard o other
xygen conc. | % (volume) | Burner type: | X17ä" sphere o jet
Chamber pressure: | psia | Fuel Bottle: | CH4 | %D-G2H4 | %
ent before? | o o yes, to | psia | Burner fuel conc.: | (volume)
Air' added?€ no o yes, to | psia | Fuel flow rate? | slpm (N2 basis)
Iso just before? | fan o GC scrub | N2 flow ratee | slpm
INSTRUMENTATION | FP? no a fixe | moving o back-n-forth
DataCam: filter? Yclear BG7 0 CH* o CH20 | ROI? Qfull reduced | fps
A Intensified: filter? o clear | CH20 none | ROI? *full o reduced | fps
iBMs: backlight filter? no | CIR backlight? o no Ryes fps? | 0 30
FLAME BEHAVIOR | Ignited? yes o no yes, but ...*
Flame o asymmetric o hole/opening(s) | 00t o none o ignition only o little o lots
Flame c oscillating o unsteady o blew out | oot@end o none D ignition little o lots
POST-TEST CONDITIONS | Oxidizer bottle pressure: | psia
alve safety timer | O | sec
6 Feb. 2019
~~~~

### Pagina 8

Cita: [pdf_77dedbe6fe9bfef8c24f, p. 8]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_77dedbe6fe9bfef8c24f/p0008.jpg)

~~~~text
ACME / Flame Design (normal flame) Science Test Sheet
Control? | {fully automated o 'manual'
TEST CONDITIONS
Test type? o ignition o no-flame Zstandard o other
D % (volume) | Burner type: | 1/4" sphere o jet
xygen conc.
Fuel Bottle: CH4 | % o C2H4
hamber pressure: | psia QR
Burner fuel conc.: | % (volume)
ent before? no o yes, to | psia
Fuel flow rate: | slpm (N2 basis)
Air' added? Eno o yes, to | psia
Iso | before? | o GC o scrub | N2 flow rate: | slpm
just
FP? o no a fixed | o back-n-forth
INSTRUMENTATION
CH20 | ROI? Efull reduced | fps
Ø DataCam: filter? | BG7
filter? | CH20 none | ROI? g-full o reduced | Z fps
Intensified: | o clear XCH* | 0
filter? | CIR backlight? no Byes fps? | 30
Ø4iBMs: backlight | no Eyes
Ignited? | but .
FLAME BEHAVIOR
hole/opening(s) | 00t | a ignition only Bittie Klots
Flame o asymmetric o
oot@end | one o ignition o little lots
Flame o oscillating o unsteady o blew out
CONDITIONS | Oxidizer bottle pressure: | / psia
POST-TEST
% (volume) | alve safety timer | 5ZD sec
xygen conc.
*GENERAL COMMENTS
454-
6 Feb. 2019
~~~~

### Pagina 9

Cita: [pdf_77dedbe6fe9bfef8c24f, p. 9]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_77dedbe6fe9bfef8c24f/p0009.jpg)

~~~~text
ACME / Flame Design (normal flame) Science Test Sheet
TEST CONDITIONS | Control? | fully automated ü 'manual'
Test type? D ignition no-flameAstandard other
conc. | % (volume) | Burner type: | €1/4" sphere o jet
xygen
hamber | psia | Fuel Bottle: | CH4 | % ßC2H4 e-0/6
pressure:
ent before? no o | to | psia | Burner fuel conc.: | % (volume)
x | yes,
Air' added? | to | psia | Fuel flow rate: D-105 slpm (N2 basis)
zno o yes,
Iso just before? Rfan a GC scrub | N2 flow rate: | slpm
INSTRUMENTATION | FP? o no o fixed moving back-n-forth
DataCam: filter? g-clear BG7 CH* CH20 | ROI? Bfull o reduced | fps
Intensified: filter? D clear CCH* CH20 none | ROI?cé full o reduced | 2-2 fps
LHiBMs: backlight filter? no Ä.yes | CIR backlight? nou yes fps? K 15 30
FLAME BEHAVIOR | Ignited? yes o no D yes, but .
Flame | hole/opening(s) | 00t (none o ignition onlyßittle lots
o asymmetric
Flame | unsteady blew out | oot@end none o ignition a little o lots
o oscillating o | o
POST-TEST CONDITIONS | Oxidizer bottle pressure: L psia
conc. 37-3 | % (volume) | alve safety timer | 4 | sec
xygen
*GENERAL COMMENTS
* 3763 Z
6 Feb. 2019
~~~~

### Pagina 10

Cita: [pdf_77dedbe6fe9bfef8c24f, p. 10]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_77dedbe6fe9bfef8c24f/p0010.jpg)

~~~~text
ACME / Flame Design (normal flame) - Science Test Sheet
ontrol? | automated o 'manual'
TEST CONDITIONS
Test type? ignition no-flameustandard o other
% (volume) | Burner type: | sphere o jet
xygen conc.
psia | Fuel Bottle: | CH4 | 0/6 y-C2H4
hamber pressure: | OR
Burner fuel conc.: | % (volume)
ent before? | o o yes, to | psia
Fuel flow rate: | slpm (N2 basis)
Air' added? no o yes, to | psia
before? | fan GC scrub | N2 flow rate: | slpm
Iso just | a
c] fixed D moving o back-n-forth
INSTRUMENTATION
CH20 | ROI? *full o reduced | fps
(Datacam: filter? | o BG7 0
CH20 | ROI? *full o reduced | fps
Intensified: filter? clear *CH* | 0 none
filter? | CIR backlight? no pyes | 30
g HiBMs: backlight | no
Ignited? yes no o yes, but .
FLAME BEHAVIOR | w
00t «ne o ignition only | lots
Flame o asymmetric o hole/opening(s)
oot@end | o ignition o little lots
Flame o oscillating o unsteady a blew out | xnone
xidizer bottle pressure: | psia
POST-TEST CONDITIONS
% (volume) | alve safety timer | sec
xygen conc.
*GENERAL COMMENTS
6 Feb. 2019
~~~~

### Pagina 11

Cita: [pdf_77dedbe6fe9bfef8c24f, p. 11]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_77dedbe6fe9bfef8c24f/p0011.jpg)

~~~~text
ACME / Flame Design (normal flame) - Science Test Sheet
est date: | CME test | 75
Local time: | est of day #:
Flame of day
TEST CONDITIONS | ontrol? | {fully automated 'manual'
Test type? o ignition a no-flame Lstandard o other
Oxygen conc. | % (volume) | Burner type: | K 1/4" sphere o jet
hamber pressure: | psia | 4K Fuel Bottle: | CH4 | % RC2H4
ent before? (no o yes, to | psia | > Burner fuel conc.: | % (volume)
Air' added?zno o yes, to | psia | Fuel flow rate: | (N2 basis)
Iso just before? Rfan GC o scrub | N2 flow rate: 0 e slpm
INSTRUMENTATION | FP? no fixed D moving o back-n-forth
QDataCam: filter? bclear BG7 0 CH* CH20 | ROI? Qfull o reduced | fps
Intensified: filter? o clear RCH* CH20 0 none | ROI? Efull o reduced | Z fps
zHiBMs: backlight filter? ono yes | CIR backlight? no Zyes | 30
FLAME BEHAVIOR e,.+u-, | Ignited? | es o no o yes, but *
...
Flame o asymmetric o hole/opening(s) | 00t *none a ignition only little lots
Flame oscillating unsteady o blew out | oot@end none D ignition little D lots
*GENERAL COMMENTS
384" | Lea-u4-e-5+-k—
6 Feb. 2019
~~~~

### Pagina 12

Cita: [pdf_77dedbe6fe9bfef8c24f, p. 12]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_77dedbe6fe9bfef8c24f/p0012.jpg)

~~~~text
ACME / Flame Design (normal flame) - Science Test Sheet
ontrol? | automated 'manual'
TEST CONDITIONS
Test type? ignition o no-flame standard other
% (volume) | Burner type: | *1/4" sphere jet
xygen conc.
e4 psia | Fuel Bottle: o CH4 | % AC2H4
hamber pressure: | /
before? | Burner fuel conc.: | % (volume)
ent | o o yes, to | psia
Fuel flow rate: Dec—lpm (N2 basis)
Air' added? gno o yes, to | psia
Iso | before? | fan GC o scrub | N2 flow rate: | '2.slpm
just
FP? ü no fixeNmoving o back-n-forth
INSTRUMENTATION
filter? | BG7 | CH20 | ROI? Qfull reduced | fps
DataCam: | aclear
filter? clear | CH20 0 none | ROI? Rfull o reduced | Z fps
Intensified: | o
KHiBMs: | filter? | CIR backlight? noøyes fps? | 30
backlight | no oes
BEHAVIOR | 82 | Ignited? Kyesonooyes, but.
FLAME
00t o none o ignition only o little Ots
Flame o asymmetric hole/opening(s)
blew out | oot@end none c] ignition o tittle o lots
Flame oscillating unsteady o
CONDITIONS | xidizer bottle pressure: A | psia
POST-TEST
% (volume) | alve safety timer | 29 | sec
xygen conc. 37.
*GENERAL COMMENTS
EeZrz—
O.-æ
6 Feb. 2019
~~~~

### Pagina 13

Cita: [pdf_77dedbe6fe9bfef8c24f, p. 13]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_77dedbe6fe9bfef8c24f/p0013.jpg)

~~~~text
ACME / Flame Design (normal flame) - Science Test Sheet
est date: | CME test #:
Local time: | est of day #:
MT: | 174 | Flame of day #:
TEST CONDITIONS | ontrol? | Afully automated o 'manual'
Test type? o ignition a no-flame standard o other
xygen conc. | % (volume) | * Burner type: | Kl/4" sphere o jet
hamber pressure: | sia | Fuel Bottle: | CH4 | 960 C2H4
ent before? no o yes, to | psia | Burner fuel conc.: | % (volume)
Air' added? guno o yes, to | psia | Fuel flow rate: | Io slpm (N2 basis)
Iso just before? | fan o GC o scrub | N2 flow rate: | slpm
INSTRUMENTATION | no o fixed moving back-n-forth
Datacam: filter? *clear o BG7 0 | CH20 | ROI? Afull reduced | fps
filter? o clear [Y-CH* o CH20 a none | ROI? full o reduced | ZZ fps
backlight filter? o no eyes | CIR backlight? no Kyes fps?K15 30
FLAME BEHAVIOR | Ignited? Kyes a no yes, but ...*
Flame o asymmetric o hole/opening(s) | 00t D none (ignition only o little D lots
Flame o oscillating o unsteady o blew out | oot@end none ignition a little lots
POST-TEST CONDITIONS | xidizer bottle pressure: | psia
xygen conc. | 3 | % (volume) | alve safety timer | 25b sec
*GENERAL COMMENTS
* | % Ö2_ | 4-4
6 Feb. 2019
~~~~

### Pagina 14

Cita: [pdf_77dedbe6fe9bfef8c24f, p. 14]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_77dedbe6fe9bfef8c24f/p0014.jpg)

~~~~text
ACME / Flame Design (normal flame) - Science Test Sheet
est date: | une24 | CME test#•. Fas
Local time: | est of day | / +
MT: | 16 | O | Flame of day#: 2—
TEST CONDITfONS | ontrol? | Rfully automated o 'manual'
Test type? o ignition o no-flame Q$tandard o other
xygen conc. | a-4-D % (volume) 4— Burner type: | d-1/4" sphere a jet
hamber pressure: | /$A- psia | OR Fuel Bottle: üCH4 | % d-C2H4
ent before? | o yes, to | psia | Burner fuel conc.: | % (volume)
Air' added? yno o yes, to | psia | Fuel flow rate: | slpm (N2 basis)
Iso just before? | an o GC o scrub | N2 flow rate: | slpm
INSTRUMENTATION | FP? c no fixed Rmoving o back-n-forth
'-Datacam: filter? | BG7 | CH20 | ROI? | o reduced | fps
_
Intensified: filter? o clear uCH* CH20 0 none | ROI? full reduced | 2.2 fps
QHiBMs: backlight filter? o no eyes | CIR backlight? no yes fps? X15 D 30
FLAME BEHAVIOR | Ignited? | D yes, but .
Flame o asymmetric o hole/opening(s) | 00t o none o ignition only o little o lots
Flame o oscillating o unsteady o blew out | oot@end a none ignition o little o lots
POST-TEST CONDITIONS | xidizer bottle pressure: 94 psia
xygen conc. | % (volume) | alve safety timer | 743 sec
*GENERAL COMMENTS
6 Feb. 2019
~~~~

### Pagina 15

Cita: [pdf_77dedbe6fe9bfef8c24f, p. 15]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_77dedbe6fe9bfef8c24f/p0015.jpg)

~~~~text
ACME / Flame Design (normal flame) - Science Test Sheet
est date: | CME test #: | 17
Local time: | 50 | est of day#: t
D
GMT: | Flame of day #:
CONDITIONS | Control? | <fully automated o 'manual'
TEST
Test type? ignition no-flame<standard other
conc. | % (volume) * | Burner type: | (1/4" sphere o jet
xygen
Fuel Bottle: | CH4 | 0/6ZC2H4 be %
hamber pressure: | psia
ent before? | to | psia | Burner fuel conc.: | % (volume)
Qno o yes,
Air' added? | to | psia | Fuel flow rate: | slpm (N2 basis)
Eno o yes,
Iso just before? | GC o scrub | N2 flow rate: a 06 slpm
INSTRUMENTATION | FP? {no fixed o moving o back-n-forth
DataCam: filter? 'Clear a BG7 CH* CH20 | ROI? & full o reduced | fps
k
zlntensified: filter? clear ECH* CH20 none | o reduced | fps
VHiBMs: backlight filter? no Qyes | CIR backlight? no | fps? €15 30
Ignited? «yes o no o | but *
FLAME BEHAVIOR | yes, | ...
Flame | hole/opening(s) | 00t none o ignition only o little o lots
o asymmetric o
Flame | blew out | oot@end o none ignition tittie D lots
o oscillating unsteady a
POST-TEST CONDITIONS | Oxidizer bottle pressure: 5/' psia
conc. | % (volume) | alve safety timer | sec
xygen
*GENERAL COMMENTS
6 Feb. 2019
~~~~

### Pagina 16

Cita: [pdf_77dedbe6fe9bfef8c24f, p. 16]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_77dedbe6fe9bfef8c24f/p0016.jpg)

~~~~text
ACME / Flame Design (normal flame) - Science Test Sheet
est date: | 24 | CME test#: 121
tow
Local time: | est of day
MT: | 174 | -z: 38 | Flame of day #:
TEST CONDITIONS | Control? | ifully automated 'manual'
Test type? o ignition no-flame {standard o other
xygen conc. | A.- D 0/0 (volume) | Burner type: | Yd/4" sphere jet
hamber | psia | R Fuel Bottle: | CH4 | % ÉC2H4 Øb0/0
pressure:
ent before? Rno o | to | psia | Burner fuel conc.: | % (volume)
yes,
Air' added? A-no o | to | psia | Fuel flow rate: | slpm (N2 basis)
yes,
Iso just before? efan a GC o scrub | N2 flow rate: DVSZslpm
INSTRUMENTATION | FP? o no o fixed o moving back-n-forth
o DataCam: filter? clear o BG7 | CH20 | ROI? o full o reduced | fps
D Intensified: filter? o clear a CH* o CH20 0 none | ROI? o full reduced | fps
o HiBMs: backlight filter? no yes | CIR backlight? o no yes fps? 0 15 0 30
BEHAVIOR | Ignited? | es o no o | but *
FLAME | yes, | ...
Flame asymmetric o hole/opening(s) | 00t o none o ignition only o littleklots
Flame o oscillating unsteady o blew out | oot@end o none D ignition littleÅlots
POST-TEST CONDITIONS | Oxidizer bottle pressure: | psia
alve safety timer | sec
*GENERAL COMMENTS
6 Feb. 2019
~~~~
