# 19175 test point log

- Identificador: pdf_0f6bb76ec5b08ce877bc
- Investigaciones: PSI-10
- Tipo de documento: Raw Data
- Estado: processed
- Temas detectados automaticamente: hardware

## Fuentes

- [PSI-10_Raw Data_19175 test point log.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-10/Raw%20Data/PSI-10_Raw%20Data_19175%20test%20point%20log.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_0f6bb76ec5b08ce877bc, p. 1]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_0f6bb76ec5b08ce877bc/p0001.jpg)

~~~~text
ACME Daily Test Point Log | 6/25/2019
Downlink Data Limit (MB) = 127,000 | Total = | 115,339
Test Point Name Script Aborts | IPSU1/HiBMS | ACME Camera | Intensified Camera
Downlink
(enter all test | Before IPSUs | Archived | Archived | Archived
Data (MB)
points) | Open | Images | Images | D/L? | Images
19175A1
19175A2 | 940 | 326 | 1456 | 6,981
19175A3 | 2300 | 1143 | 3559 | 18,073
19175A4 | 1021 | 143 | 1581 | 6,969
19175B1 | 703 | 333 | 1086 | 5,472
1917582 | 418 | 219 | 647 | 3,318
1917583 | 424 | 2 | 77 | 1,110
19175B4 | 1333 | 1411 | 2066 | 12,655
1917585 | 1033 | 979 | 1598 | 9,466
19175B6 | 826 | 270 | 1279 | 6,086
19175B7 | 883 | 120 | 1366 | 6,013
19175B8 | 947 | 127 | 1466 | 6,447
19175B9 | 838 | 275 | 1298 | 6,178
19175N1 | 1400 | 199 | 2163 | 9,551
19175N2 | 1154 | 438 | 1786 | 8,676
19175N3 | 1119 | 400 | 1733 | 8,344
24
Date: | 14
~~~~
