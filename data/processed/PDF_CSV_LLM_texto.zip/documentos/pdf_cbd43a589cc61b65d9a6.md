# 21174 test parameter notes

- Identificador: pdf_cbd43a589cc61b65d9a6
- Investigaciones: PSI-159
- Tipo de documento: Raw Data
- Estado: processed
- Temas detectados automaticamente: ignition, extinction, hardware, operations

## Fuentes

- [PSI-159_Raw Data_21174 test parameter notes.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-159/Raw%20Data/PSI-159_Raw%20Data_21174%20test%20parameter%20notes.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_cbd43a589cc61b65d9a6, p. 1]. Metodo: windows_ocr_grid_removed.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_cbd43a589cc61b65d9a6/p0001.jpg)

~~~~text
testpointName | 21174A1
dataCameraPrelgnitionExposureUs | 1000000
dataCameraTestExposureUs | 100000
analogCameraShutter | 2
uselntensifiedCamera | TRUE
intensifierlgnitionGain | 20000
intensifier TestGain | 60000
preignitionlmageTimeSec
postFlamelmagingTimeSec | 5
useDataCameraAut0Gain | FALSE
autoGainT01erancePercent | 5
autoGainMaxDb | 33
autoGainMinDb
autoGainOutliers
autoGainRatePercent | 100
autoGainTargetPercent | 50
rampDataCameraGain | FALSE
dataCameraGain1dB
dataCameraGain2dB
dataCameraGain3dB
dataCameraHoldTime1Sec
dataCameraH01dTime2Sec
dataCa meraRamp1t02TimeSec
dataCa meraRamp2t03TimeSec | 5
dataCameraManualGain | '33
useBracketedExposures | FALSE
bracketinglmagesPerExposure | 1
bracketingNumberOfExposures | 4
bracketingExposureStartUsec | sooo
bracketingExposureMultiplierTimes100 | '1000
igniterStartPosition | 2170
igniterEndPosition | 2290
igniterVelocityCountsPerSec | 80
igniterPreheatPowerV | 3
igniterPreheatDurationMs | 1000
igniterlgnitionPowerV | 4
igniterlgnitionDurationMs | 3000
igniterDelayBeforeRetractMs | 1800
igniterRetractVelocityCountsPerSec | 500
pmt1Gain | 5.5
pmt2Gain | 6.0
pmt3Gain | 5.5
fiberlgnitionPosition
fiberTestPosition
fiberMoveDuringTest | FALSE
fiberSegmentDistance | 100
fiberVe10city | 3000
fiberH01dDurationSec | 1
fiberCycles | 100
useFoma | TRUE
flowTimeoutSec | 360
fuelFlowlgnitionDeltaMs | 2000
nitrogenFlowlgnitionDeltaMs
stabilizationTime1Sec
stabilizationTime2Sec | 5
fuellgnitionFt0wSlpm | 0.499 | D, 233 BASS
nitrogenlgnitionFlowSlpm | 0.000
fuelTestFlow1Slpm | 0.499 | osw
nitrogenTestFlow1Slpm | 0.000
fuelTestFlow2Slpm | 0.000
nitrogen TestFlow2Slpm | 0.000
fuelTestFlow3Slpm | 0.000
nitrogen TestFlow3Slprn | 0.000
constantFlowTime1Sec | 330
constantFlowTime2Sec | o
constantF10wTime3Sec
ignitionTOTestRampTimeSec
testFlowRamp1T02TimeSec
testFlowRamp2T03TimeSec
postExtinctionDelaySec | 3
postExtinCtionF10wChangeFuelPercent
postExtinctionFlowChangeNitrogenPercent
postExtinctionFlowChangeRampTimeSec
postExtinctionFlowChangeHoldSec
~~~~

### Pagina 2

Cita: [pdf_cbd43a589cc61b65d9a6, p. 2]. Metodo: windows_ocr_grid_removed.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_cbd43a589cc61b65d9a6/p0002.jpg)

~~~~text
testpointName | 2117481
dataCameraPrelgnitionExposureUs | 1000000
dataCameraTestExposureUs | 100000
analogCameraShutter | 2
uselntensifiedCamera | TRUE
intensifierlgnitionGain | 20000
intensifierTestGain | 60000
preignitionlmageTimeSec
postFlamelmagingTimeSec | 5
useDataCameraAut0Gain | FALSE
autoGainTolerancePercent | 5
autoGainMaxDb | 33
autoGainMinDb
autoGainOutliers
auto Ga inRatePercent | 100
autoGainTargetPercent | 50
rampDataCameraGain | FALSE
dataCameraGain1dB
dataCameraGain2dB
dataCameraGain3dB
dataCameraH01dTime1Sec
dataCameraH01dTime2Sec
dataCameraRamp1t02TimeSec | 5
dataCameraRamp2t03TimeSec | 5
dataCameraManualGain
useBracketedExposures | TRUE
bracketinglmagesPerExposure | 1
bracketingNumberOfExposures | 4
bracketingExposureStartUsec | 50000
bracketingExposureMultiplierTimeSIOO | 200
igniterStartPosition | 2170
igniterEndPosition | 2290
igniterVelocityCountsPerSec | 80
igniterPreheatP0werV | 3
igniterPreheatDurationMs | 1000
igniterlgnitionPowerV | 4
igniterlgniti0nDurationMs | 3000
igniterDelayBeforeRetractMs | 1800
igniterRetractVelocityCountsPerSec | 500
pmt1Gain | 5.5
pmt2Gain | 6.0
pmt3Gain | 5.5
fiberlgnitionPOsition | 10000
fiberTestPosition | 17000
fiberMoveDuringTest | FALSE
fiberSegmentDistance | 100
fiberVelocity | 3000
fiberHoldDurationSec | 1
fiberCycles | 100
useFoma | TRUE
flowTimeoutSec | 360
fuelF10wlgnitionDeltaMS
nitrogenFlowlgnitionDeltaMs
stabilizationTime1Sec
stabilizationTime2Sec | 5
fuellgnitionF10wSlpm | 0.233
nitrogenlgnitionFlowSlpm | 0.000
fuelTestFlow1Slpm | 0.233
nitrogenTestFlow1Slpm | 0.000
fuel TestFlow2Slpm | 0.000
nitrogenTestFlow2Slpm | 0.000
fuelTestF10w3Slpm | 0.000
nitrogen TestFlow3Slpm | 0.000
constantFlowTime1Sec | 330
consta ntF10wTime2Sec
constantFlowTime3Sec
ignitionToTestRampTimeSec
testF10wRamp1T02TimeSec
testFiowRamp2T03TimeSec
postExtinctionDelaySec | 3
postExtinctionFlowChangeFuelPercent
postExtinctionFlowChangeNitrogenPercent
postExtincti0nFlowChangeRampTimeSec
postExtinctionF10wCha ngeH01dSec
~~~~

### Pagina 3

Cita: [pdf_cbd43a589cc61b65d9a6, p. 3]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_cbd43a589cc61b65d9a6/p0003.jpg)

~~~~text
testp0intName | 21174C1
dataCameraPrelgniti0nExposureUs | 1000000
dataCameraTestExposureUs | 100000
analogCameraShutter | 2
uselntensifiedCamera | TRUE
intensifierlgnitionGain | 20000
intensifierTestGain | 60000
prelgnitionlmageTimeSec
postFiamelmagingTimeSec
useDataCameraAutoGain | FALSE
autoGainT01erancePercent | 5
autoGainMaxDb | 33
autoGainMinDb | 0
autoGainOutliers
autoGainRatePercent | 100
autoGainTargetPercent | 50
rampDataCameraGain | FALSE
dataCameraGain1dB
dataCameraGain2dB
dataCameraGain3dB
dataCameraHoldTime1Sec
dataCameraH01dTime2SeC
data Camera Ramplt02TimeSec | 5
dataCameraRamp2t03TimeSec | 5
dataCameraManualGain | 33
useBracketedExposures | FALSE
bracketinglmagesPerExposure | 1
bracketingNumberOfExposures | 4
bracketingExposureStartUsec | sooo
bracketingExposureMultiplierTimes100 | 1000
igniterStartPosition | 2170
igniterEndPosition | 2290
igniterVelocityCountsPerSec | 80
igniterPreheatPowerV | 3
igniterPreheatDurationMs | 1000
igniterlgnitionP0werV | 4
igniterlgnitionDurationMs | 3000
igniterDelayBef0reRetractMs | 1800
igniterRetractVelocityCountsPerSec | soo
pmt1Gain | 5.5
pmt2Gain | 6.0
pmt3Gain | 5.5
fiberlgnitionPosition
fiberTestPosition
fiberM0veDuringTest | FALSE
fiberSegmentDistance | 100
fiberVelocity | 3000
fiberH01dDurationSec | 1
fiberCycles | 100
useFoma | TRUE
flowTimeoutSec | 360
fuelFlowlgnitionDeltaMs | 500
nitrogenF10wlgnitionDe'taMs
stabilizationTime1Sec
stabilizationTime2Sec | 5
fuellgnitionFlOwSlpm | 0.499
nitrogenlgnitionFlowSlpm | 0.000
fuelTestFlow1Slpm | 0.499
nitrogenTestFlow1Slpm | 0.000
fuelTestF10w2Slpm | 0.000
nitrogenTestFlow2Slpm | 0.000
fuelTestFlow3Slpm | 0.000
nitrogenTestFlow3Slpm | 0.000
constantFlowTime1Sec | 330
constantFlowTime2Sec
constantF10wTime3Sec
ignitionTOTestRampTimeSec
testFlowRamp1T02TimeSec
testFlowRamp2T03TimeSec
postExtinctionDelaySec | 3
postExtinctionFlowChangeFuePercent | 0
postExtinctiOnFlowChangeNitrogenPercent
postExtinctionFlOwChangeRampTimeSec
postExtinctionFlowChangeHoldSec
2.9-3<23
n5z5 | i 270b
14écx)
~~~~

### Pagina 4

Cita: [pdf_cbd43a589cc61b65d9a6, p. 4]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_cbd43a589cc61b65d9a6/p0004.jpg)

~~~~text
testpointName | 21174D1
dataCameraPrelgnitionExposureUs | 1000000
dataCameraTestExposureUs | 100000
analogCameraShutter | 2
uselntensifiedCamera | TRUE
intensifierlgnitionGain | 20000
intensifierTestGain | 60000
preignitionlmageTimeSec
postFlamelmagingTimeSec
useDataCameraAutoGain | FALSE
autoGainTolerancePercent | 5
autoGainMaxDb | 33
autoGainMinDb
autoGainOutliers
autoGainRatePercent | 100
autoGainTargetPercent | 50
rampDataCameraGain | FALSE
dataCameraGain1dB
dataCameraGain2dB
dataCameraGain3dB
dataCa meraH01dTime1Sec | 0
dataCameraHoldTime2Sec
dataCameraRamp1t02TimeSec
dataCameraRamp2t03TimeSec | 5
dataCameraManuaiGain
useBracketedExposures | TRUE
bracketinglmagesPerExposure | 1
bracketingNumberOfExp0sures | 4
bracketingExposureStartUsec | soooo
bracketingExposureMultiplierTimes100 | 200
igniterStartP0siti0n | 2170
igniterEndPosition | 2290
igniterVelocityCountsPerSec | 80
igniterPreheatPowerV | 3
igniterPreheatDurationMs | 1000
igniterigniti0nPowerV | 4
igniterlgnitionDurationMs | 3000
igniterDelayBeforeRetractMs | 1800
igniterRetractVelocityCountsPerSec | 500
pmt1Gain | 5.5
pmt2Gain | 6.0
pmt3Gain | 5.5
fiberignitionPosition | 10000
fiberTestPosition | 17000
fiberM0veDuringTest | FALSE
fiberSegmentDistance | 100
fiberVelocity | 3000
fiberH01dDu rationSec
fiberCycies | 100
useFoma | TRUE
flowTimeoutSec | 360
fuelFlowlgnitionDeltaMs
nitrogenFlowlgnitionDeltaMs
stabilization TimelSeC
stabilizationTime2Sec | 5
fuellgnitionFlowSlpm | 0.233
nitrogenlgnitionF10wSlpm | 0.000
fuelTestFlow1Slpm | 0.233
nitrogenTestFlow1Slpm | 0.000
fuelTestFlow2Slpm | 0.000
nitrogenTestF10w2Slpm | 0.000
fuelTestFlow3Slpm | 0.000
nitrogenTestFlow3Slpm | 0.000
constantF10wTime1Sec | 330
constantFlowTime2Sec
constantFlowTime3Sec
ignitionTOTestRampTimeSec
testFlowRamp1T02TimeSec
testFlowRamp2T03TimeSec
postExtinctionDelaySec
postExtinctionFlowChangeFuelPercent
postExtinctionF10wChangeNitrogenPercent
postExtinctionFiowChangeRampTimeSec
postExtinctionFlowChangeH01dSec
~~~~

### Pagina 5

Cita: [pdf_cbd43a589cc61b65d9a6, p. 5]. Metodo: windows_ocr_grid_removed.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, multiple_ocr_readings_values_require_verification, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_cbd43a589cc61b65d9a6/p0005.jpg)

~~~~text
testpointName | 21174F1
dataCameraPrelgnitionExposureUs | 1000000
dataCameraTestExposureUs | 100000
analogCameraShutter | 2
uselntensifiedCamera | TRUE
intensifierlgnitionGain | 20000
intensifier TestGain | 60000
prelgnitionlmageTimeSec
postFlamelmagingTimeSec | 5
useDataCameraAut0Gain | FALSE
autoGainT01erancePercent | 5
autoGainMaxDb | 33
autoGainMinDb
autoGainOutliers
autoGainRatePercent | 100
autoGainTargetPercent | 50
rampDataCameraGain | FALSE
dataCameraGain1dB
dataCameraGain2dB
dataCameraGain3dB
dataCameraH01dTime1Sec
dataCameraH01dTime2Sec
dataCameraRamp1t02TimeSec | 5
data Camera Ramp2t03TimeSec | 5
dataCameraManualGain | 33
useBracketedExposures | FALSE
bracketinglmagesPerExposure | 1
bracketingNumberOfExposures | 4
bracketingExposureStartUsec | sooo
bracketingExposureMultiplierTimes100 | 1000
igniterStartPosition | 2170
igniterEndPosition | 2290
igniterVelocityCountsPerSec | 80
igniterPreheatPowerV | 2.8
igniterPreheatDurati0 nMs | 10000
igniterlgnitionPowerV | 27 | 3
igniterlgnitionDurationMs | • 10000
igniterDelayBeforeRetractMs | 8200
igniterRetractVelocityCountsPerSec | soo
pmt1Gain | 5.5
pmt2Gain | 6.0
pmt3Gain | 5.5
fiberlgnitionPosition
fiberTestPositi0n
fiberMoveDuringTest | FALSE
fiberSegmentDistance | 100
fiberVelocity | 3000
fiberH01dDurationSec | 1
fiberCycles | 100
useFoma | TRUE
flowTimeoutSec | 360 | 150
fuelFlowlgnitionDeltaMs
nitrogen FlowlgnitionDeltaMs
stabilizationTime1Sec
stabilizationTime2Sec
fuelignitionFlowSlpm | 0.310
nitrogenlgnitionFlowSlpm | 0.000
fuelTestFlow1Slpm | 0.310 | D,zs3 /
nitrogenTestF10w1Slpm | 0.000
fuelTestFlow2Slpm | 0.000
nitrogenTestFlow2Slpm | 0.000
fuelTestFlow3Slpm | 0.000
nitrogenTestF10w3Slpm | 0.000
constantFlowTime1Sec | 330
constantFlowTime2Sec | o
constantFlowTime3Sec
ignitionToTestRampTimeSec
testF10wRamp1T02TimeSeC
testFlowRamp2T03TimeSec
postExtinctionDelaySec | 3
postExtinctionF10wChangeFuelPercent
postExtinctionFlowChangeNitrogenPercent
postExtinctionFlowChangeRampTimeSec
postExtinctionF10wChangeHoldSec
~~~~
