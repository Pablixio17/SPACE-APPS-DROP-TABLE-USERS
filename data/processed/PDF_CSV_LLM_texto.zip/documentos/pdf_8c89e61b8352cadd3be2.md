# Lopez-Camara et al 2019 Comprehensive chemical kinetic mechanism for simple hydrocarbon fuels

- Identificador: pdf_8c89e61b8352cadd3be2
- Investigaciones: PSI-22
- Tipo de documento: Presentations
- Estado: processed
- Temas detectados automaticamente: computational_models, oxygen, hardware

## Fuentes

- [PSI-22_Presentations_Lopez-Camara et al 2019 Comprehensive chemical kinetic mechanism for simple hydrocarbon fuels.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-22/Presentations/PSI-22_Presentations_Lopez-Camara%20et%20al%202019%20Comprehensive%20chemical%20kinetic%20mechanism%20for%20simple%20hydrocarbon%20fuels.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_8c89e61b8352cadd3be2, p. 1]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Comprehensive chemical kinetic mechanism for simple hydrocarbon 
fuels including important excited and charged species
C-F. López-Cámara 1 C. Saggese 2 W. Pitz 2 D. Dunn-Rankin 1 
1University of California at Irvine, Civil and Environmental Engineering Dept., Irvine 92697, California, USA
2 Lawrence Livermore National Laboratory, Livermore 94550, California, USA
35th Annual Meeting of the American Society for Gravitational and Space Research
Denver, CO, USA
November 20-23 2019
ASGSR Annual meeting. Nov 20-23, 2019. clopezca@uci.edu 1
Acknowledgements: 
The National Science Foundation (NSF) with Dr. Prakash Balan as contract monitor for the Non-Academic Research Internship for Graduate Students (INTERN) via grant CBET1605533 for the 
internship at the Lawrence Livermore National Laboratory (LLNL).
ACME project, supported by NASA’s ISS Research via agreement NNX07AB55A, with Dennis Stocker as contract monitor. 
LLNL-PRES-797100
This work was performed under the auspices of the U.S. Department of Energy by Lawrence Livermore National Laboratory under contract DE-AC52-07NA27344. Lawrence Livermore National Security, LLC
~~~~

### Pagina 2

Cita: [pdf_8c89e61b8352cadd3be2, p. 2]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_8c89e61b8352cadd3be2/p0002.jpg)

~~~~text
No E-Field | No E-Field | E-Field applied
lg
F. B. Carleton & F. J. Weinberg. Nature. Volume 330, p. 635-636 (1987)
~~~~

### Pagina 3

Cita: [pdf_8c89e61b8352cadd3be2, p. 3]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Introduction
Minor 
Species
Excited Species
CH* Flame location
OH* Heat release
Charged 
Species HCO+
, H3O+
, e￾Interact with e-field creating 
ion-wind
Main 
hydrocarbon 
flame 
chemistry 
+
ASGSR Annual meeting. Nov 20-23, 2019. clopezca@uci.edu - LLNL-PRES-797100 3
Comprehensive chemical kinetic mechanism for 
simple hydrocarbon fuels including important 
excited and charged species
~~~~

### Pagina 4

Cita: [pdf_8c89e61b8352cadd3be2, p. 4]. Metodo: native_plus_windows_ocr.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed.

[Imagen de la pagina](../imagenes/pdf_8c89e61b8352cadd3be2/p0004.jpg)

~~~~text
Introduction
Lu & Law, PECS 2009
Our region of interest 
(low number of species)
ASGSR Annual meeting. Nov 20-23, 2019. clopezca@uci.edu - LLNL-PRES-797100 4

[Texto OCR de la imagen]
Introduction
*aes (I-LN.)
a
pahiäe
'81201
104
C16(l-LtV".
C14(LDL)
Oatme (LLN-) , • | (LLM-)
(EbStC-CMR*
et d) | 20
Ci-ß(KÜYü.f)
103 | sooctae (Lu & LN.')
LSC CIC4 | %eetal | (Lu & Law)
USCü+4
CIC3 (Qn et d)
z | e before 2000
A 2000-2004
(Lee±)
2005-2009
102
5K | since 2010
101 | 102 | 103 | 104
Number of species, K
Our region of interest
(low number of species)
Lu & Law, PECS 2009
ASGSR Annual meeting. Nov 20-23, 2019. clopezca@uci.edu - LLNL-PRES-797100
~~~~

### Pagina 5

Cita: [pdf_8c89e61b8352cadd3be2, p. 5]. Metodo: native.

~~~~text
To build a chemical kinetic model that contains the minor species CH*, OH*, H3O+
and
HCO+ which trust-worthily predicts non-premixed flame behavior at steady state. The size
of the model should be small enough to handle e-field 2D simulations.
Goal
Goal
ASGSR Annual meeting. Nov 20-23, 2019. clopezca@uci.edu - LLNL-PRES-797100 5
~~~~

### Pagina 6

Cita: [pdf_8c89e61b8352cadd3be2, p. 6]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Methodology
Fuel model 1
+ CH*/OH* 2
+ e
-/ions 3
DETAILED
REDUCED
1. Reduction (PSR)
2. Validation (Counterflow)
Model 1
Model 0
Model reduction and validation scheme
Chemkin-Pro®
1
The San Diego Mechanism. https://web.eng.ucsd.edu/mae/groups/combustion/mechanism.html
2 K.T Walsh. PhD Dissertation, Yale University, 2000
3 Belhi et al. CST 2018
ASGSR Annual meeting. Nov 20-23, 2019. clopezca@uci.edu - LLNL-PRES-797100 6
1. Validation (Counterflow and Jet)
2. Validation (Experiments)
~~~~

### Pagina 7

Cita: [pdf_8c89e61b8352cadd3be2, p. 7]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Chemi-ionization reaction
CH + O HCO+
+ e-
(1)
Main reactions for hydronium ion (H3O+
)
HCO+
+ H2O CO + H3O+
(2)
H3O+
+ e- H + H2O (3)
Main reactions for chemiluminescence of CH*
C2H + O2 CH* + CO2 (4)
C2H + O CH* + CO (5)
CH CH* + hν (6)
Main reaction for chemiluminescence of OH*
CH + O2 OH* + CO (7)
Chemistry of minor species Methodology
ASGSR Annual meeting. Nov 20-23, 2019. clopezca@uci.edu - LLNL-PRES-797100 7
~~~~

### Pagina 8

Cita: [pdf_8c89e61b8352cadd3be2, p. 8]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Results
Reduction of UCSD detailed model with CH*/OH* for CH4
Chemkin-Pro® and Workbench
Targets 
C2H H2O O
CH O2
OH
----------------------------------------------------------- Keep species:
CH4 C2H CO H2O N2 O H3O+
CH CO2 H O2 HCO+
CH* H2 OH e- OH*
% relative tolerance 
MAXIMUM (target 
species)
Absolute 
tolerance
#species 
(BEST 
reduction)
8 1e-5 31
All target species
Reduced model contains excited 
species, chemi-ions and C2H2
ASGSR Annual meeting. Nov 20-23, 2019. clopezca@uci.edu - LLNL-PRES-797100 8
Detailed model:
83 species
~~~~

### Pagina 9

Cita: [pdf_8c89e61b8352cadd3be2, p. 9]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Results Comparison of detailed and reduced model for CH4
Validation with detailed model in a Chemkin-Pro® counterflow configuration
Legend Sub-index
r: reduced model
d: detailed model
ASGSR Annual meeting. Nov 20-23, 2019. clopezca@uci.edu - LLNL-PRES-797100 9
~~~~

### Pagina 10

Cita: [pdf_8c89e61b8352cadd3be2, p. 10]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Results Comparison of detailed and reduced model for CH4
Validation with detailed model in a Chemkin-Pro® counterflow configuration
S
f **
*
*
j *
*
*
ASGSR Annual meeting. Nov 20-23, 2019. clopezca@uci.edu - LLNL-PRES-797100 10
~~~~

### Pagina 11

Cita: [pdf_8c89e61b8352cadd3be2, p. 11]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Results Comparison of detailed and reduced model for CH4
Validation with detailed model in a Chemkin-Pro® counterflow configuration
+5
5
+
+ 5
5 5
c+
+
+
e
-
e
- e
-
ASGSR Annual meeting. Nov 20-23, 2019. clopezca@uci.edu - LLNL-PRES-797100 11
~~~~

### Pagina 12

Cita: [pdf_8c89e61b8352cadd3be2, p. 12]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
289.647 points (144.230 blocks) 289.647 points (144.230 blocks)
EXTRUDED BURNER JET BURNER
All units in [mm] - Meshes and simulations made using OpenFOAM®
Burner geometries
ASGSR Annual meeting. Nov 20-23, 2019. clopezca@uci.edu - LLNL-PRES-797100 12
~~~~

### Pagina 13

Cita: [pdf_8c89e61b8352cadd3be2, p. 13]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
13
Drawing not in scale
Boundary conditions
ASGSR Annual meeting. Nov 20-23, 2019. clopezca@uci.edu - LLNL-PRES-797100 13
~~~~

### Pagina 14

Cita: [pdf_8c89e61b8352cadd3be2, p. 14]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Results Comparison of predicted and measured flame location (CH*)
Validation with experiments using 2D CFD OpenFOAM® simulations
ASGSR Annual meeting. Nov 20-23, 2019. clopezca@uci.edu - LLNL-PRES-797100 14
[CH*] plot. Extruded geometry - 20sccm
–– Experiments (Tinajero and Dunn-Rankin, CNF 2019)
–– RM; LLNL Model 0 (detailed chemical kinetic model) –– RM; LLNL Model 1 (reduced chemical kinetic model) 
Contour threshold (model): [CH*] = 1e-12
~~~~

### Pagina 15

Cita: [pdf_8c89e61b8352cadd3be2, p. 15]. Metodo: native.

~~~~text
Final remarks and future work
Final remarks
• We have built a chemical kinetic model that contains the minor species CH*, OH*, H3O+
and HCO+
and trust-worthily predicts non-premixed flame behavior at steady state. 
Comparison between experimental and numerical results validated the reduced model.
• Speed up in the simulations without e-field in comparison with detailed model was 
obtained (> x2).
• The size of the reduced model should be small enough to handle e-field 2D simulations.
Near-future goals
Validation of the model
• Change the burner geometry and repeat the simulation, comparing it to experiments.
• Check how the methane flame responds to an external applied e-field, comparing it to
experiments (at 1g and µg).
Others
• Repeat the mechanism reduction process with an C2H4 detailed model.
ASGSR Annual meeting. Nov 20-23, 2019. clopezca@uci.edu - LLNL-PRES-797100 15
~~~~

### Pagina 16

Cita: [pdf_8c89e61b8352cadd3be2, p. 16]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Thank you
Disclaimer
This document was prepared as an account of work sponsored by an agency of the United States government. Neither the United 
States government nor Lawrence Livermore National Security, LLC, nor any of their employees makes any warranty, expressed or 
implied, or assumes any legal liability or responsibility for the accuracy, completeness, or usefulness of any information, apparatus, 
product, or process disclosed, or represents that its use would not infringe privately owned rights. Reference herein to any specific 
commercial product, process, or service by trade name, trademark, manufacturer, or otherwise does not necessarily constitute or 
imply its endorsement, recommendation, or favoring by the United States government or Lawrence Livermore National Security, LLC.
The views and opinions of authors expressed herein do not necessarily state or reflect those of the United States government or 
Lawrence Livermore National Security, LLC, and shall not be used for advertising or product endorsement purposes.
~~~~
