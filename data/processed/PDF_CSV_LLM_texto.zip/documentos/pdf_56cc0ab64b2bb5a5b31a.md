# Drawing_PMMA.Spherical.Section

- Identificador: pdf_56cc0ab64b2bb5a5b31a
- Investigaciones: PSI-26
- Tipo de documento: Engineering Documents
- Estado: processed
- Temas detectados automaticamente: solid_materials

## Fuentes

- [PSI-26_Engineering Documents_Drawing_PMMA.Spherical.Section.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-26/Engineering%20Documents/PSI-26_Engineering%20Documents_Drawing_PMMA.Spherical.Section.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_56cc0ab64b2bb5a5b31a, p. 1]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_56cc0ab64b2bb5a5b31a/p0001.jpg)

~~~~text
8 | 7 | 6 | 5 | 3 | 2 | 1
NOTES
MATERIAL. DELVIES PLASTIC 1.50 INCH DIAMETER
CAST ROUND CLEAR PMMA BALL.
600 | 2. MATERIAL CERTIFICATION REQUIRED PER QUALITY
LEVE | SPECIFIED IN WORK ORDER/SOW.
300 | 3. OPTICALLY CLEAR ALL OVER UNLESS OTHERW ISE NOTED.
4. CLEAN ONLY BY IMMERSION IN MILD SOAP SOLUTION
IN DISTILLED WATER. RINSE WITH DISTILLED WATER
AND LET AIR DRY.
5. HANDLE WITH CLEAN, LINT FREE G ovas.
6. BEFORE STORAGE. PROTEC | w I H CONTAMINA ION
BARRIER. USE CLEAN, NEW | TRANSPARENT
,
POLYETHY ENE BAG FOR SMALL ITEMS OR | MIL
SR19. 05±.12 | THICK MINIMUM POLYETHYLENE SHEET AND SEAL.
MARK PART NUMBER. A DASH, AND A SERIAL/LOT
NUMBER AS SPECIFIED IN WORK ORDER/SOW
BY TAGGING PER SAE AS478 35).
3.7
Ø2.o
Ø.25 A
(Ø19
7.3
BASS-ECO-031 In Process
SECTION
REV | DESCRIPT ON | AppROVED
REVISION HISTORY
THIS DRAW ING IS UNDER
ION CONTROL: DO NOT | ZIN TECHNOLOGIES
Sild3MFA1085 | 671.5 ENGLE ROAD | NATIONAL AERONAUTICS AND SPACE ADMINISTRATION
REVISE WITHOUT AN APPROVED ECO. | H. GLENN RESEARCH CENTER
AIRPORT EXECUTIVE PARK | VA6SiA | JOHN
NEXT ASSEMBLY | CLEVELAND, OHIO "130 | LEW | FIELD
APPROVED: | Mcaoswr 06//9//3
UNLESS OTHERW ISE SPECIFIED. | (440) 625-2200 | CLEVELAND. OHIO
1. ALL DIMENSIONS ARE IN MILLIMETERS | PRIOR TO USE. CHECK WI H | www.z in-tech.com
2. BREAK EDGES 0.25-0.50 | MANAGEMENT FOR ANY OU STANDING ECOS.
3. INSIDE CORNERS RO.5 MAX
4. LINEAR TOLERANCES: | DESIGNER S | 06//0//3 | QUALITY | D. | 06//8//3 | I TLE
0.5-6
OVER 6-30 | REVIEWER V. | 06/////3 | MATERIALS M, W/IK///SOW 06//4//3
OVER 30-120 | ±0.3
OVER 120-315 ±0.5 | PMMA SPHERICAL SECTION SAMPLE
OVER 315-1000 ±0.8 | MECHANICAL C. | 06//4//3 | PROJ LEAD r. IOR/K 06//9//3
OVER 1000-2000 ±1.2
5. ANGULAR TOLERANCES: ±0.50 | ELECTRICA
THIRD ANGLE PROJECTION STRUCTURAL
SIZE | CAGE CODE | DWG NO | REV
SAFETY | c Bomowr 06//4//3
DIMENSIONS AND TOLERANC ING | CONTRACT NUMBER: NNC09BA02B
PER ASME YIG.5M-1994 | PROJECT CODE: SPACEI 8 | SCALE | INITIAL REL DATE 06/25/2013 SHEET
RELEASE LEVEL: WORKING | PRO/E VERSION: Wildfire 5.0
7 | 6 | 5 | 3 | MODEL: Sild3MFD1086
~~~~
