# Tinajero et al 2014 Ground-Based Schlieren Experiments

- Identificador: pdf_eb5f3d6d0cbc5bc023dc
- Investigaciones: PSI-22
- Tipo de documento: Presentations
- Estado: processed
- Temas detectados automaticamente: electric_fields, hardware, microgravity, operations

## Fuentes

- [PSI-22_Presentations_Tinajero et al 2014 Ground-Based Schlieren Experiments.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-22/Presentations/PSI-22_Presentations_Tinajero%20et%20al%202014%20Ground-Based%20Schlieren%20Experiments.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Pasajes de orientacion (extractivos, no resumen validado)

### conclusion - pagina 18

Conclusions
1. Transient Effects due to Voltage Steps
I A wave is created in thermal plume. The wave is more apparent near
satuartion fields and for longer electrode spacings.
I Average plume wave velocity was linear with average field strength
I 75hz oscillation appears in the ion current measurements when field strength
surpasses 2kV/cm. This oscillation can clearly be seen in the schlieren
videos
2. Time-Scales
I UCI H.V. power supply produces electrode potential on the order of a 1kV in
2-3ms. The ACME H.V. power supply produces the same electrode potential
at a rate 0.1kV/ms
I Bulk of ion current arrives downstream at ⇡10-20ms
I Plume reaction time for a voltage step from the UCI power supply was
⇡2-3ms. The plume reaction time for the ACME power supply was seen to
be longer
ASGSR 2014, Pasadena Chemi-Ion Driven Flows in a Time Varying Electric Field

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_eb5f3d6d0cbc5bc023dc, p. 1]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Ground-Based Schlieren Experiments of
Chemi-Ion Driven Flows in a Time Varying
Electric Field
Jesse Tinajero1 Derek Dunn-Rankin1 Jie Bia2 Miguel Plascencia1
1Mechanical and Aerospace Engineering,
University of California-Irvine
2School of Marine Engineering,
Northwestern Polytechnical University
ASGSR - October 26th, 2014
ASGSR 2014, Pasadena Chemi-Ion Driven Flows in a Time Varying Electric Field
~~~~

### Pagina 2

Cita: [pdf_eb5f3d6d0cbc5bc023dc, p. 2]. Metodo: native.

~~~~text
Motivation
I Preparation for 2016-17 micro-gravity experiments on-board the ISS via
Nasa’s ACME (Advanced Combustion Via Microgravity Experiments)
I Study the transient effect of chemi-ions in the bulk gas
I Study the effects of important parameters (i.e. field strength and electrode
gap distance) that characterize electric field combustion (i.e. time-scales
and length-scales) in a transient state
I Acquire full dynamic control of combustion using electric fields
ASGSR 2014, Pasadena Chemi-Ion Driven Flows in a Time Varying Electric Field
~~~~

### Pagina 3

Cita: [pdf_eb5f3d6d0cbc5bc023dc, p. 3]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_eb5f3d6d0cbc5bc023dc/p0003.jpg)

~~~~text
INTRODUCTION
Negative Electrode
W/Respect To Ground
Reaction
Zone
Grounded Burner
Electrode
ASGSR 2014, PASADENA | CHEMI-ION DRIVEN FLOWS IN A TIME VARYING ELECTRIC FIELD
~~~~

### Pagina 4

Cita: [pdf_eb5f3d6d0cbc5bc023dc, p. 4]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_eb5f3d6d0cbc5bc023dc/p0004.jpg)

~~~~text
EXPERIMENT - SCHLIEREN
Lens | Lens
in | in
Knife Edge
Light | Flame
Source
M Ovie Screen
z | High Speeed
Video Camera
x
ASGSR 2014, PASADENA | CHEMI-ION DRIVEN FLOWS IN A TIME VARYING ELECTRIC FIELD
~~~~

### Pagina 5

Cita: [pdf_eb5f3d6d0cbc5bc023dc, p. 5]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_eb5f3d6d0cbc5bc023dc/p0005.jpg)

~~~~text
EXPERIMENT - H.V. POWER SUPPLY CIRCUIT
GNO
+12 VDC
GNO
ASGSR 2014, PASADENA | CHEMI-ION DRIVEN FLOWS IN A TIME VARYING ELECTRIC FIELD
~~~~

### Pagina 6

Cita: [pdf_eb5f3d6d0cbc5bc023dc, p. 6]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Experiment - uci Coflow Burner
I Fuel: Methane
I Fuel Flow Rate: 7cm/s
I Burner Material: Stainless Steel
ASGSR 2014, Pasadena Chemi-Ion Driven Flows in a Time Varying Electric Field
~~~~

### Pagina 7

Cita: [pdf_eb5f3d6d0cbc5bc023dc, p. 7]. Metodo: native.

~~~~text
Ion Current Vs Field Strength - Eave = ￾4 V/H
ACME H.V.P.S.
0 0.5 1 1.5 2 2.5 3 3.5 0
0.5
1
1.5
2
2.5
Field Strength [kV/cm]
Ion Current [µA]
UltraVolt − Field Strength vs Ion Current
Methane Flame − 25mm gap
0 0.5 1 1.5 2 2.5 3 3.5 0
0.5
1
1.5
2
2.5
Field Strength [kV/cm]
Ion Current [µA]
UltraVolt − Field Strength vs Ion Current
Methane Flame − 30mm gap
0 0.5 1 1.5 2 2.5 3 3.5 0
0.5
1
1.5
2
2.5
Field Strength [kV/cm]
Ion Current [µA]
UltraVolt − Field Strength vs Ion Current
Methane Flame − 35mm gap
UCI H.V.P.S.
0 0.5 1 1.5 2 2.5 3 3.5 0
0.5
1
1.5
2
2.5
Field Strength [kV/cm]
Ion Current [µA]
Trek − Field Strength vs Ion Current
Methane Flame − 25mm gap
0 0.5 1 1.5 2 2.5 3 3.5 0
0.5
1
1.5
2
2.5
Field Strength [kV/cm]
Ion Current [µA]
Trek − Field Strength vs Ion Current
Methane Flame − 30mm gap
0 0.5 1 1.5 2 2.5 3 3.5 0
0.5
1
1.5
2
2.5
Field Strength [kV/cm]
Ion Current [µA]
Trek − Field Strength vs Ion Current
Methane Flame − 35mm gap
ASGSR 2014, Pasadena Chemi-Ion Driven Flows in a Time Varying Electric Field
~~~~

### Pagina 8

Cita: [pdf_eb5f3d6d0cbc5bc023dc, p. 8]. Metodo: native.

~~~~text
Ion Current Vs Field Strength - Eave = ￾4 V/H
0 0.5 1 1.5 2 2.5 3 3.5 0
0.5
1
1.5
2
2.5
Field Strength [kV/cm]
Ion Current [
µA]
Trek − Field Strength vs Ion Current
Methane Flame − 35mm gap
ASGSR 2014, Pasadena Chemi-Ion Driven Flows in a Time Varying Electric Field
~~~~

### Pagina 9

Cita: [pdf_eb5f3d6d0cbc5bc023dc, p. 9]. Metodo: native.

~~~~text
Transient Results - uci h.v. power supply
35mm gap
0 10 20 30 40 50 60 70 80 90 100 −9
−8
−7
−6
−5
−4
−3
−2
−1
0
Electrode Mesh Potential [kV]
Time [ms]
Trek − Transient High Voltage Steps
Methane Flame − 35mm Gap
0 10 20 30 40 50 60 70 80 90 100 −2.5
−2
−1.5
−1
−0.5
0
Ion Current [µA]
Time [ms]
Trek − Transient Shunt Measurements
Methane Flame − 35mm Gap
Neg2000VStep
Neg3000VStep
Neg4000VStep
Neg5000VStep
Neg6000VStep
Neg7000VStep
Neg8000VStep
ASGSR 2014, Pasadena Chemi-Ion Driven Flows in a Time Varying Electric Field
~~~~

### Pagina 10

Cita: [pdf_eb5f3d6d0cbc5bc023dc, p. 10]. Metodo: native.

~~~~text
Transient Results - acme h.v. power supply
35mm gap
0 10 20 30 40 50 60 70 80 90 100 −9
−8
−7
−6
−5
−4
−3
−2
−1
0
1
Electrode Mesh Potential [kV]
Time [ms]
UltraVolt − Transient High Voltage Steps
Methane Flame − 35mm Gap
0 10 20 30 40 50 60 70 80 90 100 −2.5
−2
−1.5
−1
−0.5
0
Ion Current [µA]
Time [ms]
UltraVolt − Transient Shunt Measurements
Methane Flame − 35mm Gap
Neg2000VStep
Neg3000VStep
Neg4000VStep
Neg5000VStep
Neg6000VStep
Neg7000VStep
Neg8000VStep
ASGSR 2014, Pasadena Chemi-Ion Driven Flows in a Time Varying Electric Field
~~~~

### Pagina 11

Cita: [pdf_eb5f3d6d0cbc5bc023dc, p. 11]. Metodo: native.

~~~~text
Transient Ion Current Measurements
uci h.v.p.s. 25mm gap
0 100 200 300 400 500 600 700 800 −2.5
−2
−1.5
−1
−0.5
0
Ion Current [µA]
Time [ms]
Trek Neg1000VStep 25mm Gap
0 100 200 300 400 500 600 700 800 −2.5
−2
−1.5
−1
−0.5
0
Ion Current [µA]
Time [ms]
Trek Neg2000VStep 25mm Gap
0 100 200 300 400 500 600 700 800 −2.5
−2
−1.5
−1
−0.5
0
Ion Current [µA]
Time [ms]
Trek Neg5000VStep 25mm Gap
0 100 200 300 400 500 600 700 800 −2.5
−2
−1.5
−1
−0.5
0
Ion Current [µA]
Time [ms]
Trek Neg5750VStep 25mm Gap
0 100 200 300 400 500 600 700 800 −2.5
−2
−1.5
−1
−0.5
0
Ion Current [µA]
Time [ms]
Trek Neg6000VStep 25mm Gap
0 100 200 300 400 500 600 700 800 −2.5
−2
−1.5
−1
−0.5
0
Ion Current [µA]
Time [ms]
Trek Neg6250VStep 25mm Gap
ASGSR 2014, Pasadena Chemi-Ion Driven Flows in a Time Varying Electric Field
~~~~

### Pagina 12

Cita: [pdf_eb5f3d6d0cbc5bc023dc, p. 12]. Metodo: native.

~~~~text
Transient Ion Current Measurements
uci h.v.p.s. 30mm gap
0 100 200 300 400 500 600 700 800 −2.5
−2
−1.5
−1
−0.5
0
Ion Current [µA]
Time [ms]
Trek Neg2000VStep 30mm Gap
0 100 200 300 400 500 600 700 800 −2.5
−2
−1.5
−1
−0.5
0
Ion Current [µA]
Time [ms]
Trek Neg2500VStep 30mm Gap
0 100 200 300 400 500 600 700 800 −2.5
−2
−1.5
−1
−0.5
0
Ion Current [µA]
Time [ms]
Trek Neg3000VStep 30mm Gap
0 100 200 300 400 500 600 700 800 −2.5
−2
−1.5
−1
−0.5
0
Ion Current [µA]
Time [ms]
Trek Neg6000VStep 30mm Gap
0 100 200 300 400 500 600 700 800 −2.5
−2
−1.5
−1
−0.5
0
Ion Current [µA]
Time [ms]
Trek Neg7000VStep 30mm Gap
0 100 200 300 400 500 600 700 800 −2.5
−2
−1.5
−1
−0.5
0
Ion Current [µA]
Time [ms]
Trek Neg7250VStep 30mm Gap
ASGSR 2014, Pasadena Chemi-Ion Driven Flows in a Time Varying Electric Field
~~~~

### Pagina 13

Cita: [pdf_eb5f3d6d0cbc5bc023dc, p. 13]. Metodo: native.

~~~~text
Transient Ion Current Measurements
uci h.v.p.s. 35mm gap
0 100 200 300 400 500 600 700 800 −2.5
−2
−1.5
−1
−0.5
0
Ion Current [µA]
Time [ms]
Trek Neg3000VStep 35mm Gap
0 100 200 300 400 500 600 700 800 −2.5
−2
−1.5
−1
−0.5
0
Ion Current [µA]
Time [ms]
Trek Neg3500VStep 35mm Gap
0 100 200 300 400 500 600 700 800 −2.5
−2
−1.5
−1
−0.5
0
Ion Current [µA]
Time [ms]
Trek Neg4000VStep 35mm Gap
0 100 200 300 400 500 600 700 800 −2.5
−2
−1.5
−1
−0.5
0
Ion Current [µA]
Time [ms]
Trek Neg7000VStep 35mm Gap
0 100 200 300 400 500 600 700 800 −2.5
−2
−1.5
−1
−0.5
0
Ion Current [µA]
Time [ms]
Trek Neg7500VStep 35mm Gap
0 100 200 300 400 500 600 700 800 −2.5
−2
−1.5
−1
−0.5
0
Ion Current [µA]
Time [ms]
Trek Neg8000VStep 35mm Gap
ASGSR 2014, Pasadena Chemi-Ion Driven Flows in a Time Varying Electric Field
~~~~

### Pagina 14

Cita: [pdf_eb5f3d6d0cbc5bc023dc, p. 14]. Metodo: native.

~~~~text
Transient Ion Current Measurements
acme h.v.p.s. 25mm gap
0 100 200 300 400 500 600 700 800 −2.5
−2
−1.5
−1
−0.5
0
Ion Current [µA]
Time [ms]
UltraVolt Neg1000VStep 25mm Gap
0 100 200 300 400 500 600 700 800 −2.5
−2
−1.5
−1
−0.5
0
Ion Current [µA]
Time [ms]
UltraVolt Neg2000VStep 25mm Gap
0 100 200 300 400 500 600 700 800 −2.5
−2
−1.5
−1
−0.5
0
Ion Current [µA]
Time [ms]
UltraVolt Neg5000VStep 25mm Gap
0 100 200 300 400 500 600 700 800 −2.5
−2
−1.5
−1
−0.5
0
Ion Current [µA]
Time [ms]
UltraVolt Neg5750VStep 25mm Gap
0 100 200 300 400 500 600 700 800 −2.5
−2
−1.5
−1
−0.5
0
Ion Current [µA]
Time [ms]
UltraVolt Neg6000VStep 25mm Gap
0 100 200 300 400 500 600 700 800 −2.5
−2
−1.5
−1
−0.5
0
Ion Current [µA]
Time [ms]
UltraVolt Neg6250VStep 25mm Gap
ASGSR 2014, Pasadena Chemi-Ion Driven Flows in a Time Varying Electric Field
~~~~

### Pagina 15

Cita: [pdf_eb5f3d6d0cbc5bc023dc, p. 15]. Metodo: native.

~~~~text
Transient Ion Current Measurements
acme h.v.p.s. 35mm gap
0 100 200 300 400 500 600 700 800 −2.5
−2
−1.5
−1
−0.5
0
Ion Current [µA]
Time [ms]
UltraVolt Neg3000VStep 35mm Gap
0 100 200 300 400 500 600 700 800 −2.5
−2
−1.5
−1
−0.5
0
Ion Current [µA]
Time [ms]
UltraVolt Neg3500VStep 35mm Gap
0 100 200 300 400 500 600 700 800 −2.5
−2
−1.5
−1
−0.5
0
Ion Current [µA]
Time [ms]
UltraVolt Neg4000VStep 35mm Gap
0 100 200 300 400 500 600 700 800 −2.5
−2
−1.5
−1
−0.5
0
Ion Current [µA]
Time [ms]
UltraVolt Neg7000VStep 35mm Gap
0 100 200 300 400 500 600 700 800 −2.5
−2
−1.5
−1
−0.5
0
Ion Current [µA]
Time [ms]
UltraVolt Neg7500VStep 35mm Gap
0 100 200 300 400 500 600 700 800 −2.5
−2
−1.5
−1
−0.5
0
Ion Current [µA]
Time [ms]
UltraVolt Neg8000VStep 35mm Gap
ASGSR 2014, Pasadena Chemi-Ion Driven Flows in a Time Varying Electric Field
~~~~

### Pagina 16

Cita: [pdf_eb5f3d6d0cbc5bc023dc, p. 16]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Schlieren Still Images
Initial State Plume In Transition
ASGSR 2014, Pasadena Chemi-Ion Driven Flows in a Time Varying Electric Field
~~~~

### Pagina 17

Cita: [pdf_eb5f3d6d0cbc5bc023dc, p. 17]. Metodo: native.

~~~~text
Average Plume Velocity Vs Field Strength
Uave = H/ 4 t
UCI H.V.P.S.
0 0.5 1 1.5 2 2.5 20
40
60
80
100
120
140
160
Average Plume Velocity Vs Field Strength
25mm Gap
Field Strength [kV/cm]
U
ave [cm/s]
Data
Fit
Confidence bounds
0 0.5 1 1.5 2 2.5 0
50
100
150
200
250
300
Average Plume Velocity Vs Field Strength
30mm Gap
Field Strength [kV/cm]
U
ave [cm/s]
Data
Fit
Confidence bounds
0.4 0.6 0.8 1 1.2 1.4 1.6 1.8 2 2.2 2.4 40
60
80
100
120
140
160
180
200
220
240
Average Plume Velocity Vs Field Strength
35mm Gap
Field Strength [kV/cm]
U
ave [cm/s]
Data
Fit
Confidence bounds
ASGSR 2014, Pasadena Chemi-Ion Driven Flows in a Time Varying Electric Field
~~~~

### Pagina 18

Cita: [pdf_eb5f3d6d0cbc5bc023dc, p. 18]. Metodo: native.

~~~~text
Conclusions
1. Transient Effects due to Voltage Steps
I A wave is created in thermal plume. The wave is more apparent near
satuartion fields and for longer electrode spacings.
I Average plume wave velocity was linear with average field strength
I 75hz oscillation appears in the ion current measurements when field strength
surpasses 2kV/cm. This oscillation can clearly be seen in the schlieren
videos
2. Time-Scales
I UCI H.V. power supply produces electrode potential on the order of a 1kV in
2-3ms. The ACME H.V. power supply produces the same electrode potential
at a rate 0.1kV/ms
I Bulk of ion current arrives downstream at ⇡10-20ms
I Plume reaction time for a voltage step from the UCI power supply was
⇡2-3ms. The plume reaction time for the ACME power supply was seen to
be longer
ASGSR 2014, Pasadena Chemi-Ion Driven Flows in a Time Varying Electric Field
~~~~

### Pagina 19

Cita: [pdf_eb5f3d6d0cbc5bc023dc, p. 19]. Metodo: native.

~~~~text
Acknowledgments
This work is supported by NASAs ISS Research Project via agreement
NNX11AP42A, with Dennis Stocker as contract monitor.
The product names and models are provided only for clarification and are in no way an endorsement on the part of NASA or the federal
government.
ASGSR 2014, Pasadena Chemi-Ion Driven Flows in a Time Varying Electric Field
~~~~

### Pagina 20

Cita: [pdf_eb5f3d6d0cbc5bc023dc, p. 20]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_eb5f3d6d0cbc5bc023dc/p0020.jpg)

~~~~text
Thanks for your attention
ASGSR 2014, PASADENA | CHEMI-ION DRIVEN FLOWS IN A TIME VARYING ELECTRIC FIELD
~~~~
