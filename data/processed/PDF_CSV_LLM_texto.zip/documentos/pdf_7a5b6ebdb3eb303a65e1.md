# Lopez-Camara et al 2019 Numerical Simulations of Laminar Non-premixed CH4-Air Jet Flames

- Identificador: pdf_7a5b6ebdb3eb303a65e1
- Investigaciones: PSI-22
- Tipo de documento: Presentations
- Estado: processed
- Temas detectados automaticamente: computational_models, hardware, electric_fields, oxygen

## Fuentes

- [PSI-22_Presentations_Lopez-Camara et al 2019 Numerical Simulations of Laminar Non-premixed CH4-Air Jet Flames.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-22/Presentations/PSI-22_Presentations_Lopez-Camara%20et%20al%202019%20Numerical%20Simulations%20of%20Laminar%20Non-premixed%20CH4-Air%20Jet%20Flames.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_7a5b6ebdb3eb303a65e1, p. 1]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_7a5b6ebdb3eb303a65e1/p0001.jpg)

~~~~text
No E-Field | E-Field applied
No E-Field
lg
F. B. Carleton & F. J. Weinberg. Nature. Volume 330, p. 635-636 (1987)
~~~~

### Pagina 2

Cita: [pdf_7a5b6ebdb3eb303a65e1, p. 2]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Numerical Simulations of Laminar Non-premixed CH4
-Air Jet 
Flames Influenced by Varying Electric Fields
C-F. Lopez-Camara1 M. Belhi 2 H. G. Im 2 D. Dunn-Rankin 1 
1King Abdullah University of Science and Technology, Clean Combustion Research Center, Thuwal 23955, KSA
2University of California at Irvine, Civil and Environmental Engineering Dept., Irvine 92697, California, USA
11th U.S. National Combustion Meeting
Organized by the Western States Section of the Combustion Institute
March 24 – 27, 2019
Pasadena, California
11th US National Meeting CI. March 24-27, 2019. clopezca@uci.edu 2
~~~~

### Pagina 3

Cita: [pdf_7a5b6ebdb3eb303a65e1, p. 3]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Where is this research placed?
11th US National Meeting CI. March 24-27, 2019. clopezca@uci.edu 3
Figure 1. Schematic of electron temperature and number density for different discharges.
Yiguang Ju and Wenting Sun; Progress Energy and Comb. Sci. Vol. 48, Jun. 2015 P. 21-83
~~~~

### Pagina 4

Cita: [pdf_7a5b6ebdb3eb303a65e1, p. 4]. Metodo: native.

~~~~text
• The response of flames to the electric field has strong dependence 
on the electrode geometry (1g and µg).
• Experiments show that an applied e-field creates a body force 
similar to that of gravity.
• High-fidelity numerical simulations are needed to provide a deeper 
understanding of these observations.
Motivation
11th US National Meeting CI. March 24-27, 2019. clopezca@uci.edu 4
~~~~

### Pagina 5

Cita: [pdf_7a5b6ebdb3eb303a65e1, p. 5]. Metodo: native.

~~~~text
Describe laminar non-premixed CH4
-air flame behavior when an axial 
electric field is applied to the flame using numerical simulations of two 
different jet burner configurations (extruded and jet).
Goal
11th US National Meeting CI. March 24-27, 2019. clopezca@uci.edu 5
~~~~

### Pagina 6

Cita: [pdf_7a5b6ebdb3eb303a65e1, p. 6]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
Burner geometries
289.647 points (144.230 blocks) 289.647 points (144.230 blocks)
EXTRUDED BURNER JET BURNER
11th US National Meeting CI. March 24-27, 2019. clopezca@uci.edu 6
All units in [mm] - Meshes and simulations made using OpenFOAM®
~~~~

### Pagina 7

Cita: [pdf_7a5b6ebdb3eb303a65e1, p. 7]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
7
Boundary conditions
The chemical kinetics model used was published by M. Belhi et al. [Combust. Theory Modelling, 2017].
Chemical kinetics model • 76 reactions; 25 species
• Includes positive and negative ions (H3O+, O2
-
, O-
, OH-
, CHO3
-
, CO3
-
) and electrons. • Secondary ionization (electron impact) reactions are not considered in the model.
11th US National Meeting CI. March 24-27, 2019. clopezca@uci.edu 7
No super-saturation 
predictions
Drawing not in scale
~~~~

### Pagina 8

Cita: [pdf_7a5b6ebdb3eb303a65e1, p. 8]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
8
11th US National Meeting CI. March 24-27, 2019. clopezca@uci.edu 8
Results 
Extruded burner Jet burner
Figure 2. (Fig. 3 paper) 
Distribution of the H3O+
number density, 
potential isolines 
(horizontal lines) and 
electric force lines.
Both simulations at 
saturation.
~~~~

### Pagina 9

Cita: [pdf_7a5b6ebdb3eb303a65e1, p. 9]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
9
Results 
Extruded burner Jet burner
11th US National Meeting CI. March 24-27, 2019. clopezca@uci.edu 9
Figure 3a. (Fig. 4 paper) I-V curves. 
Experimental values are from Tinajero et al. (CST, 10, 1739–1750)
0
0,5
1
1,5
2
2,5
0 1 2 3 Ion Current [μA]
Field Strength [kV/cm]
Experimental
Numerical
0
0,5
1
1,5
2
2,5
0 1 2 3 Ion Current [μA]
Field Strength [kV/cm]
Experimental
Numerical
~~~~

### Pagina 10

Cita: [pdf_7a5b6ebdb3eb303a65e1, p. 10]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
0
0,5
1
1,5
2
2,5
3
3,5
0 1 2 3 Ion Current [μA]
Field Strength [kV/cm]
0
0,5
1
1,5
2
2,5
3
3,5
0 1 2 3 Ion Current [μA]
Field Strength [kV/cm]
10
Results 
Extruded burner Jet burner
11th US National Meeting CI. March 24-27, 2019. clopezca@uci.edu 10
Figure 3b. I-V curves (simulation up to supersaturation region)
Experimental values are from Tinajero et al. (CST, 10, 1739–1750)
Experimental
Numerical
Experimental
Numerical
~~~~

### Pagina 11

Cita: [pdf_7a5b6ebdb3eb303a65e1, p. 11]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
11
Results 
Extruded burner Jet burner
11th US National Meeting CI. March 24-27, 2019. clopezca@uci.edu 11
4000V 5000V 4000V 4500V 5000V
Figure 4. Contour XH3O+ , potential isolines and electric field force vectors (at expected saturation plateau)
~~~~

### Pagina 12

Cita: [pdf_7a5b6ebdb3eb303a65e1, p. 12]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
12
11th US National Meeting CI. March 24-27, 2019. clopezca@uci.edu 12
Figure 5. Downstream current density (anode). Experimental measurements, unipolar flame model, 
and the Warburg distribution (theoretical).
M. Papac and D. Dunn-Rankin; Combustion Theory and Modelling, July 2007
Results
Literature - Jet geometry
~~~~

### Pagina 13

Cita: [pdf_7a5b6ebdb3eb303a65e1, p. 13]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
13
11th US National Meeting CI. March 24-27, 2019. clopezca@uci.edu 13
Figure 6. Downstream current density (anode). Experimental measurements. Left figure units in [mm].
J. Tinajero and D. Dunn-Rankin, Combustion and Flame, Vol. 199 January 2019, P. 365-376
Results
Literature - Flush geometry
~~~~

### Pagina 14

Cita: [pdf_7a5b6ebdb3eb303a65e1, p. 14]. Metodo: native.

Calidad: figures_not_digitized.

~~~~text
14
11th US National Meeting CI. March 24-27, 2019. clopezca@uci.edu 14
Results 
Extruded burner Jet burner
Figure 7. (Fig. 5 paper) Downstream current density (anode) at different field strengths. Computational results.
1,14kV/cm
0,57kV/cm 0,14kV/cm
1,01kV/cm
~~~~

### Pagina 15

Cita: [pdf_7a5b6ebdb3eb303a65e1, p. 15]. Metodo: native.

~~~~text
• There are indications that the model will be able to reproduce accurately the I-V curves obtained
experimentally. • The I-V curves obtained are showing an agreement with the experiments by less than a 30%
difference in the sub-saturation domain, but there remains some further analysis of the
simulation results and physical understanding on how to capture the transition to saturation
accurately. • Further simulations are needed to test if the model will predict the saturation region plateau of the
I-V curve. • Future ion characterization will help explain the behavior of ions and determine what produces the
valley in the current density downstream of the jet burner. This characterization will be valuable
also to observe in detail the charge flux.
Summary
11th US National Meeting CI. March 24-27, 2019. clopezca@uci.edu 15
~~~~

### Pagina 16

Cita: [pdf_7a5b6ebdb3eb303a65e1, p. 16]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, sparse_text_or_visual_only, tiled_ocr_not_manually_verified.

[Imagen de la pagina](../imagenes/pdf_7a5b6ebdb3eb303a65e1/p0016.jpg)

~~~~text
Thank you
~~~~
