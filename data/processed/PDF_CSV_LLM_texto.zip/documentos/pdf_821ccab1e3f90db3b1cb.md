# 21328 test sheets

- Identificador: pdf_821ccab1e3f90db3b1cb
- Investigaciones: PSI-10
- Tipo de documento: Raw Data
- Estado: processed
- Temas detectados automaticamente: pressure, ignition, hardware, soot, oxygen

## Fuentes

- [PSI-10_Raw Data_21328 test sheets.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-10/Raw%20Data/PSI-10_Raw%20Data_21328%20test%20sheets.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_821ccab1e3f90db3b1cb, p. 1]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_821ccab1e3f90db3b1cb/p0001.jpg)

~~~~text
ACME / Flame Design (inverse flame) - Science Test Sheet
est date: | CME test
Local time: | est of day#: I
MT: | Flame of day #:
TEST CONDITIONS | Control? | Kfully automated 'manual'
Test type? ignition | Cother | (O
Chamber atmosphere | 02 bottle: | 85% (volume)
C2H4 conc. | .a.;Z | % (vol, nominal) | Burner 02 conc.: | % (volume
C2H4 conc. | % (vol, per calc) | 2 flow rate: | slpm (N2 basis)
Chamber pressure: | psia (CIR avg per FCU | N 2 flow rate: | slpm
ent before? o no | to 0-2— psia
Iso just before? | fan GC scrub
FP? no•kfixed moving back-n-forth
INSTRUMENTATION | Gain: D DataCam | ops camera
DataCam: filter? *clear o BG7 0 CH* CH20 | ROI? Kfull reduced | fps
ntensified: filter? clearXCH* CH20 none | ROI? Cfull o reduced | fps
backlight filter? no *fes | CIR backlight? q-ao yes fps-?-e-t5T30
FLAME BEHAVIOR
Flame hot cool maybe cool | Ignited? •yes a no c.i yes, but ..
Flame hole/opening partially detached | 00t@ignition none littl | lots
Flame ü oscillating ü unsteady quasi-stead | SOOt@middle none littl | lots
Out ext. detect time out temp. limit | Soot@end | o none little lots
POST-TEST CONDITIONS
Fuel conc. | •?-7ÄDC % (vol, per calc) | Chamber pressure: 47 psia (CIR avg per FCU)
alve safety timer | sec | Oxidizer bottle pressure: | psia
*GENERAL COMMENTS
19 Oct. 2021
~~~~

### Pagina 2

Cita: [pdf_821ccab1e3f90db3b1cb, p. 2]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_821ccab1e3f90db3b1cb/p0002.jpg)

~~~~text
ACME / Flame Design (inverse flame) - Science Test Sheet
est date: | CME test | 'Z)
Local time: | est of day#:
MT: | Flame of day
TEST CONDITIONS | Control? | automated o 'manual'
Test type? ignition no-flametk standard Other
Chamber atmosphere | 02 bottle: | 85% (volume)
C2H4 conc. | % (vol, nominal) | Burner 02 conc.: | % (volume)
C2H4 conc. | e/eo,/o (vol, per calc) | 02 flow rate: | slpm (N2 basis
hamber pressure: | psia (CIR avg per FCU) | N2 flow rate: | slpm
ent before . no o yes, to | psia
Iso just before? | fan D GC scrub
FP? o no Sfixed c] moving back-n-forth
INSTRUMENTATION | Gain: | DataCam 2— ops camera
DataCam: filter? •clear o BG7 0 CH* CH20 | ROI? | reduced | fps
q_lntensified: filter? clearÉ CH* o CH20 0 none | ROI? EL full o reduced | ZZ fps
g-HiBMs•: backlight filter? no*yes | CIR backlight?wno yes
FLAME BEHAVIOR
Flameéhot cool o maybe cool | ü no Cl yes, but ...*
Flame hole/opening o partially detached | SOOt@ignition none c:] littleE lots
Flame oscillating o unsteady quasi-stead | SOOt@middIe c] none c] little Zlots
Out o ext. detects •me out temp. limit | SOOt@end | o none o little Llots
POST-TEST CONDITIONS
Fuel conc. | % (vol, per calc) | hamber pressure: / Bpsia (CIR avg per FCU)
alve safety timer | sec | Oxidizer bottle pressure: | psia
*GENERAL COMMENTS
JL 741
o
19 Oct. 2021
~~~~

### Pagina 3

Cita: [pdf_821ccab1e3f90db3b1cb, p. 3]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_821ccab1e3f90db3b1cb/p0003.jpg)

~~~~text
ACME / Flame Design (inverse flame) - Science Test Sheet
TEST CONDITIONS | ontrol? | Zfully automated o 'manual'
Test type? ignition o no-flame Astandard pother
Chamber atmosphere | 02 bottle: | 85% (volume)
C2H4 conc. | % (vol, nominal) | Burner 02 conc.. | 0/0 (volume
C2H4 conc. | % (vol, per calc) | 02 flow rate: | slpm (N2 basis)
hamber pressure: | psia (CIR avg per FCU) | N 2 flow rate: | slpm
ent before? B-no yes, to | psia
Iso just before? | fan GC scrub
FP? no | c] moving back-n-forth
INSTRUMENTATION | ain: | DataCam ZI ops camera
*DataCam: filter? *lear o BG7 0 CH* o CH20 | ROI?Qfull reduced | fps
g-lntensified: filter? clear $CH* o CH20 0 none | ROI? efull reduced | 2 fps
backlight filter? nog.yes | CIR | yes
FLAME BEHAVIOR
Flame 'k hot ü cool maybe cool | Ignited. yes o no o yes, but .
Flame hole/opening partially detached | Soot@ignition o none o little" Ots
Flame oscillating unsteady' quasi-stead | Soot@middle 4 none little lots
Out ext. detect time out temp. limit | oot@end | one o little o lots
POST-TEST CONDITIONS
Fuel conc. | % (vol, per calc) | hamber pressure: | psia (CIR avg per FCU
alve safety timer | Z 3 | sec | xidizer bottle pressure: | psia
*GENERAL COMMENTS
4.es-f—
19 Oct. 2021
4cs+
~~~~

### Pagina 4

Cita: [pdf_821ccab1e3f90db3b1cb, p. 4]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_821ccab1e3f90db3b1cb/p0004.jpg)

~~~~text
ACME / Flame Design (inverse flame) - Science Test Sheet
est date: | CME test #: | 28
Local time: | est of day #:
GMT: | Flame of day #:
TEST CONDITIONS | Control? | fully automated 'manual'
Test type? o ignition o no-flamewstandard tÅother
hamber atmosphere | 02 bottle: | 85% (volume)
C2H4 conc. | % (vol, nominal) | Burner 02 conc.: | % (volume)
C2H4 conc. | % (vol, per calc) | 02 flow rate: | slpm (N2 basis)
hamber pressure: | psia (CIR avg per FCU) | slpm
ent before? o n | yes, to | psia
Iso just before? Üfån GC scrub
no | o moving c] back-n-forth
INSTRUMENTATION | Gain: | C) DataCam | ops camera
RDataCam: | BG7 | CH20 | ROI? kfull o reduced | fps
Älntensified: filter? clear LCH* CH20 none | ROI? Cfull reduced
a-HiBMs: backlight filter? noÅyes | CIR backlight? | yes fps?-c-1fi-30
FLAME BEHAVIOR
Flame hot cool maybe cool | Ignited? ues o no yes, but
Flame o hole/opening €partially detached | Soot@ignition none little•Aots
Flame g-oscillating (_unsteady quasi-stead | 00t@middle Ånone little o lots
Out | detect time out o temp. limit | SOOt@end | gone D little lots
POST-TEST CONDITIONS
Fuel conc. | % (vol, per calc) | Chamber pressure: | psia (CIR avg per FCU)
alve safety timer | sec | Oxidizer bottle pressure: | t psia
*GENERAL COMMENTS
A V & 5q, e-4M1/
19 Oct. 2021
~~~~

### Pagina 5

Cita: [pdf_821ccab1e3f90db3b1cb, p. 5]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_821ccab1e3f90db3b1cb/p0005.jpg)

~~~~text
ACME / Flame Design (inverse flame) - Science Test Sheet
est date: | CME test#: | Z
Local time: | 7>60 | est of day #:
GMT: | Flame of day #: | eel
TEST CONDITIONS | Control? | A fully automated 'manual'
Test type? o ignition no-flame
Chamber atmosphere | 2 bottle: | 85% (volume)
2H4 conc. | % (vol, nominal) | Burner 02 conc.. | 0/0 (volume)
C2H4 conc. | % (vol, per calc) | 02 flow rate: | slpm (N2 basis
hamber pressure: -C) psia (CIR avg per FCU) | slpm
ent before? É-no yes, to | psia
Iso just before? •fan o GCo scrub
FP? CJ no | moving back-n-forth
INSTRUMENTATION | Gain: | Ö DataCam _æl_ ops camera
DataCam: filter? | BG7 | CH20 | ROI? < full c.) reduced | fps
Intensified: filter? clear gay-I* CH20 none | ROI? g full reduced | fps
backlight filter? no.yes | CIR backlight?dno yes fps-?-æ4s-g-3Q— ne
FLAME BEHAVIOR
Flame hot cool maybe cool | Ignited? yes no o yes, but
Flame a hole/opening*partially detached | 00t@ignition none ü little Klots
Flame g.-oscillating Åunsteady ü quasi-stead | 00t@middle none little o lots
Out Vext. detect ü time out temp. limit | 00t@end | Z-none little lots
POST-TEST CONDITIONS
*GENERAL COMMENTS
5 | 14)oers
a
19 Oct. 2021
~~~~

### Pagina 6

Cita: [pdf_821ccab1e3f90db3b1cb, p. 6]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_821ccab1e3f90db3b1cb/p0006.jpg)

~~~~text
ACME / Flame Design (inverse flame) - Science Test Sheet
est date: | CME test
Local time: | est of day#:
MT: | 23 | Flame of day #:
TEST CONDITIONS | ontrol? | Afully automated 'manual'
Test type? ignition o | Rother
Chamber atmosphere | 02 bottle: | 85% (volume)
C2H4 conc. | % (vol, nominal) | Burner 02 conc.. | % (volume)
C2H4 conc. | ZO | % (vol, per calc) | 02 flow rate: | 2 | (N2 basis)
hamber pressure: IWD psia (CIR avg per FCU | CD | slpm | no
ent before? | o yes, to | psia
Iso just before? | fan o GC D scrub
FP? no (fixed moving c] back-n-forth
INSTRUMENTATION | ain: | DataCam | ops camera
DataCam: filter?kclear BG7 CH* CH20 | ROI? (full reduced | fps
Elntensified: filter? a | CH20 a none | ROI? | o reduced | 23fps
EHiBMs: backlight filter? | yes | CIR backlightæno yes
5
FLAME BEHAVIOR
Flame A-hot o cool maybe cool | Ignited? yes no yes, but ..
Flame | detached | 00t@ignition D none little tots
Flame oscillating Lunsteady c] quasi-stead | 00t@middlef none little lots
Ou | ext. detect time out c] temp. limit | oot@end | none c] little lots
POST-TEST CONDITIONS
Fuel conc. | % (vol, per calc) | hamber pressure: | D psia (CIR avg per FCU)
alve safety timer | 8 | sec | xidizer bottle pressure: | 34 psia
*GENERAL COMMENTS
TÉfO
19 Oct. 2021
~~~~

### Pagina 7

Cita: [pdf_821ccab1e3f90db3b1cb, p. 7]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_821ccab1e3f90db3b1cb/p0007.jpg)

~~~~text
ACME / Flame Design (inverse flame) - Science Test Sheet
est date: | 34 | CME test#:
Local time: | est of day #: -7
MT: | Z € | 204 | Flame of day#: 7
TEST CONDITIONS | Control? | automated 'manual'
Test type? ignition no-flame estandard ktother
Chamber atmosphere | 02 bottle: | 85% (volume)
C2H4 conc. | % (vol, nominal) | Burner 02 conc.: | % (volume
C2H4 conc. | % (vol, per calc) | 02 flow rate: | slpm (N2 basis)
Chamber pressure: | psia (CIR avg per FCU | slpm
ent | yes, to | psia
Iso just before? | GC scrub
o noSfixed moving back-n-forth
INSTRUMENTATION | Gain: | DataCam | ops camera
DataCam: filter?Äclear o BG7 CH* o CH20 | ROI? K full D reduced | fps
Antensified: filter? clear | D CH20 none | ROI? ETfull reduced | fps
æ-HiBMs: backlight filter? | yes | CIR backlight?Äo o yes fps-?-e4Se-30
FLAME BEHAVIOR
Flame Khot ü cool maybe cool | Ignited?kyes c] no o yes, but ...*
Flame c] hole/openin | partially detached | SOOt@ignition o nonesQlittle lots
7
Flam Q" oscillating | 00t@middle none little lots
ut ø_ext. detect time out temp. limit | 00t@end | enone o little 1.3 lots
POST-TEST CONDITIONS
*GENERAL COMMENTS
19 Oct. 2021
~~~~

### Pagina 8

Cita: [pdf_821ccab1e3f90db3b1cb, p. 8]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_821ccab1e3f90db3b1cb/p0008.jpg)

~~~~text
ACME / Flame Design (inverse flame) - Science Test Sheet
est date: | test#: | 5
Local time: | est of day #:
GMT: | 2-1 Z | Flame of day #:
TEST CONDITIONS | ontrol? | fully automated 'manual'
Test type? a ignition o no-flamezstandard€other
Chamber atmosphere | 02 bottle: | 85% (volume)
C2H4 conc. | % (vol, nominal) | Burner 02 conc.. | % (volume
C2H4 conc. | % (vol, per calc) | 02 flow rate: | slpm (N2 basis)
hamber pressure: | psia (CIR avg per FCU) | rate: | slpm | AO
ent before? kno o yes, to | psia
Iso just before? Ufan GC scrub
o no fixed o moving back-n-forth
INSTRUMENTATION | ain: | O DataCam zl_ ops camera
ØataCam: | BG7 | CH20 | full reduced | fps
V-lntensified: filter? clear | CH20 none | full c] reduced | fps
344i,BMsi backlight filter? no | CIR backlight?p no yes fps2æ45-e-30 ne
FLAME BEHAVIOR
o cool o maybe cool | Ignited? Kyes no yes, but .
Flame hole/opening | artially detached | 00t@ignition none | t] lots
Flame | quasi-stead | 00t@middle none Cl little lots
Out ext. detect o time out o temp. limit | SOOt@end e*-none little ü lots
POST-TEST CONDITIONS
Fuel conc. | % (vol, per calc) | Chamber pressure: | psia (CIR avg per FCU)
alve safety timer | i | sec | Oxidizer bottle pressure: | psia
*GENERAL COMMENTS
19 Oct. 2021
~~~~

### Pagina 9

Cita: [pdf_821ccab1e3f90db3b1cb, p. 9]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_821ccab1e3f90db3b1cb/p0009.jpg)

~~~~text
ACME / Flame Design (inverse flame) - Science Test Sheet
est date: | CME test #:
Local time: | est Of d a y # :
GMT: | Flame of day #:
Rack Officer (RO): | PD (ACME):
DMO (CIR): | Researcher:
TEST CONDITIONS | ontrol? | fully automated 'manual'
Test type? ignition no-flame gstandardk other
Chamber atmosphere | 02 bottle: | 85% (volume)
C2H4 conc. | % (vol, nominal) | Burner 02 conc.. | % (volume)
C2H4 conc. | bio O/o(vol, | 02 flow rate: | slpm (N2 basis)
Chamber pressure: ( | psia (CIR avg per FCU) | N 2 flow rate: | Deiz- slpm
ent before? E-no yes, to | psia
Iso just before? gfan GC scrub
FP? no k fixed moving back-n-forth
INSTRUMENTATION | Gain: | Ö DataCam -Z-a ops camera
DataCam: filter? •clear BG7 CH* CH20 | ROI? Qfull Cl reduced | fps
e-lntensified: filter? clear RCH* a CH20 none | ROI? gfull reduced | ZE.- fps
filter? noßyes | CIR | yes fps?-E45a-30
J3Åt5
FLAME BEHAVIOR
Flame | ot o cool maybe cool | Ignited? yes no yes, but .
Flame hole/opening L-partially detached | Soot@ignition none little lots
me oscillating <unsteady quasi-stead | SOOt@middle none little lots
Out ext. detect time out ü temp. limit | 00t@end | Znone little o lots
POST-TEST CONDITIONS
Fuel conc. | % (vol, per calc) | hamber pressure: | ,Dpsia (CIR avg per FCU
alve safety timer | 7 | sec | Oxidizer bottle pressure: | psia
*GENERAL COMMENTS
19 Oct. 2021
~~~~
