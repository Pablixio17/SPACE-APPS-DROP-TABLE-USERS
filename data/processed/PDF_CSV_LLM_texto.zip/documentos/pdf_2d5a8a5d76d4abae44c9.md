# 19115 test sheets

- Identificador: pdf_2d5a8a5d76d4abae44c9
- Investigaciones: PSI-10
- Tipo de documento: Raw Data
- Estado: processed
- Temas detectados automaticamente: pressure, ignition, hardware, oxygen

## Fuentes

- [PSI-10_Raw Data_19115 test sheets.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-10/Raw%20Data/PSI-10_Raw%20Data_19115%20test%20sheets.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_2d5a8a5d76d4abae44c9, p. 1]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_2d5a8a5d76d4abae44c9/p0001.jpg)

~~~~text
ACME / Flame Design (normal flame) - Science Test Sheet
est date: | 2-5 | CME test#: 19/' Al
Local time: | est of day #:
GMT: | Flame of day #:
TEST CONDITIONS | Control? | fully automated o 'manual'
Test type? | o no-flame o standard o other
xygen conc. | % (volume) + | Burner type: | {1/4" sphere jet
hamber pressure: | $ psia | uR Fuel Bottle: | CH4 | % | 0/0
ent before? o no Ryes, to | psia | Burner fuel conc.: | LD % (volume)
Air' added? o no uyes, to | psia | Fuel flow rate: 0073 slpm (N2 basis)
Iso just before? Wan ZGC scrub | slpm
INSTRUMENTATION | FP? no fixed moving back-n-forth
5DataCam: | BG7 | CH20 | ROI? (full reduced | fps
filter? o clearÄCH* CH20 none | ROI? *full reduced | Z fps
HiBMs: backlight filter? o no eyes | CIR backlight? o no Q yes fps?K15 30
FLAME BEHAVIOR | Ignited? yes no o yes, but ...*
Flame asymmetric o hole/opening(s) | oot o none* ignition only little lots
Flame oscillating Yunsteady Rblew out | oot@end none ignition little lots
*GENERAL COMMENTS
C-/t.oer¯
4-0 (.-Ø
~~~~

### Pagina 2

Cita: [pdf_2d5a8a5d76d4abae44c9, p. 2]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_2d5a8a5d76d4abae44c9/p0002.jpg)

~~~~text
ACME / Flame Design (normal flame) - Science Test Sheet
est date: | 25 2.0 | CME test#: (7115
Local time: | est of day | Z
MT: | Flame of day#:
Rack Officer (RO): | PD (ACME):
DMO (CIR): | Researcher:
TEST CONDITIONS | Control? | (fully automated o 'manual'
Test type? A ignition no-flame ü standard other
Oxygen conc. | % (volume) | Burner type: | R/4" sphere c] jet
Chamber pressure: | psia | Fuel Bottle: CH4 | % ü C2H4
ent before? o no yes, to | psia | Burner fuel conc.: so % (volume)
Air' added? o no o yes, to | psia | Fuel flow rate: 4073 slpm (N2 basis)
Iso just before? Xfan GC scrub | N2 flow rate: D.D7B slpm
INSTRUMENTATION | FP? no c] fixed o moving back-n-forth
DataCam: filter? *clear o BG7 | CH20 | ROI? Atull o reduced | fps
Clntensified: filter? clear | CH20 none | ROI? Üull reduced | fps
RHiBMs: backlight filter? no eyes | CIR backlight? no (yes fps? 15 30
FLAME BEHAVIOR | Ignited? yes | o yes, but ...*
Flame asymmetric o hole/opening(s) | 00t o none o ignition only ü little lots
Flame oscillating o unsteady o blew out | oot@end ü none o ignition o little lots
*GENERAL COMMENTS
2051 Z | -/•esA—
pm7¯l
6 Feb. 2019
~~~~

### Pagina 3

Cita: [pdf_2d5a8a5d76d4abae44c9, p. 3]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_2d5a8a5d76d4abae44c9/p0003.jpg)

~~~~text
ACME / Flame Design (normal flame) - Science Test Sheet
est date: | A.-a.1 | CME test #:
Local time: | est of day #:
MT: | Flame of day #:
TEST CONDITIONS | ontrol? | [Ktully automated 'manual'
Test type? Ngnition no-flame o standard o other
xygen conc. | % (volume) | Burner type: | K 1/4" sphere o jet
Chamber pressure: | psia | OR Fuel Bottle: 0 CH4 | % dC2H4
ent before? | o yes, to | psia | Burner fuel conc.: | % (volume)
Air' added? | o yes, to | psia | Fuel flow rate: | slpm (N2 basis)
Iso just before? lifan GC scrub | N2 flow rate: | slpm
INSTRUMENTATION | FP? no fixed moving back-n-forth
*DataCam: filter? Kclear BG7 | CH20 | ROI? R_full reduced | fps
Xlntensified: filter? clear {CH* CH20 0 none | ROI? *full reduced | 4fps
EHiBMs: backlight filter? no (yes | CIR backlight? now-yes | 30
FLAME BEHAVIOR | Ignited? Kyes o no o yes, but ...*
Flame o asymmetric c] hole/opening(s) | 00t o none •gnition only o little lots
Flame {oscillating | nsteady | lew out | oot@end none o ignition little o lots
*GENERAL COMMENTS
6 Feb. 2019
~~~~

### Pagina 4

Cita: [pdf_2d5a8a5d76d4abae44c9, p. 4]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_2d5a8a5d76d4abae44c9/p0004.jpg)

~~~~text
ACME / Flame Design (normal flame) - Science Test Sheet
est date: | A | CME test
Local time: | est of day #:
MT: | 1 | Flame of day#:
TEST CONDITIONS | Control? | ully automated 'manual'
Test type? Y-ignition no-flame o standard other
Oxygen conc. | % (volume) | Burner type: | 1/4" sphere o jet
hamber pressure: | psia | R Fuel Bottle: | CH4 | % gC2H4
ent before? | yes, to | psia | Burner fuel conc.: | % (volume)
Air' added? Y-no o yes, to | psia | Fuel flow rate: 0092-slpm (N2 basis)
Iso just before? Oan GC scrub
INSTRUMENTATION | FP? o no fixed o moving back-n-forth
DataCam: filter?k clear BG7 | CH20 | ROI? kfull reduced | fps
_
Intensified: filter? o clearø-CH* CH20 0 none | ROI? | reduced | fps
HiBMs: backlight filter? no | CIR backlight? no gyes fps? (15 30
FLAME BEHAVIOR | Ignited? Kyes no o yes, but ...*
Flame o asymmetric hole/opening(s) | 00t Khone o ignition only a little lots
Flame Oscillating unsteady Qblew out | oot@end none o ignition o little o lots
*GENERAL COMMENTS
ZOZ | oz- beat-z— | ken
6 Feb. 2019
~~~~

### Pagina 5

Cita: [pdf_2d5a8a5d76d4abae44c9, p. 5]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_2d5a8a5d76d4abae44c9/p0005.jpg)

~~~~text
ACME / Flame Design (normal flame) - Science Test Sheet
est date: | CME test#: 8115Cl
Local time: | est of day #:
GMT: 17/1 | Flame of day #:
TEST CONDITIONS | Control? | kfully automated 'manual'
Test type? *ignition no-flame o standard o other
Oxygen conc. | % (volume) -k | Burner type: | 1/4" sphere o jet
hamber pressure: | psia OR Fuel Bottle: o CH4 | % o C2H4ZQ0/0
ent before? Beno o yes, to | psia | Burner fuel conc.: | % (volume)
Air' added? Y-no o yes, to | psia | Fuel flow rate: DAslpm (N2 basis)
Iso just before? ufan GC scrub | slpm
INSTRUMENTATION | FP? o no a fixed o moving o back-n-forth
DataCam: filter? *clear o BG7 0 CH* CH20 | ROI? Cfull reduced | fps
_
E Intensified: filter? o clear *CH* CH20 0 none | ROI? y-full o reduced | Zfps
HiBMs: backlight filter? o nozyes | CIR backlight? no €yes | 0 30
e«Es
FLAME BEHAVIOR | Ignited? o yeskno o ye but
, | .
Flame o asymmetric o hole/opening(s) | 00t o none o ignition only little o lots
Flame oscillating unsteady o blew out | oot@end none ignition little o lots
POST-TEST CONDITIONS | Oxidizer bottle pressure: 4 psia
xygen conc. | % (volume) | alve safety timer | 77 Z sec
*GENERAL COMMENTS
c-æ.€be-r—
O-æ
6 Feb. 2019
~~~~

### Pagina 6

Cita: [pdf_2d5a8a5d76d4abae44c9, p. 6]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_2d5a8a5d76d4abae44c9/p0006.jpg)

~~~~text
ACME / Flame Design (normal flame) - Science Test Sheet
est date: | 201 | CME test #:
Local time: | est of day#:
MT: | 2/:zl | Flame of day #:
Rack Officer (RO): | PD (ACME):
DMO (CIR): | Researcher:
TEST CONDITIONS | Control? | fully automated 'manual'
Test type?kignition no-flame standard o other
xygen conc. | % (volume) | Burner type: | &1/4" sphere o jet
Chamber pressure: | psia | Fuel Bottle: | CH4 | 0/0 | 2H4
ent before? | yes, to | psia | Burner fuel conc.: | % (volume)
Air' added? no yes, to | psia | Fuel flow rate: 092-slpm (N2 basis)
Iso just before? Afan GC scrub | slpm
INSTRUMENTATION | FP? no fixed moving back-n-forth
R'DataCam: filter? clear BG7 | CH20 | ROI? Wull reduced | fps
Intensified: filter? clear CH* o CH20 0 none | ROI? X full ü reduced | ZZ fps
HiBMs: backlight filter? o no Ryes | CIR backlight? no yes fps?R 15 30
FLAME BEHAVIOR | Ignited? yes a no o yes, but ...*
Flame o asymmetric D hole/opening(s) | ootd none a ignition only o little c] lots
Flame A-oscillating wunsteady | out | ignition o little o lots
*GENERAL COMMENTS
20<24-70
6 Feb. 2019
~~~~

### Pagina 7

Cita: [pdf_2d5a8a5d76d4abae44c9, p. 7]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_2d5a8a5d76d4abae44c9/p0007.jpg)

~~~~text
ACME / Flame Design (normal flame) - Science Test Sheet
est date: Ark* | CME test#: [€115 F
Local time: | est of day #:
GMT: | Flame of day #:
TEST CONDITIONS | Control? | fully automated 'manual'
Test type? | o no-flame a standard other
xygen conc. | % (volume) | Burner type: | (1/4" sphere c] jet
Chamber pressure: | psia | Fuel Bottle: üCH4 | C2H4
ent before? kno yes, to | psia | Burner fuel conc.: | o % (volume)
Air' added? eno yes, to | psia | Fuel flow rate: OD5z- slpm (N2 basis)
Iso just before? cfan GC scrub | N2 flow rate: | slpm
INSTRUMENTATION | FP? no o fixed moving ü back-n-forth
(DataCam: filter? R clear BG7 | CH20 | ROI? Zfull reduced | fps
Z Intensified: filter? clear q-CH* o CH20 0 none | ROI? z full o reduced | Z fps
backlight filter? no»4 yes | CIR backlight? o no Eyes fps? €15 30
FLAME BEHAVIOR | Ignited? Kyes no yes, but ...*
Flame o asymmetric o hole/opening(s) | oot<none ignition only little lots
Flame oscillating unsteady Qblew out | oot@end none o ignition little o lots
*GENERAL COMMENTS
6 Feb. 2019
~~~~

### Pagina 8

Cita: [pdf_2d5a8a5d76d4abae44c9, p. 8]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_2d5a8a5d76d4abae44c9/p0008.jpg)

~~~~text
ACME / Flame Design (normal flame) - Science Test Sheet
est date: | CME test #:
Local time: | est of day #:
GMT: | (5 | 2-2=1 S | Flame of day #:
TEST CONDITIONS | Control? | fully automated 'manual'
Test type? Xignition no-flame o standard other
Oxygen conc. | % (volume) | Burner type: | b4/4" sphere o jet
hamber pressure: | psia | Fuel Bottle: D CH4 | 0/0 XC2H4
ent before? no yes, to | psia | Burner fuel conc.: | % (volume)
Air' added? | to | '2 Fuel flow rate:
wno o yes, | psia | D.05zslpm (N2 basis)
Iso just before? *fan GC scrub | N2 flow rate: | ,07Bslpm
INSTRUMENTATION | FP?Xno fixed moving o back-n-forth
pataCam: filter? zclear o BG7 c] CH* o CH20 | ROI?æ full ü reduced | fps
Zlntensified: filter? clear gCH* CH20 none | ROI? full c] reduced | fps
gHiBMs: backlight filter? no *yes | CIR backlight? | yes fps?se 15 30
FLAME BEHAVIOR | Ignited? *yes a no yes, but
Flame a asymmetric o hole/opening(s) | 00 | none ignition only o little o lots
Flame oscillatingzunsteady blew out | oot@end none ignition o little o lots
*GENERAL COMMENTS
b
Be03
6 Feb. 2019
~~~~

### Pagina 9

Cita: [pdf_2d5a8a5d76d4abae44c9, p. 9]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_2d5a8a5d76d4abae44c9/p0009.jpg)

~~~~text
ACME / Flame Design (normal flame) - Science Test Sheet
est date: | CME test | /
Local time: | 44 | est of day #:
MT: | Flame of day#:
TEST CONDITIONS | Control? | automated o 'manual'
Test type? Lignition c] no-flame o standard other
Oxygen conc. | *-2--1 % (volume) | Burner type: | A 1/4" sphere jet
Chamber pressure: | 4 | psia | uR Fuel Bottle: | CH4 | % C2H4 | 0/0
ent before? q no yes, to | psia | Burner fuel conc.: | % (volume)
Air' added? | yes, to | psia | Fuel flow rate: a | slpm (N2 basis)
Iso just before? Wan GC scrub | N2 flow rate: O,2.D | slpm
INSTRUMENTATION | FP? | fixed moving back-n-forth
•atacam: filter? | BG7 | CH20 | ROI? •full reduced | fps
filter? clear BCH* CH20 0 none | ROI? g full reduced | 2-2 fps
*HiBMs: backlight filter? noguyes | CIR backlight? o nonyes fps? g-15 30
FLAME BEHAVIOR | Ignited? yes | yes, but ...*
Flame asymmetric hole/opening(s) | 00t o none o ignition only little c] lots
Flame o oscillating unsteady o blew out | oot@end o none ignition a little D lots
*GENERAL COMMENTS
d-Lc.A.cber
Z
6 Feb. 2019
~~~~

### Pagina 10

Cita: [pdf_2d5a8a5d76d4abae44c9, p. 10]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_2d5a8a5d76d4abae44c9/p0010.jpg)

~~~~text
ACME / Flame Design (normal flame) - Science Test Sheet
est date: | 25 | CME test #: | 11
Local time: | 752-7 | est of day #:
MT: | Flame of day #:
TEST CONDITIONS | Control? | fully automated 'manual'
Test type? | o no-flame o standard other
Oxygen conc. | 2 | % (volume) | Burner type: | ZI/4" sphere jet
Chamber pressure: | psia | Fuel Bottle: | CH4 | % a C2H4
ent before? | o yes, to | psia | Burner fuel conc.: | .40 % (volume)
Air' | o yes, to | psia | Fuel flow rate: o. | slpm (N2 basis)
Iso just before? | fan a GC o scrub | N2 flow rate: | ö- | slpm
INSTRUMENTATION | no o fixed moving back-n-forth
ADataCam: filter? Kclear BG7 CH* CH20 | ROI? < full o reduced | fps
Antensified: filter? clear KCH* CH20 none | ROI? gfull reduced | 23- fps
KHiBMs: backlight filter? no *yes | CIR backlight? noyyes fps? *-15 30
FLAME BEHAVIOR | Ignited? V yes no yes, but
.
Flame asymmetric hole/opening(s) | oot o none Agnition only a little lots
Flame oscillating unsteady blew out | oot@end *none a ignition little lots
POST-TEST CONDITIONS | Oxidizer bottle pressure: | psia
alve safety timer | sec
*GENERAL COMMENTS
-I-z-$*- | t---kß,mbe.t—
C)-.æ | per—
6 Feb. 2019
~~~~

### Pagina 11

Cita: [pdf_2d5a8a5d76d4abae44c9, p. 11]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_2d5a8a5d76d4abae44c9/p0011.jpg)

~~~~text
ACME / Flame Design (normal flame) - Science Test Sheet
est date: | 25 | CME test#: / 15k 1
Local time: | est of day #:
MT: | Flame of day #:
TEST CONDITIONS | ontrol? | *fully automated c] 'manual'
Test type? *ignition o no-flame standard other
Oxygen conc. | Z % (volume) | Burner type: | X1/4" sphere jet
hamber pressure: | psia | O | Fuel Bottle: CH4 | % eC2H4 /DÖ %
ent before? | o yes, to | psia 2 Burner fuel conc.: | % (volume)
Air' | no o yes, to | psia | Fuel flow rate: OZ slpm (N2 basis)
Iso just before? | o GC scrub | N2-flow•ate: | slpm
INSTRUMENTATION | FP? | o fixed moving back-n-forth
DataCam: filter? sclear o BG7 0 CH* CH20 | ROI? E full reduced | fps
Intensified: filter? o clear | CH20 0 none | ROI? v full reduced | fps
backlight filter? no Ryes | CIR backlight? no *Yes fps? g 15 30
FLAME BEHAVIOR | Ignited? yes o no yes, but ...*
Flame asymmetric hole/opening(s) | 00t o none ignition only o little lots
Flame oscillating R unsteadyzblew out | oot@end none ignition little lots
*GENERAL COMMENTS
6 Feb. 2019
~~~~

### Pagina 12

Cita: [pdf_2d5a8a5d76d4abae44c9, p. 12]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_2d5a8a5d76d4abae44c9/p0012.jpg)

~~~~text
ACME / Flame Design (normal flame) - Science Test Sheet
est date: | CME test #:
Local time: | est of day | / 2
MT: / | Flame of day#: n.
TEST CONDITIONS | Control? | fully automated 'manual'
Test | no-flame o standard other
Oxygen conc. | % (volume) | Burner type: | 0/4" sphere o jet
hamber pressure: | psia | Fuel Bottle: o CH4 | % E-C2H4
ent before? R no yes, to | psia | Burner fuel conc.: 6 D % (volume)
Air' added? no yes, to | psia | Fuel flow rate: D,D5Z slpm (N2 basis)
Iso just before? Afan GC scrub | N2 flow rate: 0-035 slpm
INSTRUMENTATION | no o fixed o moving CJ back-n-forth
DataCam: filter? Mclear BG7 | o CH20 | ROI? Q full o reduced | fps
Intensified: filter? clear *CH* CH20 none | ROI? *full reduced | fps
*HiBMs: backlight filter? no [Ryes | CIR backlight? no Q•yes fps? Q 15 30
FLAME BEHAVIOR | Ignited? o ye*no o yes, but .
Flame asymmetric hole/opening(s) | 00t none a ignition only little o lots
Flame o oscillating a unsteady o blew out | oot@end o none ignition little lots
POST-TEST CONDITIONS | Oxidizer bottle pressure: 1447 psia
Oxygen conc. | % (volume) | alve safety timer | sec
*GENERAL COMMENTS
bccr-e-
4
ct--Jnt+
6 Feb. 2019
~~~~

### Pagina 13

Cita: [pdf_2d5a8a5d76d4abae44c9, p. 13]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_2d5a8a5d76d4abae44c9/p0013.jpg)

~~~~text
ACME / Flame Design (normal flame) - Science Test Sheet
est date: | 25 | CME test #:
Local time: | est of day #:
GMT: | Flame of day #:
Rack Officer (RO): | PD (ACME):
DMO (CIR): | Researcher:
TEST CONDITIONS | Control? | fully automated 'manual'
Test | o no-flame standard o other
Oxygen conc. | ...Z | % (volume) | Burner type: | {1/4" sphere jet
Chamber pressure: | 4, | psia OR Fuel Bottle: CH4 | 0/0*C2H4
ent before? xno o yes, to | psia | Burner fuel conc.: | 600/0 (volume)
Air' | yes, to | psia | Fuel flow rate: O zslpm (N2 basis)
Iso just before? Q fan GC scrub | N2 flow rate: | slpm
INSTRUMENTATION | FP? (no o fixed moving o back-n-forth
(Datacam: filter? Gear BG7 | CH20 | ROI? full o reduced | fps
e Intensified: filter? clear LCH* CH20 none | ROI? o full reduced | 2fps
Z HiBMs: backlight filter? no yes | CIR backlight? no u-yes fps? | 30
FLAME BEHAVIOR | Ignited? yesd_no a yes, but *
...
Flame asymmetric hole/opening(s) | 00t o none ignition only o little o lots
Flame oscillating o unsteady o blew out | oot@end o none o ignition little lots
*GENERAL COMMENTS
cqlecl.-kr
*
bee-au.Ä-se
a 5
6 Feb. 2019
~~~~

### Pagina 14

Cita: [pdf_2d5a8a5d76d4abae44c9, p. 14]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_2d5a8a5d76d4abae44c9/p0014.jpg)

~~~~text
ACME / Flame Design (normal flame) - Science Test Sheet
est date: | CMEtest#: 1 /t5 | 1
Local time: | est of day #:
MT: | Flame of day #:
TEST CONDITIONS | Control? | <fully automated 'manual'
Test type? G•lition o no-flame o standard a other
xygen conc. | 'V2-l % (volume) | Burner type: | 81/4" sphere jet
Chamber pressure: | psia | Fuel Bottle: üCH4 | % KC2H4 | %
ent before? kno a yes, to | psia | Burner fuel conc.: | 40/0 (volume)
Air' added? Lno o yes, to | psia | Fuel flow rate: D Z&slpm (N2 basis)
Iso just before? (fan GC scrub | N2 flow rate: D-133slpm
INSTRUMENTATION | FP? | fixed moving back-n-forth
& DataCam: filter? | BG7 | CH20 | ROI? {full reduced | fps
Zlntensified: filter? o clear *CH* CH20 none | ROI? g full o reduced | fps
gHiBMs: backlight filter? o no | CIR backlight? o•no Ayes fps? d 15 30
FLAME BEHAVIOR | Ignited? | no yes, but
.
Flame asymmetric o hole/opening(s) | 00t o none | only o little lots
Flame o oscillating unsteady blew out | oot@end | ignition little lots
*GENERAL COMMENTS
4-es
6 Feb. 2019
~~~~

### Pagina 15

Cita: [pdf_2d5a8a5d76d4abae44c9, p. 15]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_2d5a8a5d76d4abae44c9/p0015.jpg)

~~~~text
ACME / Flame Design (normal flame) - Science Test Sheet
est date: | CME test#: til 5/73
Local time: | est of day#: /
MT: | Flame of day #:
Rack Officer (RO): | PD (ACME):
DMO (CIR): | Researcher:
TEST CONDITIONS | ontrol? | (fully automated 'manual'
Test type? (ignition no-flame c] standard o other
xygen conc. | % (volume) | Burner type: | ZI/4" sphere jet
Chamber pressure: | 4, psia | 4K Fuel Bottle: | CH4 | 0/0AC2H4 'DO %
ent before? Xno yes, to | psia | Burner fuel conc.: | o % (volume)
Air' added? | o o yes, to | psia | Fuel flow rate: | slpm (N2 basis)
Iso just before? *fan GC scrub | N2 flow rate: | slpm
INSTRUMENTATION | FP? 460 fixed o moving o back-n-forth
DataCam: filter? (clear BG7 0 CH* o CH20 | ROI? Ä_full reduced | fps
L Intensified: filter? clear B-CH* CH20 0 none | ROI? p full reduced | Z fps
HiBMs: backlight filter? no | CIR backlight? no zyes fps? A5 30
FLAME BEHAVIOR | Ignited? yes | yes, but ...*
Flame asymmetric o hole/opening(s) | 00t none ignition only o little o lots
Flame o oscillating o unsteady o blew out | oot@end a none o ignition little lots
POST-TEST CONDITIONS | Oxidizer bottle pressure: | psia
alve safety timer | sec
*GENERAL COMMENTS
bee 4zs-f—
Fr-
6 Feb. 2019
~~~~

### Pagina 16

Cita: [pdf_2d5a8a5d76d4abae44c9, p. 16]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_2d5a8a5d76d4abae44c9/p0016.jpg)

~~~~text
ACME / Flame Design (normal flame) - Science Test Sheet
est date: | .4 7/ | 2.01 | CME test | 17115"44
Local time: | est of day#:
MT: | 9114 | Flame of day | D
TEST CONDITIONS | ontrol? | automated 'manual'
Test type? u ignition o no-flame o standard other
Oxygen conc. | % (volume) * | Burner type: | sphere o jet
hamber pressure: | psia | Fuel Bottle: o CH4 | % SC2H4 | 0/0
ent before? (no yes, to | psia | Burner fuel conc.: | % (volume)
Air' added? A no yes, to | psia | Fuel flow rate: DD5zslpm (N2 basis)
Iso just before? A-fan GC scrub | N2 flow rate: 6 | slpm
INSTRUMENTATION | FP? no c] fixed moving o back-n-forth
DataCam: filter?bQ clear o BG7 0 CH* CH20 | ROI? Rfull a reduced | fps
Ylntensified: filter? o clear,e CH* o CH20 none | ROI? | o reduced | fps
HiBMs: backlight filter? o nozyes | CIR backlight? no Ryes fps? | 30
FLAME BEHAVIOR | Ignited? {yes o no o yes, but ...*
Flame o asymmetric o hole/opening(s) | 00t o none (ignition onlyßlittle o lots
Flame | Runsteady (blew out | oot@end g-none ignition little lots
*GENERAL COMMENTS
(933% | 4-zsF
6 Feb. 2019
~~~~

### Pagina 17

Cita: [pdf_2d5a8a5d76d4abae44c9, p. 17]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_2d5a8a5d76d4abae44c9/p0017.jpg)

~~~~text
ACME / Flame Design (normal flame) - Science Test Sheet
est date: | 25 | CME test#: I //
Local time: | est of day #:
GMT: | Flame of day#:
Rack Officer (RO): | PD (ACME):
DMO (CIR): | Researcher:
TEST CONDITIONS | Control? | fully automated o 'manual'
Test type? E ignition no-flame standard other
Oxygen conc. | % (volume) | Burner type: | &1/4" sphere o jet
Chamber pressure: | psia | Fuel Bottle: o CH4 | % C2H4 too 0/0
ent before? | yes, to | psia | Burner fuel conc.: /0D0/0 (volume)
Air' added? gno o yes, to | psia | Fuel flow rate: Dp" slpm (N2 basis)
Iso just before? kfan GC scrub | *2ftow-räte: | @ slpm
INSTRUMENTATION | FP? Mno o fixed moving o back-n-forth
*DataCam: filter? Kclear BG7 | CH20 | ROI? Null reduced | fps
_
M--lntensified: filter? o clear | CH20 none | ROI? X full reduced | Z fps
*HiBMs: backlight filter? o no ryes | CIR backlight? noQyes fps? K15 30
FLAME BEHAVIOR | Ignited? o | o yes, b t.
Flame asymmetric o hole/opening(s) | oot o none ignition only o little lots
Fla | oot@end none o ignition o little lots
*GENERAL COMMENTS
22/0 D.z_
6 Feb. 2019
~~~~

### Pagina 18

Cita: [pdf_2d5a8a5d76d4abae44c9, p. 18]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_2d5a8a5d76d4abae44c9/p0018.jpg)

~~~~text
ACME / Flame Design (normal flame) - Science Test Sheet
est date: | 201 | CME test#: 1 1154
Local time: | Dreg | est of day #:
GMT: | z.-og | Flame of day #:
TEST CONDITIONS | Control? | fully automated o 'manual'
Test type? "gnition o no-flame o standard o other
Oxygen conc. | % (volume) | Burner type: | *1/4" sphere o jet
Chamber pressure: | psia | R Fuel Bottle: DCH4 | C2H4 | %
ent before? eno yes, to | psia | Burner fuel conc.: /æ % (volume)
Air' added? | o yes, to | psia | Fuel flow rate: | slpm (N2 basis)
Iso just before? | GC scrub | slpm
INSTRUMENTATION | FP? | fixed o moving back-n-forth
LDataCam: filter? *clear BG7 0 CH* o CH20 | ROI? *full o reduced | fps
_
g Intensified: filter? clear>d CH* o CH20 0 none | ROI? *full reduced | -Zfps
ø-HiBMs: backlight filter? no Oes | CIR backlight? nomyes fps?A 15 30
FLAME BEHAVIOR | Ignited? yes o no o yes, but ...*
Flame asymmetric o hole/opening(s) | 00t none ignition only little a lots
Flame oscillating *unsteady blew out | oot@end none o ignition little lots
*GENERAL COMMENTS
6 Feb. 2019
~~~~
