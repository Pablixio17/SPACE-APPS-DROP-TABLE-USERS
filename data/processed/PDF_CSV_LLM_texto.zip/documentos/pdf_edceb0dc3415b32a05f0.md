# 21112 test sheets

- Identificador: pdf_edceb0dc3415b32a05f0
- Investigaciones: PSI-159
- Tipo de documento: Raw Data
- Estado: processed
- Temas detectados automaticamente: oxygen, pressure, ignition, hardware, soot

## Fuentes

- [PSI-159_Raw Data_21112 test sheets.pdf](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-159/Raw%20Data/PSI-159_Raw%20Data_21112%20test%20sheets.pdf)

## Lectura conjunta con CSV

Vincular por investigation_id y por las referencias del CSV. Las menciones de test_id son candidatos de correspondencia, no una validacion del ensayo. No rellenar medidas ausentes del CSV a partir de contexto general del estudio.
Texto en el idioma original. Las citas usan doc_id y numero fisico de pagina del PDF. El OCR conserva incertidumbre; comprobar cifras, formulas y anotaciones manuscritas en la imagen original.

## Orientacion

No se ha identificado un apartado de resumen o conclusiones. Consultar el contenido paginado; los registros operativos y tablas pueden no contener conclusiones narrativas.

## Contenido completo por paginas

### Pagina 1

Cita: [pdf_edceb0dc3415b32a05f0, p. 1]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_edceb0dc3415b32a05f0/p0001.jpg)

~~~~text
ACME / CFI-G (normal flame) - Science Test Sheet
est date: | CME test
Local time: | est of day #:
MT: | C) | Flame of day #:
Rack Officer (RO): | PD (ACME):
DMO (CIR): | Researcher:
TEST CONDITIONS | Control? | K fully automated 'manual'
Test type? ignition no-flameø standard other
xygen conc. | % (vol, nominal) | Fuel bottle (next row)
Oxygen conc. | % (vol, per calc) | C2H6 | C3H8 VD' 0/0 0 n-C4H10 | %
hamber pressure: | psia (CIR avg) | Burner fuel conc.: | %
(volume)
ent before? no yes, to | psia | Fuel flow rate: | slpm (N2
o.e7C> | basis)
Air' added? | yes, to /Z(+ psia | N2-flowrate7 (9
slpm
Iso just before? o fan GC scrub
FP? | fixed moving back-n-forth
INSTRUMENTATION | ain: 3 > DataCam 2 | camera
ops
•DataCam: filter?Qlear c] BG7 CH* o CH20 | ROI? Q full reduced | fps
_
Intensified: filter? clear | none | ROI? m full reduced | fps
æ-HiBMs:• backlight filter? a no | CIR backlight?Eno
yes
FLAME BEHAVIOR
Flame hot o cool ü maybe cool | o no | but
yes,
Flame o hole/opening o partially detached | oot@ignition | none little lots
Flame oscillating unsteadyK | oot@middle c] none little Clots
o
Out ext. detect time out emp. limit | oot@end | a none little lots
D
POST-TEST CONDITIONS | Chamber | (CIR
pressure: ( | psia | avg)
Oxygen conc. | 37-13% (vol, per calc) | xidizer bottle pressure: | psia
alve safety timer | sec | Fuel bottle
pressure: | psia
*GENERAL COMMENTS
24 March 2021
~~~~

### Pagina 2

Cita: [pdf_edceb0dc3415b32a05f0, p. 2]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_edceb0dc3415b32a05f0/p0002.jpg)

~~~~text
ACME / CFI-G (normal flame) - Science Test Sheet
est date: | CME test
Local time: | est of day #:
MT: | Flame of day #:
Rack Officer (RO): | PD (ACME):
DMO (CIR): | Researcher:
TEST CONDITIONS | ontrol? | € fully automated 'manual'
Test type? ignition no-flameåstandard o other
Oxygen conc. | 0/0 (vol, nominal) | Fuel bottle (next row)
xygen conc. | % (vol, per calc) | o C2H6 | % | n-C4H10 | 0/0
Chamber pressure: I | psia (CIR avg) | Burner fuel conc.: | *20/0 (volume)
ent before? no yes, to | psia | Fuel flow rate: | slpm (N2 basis)
Air' added? Ono yes, to | psia | N2 flow rate: | D > | slpm
Iso just before? q fan GC scrub
FP?Qno o fixed moving c] back-n-forth
INSTRUMENTATION | ain: | DataCam | ops camera
DataCam: filter?bclear BG7 CH* CH20 | ROI? Qfull reduced | fps
_
•Intensified: filter? clear o CH* | none | ROI? •full reduced | fps
_
• backlight filter? no éyes | CIR backlight? uno
yes
FLAME BEHAVIOR
Flame | ot o cool c] maybe cool | Ignited? yes a no o yes, but ...*
Flame Ahole/opening partially detached | Soot@ignition | none little lots
Flame Qoscillating#unsteady | Soot@middle | none eulittle o lots
Out'<ext. detect time out a temp. limit | oot@end | none little lots
POST-TEST CONDITIONS | Chamber pressure: | psia (CIR avg)
Oxygen conc. | % (vol, per calc) | Oxidizer bottle pressure: zzzn90 psia
alve safety timer | Fuel bottle pressure: | psia
*GENERAL COMMENTS
24 March 2021
~~~~

### Pagina 3

Cita: [pdf_edceb0dc3415b32a05f0, p. 3]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_edceb0dc3415b32a05f0/p0003.jpg)

~~~~text
ACME / CFI-G (normal flame) - Science Test Sheet
est date: | CME test#: 2
Local time: | est of day #:
MT: | Flame of day #:
Rack Officer (RO): | PD (ACME):
DMO (CIR): | Researcher:
TEST CONDITIONS | Control? | Qfully automated 'manual'
o
Test type? ignition no-flame < standard other
Oxygen conc. | % (vol, nominal) | Fuel bottle (next row)
Oxygen conc. - | % (vol, per calc) | C2H6 | % n C3H8 | n-C4H10 | %
Chamber pressure: 3-46 psia (CIR avg) | Burner fuel conc.:
(volume)
ent before? no yes, to | psia | Fuel flow rate: | slpm (N 2
basis)
Air' | yes, to | psia | wrate: D
slpm
Iso just before? #Nfan a GC scrub
FP? •no o fixed moving back-n-forth
INSTRUMENTATION | ain: | Datacam
ops camera
Datacam: filter? | BG7 | CH20 | ROI? | reduced | fps
filter? clear o CH* pCH20 0 none | ROI? <-full reduced | fps
a-HiBMs•. backlight filter? no yes | CIR backlight? uno | fps?-G45030
yes
FLAME BEHAVIOR
Flameg hot o cool o maybe cool | Ignited? yes a no | but
yes, | .
partially detached | oot@ignition | none little lots
Flame & oscillating,å unsteady o | oot@middle | little lots
none
Out ext. detect c] time out temp. limit | oot@end | none little lots
POST-TEST CONDITIONS | Chamber | (CIR
pressure: 3 | psia | avg)
Oxygen conc. | 75 % (vol, per calc) | xidizer bottle pressure: | psia
alve safety timer | sec | Fuel bottle | psia
pressure:
*GENERAL COMMENTS
24 March 2021
~~~~

### Pagina 4

Cita: [pdf_edceb0dc3415b32a05f0, p. 4]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_edceb0dc3415b32a05f0/p0004.jpg)

~~~~text
ACME / CFI-G (normal flame) - Science Test Sheet
est date: | CME test #:
Local time: | est of day #:
GMT: | Flame of day #:
Rack Officer (RO): | PD (ACME):
DMO (CIR): | Researcher:
TEST CONDITIONS | Control? | fully automated 'manual'
ü
Test type? o ignition no-flame standard o other
Oxygen conc. | % (vol, nominal) | Fuel bottle (next row)
Oxygen conc. | 0 | % (vol, per calc) | ü C2H6 | 0/0 SC3H8 ( b 00/0 0 n -C4H10 | 0/0
Chamber pressure: E&hpsia (CIR avg) | Burner fuel conc.: | %
(volume)
ent beforeW10 yes, to | psia | Fuel flow | > | slpm (N2
basis)
Air' added?gno yes, to | psia | BE-flowrates ZD
slpm
Iso just before? | fan c] GC scrub
FP? Kno fixed o moving back-n-forth
INSTRUMENTATION | ain: | DataCam
ops camera
KDataCam: filter? Kclear ü BG7 CH* CH20 | reduced
o | fps
_
Intensified: filter? clear | KCH20 none | ROI? full reduced | fps
v
U.HiBMsrbacklight filter? no | CIR | yes
FLAME BEHAVIOR
Flame hot cool maybe cool | Ignited? | o no | but ...*
yes | yes,
Flameßhole/openin | partially detached | oot@ignttion | none o littlev lots
Flame •oscillatingAunsteady o | oot@middle | little lots
a none Q
Out c] ext. detect time out temp. limit | oot@end | little Ots
o none o
POST-TEST CONDITIONS | hamber
pressure: | psia (CIR avg)
xygen conc. | -7 Z % (vol, per calc) | Oxidizer bottle pressure: | psia
alve safety timer | 54/ | sec | Fuel bottle | 4--
pressure: | psia
*GENERAL COMMENTS
24 March 2021
~~~~

### Pagina 5

Cita: [pdf_edceb0dc3415b32a05f0, p. 5]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_edceb0dc3415b32a05f0/p0005.jpg)

~~~~text
ACME / CFI-G (normal flame) - Science Test Sheet
est date: | CME test #: 73/1 2
Local time: | est of day
GMT: | Flame of day #:
Rack Officer (RO): <S4. | PD (ACME): | G
DMO (CIR): | Researcher:
TEST CONDITIONS | Control? | automated 'manual'
Test type? ignition D no-flame [Sstandard o other
Oxygen conc. | % (vol, nominal) | Fuel bottle (next row)
Oxygen conc. 347B % (vol, per calc) | o C2H6 | O/öéC3H8 | n-C4H10
Chamber pressure: E 62psia (CIR avg) | Burner fuel conc.: | %
, | (volume)
ent before? no yes, to | psia | Fuel flow rate: | > | slpm (N2 basis)
Air' added? ü;no yes, to | psia | ow-rate: | slpm
Iso just before? wfan GC scrub
FP? Kno fixed moving o back-n-forth
INSTRUMENTATION | ain: | DataCam 31 | camera
ops
SDataCam: filter?Sclear BG7 | CH20 | ROI? €full reduced
fps
_
• Intensified: filter? o clear o | none | ROI? Afull reduced | fps
_
HiBMs: backlight filter? no Ayes | CIR backlight?.no o | fps?-æasa30
yes
FLAME BEHAVIOR
Flame Khot o cool o maybe cool | Ignited? | o no o | but ...*
yes,
Flame hole/opening partially detached | oot@ignition | none little Ots
Flamed oscillating (unsteady | oot@middle o none o little flots
Out 'ext. detect time out temp. limit | oot@end | noneüfljttle o lots
POST-TEST CONDITIONS | Chamber pressure: | (CIR
psia | avg)
Oxygen conc. 33, | % (vol, per calc) | xidizer bottle pressure: 17>4-1 psia
alve safety timer | sec | Fuel bottle | psia
pressure:
*GENERAL COMMENTS
S04<_
24 March 2021
~~~~

### Pagina 6

Cita: [pdf_edceb0dc3415b32a05f0, p. 6]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_edceb0dc3415b32a05f0/p0006.jpg)

~~~~text
ACME / CFI-G (normal flame) - Science Test Sheet
est date: | CME test #:
Local time: | est of day #:
MT: | Flame of day #:
Rack Officer (RO): | PD (ACME):
DMO (CIR): | Researcher:
TEST CONDITIONS | Control? | automated 'manual'
Test type? ignition no-flame Estandard c] other
Oxygen conc. | % (vol, nominal) | Fuel bottle (next row)
xygen conc. | 3 _cg % (vol, per calc) | C2H6 | % | % n-C4H10 | %
Chamber pressure: | psia (CIR avg) | Burner fuel conc.: | % (volume)
ent before? E no yes, to | psia | Fuel flow rate: (2&4 > | slpm (N2 basis)
Air' | yes, to | psia | N2 flow rate: | > | slpm
Iso just before? | fan GC scrub
no fixed moving back-n-forth
INSTRUMENTATION | ain: | DataCam | ops camera
LDataCam: filter? | BG7 | CH20 | full reduced | fps
_
S Intensified: filter? clear CH* | none | ROI? gfull c] reduced | fps
-g-HiBMs: backlight filter? no Kyes | CIR backlight? | yes fps?-o-1SÜ300
FLAME BEHAVIOR
Flame Vhot o cool CJ maybe cool | Ignited? Kyes o no yes, but
..
Flame hole/opening o partially detached | oot@ignition | none little lots
z.
Flame oscillating unsteady | oot@middle X none little c] lots
Out ext. detect o time ou temp. limit | oot@end | none little lots
POST-TEST CONDITIONS | Chamber pressure: | psia (CIR avg)
xygen conc. | 0/0 (vol, per calc) | Oxidizer bottle pressure: /Z7C psia
alve safety timer | sec | Fuel bottle pressure: | psia
*GENERAL COMMENTS
24 March 2021
~~~~

### Pagina 7

Cita: [pdf_edceb0dc3415b32a05f0, p. 7]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_edceb0dc3415b32a05f0/p0007.jpg)

~~~~text
ACME / CFI-G (normal flame) - Science Test Sheet
est date: | CME test#: ZI II z C
Local time: | est of day #:
MT: | Flame of day #:
TEST CONDITIONS | Control? | U fully automated ü 'manual'
Test type? ignition no-flamepstandard other
Oxygen conc. | AD % (vol, nominal) | Fuel bottle (next row)
Oxygen conc. 336 | % (vol, per calc) | C2H6 | 0/0 @C3H8 | % n-C4H10 | %
Chamber pressure: | psia (CIR avg) | Burner fuel conc.. | IC>rD % (volume)
ent before? Äno o yes, to | psia | Fuel flow rate: | slpm (N2 basis)
Air' added? 6-no yes, to | psia | D | slpm
Iso just before? Øfan GC scrub
FP? Xno fixed o moving back-n-forth
INSTRUMENTATION | ain: | DataCam | ops camera
DataCam: filter?VFlear BG7 | CH20 | ROI? Rfull a reduced | fps
_
Intensified: filter? clear | none | o reduced | fps
—z
filter? no | CIR backlight?nno yes
FLAME BEHAVIOR
Flamesü_hot a cool D maybe cool | Ignited? yes no yes, but ...*
Flame ü hole/opening partially detached | oot@ignition | none littleålots@u
Flame oscillating unstead | oot@middle | none o little o lots
Out o ext. detect time out temp. limit | oot@end | none little lots
POST-TEST CONDITIONS | Chamber pressure: | psia (CIR avg)
Oxygen conc. 32>42 % (vol, per calc) | Oxidizer bottle pressure: | Ö psia
alve safety timer | 3 | sec | Fuel bottle pressure: | psia
*GENERAL CO MENT
24 March 2021
~~~~

### Pagina 8

Cita: [pdf_edceb0dc3415b32a05f0, p. 8]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_edceb0dc3415b32a05f0/p0008.jpg)

~~~~text
ACME / CFI-G (normal flame) - Science Test Sheet
est date: | CME test
Local time: | est of day
GMT: | Flame of day #: Z
Rack Officer (RO): | PD (ACME):
DMO (CIR): | Researcher:
TEST CONDITIONS | Control? | automated o 'manual'
Test type? ignition no-flames standard other
xygen conc. | 0 0/0 (vol, nominal) | Fuel bottle (next row)
Oxygen conc. | % (vol, per calc) | o C2H6 | 0/0 | c] n-C4H10_O/o
Chamber pressure: | psia (CIR avg) | Burner fuel conc.: | Dö % (volume)
ent before? no yes, to | psia | Fuel flow rate: | slpm (N2 basis)
Air' added? a no yes, to | psia | N2 flow rate: | > | slpm
Iso just before? x fan GC scrub
no fixed moving back-n-forth
INSTRUMENTATION | ain: | DataCam | ops camera
BDataCam: filter?€clear BG7 | CH20 | ROI? Xfull reduced | fps
g-lntensified: filter? clear CH* Y CH20 none | full o reduced | fps
cklight filter? no Styes | CIR backlight?gno yes
FLAME BEHAVIOR
Flame Khot ü cool maybe cool | Ignited? Ryes no o | but
yes,
Fla me Khole/opening apartially detached | oot@ignition c] none little lots
Flame oscillatingcunsteady | oot@middle o none (little lots IO
Out Next. detect o time out o temp. limit | oot@end | none little Cl lots
POST-TEST CONDITIONS | Chamber pressure: | psia (CIR avg)
Oxygen conc. | % (vol, per calc) | Oxidizer bottle pressure: | psia
alve safety timer | sec | Fuel bottle pressure: | psia
*GENERAL COMMENTS
24 March 2021
~~~~

### Pagina 9

Cita: [pdf_edceb0dc3415b32a05f0, p. 9]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_edceb0dc3415b32a05f0/p0009.jpg)

~~~~text
ACME / CFI-G (normal flame) - Science Test Sheet
est date: | CME test #:
Local time: | ESC | est of day #:
GMT: | Flame of day #:
TEST CONDITIONS | Control? | automated 'manual'
Test type? o ignition no-flame Sstandard other
Oxygen conc. | D % (vol, nominal) | Fuel bottle (next row)
Oxygen conc. | % (vol, per calc) | C2H6 | 0/0KC3H8?C'C % n-C4H10
Chamber pressure: I E/ psia (CIR avg) | Burner fuel conc.: | % (volume)
ent before? no yes, to | psia | Fuel flow rate: | slpm (N2 basis)
Air' added?Ano yes, to | psia | rate: | slpm
Iso just before? | fan D GC o scrub
no o fixed D moving c] back-n-forth
INSTRUMENTATION | ain: | DataCam 31 ops camera
DataCam: filter? rclear BG7 CH* CH20 | ROI? | reduced | fps
_
alntensified: filter? clear | CH20 none | ROI? full reduced | fps
_
-a-HiBMs: backlight filter? o noeyes | CIR backlight? gno yes fps20-15GBO—
FLAME BEHAVIOR
Flame hot o cool maybe cool | Ignited? o yeso_nooy but ...*
,
Flame hole/opening partially detached | oot@ignition | none little ü lots
Flame oscillating unsteady | oot@middle | none o little o lots
ut ext. detect time out temp. limit | oot@end | none little lots
POST-TEST CONDITIONS | Chamber pressure: | I psia (CIR avg)
xygen conc. | 31. | % (vol, per calc) | xidizer bottle pressure: /Z7& psia
alve safety timer | sec | Fuel bottle pressure: | psia
*GENERAL COMMENTS
24 March 2021
~~~~

### Pagina 10

Cita: [pdf_edceb0dc3415b32a05f0, p. 10]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_edceb0dc3415b32a05f0/p0010.jpg)

~~~~text
ACME / CFI-G (normal flame) - Science Test Sheet
est date: | CME test #:
Local time: | est of day#: /CD
GMT: | Flame of day #:
Rack Officer (RO): | I | PD (ACME):
DMO (CIR): | Researcher:
TEST CONDITIONS | Control? | (fully automated 'manual'
Test type? ignition o no-flame standard o other
Oxygen conc. | % (vol, nominal) | Fuel bottle (next row)
Oxygen conc. | '4 % (vol, per calc) | C2H6 | % | /oc> % o n-C4H10 | %
Chamber pressure: | psia (CIR avg) | Burner fuel conc.: | % (volume)
ent before? no o yes, to | psia | Fuel flow rate: | slpm (N2 basis)
Air' added? uno o yes, to | psia | D > | slpm
Iso just before? | fan GC scrub
FP? | o fixed moving back-n-forth
INSTRUMENTATION | ain: | DataCam 2_1_ ops camera
gDataCam: filter? EKql_ear BG7 0 CH* CH20 | ROI? full reduced | fps
R | _
Intensified: filter? D clear o CH* *CH20 none | ROI? yfull o reduced | fps
_
filter? no | CIR backlight?wzno yes fps?-€45 30
FLAME BEHAVIOR
Flame hot o cool maybe cool | Ignited? c] | no a | but ...*
yes | yes,
Flame hole/opening partially detached | oot@ignition | none little o lots
Flame oscillating c] unsteady | oot@middle CJ none little lots
Out ext. detect o time out c] temp. limit | oot@end | none o little lots
POST-TEST CONDITIONS | Chamber pressure: /ß,Z20 psia (CIR avg)
Oxygen conc. | [r 4 % (vol, per calc) | Oxidizer bottle pressure: IZOD psia
alve safety timer | sec | Fuel bottle pressure: | psia
*GENERAL COMMENTS
24 March 2021
~~~~

### Pagina 11

Cita: [pdf_edceb0dc3415b32a05f0, p. 11]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_edceb0dc3415b32a05f0/p0011.jpg)

~~~~text
ACME / CFI-G (normal flame) - Science Test Sheet
est date: | CME test #:
Local time: | est of day
GMT: | Flame of day #:
Rack Officer (RO): | PD (ACME):
DMO (CIR): | Researcher:
TEST CONDITIONS | Control? | fully automated 'manual'
Test type? o ignition c] no-flame standard c] other
Oxygen conc. | % (vol, nominal) | Fuel bottle (next row)
Oxygen conc. | /<i4 % (vol, per calc) | C2H6 | % <C3H8 | n-C4H10 | %
Chamber pressure: /3Cc psia (CIR avg) | Burner fuel conc.: | % (volume)
ent before? | o yes, to | psia | Fuel flow rate: Dec > | slpm (N2 basis)
Air' added? Kno yes, to | psia | rate: | > | slpm
Iso just before? Yfan GC scrub
FP? | o fixed moving back-n-forth
INSTRUMENTATION | ain: | DataCam | camera
ops
ÉDataCam: filter? Ü-clear BG7 0 CH* CH20 | ROI? full reduced | fps
_
Ölntensified: filter? o clear o CH* | none | ROI? 4full o reduced | fps
æ-4åiBMs: backlight filter? no yes | CIR backlight? no o yes
PEA
FLAME BEHAVIOR
Flame hot cool maybe cool | Ignited? yes no yes, but
.
Flame hole/opening D partially detached | oot@ignition | none little o lots
Flame o oscillating unsteady | oot@middle Cl none little o lots
Out o ext. detect o time out o temp. limit | oot@end | none o little o lots
POST-TEST CONDITIONS | Chamber pressure: Z, Z" psia (CIR avg)
Oxygen conc. | 0/0 (vol, per calc) | Oxidizer bottle pressure: | psia
alve safety timer | 6 | sec | Fuel bottle pressure: | psia
*GENERAL COMMENTS
24 March 2021
~~~~

### Pagina 12

Cita: [pdf_edceb0dc3415b32a05f0, p. 12]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_edceb0dc3415b32a05f0/p0012.jpg)

~~~~text
ACME / CFI-G (normal flame) - Science Test Sheet
est date: | CME test | 2/ n?-CC
Local time: | est of day #:
GMT: | 117_ | Flame of day #:
Rack Officer (RO): | PD (ACME):
DMO (CIR): | Researcher:
TEST CONDITIONS | Control? | fully automated c] 'manual'
Test type? o ignition no-flameå standard o other
xygen conc. | % (vol, nominal) | Fuel bottle (next row)
Oxygen conc. | % (vol, per calc) | C2H6 | O/oAC3H8 / 000/0 n-C4H 10 | 0/0
Chamber pressure: | psia (CIR avg) | Burner fuel conc.. | % (volume)
ent before? gno yes, to | psia | Fuel flow rate: | > | slpm (N2 basis)
Air' added? no yes, to | psia | rate: | D | slpm
Iso just before? | fan GC o scrub
FP? Kno fixed moving o back-n-forth
INSTRUMENTATION | Gain: | DataCam 3 | ops camera
OataCam: filter? | BG7 | CH20 | ROI? full reduced | fps
g
ü4ntensified: filter? clear | SCH20 none | ROI? full reduced | fps
EHiBMs: backlight filter? o no | CIR backlight? gno a yes | 30
FLAME BEHAVIOR
Flame o hot cool maybe cool | Ignited? o yes | o yes, but ...*
Flame hole/opening partially detached | oot@ignition | none ü little lots
Flame o oscillating o unsteady | oot@middle | none ü little lots
Out ext. detect time out o temp. limit | oot@end | none c] little lots
POST-TEST CONDITIONS | Chamber pressure: | psia (CIR avg)
Oxygen conc. | % (vol, per calc) | Oxidizer bottle pressure: | psia
alve safety timer | sec | Fuel bottle pressure: | psia
*GENERAL COMMENTS
24 March 2021
~~~~

### Pagina 13

Cita: [pdf_edceb0dc3415b32a05f0, p. 13]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_edceb0dc3415b32a05f0/p0013.jpg)

~~~~text
ACME / CFI-G (normal flame) - Science Test Sheet
est date: | CME test | 211
Local time: | est of day #:
GMT: | lame of day #:
Rack Officer (RO): | PD (ACME):
DMO (CIR): | Researcher:
TEST CONDITIONS | ontrol? | fully automated a 'manual'
Test type? c] ignition no-flame p standard other
Oxygen conc. | % (vol, nominal) | Fuel bottle (next row)
xygen conc. | % (vol, per calc) | C2H6 | % NC3H8 | % n-C4H10 | %
Chamber pressure: | psia (CIR avg) | Burner fuel conc.: | % (volume)
ent before? no | to | psia | Fuel flow rate: | slpm (N2 basis)
Air' added? no | to | gpsia | te: | > | slpm
Iso just before? | fan GC scrub
FP?€ no o fixed moving o back-n-forth
INSTRUMENTATION | Gain: -23' DataCam z_l_ ops camera
DataCam: filter? «ear BG7 CH* o CH20 | ROI? full o reduced | fps
_
ulntensified: filter? o clear a CH* $NCH20 0 none | ROI? Efull reduced | fps
@HiBMs: backlight filter? no yes | CIR | yes
FLAME BEHAVIOR
Flame hot ü cool maybe cool | Ignited? yesa no | but
yes, | ...
Flame a hole/opening partially detached | oot@ignition | none little lots
Flame oscillating unsteady c] | oot@middle | none o little lots
Out ext. detect time out c] temp. limit | Soot@end | none little c] lots
POST-TEST CONDITIONS | Chamber pressure: | psia (CIR avg)
xygen conc. | % (vol, per calc) | Oxidizer bottle pressure: | psia
alve safety timer | f 7 | sec | Fuel bottle pressure: | psia
*GENERAL COMMENTS
24 March 2021
~~~~

### Pagina 14

Cita: [pdf_edceb0dc3415b32a05f0, p. 14]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_edceb0dc3415b32a05f0/p0014.jpg)

~~~~text
ACME / CFI-G (normal flame) - Science Test Sheet
est date: | CME test#: ZI
Local time: | est of day #: //
GMT: | Flame of day#:
Rack Officer (RO): | PD (ACME):
DMO (CIR): | Researcher:
TEST CONDITIONS | ontrol? | fully automated 'manual'
Test type? ignition o no-flame standard other
xygen conc. | % (vol, nominal) | Fuel bottle (next row)
Oxygen conc. | % (vol, per calc) | C2H6 | % | n-C4H10 | 0/6
Chamber pressure: | psia (CIR avg) | Burner fuel conc.: | % (volume)
ent before? a no yes, to | psia | Fuel flow rate: b,tü | slpm (N2 basis)
Air' added? a-no yes, to | psia | > | slpm
Iso just before? | fan D GC scrub
fixed D moving back-n-forth
INSTRUMENTATION | ain: | DataCam | ops camera
Datacam: filter? | BG7 | CH20 | ROI? gfull o reduced | fps
_
Xlntensified: filter? o clear | none | ROI? Qfull reduced | fps
___
•...backlight filter? ü no Ryes | CIR backlight? gno yes fps2ff-15Ü30
FLAME BEHAVIOR
Flame | cool c] maybe cool | Ignited? | a | but
yes,
Flame hole/opening@ partially detached | oot@ignition | none o little plots
Flame a oscillating unsteady | oot@middle | noneØ little lots
Out ext. detect o time out o temp. limit | oot@end | none o little lots
POST-TEST CONDITIONS | Chamber pressure: | psia (CIR avg)
xygen conc. | % (vol, per calc) | xidizer bottle pressure: | psia
alve safety timer | sec | Fuel bottle pressure: | psia
*GENERAL COMMENTS
24 March 2021
~~~~

### Pagina 15

Cita: [pdf_edceb0dc3415b32a05f0, p. 15]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_edceb0dc3415b32a05f0/p0015.jpg)

~~~~text
ACME / CFI-G (normal flame) - Science Test Sheet
est date: | CME test
Local time: | est of day
GMT: | lame of day #:
Rack Officer (RO): | PD (ACME):
DMO (CIR): | Researcher:
TEST CONDITIONS | ontrol? | fully automated o 'manual'
Test type? o ignition no-flame standard other
Oxygen conc. | % (vol, nominal) | Fuel bottle (next row)
xygen conc. | % (vol, per calc) | a C2H6 | % C3H8 | % n-C4H10 | %
Chamber pressure: | psia (CIR avg) | Burner fuel conc.: | % (volume)
ent before? no yes, to | psia | Fuel flow rate: | slpm (N2 basis)
Air' added? | o yes, to | psia | low-rate: | > | slpm
Iso just before? | fan GC scrub
no fixed moving back-n-forth
INSTRUMENTATION | ain: | DataCam | s camera
Datacam: filteræåclear BG7 | CH20 | ROI? g full a reduced | fps
_
A Intensified: filter? clear CH* CH20 none | ROI? g full o reduced | fps
-ü+{iBMs: backlight filter? noqyes | CIR backlight?tåno c] yes fps?a-15-ü-3C—
FLAME BEHAVIOR
Flame hot cool a maybe cool | Ignited? | o no ü | but *
yes, | ...
Flame o hole/opening partially detached | oot@ignition | none littl | lots
Flame o oscillatingø unsteady o | Soot@middle | none little lots
Out q{ext. detect o time out D temp. limit | oot@end | Cgnone little lots
POST-TEST CONDITIONS | Chamber pressure: | 770 psia (CIR avg)
Oxygen conc. | % (vol, per calc) | Oxidizer bottle pressure: f' | psia
alve safety timer | sec | Fuel bottle pressure: | psia
*GENERAL COMMENTS
24 March 2021
~~~~

### Pagina 16

Cita: [pdf_edceb0dc3415b32a05f0, p. 16]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_edceb0dc3415b32a05f0/p0016.jpg)

~~~~text
ACME / CH-G (normal flame) - Science Test Sheet
est date: | CME test #: 21117_É4
Local time: | est of day #:
GMT: | Flame of day #:
TEST CONDITIONS | Control? | Vfully automated 'manual'
Test type? ignition o no-flame X_standard other
Oxygen conc. | /o (vol, nominal) | Fuel bottle (next row)
xygen conc. | (vol, per calc) | ü C2H6 | 0/0 yd C3H8 | 0/0 c] | _O/o
Chamber pressure: ) 44psia (CIR avg) | Burner fuel conc.: | 0/0 (volume)
ent before? no yes, to | psia | Fuel flow | — > | slpm (N2 basis)
Air' added? xno yes, to | psia | te: | > | slpm
Iso just before? *fan a GC scrub
FP? Kno o fixed moving back-n-forth
INSTRUMENTATION | ain: | Datacam q ( ops camera
DataCam: filter? | BG7 | CH20 | ROI? full o reduced | fps
Q
{Clntensified: filter? a clear o | CH20 0 none | ROI? & full reduced | fps
g-+liBMs. backlight filter? o no Byes | CIR | yes
FLAME BEHAVIOR
Flame hot o cool maybe cool | Ignited? yes o no c] yes, but *
...
Flame hole/openingS artially detached | oot@ignition | none o littleßlots
Flame oscillating unsteady | oot@middle | none o little lots
Ou | ext. detect time out temp. limit | oot@end | ü_none a little lots
POST-TEST CONDITIONS | Chamber pressure: MY;" psia (CIR avg)
Oxygen conc. | % (vol, per calc) | Oxidizer bottle pressure: 76 Z. psia
alve safety timer | sec | Fuel bottle pressure: | psia
*GENERAL COMMENTS
24 March 2021
~~~~

### Pagina 17

Cita: [pdf_edceb0dc3415b32a05f0, p. 17]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_edceb0dc3415b32a05f0/p0017.jpg)

~~~~text
ACME / CFI-G (normal flame) - Science Test Sheet
est date: | CME test #:
Local time: | est of day#: I -7
GMT: | Flame of day #:
Rack Officer (RO): | PD (ACME):
DMO (CIR): | Researcher:
TEST CONDITIONS | Control? | Åfully automated 'manual'
Test type? ignition no-flame å-standard o other
Oxygen conc. | z | % (vol, nominal) | Fuel bottle (next row)
Oxygen conc. | % (vol, per calc) | C2H6 | 0/0 C3H8 'CD 0/0 0 n-C4H10
hamber pressure: | psia (CIR avg) | Burner fuel conc.: | % (volume)
ent before? no yes, to | psia | Fuel flow rate: D ö > | slpm (N2 basis)
Air' added? €no o yes, to | psia | flow rate:- D; > | slpm
Iso just before? | an GC scrub
FP? g-no a fixed o moving back-n-forth
INSTRUMENTATION | ain: | Datacam | ops camera
YNDataCam: filter? | BG7 CH* CH20 | ROI? full o reduced | fps
'9
é-lntensified: filter? clear | none | ROI?Afull reduced | fps
filter? no dyes | CIR backlight? åno yes
FLAME BEHAVIOR
Flame c] hot cool maybe cool | Ignited? o yes eno yes, but
.
Flame hole/opening partially detached | oot@ignition | none little lots
Flame oscillating unsteady | oot@middle | none little lots
Out ü ext. detect time out temp. limit | oot@end | c] none little lots
POST-TEST CONDITIONS | Chamber pressure: | 7 psia (CIR avg)
Oxygen conc. | % (vol, per calc) | Oxidizer bottle pressure: | psia
alve safety timer | sec | Fuel bottle pressure: | psia
*GENERAL COMMENTS
cs„e_ | -
24 March 2021
~~~~

### Pagina 18

Cita: [pdf_edceb0dc3415b32a05f0, p. 18]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_edceb0dc3415b32a05f0/p0018.jpg)

~~~~text
ACME / CFI-G (normal flame) - Science Test Sheet
est date: | CME test #: 24 ( ( ZH-
Local time: | est of day #:
MT: | Flame of day #: 12
TEST CONDITIONS | Control? | [Xfully automated 'manual'
Test type? D ignition o no-flame åétandard o other
Oxygen conc. | % (vol, nominal) | Fuel bottle (next row)
Oxygen conc. | "3 0/0 (Vol, | C2H6 | %
per | c) n-C4H10_O/o
Chamber pressure: | psia (CIR avg) | Burner fuel conc.. | % (volume)
ent before? no o yes, to | psia | Fuel flow rate: 0, | > | slpm (N 2 basis)
Air' added? nno o yes, to | psia | N2flowxate : | slpm
Iso just before? ufan GC scrub
FP?Kno o fixed moving back-n-forth
INSTRUMENTATION | ain: | DataCam | ops camera
€DataCam: | BG7 CH* CH20 | ROI? A full reduced | fps
E-Intensified: filter? o clear CH* EfCH20 none | ROI? Qfull o reduced | 2.
g-HiBMs:backlight filter? no*å yes | CIR backlight? Doo yes fps?a15€ 3C
FLAME BEHAVIOR
Flame hot cool o maybe cool | Ignited? yes c] no o yes, but
.
Flame hole/opening €_partially detached | oot@ignition | none little Élots
Flame yoscillating Qunsteady c] | oot@middle Qnone ü little lots
Out p'ext. detect time out o temp. limit | oot@end | ffnone little lots
POST-TEST CONDITIONS | Chamber pressure: | psia (CIR avg)
Oxygen conc. | % (vol, per calc) | Oxidizer bottle pressure: | psia
alve safety timer | sec | Fuel bottle pressure: | psia
*GENERAL COMMENTS
24 March 2021
~~~~

### Pagina 19

Cita: [pdf_edceb0dc3415b32a05f0, p. 19]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_edceb0dc3415b32a05f0/p0019.jpg)

~~~~text
ACME / CFI-G (normal flame) - Science Test Sheet
est date: | ZZ ZOZ | CME test #: ZI
Local time: | est of day
GMT: | lame of day #:
Rack Officer (RO): | PD (ACME):
DMO (CIR): | Researcher:
TEST CONDITIONS | Control? | Vfully automated 'manual'
Test type? ignition o no-flame | o other
Oxygen conc. | % (vol, nominal) | Fuel bottle (next row)
Oxygen conc. | % (vol, per calc) | o C2H6 | 0/0 MyC3H8 / oc 0/0 ü n -C4H IO | 0/0
Chamber pressure: 14/47 psia (CIR avg) | Burner fuel conc.: | % (volume)
ent before? | yes, to | psia | Fuel flow rate: O, b4€> | slpm (N2 basis)
Air' added?.no yes, to | psia | slpm
Iso just before? | fan GC scrub
FP? B-no fixed moving D back-n-forth
INSTRUMENTATION | ain: | DataCam _=ops camera
KDataCam: filter? | BG7 | CH20 | ROI? | reduced | fps
Alntensified: filter? clear | none | ROI? Qfull c] reduced | fps
_
filter? no g yes | CIR backlight? | yes
FLAME BEHAVIOR
Flameb&ot a cool a maybe cool | Ignited?Åyes no yes, but .
Flame hole/openingM partially detached | oot@ignition | none o little Ø40ts
Flame oscillating unsteady | oot@middle Q none little lots
Out Äext. detect a time out temp. limit | oot@end | little o lots
POST-TEST CONDITIONS | Chamber pressure: | (7 psia (CIR avg)
Oxygen conc. | % (vol, per calc) | Oxidizer bottle pressure: | psia
alve safety timer | sec | Fuel bottle pressure: | psia
*GENERAL COMMENTS
24 March 2021
~~~~

### Pagina 20

Cita: [pdf_edceb0dc3415b32a05f0, p. 20]. Metodo: windows_ocr_en_US.

Calidad: figures_not_digitized, handwriting_and_equations_require_visual_check, ocr_not_manually_transcribed, table_structure_not_manually_validated.

[Imagen de la pagina](../imagenes/pdf_edceb0dc3415b32a05f0/p0020.jpg)

~~~~text
ACME / CH-G (normal flame) - Science Test Sheet
est date: | CME test #:
Local time: | est of day #:
GMT: | lame of day #:
Rack Officer (RO): | PD (ACME):
DMO (CIR): | Researcher:
TEST CONDITIONS | ontrol? | é_fully automated c] 'manual'
Test type? ignition o no-flame <standard other
Oxygen conc. | Q7_ | % (vol, nominal) | Fuel bottle (next row)
xygen conc. | % (vol, per calc) | C2H6 | % C3H8 -1.220/0 ü n-C4H10
hamber pressure: '4 07 psia (CIR avg) | Burner fuel conc.: | % (volume)
ent before? no yes, to | psia | Fuel flow rate: | slpm (N2 basis)
Air' added? Kno o yes, to | psia | slpm
Iso just before? q_fan GC scrub
FP? üo fixed moving o back-n-forth
INSTRUMENTATION | ain: | DataCam | ops camera
DataCam: filter? Qclear BG7 0 CH* CH20 | full reduced | fps
filter? D clear | none | ROI? Ofull reduced | fps
ZHiBMs: backlight filter? no Ayes | CIR backlight?uno yes fps?-e-15æ30—
FLAME BEHAVIOR | 41
Flame hot cool maybe cool | Ignited? o ye | no yes, but
.
Flame hole/opening partially detached | oot@ignition | none little o lots
Flame D oscillating a unsteady o | oot@middle | none little lots
Out c] ext. detect time out o temp. limit | oot@end | o none little lots
POST-TEST CONDITIONS | Chamber pressure: /// ZE/ psia (CIR avg)
xygen conc. | % (vol, per calc) | Oxidizer bottle pressure: ?3C) psia
alve safety timer | sec | Fuel bottle pressure: | 4 | psia
*GENERAL COMMENTS
24 March 2021
~~~~
