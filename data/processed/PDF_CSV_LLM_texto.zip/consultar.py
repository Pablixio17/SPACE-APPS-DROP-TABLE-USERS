"""Read-only retrieval of joint PDF/CSV context. Python standard library only."""
import argparse,json,re,sqlite3,unicodedata,sys
sys.stdout.reconfigure(encoding='utf-8')
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--study');p.add_argument('--record-id');p.add_argument('--test-id')
p.add_argument('--query',default='');p.add_argument('--limit',type=int,default=8)
args=p.parse_args();limit=max(1,min(args.limit,30))
db=Path(__file__).resolve().parent/'conocimiento.sqlite'
c=sqlite3.connect('file:'+db.as_posix()+'?mode=ro',uri=True);c.row_factory=sqlite3.Row
conditions=['record_scope <> ?'];params=['empty_source_row']
if args.study:conditions.append('investigation_id = ?');params.append(args.study)
if args.record_id:conditions.append('record_id = ?');params.append(args.record_id)
if args.test_id:conditions.append("upper(replace(test_id,' ','')) = ?");params.append(re.sub(r'\s+','',args.test_id).upper())
record_count=c.execute('SELECT count(*) FROM experiments WHERE '+' AND '.join(conditions),params).fetchone()[0]
records=c.execute('SELECT * FROM experiments WHERE '+' AND '.join(conditions)+' LIMIT 20',params).fetchall() if any([args.study,args.record_id,args.test_id]) else []
ids=[r['record_id'] for r in records]
filters=[];filterparams=[]
if args.study:
 filters.append('ch.doc_id IN (SELECT doc_id FROM sources WHERE investigation_id=? UNION SELECT rd.doc_id FROM record_documents rd JOIN experiments e ON e.record_id=rd.record_id WHERE e.investigation_id=?)');filterparams.extend([args.study,args.study])
if args.record_id:
 filters.append('ch.doc_id IN (SELECT doc_id FROM record_documents WHERE record_id=?)');filterparams.append(args.record_id)
if args.test_id and ids:
 placeholders=','.join('?' for x in ids)
 filters.append('ch.page_id IN (SELECT page_id FROM test_mentions WHERE record_id IN ('+placeholders+'))');filterparams+=ids
translation={'oxigeno':'oxygen','presion':'pressure','ignicion':'ignition','extincion':'extinction','humo':'smoke','hollin':'soot','microgravedad':'microgravity','llama':'flame','gotas':'droplets','combustible':'fuel','electrico':'electric'}
terms=[]
for word in re.findall(r'\w+',args.query):
 folded=''.join(ch for ch in unicodedata.normalize('NFKD',word.lower()) if not unicodedata.combining(ch))
 terms.append(translation.get(folded,word))
if terms:
 match=' AND '.join('"'+t.replace('"','""')+'"' for t in terms)
 sql='SELECT ch.*,pg.method,pg.quality_flags_json,pg.image_path FROM search JOIN chunks ch ON ch.chunk_id=search.chunk_id JOIN pages pg ON pg.page_id=ch.page_id WHERE search MATCH ?'
 if filters:sql+=' AND '+' AND '.join(filters)
 sql+=' ORDER BY bm25(search) LIMIT ?'
 evidence=c.execute(sql,[match]+filterparams+[limit]).fetchall()
else:
 sql='SELECT ch.*,pg.method,pg.quality_flags_json,pg.image_path FROM chunks ch JOIN pages pg ON pg.page_id=ch.page_id'
 if filters:sql+=' WHERE '+' AND '.join(filters)
 sql+=' ORDER BY ch.doc_id,ch.page_id,ch.part LIMIT ?'
 evidence=c.execute(sql,filterparams+[limit]).fetchall()
result={'question_terms':args.query,'record_count':record_count if any([args.study,args.record_id,args.test_id]) else None,
 'records_truncated':record_count>20 if records else False,
 'records':[json.loads(r['data_json']) for r in records],
 'evidence':[{'chunk_id':r['chunk_id'],'text':r['text'],'citation':json.loads(r['citation_json']),
 'extraction_method':r['method'],'quality_flags':json.loads(r['quality_flags_json']),'image_path':r['image_path']} for r in evidence],
 'instructions':'Use record_id for CSV facts and doc_id/page for PDF evidence. Study links and test-ID mentions are not verified measurement matches. Do not fill missing CSV values from OCR without checking the source image.'}
print(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False));c.close()
