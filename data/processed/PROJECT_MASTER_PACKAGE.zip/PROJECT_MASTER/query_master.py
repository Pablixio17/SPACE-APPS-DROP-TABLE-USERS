"""Query the merged reference using Python 3 standard-library only. Read-only."""
from pathlib import Path
import argparse,json,sqlite3,re,sys

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--database',type=Path,default=Path(__file__).with_name('PROJECT_MASTER.sqlite'))
    p.add_argument('--project');p.add_argument('--record-id');p.add_argument('--test-id');p.add_argument('--query')
    p.add_argument('--limit',type=int,default=10);p.add_argument('--include-archive',action='store_true')
    p.add_argument('--export-jsonl',type=Path)
    a=p.parse_args()
    if a.limit<1 or a.limit>1000:p.error('--limit must be 1–1000')
    c=sqlite3.connect(a.database.resolve().as_uri()+'?mode=ro',uri=True);c.row_factory=sqlite3.Row
    def readj(s):return json.loads(s) if s is not None else None
    def emit(f,kind,payload):f.write(json.dumps({'type':kind,**payload},ensure_ascii=False,allow_nan=False)+'\n')
    if a.export_jsonl:
        if a.export_jsonl.resolve()==a.database.resolve():p.error('Export must not overwrite the database')
        with a.export_jsonl.open('w',encoding='utf-8') as f:
            emit(f,'contract',{'value':readj(c.execute("select value_json from master_meta where key='contract'").fetchone()[0])})
            for r in c.execute('select * from field_dictionary order by position'):
                field=dict(r);field['value_type']=field.pop('type');emit(f,'field',field)
            for r in c.execute('select summary_json from project_summaries'):emit(f,'project',readj(r[0]))
            for r in c.execute('select * from master_records'):
                emit(f,'record',{'record_id':r['record_id'],'record':readj(r['record_json']),'raw_curated':readj(r['raw_curated_json']),'integration':readj(r['integration_json'])})
            for r in c.execute('select * from source_differences'):
                x=dict(r);x['preferred_value']=readj(x.pop('preferred_json'));x['archive_value']=readj(x.pop('archive_json'));emit(f,'source_difference',x)
            for table,kind in [('master_record_documents','document_link'),('test_mentions','candidate_test_mention'),('sources','pdf_source'),('documents','document'),('pages','page'),('chunks','chunk')]:
                for r in c.execute('select * from '+table):
                    x=dict(r)
                    for k in list(x):
                        if k.endswith('_json'):x[k[:-5]]=readj(x.pop(k))
                    emit(f,kind,x)
        print(json.dumps({'export':str(a.export_jsonl.resolve()),'status':'complete'}));return
    filters=["source_tier IN ('curated','archive_only')" if a.include_archive else "source_tier='curated'"];args=[]
    if a.project:filters.append('investigation_id=?');args.append(a.project)
    if a.record_id:
        # Exact ID is an explicit request, including an archived or empty row.
        filters=[x for x in filters if not x.startswith('source_tier')];filters.append('record_id=?');args.append(a.record_id)
    if a.test_id:filters.append("json_extract(record_json,'$.test_id')=?");args.append(a.test_id)
    where=' AND '.join(filters);total=c.execute('select count(*) from master_records where '+where,args).fetchone()[0]
    rs=[dict(r) for r in c.execute('select * from master_records where '+where+' order by record_id limit ?',args+[a.limit])]
    result={'record_count_total':total,'records_returned':len(rs),'record_filter_note':'--query searches evidence text; record selection uses project, record ID, test ID and source tier','records':[],'projects':[],'evidence':[]}
    for r in rs:
        rid=r['record_id'];result['records'].append({'record':readj(r['record_json']),'integration':readj(r['integration_json']),'source_differences':[{'field':v['field'],'preferred_value':readj(v['preferred_json']),'archive_value':readj(v['archive_json']),'resolution':v['resolution']} for v in c.execute('select * from source_differences where record_id=?',(rid,))],'candidate_test_mentions':[dict(m) for m in c.execute('select * from test_mentions where record_id=?',(rid,))]})
    pids=[a.project] if a.project else sorted({r['investigation_id'] for r in rs})
    for pid in pids:
        row=c.execute('select summary_json from project_summaries where investigation_id=?',(pid,)).fetchone()
        if row:result['projects'].append(readj(row[0]))
    docids=set()
    if a.record_id or a.test_id:
        # Scope to every matching record, not just the returned page of records.
        for r in c.execute('select distinct d.doc_id from master_record_documents d join master_records m using(record_id) where '+where,args):docids.add(r[0])
    elif a.project:
        docids.update(r[0] for r in c.execute('select distinct doc_id from sources where investigation_id=?',(a.project,)))
        docids.update(r[0] for r in c.execute('select distinct d.doc_id from master_record_documents d join master_records m using(record_id) where m.investigation_id=?',(a.project,)))
    if a.query:
        tokens=re.findall(r'\w+',a.query,flags=re.UNICODE)
        if not tokens:p.error('Query needs at least one word')
        match=' AND '.join('"'+t.replace('"','""')+'"' for t in tokens)
        sql='select k.*,p.page_number,p.method,p.quality_flags_json from search join chunks k on search.chunk_id=k.chunk_id join pages p on k.page_id=p.page_id where search match ?'
        params=[match]
        if a.project or a.record_id or a.test_id:
            if not docids:result['evidence_note']='No contextual documents for this selection';sql=None
            else:sql+=' AND k.doc_id IN ('+','.join('?' for _ in docids)+')';params.extend(sorted(docids))
        if sql:
            sql+=' ORDER BY rank LIMIT ?';params.append(a.limit)
            for r in c.execute(sql,params):result['evidence'].append({'chunk_id':r['chunk_id'],'doc_id':r['doc_id'],'page':r['page_number'],'text':r['text'],'citation':readj(r['citation_json']),'extraction_method':r['method'],'quality_flags':readj(r['quality_flags_json']),'link_scope':'document_context_not_verified_test_measurement'})
    if hasattr(sys.stdout,'reconfigure'):sys.stdout.reconfigure(encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False))

if __name__=='__main__':main()
