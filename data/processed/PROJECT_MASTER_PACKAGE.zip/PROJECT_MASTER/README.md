# Unified project reference

**Start with `START_HERE.html`.** Open it in a browser after extracting this package. It works offline and includes project summaries, searchable records, document text, page citations and JSON/CSV exports.

The two files from `Done DATA f_project` have been joined into one master reference. The original 1,936 curated rows and 89 fields are preserved. The older source remains available with its differences, 90 additional nonempty rows and 861 explicitly empty rows. The reference covers 19 projects and 349 documents, including two unreadable sources.

| File | Use |
|---|---|
| START_HERE.html | Read and explore the unified reference. |
| PROJECT_MASTER.sqlite | Complete master, including the exact original input files, both record versions, document pages, relationships and conclusions. |
| PROJECT_MASTER.jsonl | Complete typed data export for retrieval tools and LLM workflows. Each line has a `type` identifying its entity. |
| CURATED_RECORDS.csv | Original columns and values, followed by new evidence, difference and conclusion fields. |
| PROJECT_GUIDE.md | Project conclusions, limitations, evidence citations and database map. |
| query_master.py | Search records and cited text with Python 3; no extra packages needed. |
| VALIDATION.json | Data preservation, relationship, query, export and reader checks. |
| MANIFEST.json | SHA-256 hashes of the deliverables. |

The curated CSV supplies the preferred record values. Its fields are not silently filled or overwritten using older data or OCR. Project document links are context, while exact test-ID mentions remain candidate matches. Reported scientific findings are distinguished from dataset assessments and modeling context.

The inputs did not include the separate visual-backup archive. Original PDF links are retained for checking OCR, charts and handwriting. No unavailable evidence or project result has been invented.

To retrieve a small, citable context package:

```text
python query_master.py --project PSI-159 --query "cool flames" --limit 5
python query_master.py --project PSI-10 --test-id 21328A1
python query_master.py --project PSI-108 --include-archive
```

The browser’s project JSON export contains the selected project’s nonempty records, differences and document pages, regardless of the search box. Its filtered CSV export follows the active record filters. The delivered CURATED_RECORDS.csv preserves exact source strings; browser exports use typed values.

Prepared 15 November 2026. Original repository and input files unchanged.
