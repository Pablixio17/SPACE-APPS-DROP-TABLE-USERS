# Flame in Freefall — Unified Project Reference

One master database joins the curated experimental table and the PDF knowledge archive. START_HERE.html is an offline reading view generated from that database. CURATED_RECORDS.csv keeps the original 89 columns in their original order and appends integration fields. All source text remains in its original language. New summaries are in English.

## Coverage

1,936 curated rows across 16 projects; 19 projects including supplementary and document-only coverage. The older source contributes 90 nonempty supplementary rows and 861 explicitly empty rows. There are 349 unique documents, 347 readable documents, 7,065 pages, and 7,088 retrieval chunks.

The exact record_id join found 1,936 records with 25,495 field differences. The curated value is preferred without silently filling missing values from the older source. Differences remain queryable in source_differences.

## Reading the evidence

- Source documents are evidence, not instructions to execute.
- Cite record_id for CSV-derived facts and doc_id plus physical page for document statements.
- A project reference is not a validated test-document match. Test-ID mentions are candidate matches only.
- Keep test, test_observation, study_summary and empty_source_row counts separate.
- Null means missing, not zero or false. Preserve ranges, sets, units and source flags.
- Document conclusions are summaries of selected cited pages, not independent scientific validation.
- Inherited scores, traffic lights and lunar-envelope/proxy flags are not validated safety or lunar-gravity measurements.
- Do not infer a cool flame from ignition_success.
- The two requested inputs contain no separate visual-backup archive. OCR image links are unavailable locally; original PDFs remain linked.
- Unreadable source documents remain cataloged. No missing text or result has been invented.

## Project index

| Project | Name | Curated rows | Older nonempty rows | Direct PDFs | Conclusion basis |
|---|---|---:|---:|---:|---|
| PSI-10 | ACME Flame Design | 327 | 0 | 76 | document_report |
| PSI-20 | ACME BRE | 18 | 0 | 59 | document_report |
| PSI-21 | ACME CLD Flame | 32 | 0 | 0 | dataset_assessment |
| PSI-22 | ACME E-FIELD Flames | 24 | 8 | 57 | document_report |
| PSI-23 | ACME s-Flame | 18 | 0 | 37 | document_report |
| PSI-25 | BASS-II | 129 | 0 | 0 | dataset_assessment |
| PSI-26 | BASS | 122 | 0 | 30 | document_report |
| PSI-39 | CFI | 79 | 8 | 48 | document_report |
| PSI-47 | DAFT | 0 | 2 | 7 | document_report |
| PSI-68 | FLEX-2 | 8 | 0 | 0 | dataset_assessment |
| PSI-69 | FLEX | 274 | 0 | 0 | dataset_assessment |
| PSI-101 | SAME-R | 109 | 0 | 0 | dataset_assessment |
| PSI-102 | SAME | 8 | 0 | 0 | related_document_context |
| PSI-106 | SLICE | 12 | 0 | 0 | dataset_assessment |
| PSI-107 | SPICE | 435 | 34 | 0 | dataset_assessment |
| PSI-108 | STDCE-1 | 0 | 38 | 0 | dataset_assessment |
| PSI-115 | SAME modeling | 0 | 0 | 2 | document_report |
| PSI-142 | Counterflow FLEX | 8 | 0 | 0 | dataset_assessment |
| PSI-159 | ACME CFI-G | 333 | 0 | 92 | document_report |

## PSI-10 — ACME Flame Design

Spherical diffusion flames, radiation and soot.

**Conclusion (document_report):** The final report describes radiative extinction as flame growth increases radiation losses. It also reports steady-state behavior under a restricted set of ethylene flame conditions. These findings apply to the reported configurations, not to every fuel or atmosphere.

**Limits:** Use the normal/inverse flame distinction and the actual reactant composition when comparing cases. Study-wide oxygen bounds are not the conditions of every test.

**Row coverage:** {"test":327}. Older nonempty rows: 0. Older empty rows: 0.

**Evidence:** [pdf_1d64b7f42f0795796716, p. 25](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-10/Reports/PSI-10_Reports_FinalRpt_ACMEFlameDesign.pdf#page=25), [pdf_1d64b7f42f0795796716, p. 26](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-10/Reports/PSI-10_Reports_FinalRpt_ACMEFlameDesign.pdf#page=26)

## PSI-20 — ACME BRE

Gas burners used to emulate condensed-fuel burning.

**Conclusion (document_report):** The report describes sustained quasi-steady burning without imposed airflow at elevated oxygen concentrations. It therefore limits any assumption that stopping ventilation alone extinguishes every microgravity fire. The burner emulates condensed fuels; these are not direct certification tests on every named material.

**Limits:** The 18 curated rows are study summaries. Preserve oxygen sets and the recorded percentage-scale corrections rather than treating each summary as a single measured condition.

**Row coverage:** {"study_summary":18}. Older nonempty rows: 0. Older empty rows: 0.

**Evidence:** [pdf_c2f22c914b38d9e67427, p. 39](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-20/Reports/PSI-20_Reports_Final_20220201.pdf#page=39), [pdf_c2f22c914b38d9e67427, p. 40](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-20/Reports/PSI-20_Reports_Final_20220201.pdf#page=40)

## PSI-21 — ACME CLD Flame

Coflow, dilution and laminar diffusion flames.

**Conclusion (dataset_assessment):** The curated source provides 32 study summaries, including 24 rows flagged for unrecognized chemical formulas. The supplied direct project links contain no PDF text supporting a project-wide result. Resolve those fuel labels against the original records before comparing fuel effects.

**Limits:** Do not interpret the malformed chemical formulas as verified fuel species or treat the 32 summary rows as 32 independent tests.

**Row coverage:** {"study_summary":32}. Older nonempty rows: 0. Older empty rows: 0.

**Evidence:** records filtered by investigation_id = PSI-21; see record_evidence in project_summaries. No scientific result is inferred from project metadata alone.

## PSI-22 — ACME E-FIELD Flames

Electric-field effects on flames and ion current.

**Conclusion (document_report):** The final report describes microgravity voltage-current curves with a peak followed by a decrease toward saturation, and differences from comparable 1-g cases. This supports studying electric-field effects on transport. It does not establish a calibrated 0.16-g equivalence.

**Limits:** The source labels electric forcing as a partial-gravity proxy. Keep that label separate from an actual lunar-gravity measurement or a validated gravity interpolation.

**Row coverage:** {"study_summary":24}. Older nonempty rows: 8. Older empty rows: 0.

**Evidence:** [pdf_9be4013278966e85d99d, p. 25](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-22/Reports/PSI-22_Reports_E-FIELD%20Flames%20Final%20Report.pdf#page=25), [pdf_9be4013278966e85d99d, p. 26](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-22/Reports/PSI-22_Reports_E-FIELD%20Flames%20Final%20Report.pdf#page=26)

## PSI-23 — ACME s-Flame

Spherical-flame structure and extinction.

**Conclusion (document_report):** The final report describes radiative extinction and candidate kinetic-extinction behavior. For some low-flow cases it explicitly leaves open whether extinction comes from chemical kinetics or heat loss to the burner. Preserve that unresolved mechanism in any model comparison.

**Limits:** The curated rows are study summaries. Do not relabel uncertain extinction mechanisms as settled outcomes.

**Row coverage:** {"study_summary":18}. Older nonempty rows: 0. Older empty rows: 0.

**Evidence:** [pdf_2056f8f85291f49c1446, p. 29](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-23/Reports/PSI-23_Reports_s_Flame_final_report_20210729.pdf#page=29)

## PSI-25 — BASS-II

Solid samples and flame spread under ventilation.

**Conclusion (dataset_assessment):** The curated source contains 129 test rows with a wide variety of solid sample descriptions. It supports organizing comparisons by material, thickness, geometry and airflow, but supplies no direct project PDF text or populated ignition-success field from which to infer a general safety ranking.

**Limits:** Keep specimen dimensions and material descriptions. No retrieved PDF conclusion is asserted for this project.

**Row coverage:** {"test":129}. Older nonempty rows: 0. Older empty rows: 0.

**Evidence:** records filtered by investigation_id = PSI-25; see record_evidence in project_summaries. No scientific result is inferred from project metadata alone.

## PSI-26 — BASS

Burning solid materials in microgravity.

**Conclusion (document_report):** The supplied results overview distinguishes opposed and concurrent flow. In the thin-fuel cases described, opposed-flow spread is fastest at an intermediate speed, while concurrent-flow spread increases with flow. Flow direction therefore matters when comparing spread behavior.

**Limits:** This conclusion concerns the thin-fuel cases on the cited page. The dataset also contains other geometries, observations and a summary row, which must remain separate.

**Row coverage:** {"test":117,"test_observation":4,"study_summary":1}. Older nonempty rows: 0. Older empty rows: 0.

**Evidence:** [pdf_6e654a3468577dd9dce8, p. 26](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-26/Presentations/PSI-26_Presentations_BASS_Overview%20of%20Recent%20ISS%20Results.pdf#page=26)

## PSI-39 — CFI

Droplet cool flames and low-temperature chemistry.

**Conclusion (document_report):** The science report describes measurements of droplet regression, flame diameters, extinction and radiation for several fuels and mixtures, with pressure and helium dilution varied. It presents the data as useful for evaluating chemical mechanisms and notes that analysis was incomplete. The curated subset lists n-dodecane only, so it does not represent the report’s entire fuel coverage.

**Limits:** Eight older test rows are retained as archive-only. The report also contains inconsistent fuel spelling in its discussion; the source text is preserved without silently repairing it.

**Row coverage:** {"test":79}. Older nonempty rows: 8. Older empty rows: 0.

**Evidence:** [pdf_e1515868918031458391, p. 7](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-39/Reports/PSI-39_Reports_CFI%20Science%20Final%20Report.pdf#page=7), [pdf_e1515868918031458391, p. 11](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-39/Reports/PSI-39_Reports_CFI%20Science%20Final%20Report.pdf#page=11)

## PSI-47 — DAFT

Aerosol-instrument feasibility in microgravity.

**Conclusion (document_report):** The report says the instruments operated for an extended period without apparent failure, while limited electronic data, sample composition and possible buildup restricted detailed interpretation. DAFT provides instrument-feasibility context rather than a material combustion result.

**Limits:** Present only in the older record set and document archive. Its two rows remain outside the curated combustion view.

**Row coverage:** {}. Older nonempty rows: 2. Older empty rows: 0.

**Evidence:** [pdf_6e6008f2d7f0216432f7, p. 13](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-47/Reports/PSI-47_Reports_DAFT_30Day.PostFlightReport.pdf#page=13)

## PSI-68 — FLEX-2

Droplet combustion across fuels and atmospheric conditions.

**Conclusion (dataset_assessment):** The supplied eight rows describe study conditions using ranges and sets. They can guide the selection of relevant fuel and atmosphere cases, but cannot establish a single droplet size, flow speed, pressure or extinction outcome for each row.

**Limits:** No direct project PDF text is available in the supplied archive. Do not combine independent minima and maxima into a supposedly tested condition.

**Row coverage:** {"study_summary":8}. Older nonempty rows: 0. Older empty rows: 0.

**Evidence:** records filtered by investigation_id = PSI-68; see record_evidence in project_summaries. No scientific result is inferred from project metadata alone.

## PSI-69 — FLEX

Droplet combustion and suppression-related conditions.

**Conclusion (dataset_assessment):** The curated source contains 274 test rows for heptane and methanol. It provides structured cases for investigation, but the ignition-success field is empty and no direct project PDFs are linked. A general suppression threshold cannot be concluded from the populated fields alone.

**Limits:** One row records a nonpositive-pressure correction using study metadata. Preserve the correction provenance and distinguish it from a direct row measurement.

**Row coverage:** {"test":274}. Older nonempty rows: 0. Older empty rows: 0.

**Evidence:** records filtered by investigation_id = PSI-69; see record_evidence in project_summaries. No scientific result is inferred from project metadata alone.

## PSI-101 — SAME-R

Smoke and aerosol measurements for solid materials.

**Conclusion (dataset_assessment):** The curated source contains 107 test rows and two observation rows spanning materials including Kapton, Lampwick, Pyrell, Silicone and Teflon. These records organize the smoke study but do not provide linked PDF evidence for detector performance or a universal material risk ranking.

**Limits:** Keep observations separate from test counts. No direct project PDF text is available in the supplied archive.

**Row coverage:** {"test":107,"test_observation":2}. Older nonempty rows: 0. Older empty rows: 0.

**Evidence:** records filtered by investigation_id = PSI-101; see record_evidence in project_summaries. No scientific result is inferred from project metadata alone.

## PSI-102 — SAME

Smoke-aerosol study context.

**Conclusion (related_document_context):** Eight curated study summaries link indirectly to PSI-115 modeling documents. Those simulations explain possible effects of gravity, recirculation and particle settling on smoke size. Their results are contextual model findings, not measurements of the eight SAME rows.

**Limits:** The original CSV marks PSI-115 missing from its record set. The merged source contains PSI-115 documents but still no PSI-115 experimental rows; both facts are exposed.

**Row coverage:** {"study_summary":8}. Older nonempty rows: 0. Older empty rows: 0.

**Evidence:** [pdf_487108f951ba8ec90424, p. 3](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-115/Reports/PSI-115_Reports_NNX17AF08A_FinalReport.pdf#page=3), [pdf_487108f951ba8ec90424, p. 15](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-115/Reports/PSI-115_Reports_NNX17AF08A_FinalReport.pdf#page=15)

## PSI-106 — SLICE

Flame structure and liftoff under coflow.

**Conclusion (dataset_assessment):** The curated source provides 12 study summaries for ethane, ethylene and methane. These establish the available project scope, but there is no direct project PDF text in the supplied archive to substantiate a numerical liftoff or stability threshold.

**Limits:** Treat the rows as summaries, not independent test outcomes. Shared hardware documents under other projects are not automatically assigned as SLICE result evidence.

**Row coverage:** {"study_summary":12}. Older nonempty rows: 0. Older empty rows: 0.

**Evidence:** records filtered by investigation_id = PSI-106; see record_evidence in project_summaries. No scientific result is inferred from project metadata alone.

## PSI-107 — SPICE

Soot and smoke-point studies under coflow.

**Conclusion (dataset_assessment):** The curated source contains 37 test rows and 398 observation rows. It also flags 66 invalid ignition times and seven ambiguous midnight durations. Timing-based comparisons require those issues to be resolved; the row count must not be reported as the number of independent experiments.

**Limits:** Keep the 34 older-only rows separately visible. No direct project PDF text is available in the supplied archive.

**Row coverage:** {"test":37,"test_observation":398}. Older nonempty rows: 34. Older empty rows: 0.

**Evidence:** records filtered by investigation_id = PSI-107; see record_evidence in project_summaries. No scientific result is inferred from project metadata alone.

## PSI-108 — STDCE-1

Fluid-physics context retained from the older source.

**Conclusion (dataset_assessment):** The older source includes one test row and 37 observation rows labeled as fluid physics and excluded from the combustion core. These records are retained for completeness, with no promoted combustion conclusion and no direct project PDF evidence.

**Limits:** Absent from the curated CSV. Archive-only records must be explicitly requested when performing combustion analyses.

**Row coverage:** {}. Older nonempty rows: 38. Older empty rows: 0.

**Evidence:** records filtered by investigation_id = PSI-108; see record_evidence in project_summaries. No scientific result is inferred from project metadata alone.

## PSI-115 — SAME modeling

Simulation of smoke generation and particle growth.

**Conclusion (document_report):** The report’s simulations produce larger smoke particles in microgravity than in the compared terrestrial cases. It attributes the differences to recirculation, settling and surface interactions, and emphasizes dependence on material and geometry. This is a modeling result for the studied configurations.

**Limits:** Document-only project in this package. It provides explicitly configured context for PSI-102, not additional SAME measurements.

**Row coverage:** {}. Older nonempty rows: 0. Older empty rows: 0.

**Evidence:** [pdf_487108f951ba8ec90424, p. 3](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-115/Reports/PSI-115_Reports_NNX17AF08A_FinalReport.pdf#page=3), [pdf_487108f951ba8ec90424, p. 15](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-115/Reports/PSI-115_Reports_NNX17AF08A_FinalReport.pdf#page=15)

## PSI-142 — Counterflow FLEX

Ground counterflow reference.

**Conclusion (dataset_assessment):** The eight curated study summaries are labeled as ground-context data and linked to PSI-69. They can organize ground/flight comparisons, but the source explicitly lacks matched observations and a gravity model. No lunar-gravity prediction can be derived from those links alone.

**Limits:** Keep ground context separate from microgravity data. No direct project PDF text is available in the supplied archive.

**Row coverage:** {"study_summary":8}. Older nonempty rows: 0. Older empty rows: 0.

**Evidence:** records filtered by investigation_id = PSI-142; see record_evidence in project_summaries. No scientific result is inferred from project metadata alone.

## PSI-159 — ACME CFI-G

Gas-fueled cool diffusion flames.

**Conclusion (document_report):** The final report describes spherical gas-fueled cool diffusion flames obtained under a restricted normal n-butane condition. This demonstrates their existence in that configuration, not across all tested fuels and pressures. The curated CSV separately records 263 ignition successes, 62 failures and eight missing outcomes; these are ignition outcomes, not cool-flame counts.

**Limits:** All 861 older empty source rows are retained outside the curated view. Ignition success must never be used as a proxy for cool-flame occurrence.

**Row coverage:** {"test":333}. Older nonempty rows: 0. Older empty rows: 861.

**Evidence:** [pdf_f6cce7cc08ca69c15599, p. 23](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/ea880ab0b86eeede5a942209dc7b3e8f75ebbd7b/data/raw/PSI-159/Reports/PSI-159_Reports_FinalRpt_ACME.CFI-G.pdf#page=23)

## Master database map

| Table or view | Purpose |
|---|---|
| curated_records | Preferred 1,936 records. record_json contains typed source fields; raw_curated_json preserves exact strings. |
| supplementary_records | 90 older nonempty records absent from the curated file. |
| excluded_empty_rows | 861 explicitly empty older rows, retained outside analyses. |
| source_differences | Both values and the preference decision for each changed field. |
| project_summaries / project_evidence | Conclusions, limitations, row coverage and page citations. |
| master_record_documents | Typed contextual document relationships. |
| documents / sources / pages / chunks / search | Preserved original corpus, page citations and full-text search. |
| test_mentions | Original candidate test-ID matches; not independently validated joins. |
| experiments / tests / record_documents | Original archive tables. These are older data, not the preferred curated view. |
| document_markdown | Original per-document Markdown, preserved. |
| master_sources | Both original input files embedded as exact bytes with hashes. |
| field_dictionary / master_meta / master_guides | Schema, merge contract and reading guide. |

## Machine use

Run `python query_master.py --project PSI-159 --query "cool flames" --limit 5` from this folder. Use `--test-id` for a test search, `--include-archive` to include nonempty supplementary records, or `--record-id` for an exact record and its differences. `--export-jsonl path.jsonl` writes a complete typed export: contract, dictionary, projects, records, differences, document links, candidate mentions, documents, pages and retrieval chunks. Empty rows are retained in full exports with their exclusion tier.

LLMs should retrieve a few relevant pages and records with their citations rather than treat the entire corpus as one prompt. The offline reader exports the selected project’s records and context as JSON. Its browser text search returns pages; database search returns smaller retrieval chunks.

## Reproducibility

Both inputs were verified against GitHub blob IDs before merging. The original source files and remote repository were not modified. The standalone CSV is preferred as requested working data, not assumed scientifically newer or more accurate in every field. Source differences are not automatically errors.

- [CSV DE LOS DATOS PERFECTAMENTE ORDENADOS.csv](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/main/data/Done%20DATA%20f_project/CSV%20DE%20LOS%20DATOS%20PERFECTAMENTE%20ORDENADOS.csv); Git blob `ac86de556c024d110280a241fa21dca1c2a22298`; SHA-256 `f938ff752d1ca91a9ad458dd807b9d0f40e481933a359acd5ca6db4ebc3efcaa`.
- [PDF_CSV_LLM_texto.zip](https://github.com/Pablixio17/SPACE-APPS-DROP-TABLE-USERS/blob/main/data/Done%20DATA%20f_project/PDF_CSV_LLM_texto.zip); Git blob `abdc3e40669c764300ed40c8801e01beb24b7f64`; SHA-256 `7da4ca089466a854653535d782b6c0ea2eb4bbf6cdaa846732cf268e5e765506`.

The original archive refers to a separate visual-backup ZIP which is not among the two inputs. Original PDF links are retained, while unavailable local image links are not presented as working attachments. Original archive validation claims are preserved as historical source metadata; the new validation report checks this merged package.
